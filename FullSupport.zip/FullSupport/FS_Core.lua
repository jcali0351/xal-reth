-- Full Support :: answers Drama Queen posts in guild chat with a supportive sentence.
-- * Knows a post is from Drama Queen by its hidden "POST" signal (Drama Queen Pro 3.1+),
--   or, if Drama Queen is installed here too, by matching its lines exactly.
-- * Replies 4-12 seconds later, picking support that fits the topic, with the poster's name.
-- * Never answers your own posts. At most once a minute per poster. Pauses in combat.

local ADDON = ...
local DQ_PREFIX = "DramaQueen"
local D = FS_DATA
local DB
local BLUE = "|cff7dd3ff"
local function msg(t) DEFAULT_CHAT_FRAME:AddMessage(BLUE .. "[Full Support]|r " .. t) end
local function me() return (UnitName("player")) end
local function short(n) return type(n) == "string" and (n:gsub("%-.*", "")) or nil end
local function secret(v) return issecretvalue and issecretvalue(v) end

local function SendChat(text, channel)
  local fn = (C_ChatInfo and C_ChatInfo.SendChatMessage) or SendChatMessage
  if not fn then return false, "no chat API" end
  return pcall(fn, text, channel)
end

-- lines from Drama Queen, if it is installed on this computer
local known
local function buildKnown()
  if known or not DQ_DATA then return end
  known = {}
  for _, l in ipairs(DQ_DATA.lines or {}) do known[l] = true end
  for _, s in ipairs(DQ_DATA.sagas or {}) do for _, l in ipairs(s) do known[l] = true end end
end

local signaled = {}          -- poster -> time of their last Drama Queen POST signal
local lastReply = {}         -- poster -> time we last supported them
local lastAny, lastErr = 0, 0
local recent = {}            -- poster -> { text, t } of their last guild line (in case the signal arrives second)

local function pickReply(text, who)
  local lower = text:lower()
  for _, t in ipairs(D.topics) do
    for _, k in ipairs(t.keys) do
      if lower:find(k, 1, true) then return (t.replies[math.random(#t.replies)]:gsub("%%s", who)) end
    end
  end
  return (D.generic[math.random(#D.generic)]:gsub("%%s", who))
end

local function support(text, who)
  if not DB.enabled then return end
  local now = GetTime()
  if lastReply[who] and now - lastReply[who] < 60 then return end
  if now - lastAny < 8 then return end
  lastReply[who], lastAny = now, now
  local reply = pickReply(text, who)
  C_Timer.After(4 + math.random() * 8, function()
    if not DB.enabled or InCombatLockdown() or not IsInGuild() then return end
    if C_ChatInfo.InChatMessagingLockdown and C_ChatInfo.InChatMessagingLockdown() then return end
    local ok, err = SendChat(reply, "GUILD")
    if ok then DB.sent = DB.sent + 1; DB.last = reply
    elseif GetTime() - lastErr > 60 then lastErr = GetTime(); msg("|cffff5555could not post:|r " .. tostring(err)) end
  end)
end

local function isDrama(text, who)
  if signaled[who] and GetTime() - signaled[who] < 6 then return true end
  buildKnown()
  return known and known[text] or false
end

local ev = CreateFrame("Frame")
for _, e in ipairs({ "ADDON_LOADED", "PLAYER_LOGIN", "CHAT_MSG_GUILD", "CHAT_MSG_ADDON" }) do ev:RegisterEvent(e) end
ev:SetScript("OnEvent", function(_, event, a1, a2, a3, a4)
  if event == "ADDON_LOADED" then
    if a1 == ADDON then
      FullSupportDB = FullSupportDB or {}; DB = FullSupportDB
      for k, v in pairs({ enabled = true, sent = 0 }) do if DB[k] == nil then DB[k] = v end end
      C_ChatInfo.RegisterAddonMessagePrefix(DQ_PREFIX)
    end
  elseif event == "PLAYER_LOGIN" then
    msg("Full Support 1.0 loaded. Standing by for drama. /fs to see options.")
  elseif event == "CHAT_MSG_ADDON" and DB then
    if a1 ~= DQ_PREFIX or a3 ~= "GUILD" or secret(a2) or secret(a4) then return end
    if a2 == "POST" then
      local who = short(a4); if not who or who == me() then return end
      local r = recent[who]
      if r and GetTime() - r.t < 3 then recent[who] = nil; support(r.text, who)   -- line arrived first
      else signaled[who] = GetTime() end
    end
  elseif event == "CHAT_MSG_GUILD" and DB then
    if secret(a1) or secret(a2) then return end
    local who = short(a2); if not who or who == me() then return end
    if isDrama(a1, who) then signaled[who] = nil; recent[who] = nil; support(a1, who)
    else recent[who] = { text = a1, t = GetTime() } end
  end
end)

SLASH_FULLSUPPORT1 = "/fs"
SLASH_FULLSUPPORT2 = "/fullsupport"
SlashCmdList.FULLSUPPORT = function(arg)
  arg = (arg or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")
  if arg == "on" then DB.enabled = true; msg("Full Support on. Your guildmates will never suffer alone.")
  elseif arg == "off" then DB.enabled = false; msg("Full Support off.")
  elseif arg == "test" then msg("Example: " .. pickReply("I think I'm pregnant.", "Vexa"))
  else
    msg(("Full Support is %s  ·  supportive replies sent: %d"):format(DB.enabled and "|cff7dff7don|r" or "|cffff5555off|r", DB.sent))
    if DB.last then msg("Last: " .. DB.last) end
    msg("/fs on  ·  /fs off  ·  /fs test")
  end
end
