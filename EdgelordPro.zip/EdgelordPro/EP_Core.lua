-- Edgelord Pro :: edgy PC-gamer emotes for the Cult of Xal'Reth (loosely based on Brain Rotter Pro)
-- Picks a rival from your target, group or online guildies and broods at them line by line.
-- Auto-edge posts emotes, party, raid and guild chat on a timer (default: Emote, every 20 seconds).
-- Escalation (off by default): each auto line comes one second sooner, down to the channel's minimum.
-- /say needs a key or button press outside instances (Blizzard rule): the SAY button says the next line,
-- and when auto-edge runs on Say the line waits on that glowing button. Inside dungeons and raids /say is automatic.

local ADDON = ...
local MEDIA = "Interface\\AddOns\\" .. ADDON .. "\\media\\"
local D = EP_DATA
local DB
local GOLD = { 0.89, 0.72, 0.32 }
local PALE = { 0.95, 0.91, 0.76 }
local PINK = { 0.95, 0.12, 0.18 }   -- Rage Red
local CYAN = { 0.55, 0.85, 1.0 }   -- monitor glow

local CHANNELS = { "EMOTE", "SAY", "PARTY", "RAID", "GUILD", "LOCAL" }
local AUTO_OK = { EMOTE = 3, SAY = 3, PARTY = 2, RAID = 2, GUILD = 10, LOCAL = 1 }   -- channel -> minimum seconds between lines
local ICON_SLOT = { monitor = 1, gauge = 2, bolt = 3, keyboard = 4, hood = 5, mask = 6, can = 7, bars = 8, controller = 9, crown = 10 }
local DANCES = { "KNEEL", "ROAR", "FLEX", "SALUTE", "GLARE", "BOW", "CHEER" }   -- dramatic poses

local function msg(t) DEFAULT_CHAT_FRAME:AddMessage("|cffff2030[Edgelord Pro]|r " .. t) end
local function pick(t) return t[math.random(#t)] end
local function shortName(n) return n and (n:gsub("%-.*", "")) end

-- Midnight (12.0+): the old global SendChatMessage only exists with the deprecation-fallback CVar,
-- so always prefer C_ChatInfo.SendChatMessage, and report failures instead of hiding them.
local function SendChat(text, channel)
  local fn = (C_ChatInfo and C_ChatInfo.SendChatMessage) or SendChatMessage
  if not fn then return false, "no chat API" end
  return pcall(fn, text, channel)
end
local lastSendErr = 0
local function reportSendError(err, tag)
  if GetTime() - lastSendErr > 60 then
    lastSendErr = GetTime()
    DEFAULT_CHAT_FRAME:AddMessage("|cffff5555[" .. tag .. "] could not post to chat:|r " .. tostring(err))
  end
end
local function nextIn(list, cur)
  for i, v in ipairs(list) do if v == cur then return list[(i % #list) + 1] end end
  return list[1]
end

local function defaults()
  EdgelordProDB = EdgelordProDB or {}
  DB = EdgelordProDB
  local d = { cat = 1, pos = {}, channel = "EMOTE", speed = 20, escalate = false, chaos = false, useTarget = true, useGroup = true,
              useGuild = true, lockTarget = false, anims = true, chime = true, danceEvery = 7, spewed = 0 }
  for k, v in pairs(d) do if DB[k] == nil then DB[k] = v end end
end

---------------------------------------------------------------- victim selection
local function onlineGuildies()
  local out, me = {}, UnitName("player")
  if not IsInGuild() then return out end
  for i = 1, (GetNumGuildMembers()) do
    local name, _, _, _, _, _, _, _, online = GetGuildRosterInfo(i)
    name = shortName(name)
    if name and online and name ~= me then out[#out + 1] = name end
  end
  return out
end

local function groupMembers()
  local out = {}
  local n = GetNumGroupMembers()
  local prefix = IsInRaid() and "raid" or "party"
  local me = UnitName("player")
  for i = 1, n do
    local name = UnitName(prefix .. i)
    if name and name ~= me and name ~= UNKNOWNOBJECT then out[#out + 1] = name end
  end
  return out
end

local function targetName()
  if UnitExists("target") and UnitIsPlayer("target") and not UnitIsUnit("target", "player") then return (UnitName("target")) end
end

local victim = "chat"
local function chooseVictim()
  local t = targetName()
  if DB.lockTarget and t then victim = t; return victim end
  local pool = {}
  if DB.useTarget and t then pool[#pool + 1] = t; pool[#pool + 1] = t end -- target gets double odds
  if DB.useGroup then for _, n in ipairs(groupMembers()) do pool[#pool + 1] = n end end
  if DB.useGuild then for _, n in ipairs(onlineGuildies()) do pool[#pool + 1] = n end end
  victim = (#pool > 0) and pick(pool) or "chat"
  return victim
end

---------------------------------------------------------------- core spew
local function catData() return D.cats[DB.cat] end
local function pos() return DB.pos[DB.cat] or 1 end

local Refresh, flash
Refresh = function() end

local function send(text, channel)
  if #text > 255 then text = text:sub(1, 252) .. "..." end
  if channel == "PARTY" and not IsInGroup() then channel = "LOCAL" end
  if channel == "RAID" and not IsInRaid() then channel = IsInGroup() and "PARTY" or "LOCAL" end
  if channel == "GUILD" and not IsInGuild() then channel = "LOCAL" end
  if channel == "LOCAL" then msg(text) else
    local ok, err = SendChat(text, channel)
    if not ok then reportSendError(err, "Edgelord Pro") end
  end
end

local pendingSay
local function nextLine()
  if DB.chaos then DB.cat = math.random(#D.cats) end
  local cat = catData()
  local p = pos()
  local line = cat.lines[p]
  local act = D.actions[line[1]]
  local who = chooseVictim()
  local text = line[2]:gsub("%%t", function() return who end)
  DB.pos[DB.cat] = (p % #cat.lines) + 1
  return text, act
end

local function rotFx(act)
  DB.spewed = DB.spewed + 1
  if DB.anims and act then
    if DB.danceEvery > 0 and DB.spewed % DB.danceEvery == 0 then DoEmote(pick(DANCES)) else DoEmote(act[1]) end
  end
  if DB.chime then PlaySoundFile(MEDIA .. "sound" .. math.random(1, 8) .. ".ogg", "Master") end
  if flash then flash() end
  if Refresh then Refresh() end
end

-- SAY: speak the waiting line (or the next one) in /say. Needs a click or key press outside instances.
function EP_Say()
  local text, act = pendingSay, nil
  if not text then text, act = nextLine() end
  if #text > 255 then text = text:sub(1, 252) .. "..." end
  local ok, err = SendChat(text, "SAY")
  if not ok then reportSendError(err, "Edgelord Pro"); return end
  pendingSay = nil
  rotFx(act)
end

function EP_Spew(fromAuto)
  local text, act = nextLine()
  if DB.channel == "SAY" then
    if IsInInstance() or not fromAuto then
      if #text > 255 then text = text:sub(1, 252) .. "..." end
      local ok, err = SendChat(text, "SAY")
      if not ok then
        if fromAuto then pendingSay = text else reportSendError(err, "Edgelord Pro") end
      end
    else
      pendingSay = text                               -- open world: waits for the SAY button
    end
  elseif DB.channel == "EMOTE" then send(act[2] .. ": " .. text, "EMOTE")
  else send(text, DB.channel) end
  DB.spewed = DB.spewed + 1
  if DB.anims then
    if DB.danceEvery > 0 and DB.spewed % DB.danceEvery == 0 then DoEmote(pick(DANCES)) else DoEmote(act[1]) end
  end
  if DB.chime then PlaySoundFile(MEDIA .. "sound" .. math.random(1, 8) .. ".ogg", "Master") end
  if flash then flash() end
  if Refresh then Refresh() end
end

---------------------------------------------------------------- auto-play
local auto, acc, esc = false, 0, 0
local function effectiveSpeed() return math.max(DB.speed - (DB.escalate and esc or 0), AUTO_OK[DB.channel] or 999) end

function EP_ToggleAuto()
  if auto then auto = false; msg("Auto-edge stopped. The shadows rest."); if Refresh then Refresh() end; return end
  if not AUTO_OK[DB.channel] then DB.channel = "EMOTE" end
  esc = 0
  auto, acc = true, effectiveSpeed()
  msg(("Auto-edge ON: a line every %ds in %s.%s"):format(effectiveSpeed(), DB.channel, DB.escalate and " Escalation ON: it gets faster." or ""))
  if DB.channel == "SAY" and not IsInInstance() then msg("Out in the world each line waits on the glowing SAY button: one click per line (Blizzard rule).") end
  if DB.channel == "LOCAL" then msg("Channel is Local: only you can see these. Click Channel to switch to Emote, Guild or Party.") end
  if Refresh then Refresh() end
end

local f, slider
local uiError

local ticker = CreateFrame("Frame")
ticker:SetScript("OnUpdate", function(_, el)
  if not auto or not DB then return end
  if not AUTO_OK[DB.channel] then auto = false; Refresh(); return end
  if InCombatLockdown() or (C_ChatInfo.InChatMessagingLockdown and C_ChatInfo.InChatMessagingLockdown()) then return end
  acc = acc + el
  if acc >= effectiveSpeed() then acc = 0; esc = esc + 1; EP_Spew(true) end
end)

---------------------------------------------------------------- UI
local function BuildUI()
local RED, CY, WHITE, DIM = { 0.95, 0.12, 0.18 }, { 0.55, 0.85, 1.0 }, { 1, 1, 1 }, { 0.62, 0.6, 0.66 }
f = CreateFrame("Frame", "EdgelordProFrame", UIParent, "BackdropTemplate")
f:SetSize(820, 540); f:SetPoint("CENTER"); f:SetFrameStrata("HIGH")
f:SetMovable(true); f:EnableMouse(true); f:SetClampedToScreen(true); f:RegisterForDrag("LeftButton")
f:SetScript("OnDragStart", f.StartMoving); f:SetScript("OnDragStop", f.StopMovingOrSizing)
f:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 2 })
f:SetBackdropColor(0.025, 0.02, 0.03, 0.97); f:SetBackdropBorderColor(RED[1], RED[2], RED[3], 1)
f:Hide(); tinsert(UISpecialFrames, "EdgelordProFrame")
local bgTex = f:CreateTexture(nil, "BACKGROUND", nil, 1); bgTex:SetPoint("TOPLEFT", 2, -2); bgTex:SetPoint("BOTTOMRIGHT", -2, 2)
bgTex:SetTexture(MEDIA .. "bg"); bgTex:SetAlpha(0.35)
-- scanlines
for y = 0, 530, 6 do local l = f:CreateTexture(nil, "BACKGROUND", nil, 2); l:SetColorTexture(0, 0, 0, 0.18); l:SetHeight(2)
  l:SetPoint("TOPLEFT", 2, -y - 2); l:SetPoint("TOPRIGHT", -2, -y - 2) end
-- RGB light strip along the top and bottom edges
local strips = {}
for i = 1, 40 do
  local t = f:CreateTexture(nil, "BORDER"); t:SetSize(20, 3); t:SetPoint("TOPLEFT", 2 + (i - 1) * 20.4, -2); strips[#strips + 1] = t
  local b = f:CreateTexture(nil, "BORDER"); b:SetSize(20, 3); b:SetPoint("BOTTOMLEFT", 2 + (i - 1) * 20.4, 2); strips[#strips + 1] = b
end
local close = CreateFrame("Button", nil, f, "UIPanelCloseButton"); close:SetPoint("TOPRIGHT", -4, -6)

local function font(parent, size, color, face, flags)
  local fs = parent:CreateFontString(nil, "OVERLAY")
  fs:SetFont(face or "Fonts\\ARIALN.TTF", size, flags or "")
  fs:SetTextColor(unpack(color or WHITE)); fs:SetShadowOffset(1, -1); return fs
end
-- flat gamer buttons: black glass, red edge, cyan on hover
local function button(parent, w, h, label, onClick, size)
  local b = CreateFrame("Button", nil, parent, "BackdropTemplate"); b:SetSize(w, h)
  b:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 })
  b:SetBackdropColor(0.09, 0.02, 0.03, 0.95); b:SetBackdropBorderColor(RED[1], RED[2], RED[3], 0.9)
  local fs = font(b, size or 13, WHITE, "Fonts\\FRIZQT__.TTF", "OUTLINE"); fs:SetPoint("CENTER"); b:SetFontString(fs)
  b:SetText(label); b:SetScript("OnClick", onClick)
  b:SetScript("OnEnter", function(s) s:SetBackdropBorderColor(CY[1], CY[2], CY[3], 1); s:SetBackdropColor(0.15, 0.03, 0.05, 1) end)
  b:SetScript("OnLeave", function(s) s:SetBackdropBorderColor(RED[1], RED[2], RED[3], 0.9); s:SetBackdropColor(0.09, 0.02, 0.03, 0.95); GameTooltip:Hide() end)
  return b
end
local function setIcon(tex, name)
  local slot = ICON_SLOT[name] or 1
  local c, r = (slot - 1) % 8, math.floor((slot - 1) / 8)
  tex:SetTexture(MEDIA .. "icons"); tex:SetTexCoord(c / 8, (c + 1) / 8, r / 8, (r + 1) / 8)
end

-- header: portrait with a red halo, glitching title, edge meter
local portrait = CreateFrame("Frame", nil, f); portrait:SetSize(96, 96); portrait:SetPoint("TOPLEFT", 16, -14)
local halo = portrait:CreateTexture(nil, "BACKGROUND"); halo:SetPoint("TOPLEFT", -6, 6); halo:SetPoint("BOTTOMRIGHT", 6, -6)
halo:SetColorTexture(RED[1], RED[2], RED[3], 0.35)
local ptex = portrait:CreateTexture(nil, "ARTWORK"); ptex:SetAllPoints(); ptex:SetTexture(MEDIA .. "edgelord_sheet")
local pi, pacc = 0, 0
local function setFrame(i) local c, r = i % 4, math.floor(i / 4); ptex:SetTexCoord(c / 4, (c + 1) / 4, r / 4, (r + 1) / 4) end
setFrame(0)
portrait:SetScript("OnUpdate", function(_, el) pacc = pacc + el; if pacc > (auto and 0.06 or 0.12) then pacc = 0; pi = (pi + 1) % 16; setFrame(pi) end end)

local titleC = font(f, 34, CY, "Fonts\\MORPHEUS.TTF", "OUTLINE"); titleC:SetPoint("TOPLEFT", 128, -16); titleC:SetText("EDGELORD PRO"); titleC:SetAlpha(0.6)
local titleR = font(f, 34, RED, "Fonts\\MORPHEUS.TTF", "OUTLINE"); titleR:SetPoint("TOPLEFT", 130, -14); titleR:SetText("EDGELORD PRO")
local sub = font(f, 12, DIM); sub:SetPoint("TOPLEFT", 132, -56)
sub:SetText("1,574 lines of PC-mastery edge  ·  nobody understands you")
local rivalText = font(f, 15, WHITE, "Fonts\\FRIZQT__.TTF"); rivalText:SetPoint("TOPLEFT", 132, -78)

local LEVELS = { "Mildly Moody", "Hood Up", "Misunderstood", "Lone Wolf", "Shadow Walker", "RGB Ascendant", "Unbearable", "Final Boss" }
local meterLbl = font(f, 11, CY, "Fonts\\FRIZQT__.TTF"); meterLbl:SetPoint("TOPRIGHT", -44, -22); meterLbl:SetJustifyH("RIGHT")
local meterBg = f:CreateTexture(nil, "ARTWORK"); meterBg:SetSize(240, 12); meterBg:SetPoint("TOPRIGHT", -44, -40); meterBg:SetColorTexture(0.12, 0.02, 0.03, 1)
local meter = f:CreateTexture(nil, "ARTWORK", nil, 1); meter:SetHeight(12); meter:SetPoint("TOPLEFT", meterBg, "TOPLEFT"); meter:SetColorTexture(RED[1], RED[2], RED[3], 1)
local stats = font(f, 11, DIM); stats:SetPoint("TOPRIGHT", -44, -82); stats:SetJustifyH("RIGHT")
local sessionPosts = 0

-- left: loadout of categories
local loadLbl = font(f, 11, CY, "Fonts\\FRIZQT__.TTF"); loadLbl:SetPoint("TOPLEFT", 18, -122); loadLbl:SetText("LOADOUT")
local catButtons = {}
for i, cat in ipairs(D.cats) do
  local b = CreateFrame("Button", nil, f); b:SetSize(222, 34); b:SetPoint("TOPLEFT", 14, -138 - (i - 1) * 36)
  b.sel = b:CreateTexture(nil, "BACKGROUND"); b.sel:SetAllPoints(); b.sel:SetColorTexture(RED[1], RED[2], RED[3], 0.22)
  b.bar = b:CreateTexture(nil, "ARTWORK"); b.bar:SetSize(3, 34); b.bar:SetPoint("LEFT"); b.bar:SetColorTexture(RED[1], RED[2], RED[3], 1)
  b.icon = b:CreateTexture(nil, "ARTWORK"); b.icon:SetSize(30, 30); b.icon:SetPoint("LEFT", 8, 0); setIcon(b.icon, cat.icon)
  b.text = font(b, 13, WHITE); b.text:SetPoint("LEFT", b.icon, "RIGHT", 8, 0); b.text:SetText(cat.title)
  local hl = b:CreateTexture(nil, "HIGHLIGHT"); hl:SetAllPoints(); hl:SetColorTexture(CY[1], CY[2], CY[3], 0.12)
  b:SetScript("OnClick", function() DB.cat = i; DB.chaos = false; Refresh() end)
  catButtons[i] = b
end

-- center: terminal with the next thought
local term = CreateFrame("Frame", nil, f, "BackdropTemplate"); term:SetPoint("TOPLEFT", 252, -122); term:SetSize(552, 128)
term:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 })
term:SetBackdropColor(0, 0, 0, 0.85); term:SetBackdropBorderColor(CY[1], CY[2], CY[3], 0.6)
local catIcon = term:CreateTexture(nil, "ARTWORK"); catIcon:SetSize(28, 28); catIcon:SetPoint("TOPLEFT", 10, -8)
local catTitle = font(term, 16, RED, "Fonts\\FRIZQT__.TTF", "OUTLINE"); catTitle:SetPoint("LEFT", catIcon, "RIGHT", 8, 0)
local catPos = font(term, 11, DIM); catPos:SetPoint("TOPRIGHT", -10, -14)
local prompt = font(term, 11, CY, "Fonts\\ARIALN.TTF"); prompt:SetPoint("TOPLEFT", 12, -44); prompt:SetText("C:\\EDGE> next_thought.exe")
local preview = font(term, 15, CY); preview:SetPoint("TOPLEFT", 12, -62); preview:SetWidth(528); preview:SetJustifyH("LEFT"); preview:SetSpacing(2)
local cursor = font(term, 15, CY); cursor:SetText("_")
local blink = 0
term:SetScript("OnUpdate", function(_, el) blink = blink + el; cursor:SetShown(math.floor(blink * 2) % 2 == 0) end)

-- action buttons
local postB = button(f, 130, 40, "POST", function() EP_Spew() end, 15); postB:SetPoint("TOPLEFT", term, "BOTTOMLEFT", 0, -12)
local sayB = button(f, 130, 40, "SAY", function() EP_Say() end, 15); sayB:SetPoint("LEFT", postB, "RIGHT", 10, 0)
local sayGlow = sayB:CreateTexture(nil, "BACKGROUND"); sayGlow:SetPoint("TOPLEFT", -6, 6); sayGlow:SetPoint("BOTTOMRIGHT", 6, -6)
sayGlow:SetColorTexture(RED[1], RED[2], RED[3], 0.6); sayGlow:Hide()
local sayPulse = sayGlow:CreateAnimationGroup(); sayPulse:SetLooping("BOUNCE")
local sp = sayPulse:CreateAnimation("Alpha"); sp:SetFromAlpha(0.15); sp:SetToAlpha(1); sp:SetDuration(0.5)
sayB:HookScript("OnEnter", function(self)
  GameTooltip:SetOwner(self, "ANCHOR_TOP"); GameTooltip:AddLine("Say it out loud in /say", 1, 0.2, 0.25)
  GameTooltip:AddLine(pendingSay and ("Waiting: " .. pendingSay) or "Says the next edgy line.", 1, 1, 1, true); GameTooltip:Show()
end)
local autoB = button(f, 130, 40, "", function() EP_ToggleAuto() end, 15); autoB:SetPoint("LEFT", sayB, "RIGHT", 10, 0)
local chaosB = button(f, 130, 40, "", function() DB.chaos = not DB.chaos; Refresh() end, 15); chaosB:SetPoint("LEFT", autoB, "RIGHT", 10, 0)

-- tuning row
slider = CreateFrame("Slider", nil, f, "BackdropTemplate")
slider:SetPoint("TOPLEFT", postB, "BOTTOMLEFT", 4, -34); slider:SetSize(300, 12); slider:SetOrientation("HORIZONTAL")
slider:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 })
slider:SetBackdropColor(0.1, 0.02, 0.03, 0.95); slider:SetBackdropBorderColor(RED[1], RED[2], RED[3], 0.8)
local thumb = slider:CreateTexture(nil, "OVERLAY"); thumb:SetSize(10, 20); thumb:SetColorTexture(CY[1], CY[2], CY[3], 1); slider:SetThumbTexture(thumb)
slider:SetMinMaxValues(1, 60); slider:SetValueStep(1); if slider.SetObeyStepMode then slider:SetObeyStepMode(true) end; slider:EnableMouse(true)
local sText = font(slider, 12, WHITE); sText:SetPoint("BOTTOMLEFT", slider, "TOPLEFT", 0, 5)
local sLow = font(slider, 10, DIM); sLow:SetPoint("TOPLEFT", slider, "BOTTOMLEFT", 0, -3); sLow:SetText("1s (unbearable)")
local sHigh = font(slider, 10, DIM); sHigh:SetPoint("TOPRIGHT", slider, "BOTTOMRIGHT", 0, -3); sHigh:SetText("60s (brooding)")
slider.update = function(v)
  if not DB then return end
  DB.speed = math.floor((v or DB.speed) + 0.5)
  sText:SetText(("Edge speed: every %ds%s"):format(DB.speed, (AUTO_OK[DB.channel] and effectiveSpeed() > DB.speed) and ("  |cff8cd9ff(" .. DB.channel .. " min " .. effectiveSpeed() .. "s)|r") or ""))
end
slider:SetScript("OnValueChanged", function(_, v) slider.update(v) end)
local chanB = button(f, 160, 26, "", function()
  DB.channel = nextIn(CHANNELS, DB.channel); if DB.channel ~= "SAY" then pendingSay = nil end
  slider.update(DB.speed); Refresh()
end, 12)
chanB:SetPoint("LEFT", slider, "RIGHT", 30, 8)
local danceB = button(f, 160, 26, "", function() DB.danceEvery = nextIn({ 0, 3, 5, 7, 10 }, DB.danceEvery); Refresh() end, 12)
danceB:SetPoint("TOPLEFT", chanB, "BOTTOMLEFT", 0, -6)

local checks = {}
local function check(key, label, x, y)
  local cb = CreateFrame("CheckButton", nil, f, "UICheckButtonTemplate"); cb:SetSize(24, 24); cb:SetPoint("TOPLEFT", x, y)
  local t = font(cb, 12, WHITE); t:SetPoint("LEFT", cb, "RIGHT", 2, 0); t:SetText(label)
  cb:SetScript("OnClick", function(self) DB[key] = self:GetChecked() and true or false; Refresh() end)
  checks[key] = cb
end
local ry = -436
check("useTarget", "Target", 252, ry); check("useGroup", "Group", 336, ry); check("useGuild", "Online guildies", 414, ry); check("lockTarget", "Lock on target", 556, ry)
check("escalate", "|cffff2030Escalation|r (gets faster)", 252, ry - 26); check("anims", "Poses", 452, ry - 26); check("chime", "Keyboard clacks", 532, ry - 26)
local foot = font(f, 10, DIM); foot:SetPoint("BOTTOMRIGHT", -14, 10)
foot:SetText("/edge help  ·  bind POST, SAY and AUTO under Key Bindings > AddOns > Edgelord Pro")

-- glitch, RGB strip and auto countdown
local hue, gl = 0, 0
f:SetScript("OnUpdate", function(_, el)
  hue = (hue + el * 0.35) % 1
  for i, t in ipairs(strips) do
    local h = (hue + i / #strips) % 1
    t:SetColorTexture(0.5 + 0.5 * math.sin(6.283 * h), 0.5 + 0.5 * math.sin(6.283 * (h + 0.33)), 0.5 + 0.5 * math.sin(6.283 * (h + 0.66)), 0.9)
  end
  if gl > 0 then gl = gl - el; titleC:SetPoint("TOPLEFT", 128 + math.random(-4, 4), -16 + math.random(-2, 2)) else titleC:SetPoint("TOPLEFT", 128, -16) end
  if auto then autoB:SetText(("STOP  %ds"):format(math.max(0, math.ceil(effectiveSpeed() - acc)))) end
end)
function flash() gl = 0.35; sessionPosts = sessionPosts + 1; halo:SetAlpha(1); C_Timer.After(0.3, function() halo:SetAlpha(0.35) end) end

-- floating SAY IT button when the panel is closed and a line is waiting
local fsay = button(UIParent, 200, 36, "|cffff2030SAY IT|r", function() EP_Say() end, 14)
fsay:SetPoint("CENTER", 0, 200); fsay:SetFrameStrata("HIGH"); fsay:Hide()
fsay:SetMovable(true); fsay:RegisterForDrag("LeftButton"); fsay:SetScript("OnDragStart", fsay.StartMoving); fsay:SetScript("OnDragStop", fsay.StopMovingOrSizing)

Refresh = function()
  if not DB then return end
  fsay:SetShown(pendingSay ~= nil and not f:IsShown())
  if not f:IsShown() then return end
  local cat = catData()
  for i, b in ipairs(catButtons) do local on = (i == DB.cat and not DB.chaos); b.sel:SetShown(on); b.bar:SetShown(on) end
  setIcon(catIcon, cat.icon)
  catTitle:SetText(DB.chaos and "CHAOS MODE" or cat.title)
  catPos:SetText(DB.chaos and "random category every line" or ("line " .. pos() .. " / " .. #cat.lines))
  local t = targetName()
  rivalText:SetText("Current rival: |cffff2030" .. ((DB.lockTarget and t) or victim) .. "|r" .. ((DB.lockTarget and t) and "  |cff8cd9ff(locked)|r" or ""))
  local lvl = math.min(#LEVELS, math.floor((sessionPosts + (DB.escalate and esc or 0)) / 4) + 1)
  meterLbl:SetText(("EDGE LEVEL %d: %s"):format(lvl, LEVELS[lvl]:upper()))
  meter:SetWidth(math.max(2, 240 * lvl / #LEVELS))
  stats:SetText(("Posts this session %d  ·  all time %d  ·  %d guildies in range"):format(sessionPosts, DB.spewed, DB.useGuild and #onlineGuildies() or 0))
  preview:SetText((cat.lines[pos()][2]:gsub("%%t", "|cffff2030[rival]|r")))
  cursor:ClearAllPoints(); cursor:SetPoint("BOTTOMLEFT", preview, "BOTTOMRIGHT", 2, 0)
  if not auto then autoB:SetText("AUTO-EDGE") end
  sayB:SetText(pendingSay and "|cffffffffSAY IT!|r" or "SAY")
  if pendingSay then if not sayGlow:IsShown() then sayGlow:Show(); sayPulse:Play() end else sayGlow:Hide(); sayPulse:Stop() end
  chaosB:SetText(DB.chaos and "CHAOS: ON" or "CHAOS")
  chanB:SetText("Channel: " .. DB.channel)
  danceB:SetText(DB.danceEvery > 0 and ("Pose every " .. DB.danceEvery) or "Poses: Off")
  for k, cb in pairs(checks) do cb:SetChecked(DB[k]) end
end
f:SetScript("OnShow", function() Refresh() end)
f:SetScript("OnHide", function() Refresh() end)
end

---------------------------------------------------------------- events / slash / bindings
local ev = CreateFrame("Frame")
ev:RegisterEvent("ADDON_LOADED"); ev:RegisterEvent("PLAYER_TARGET_CHANGED"); ev:RegisterEvent("GROUP_ROSTER_UPDATE")
ev:RegisterEvent("PLAYER_LOGIN")
ev:SetScript("OnEvent", function(_, e, a1)
  if e == "ADDON_LOADED" and a1 == ADDON then
    defaults()
    local ok, err = pcall(BuildUI)
    if not ok then
      uiError = tostring(err); f = nil
      msg("|cffff5555Window failed to build:|r " .. uiError .. "  (Edge and auto-edge still work: /edge now, /edge auto)")
    else
      slider:SetValue(DB.speed); slider.update(DB.speed)
    end
  elseif e == "PLAYER_LOGIN" then
    if C_GuildInfo and C_GuildInfo.GuildRoster then C_GuildInfo.GuildRoster() end
    msg("Edgelord Pro 1.1 loaded. Type |cffff2030/edge|r to open. Nobody understands you, but this addon tries.")
  elseif DB and f then
    pcall(Refresh)
  end
end)

function EP_Toggle()
  if not f then msg("Window unavailable: " .. (uiError or "not loaded yet")); return end
  f:SetShown(not f:IsShown())
end
BINDING_HEADER_EDGELORDPRO = "Edgelord Pro"
BINDING_NAME_EP_SPEW = "Post the next edgy line"
BINDING_NAME_EP_SAY = "Say the next line (/say)"
BINDING_NAME_EP_AUTO = "Toggle auto-edge"
BINDING_NAME_EP_TOGGLE = "Open / close Edgelord Pro"

SLASH_EDGELORDPRO1 = "/edge"
SLASH_EDGELORDPRO2 = "/edgelord"
SlashCmdList.EDGELORDPRO = function(arg)
  arg = (arg or ""):lower()
  if arg == "now" or arg == "spew" or arg == "s" then EP_Spew()
  elseif arg == "say" then EP_Say()
  elseif arg == "auto" then EP_ToggleAuto()
  elseif arg == "stop" then auto = false; msg("Auto-edge stopped. The shadows rest."); if Refresh then Refresh() end
  elseif arg == "escalate" then DB.escalate = not DB.escalate; msg("Escalation " .. (DB.escalate and "ON: every auto line comes a second sooner." or "off.")); if Refresh then Refresh() end
  elseif arg == "help" then
    msg("/edge - open the HUD  ·  /edge now - post  ·  /edge say  ·  /edge auto | stop  ·  /edge escalate  ·  /edge chaos")
  elseif arg == "chaos" then DB.chaos = not DB.chaos; msg("Chaos " .. (DB.chaos and "ON" or "off")); if Refresh then Refresh() end
  else EP_Toggle() end
end
