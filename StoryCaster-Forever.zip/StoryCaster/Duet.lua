-- StoryCaster: duets and group scenes.
-- Lines that start with [Name] belong to that character. Whoever presses Play sends the script to the others
-- (party, raid or instance chat, or whispers when not grouped) over a hidden addon channel, then runs the timer;
-- on each line meant for someone else it sends a cue, and that player's StoryCaster performs it.
-- Everyone in the scene needs StoryCaster. Nothing is performed for anyone who has not accepted the invitation.
local ADDON, ns = ...
local R = ns.R
local PREFIX = "StoryCaster"
local CHUNK = 200

local function short(name) return ((name or ""):match("^([^%-]+)") or name or ""):lower() end
local function isMe(name) return short(name) == short(UnitName("player")) end

local function addonSend(msg, chan, target)
  local f = (C_ChatInfo and C_ChatInfo.SendAddonMessage) or SendAddonMessage
  if f then pcall(f, PREFIX, msg, chan, target) end
end
R.AddonSend = addonSend
R.ShortName = short

-- where scene messages go: the group if there is one, otherwise a whisper to each player in the cast
function R:SceneTargets(cast)
  if IsInGroup and LE_PARTY_CATEGORY_INSTANCE and IsInGroup(LE_PARTY_CATEGORY_INSTANCE) then return { { "INSTANCE_CHAT" } } end
  if IsInRaid and IsInRaid() then return { { "RAID" } } end
  if IsInGroup and IsInGroup() then return { { "PARTY" } } end
  local out = {}
  for _, who in ipairs(cast or {}) do out[#out + 1] = { "WHISPER", who } end
  return out
end

function R:SceneSend(msg)
  for _, t in ipairs((self.scene and self.scene.targets) or {}) do addonSend(msg, t[1], t[2]) end
end

-- the leader: invite the cast; returns how many seconds to wait before the first line
function R:CastScene(name, script, cast)
  if self.run then self.run.lines = script end -- duets are never shuffled: everyone counts lines the same way
  local id = tostring(math.random(100000, 999999))
  self.scene = { id = id, targets = self:SceneTargets(cast), cast = cast, joined = {}, declined = {}, waiting = true }
  local blob = self:ScriptToText(script):gsub("|", "\a") -- a choice's | travels as \a
  local chunks = {}
  for i = 1, #blob, CHUNK do chunks[#chunks + 1] = blob:sub(i, i + CHUNK - 1) end
  local msgs = { ("H\t%s\t%s\t%d"):format(id, (name:gsub("\t", " ")), #chunks) }
  for i, c in ipairs(chunks) do msgs[#msgs + 1] = ("D\t%s\t%d\t%s"):format(id, i, c) end
  msgs[#msgs + 1] = "G\t" .. id
  for i, m in ipairs(msgs) do C_Timer.After((i - 1) * 0.15, function() self:SceneSend(m) end) end
  self:Print(("Duet: invited %s. They need StoryCaster, and to press Join. The scene starts when everyone has joined (or in %d seconds)."):format(table.concat(cast, ", "), self.DUET_WAIT))
  return self.DUET_WAIT
end

-- the ready-check: who has joined, who is still awaited
R.DUET_WAIT = 45
function R:DuetWaitingText()
  local sc = self.scene
  if not sc then return "" end
  local missing, n = {}, 0
  for _, who in ipairs(sc.cast) do
    if sc.joined[short(who)] then n = n + 1 elseif not sc.declined[short(who)] then missing[#missing + 1] = who end
  end
  return ("duet: %d of %d joined%s"):format(n, #sc.cast, #missing > 0 and (", waiting for " .. table.concat(missing, ", ")) or "")
end

function R:DuetAnswer(kind, sender)
  local sc = self.scene
  if not sc then return end
  local who = short(sender)
  local inCast = false
  for _, c in ipairs(sc.cast) do if short(c) == who then inCast = true end end
  if not inCast then return end
  if kind == "J" then sc.joined[who] = true; self:Print(sender:match("^[^%-]+") .. " joined the scene.")
  else sc.declined[who] = true; self:Print(sender:match("^[^%-]+") .. " won't be joining the scene.") end
  local all = true
  for _, c in ipairs(sc.cast) do if not sc.joined[short(c)] and not sc.declined[short(c)] then all = false end end
  if all and sc.waiting then
    sc.waiting = false
    self:Print("Everyone is here. The scene begins.")
    if self.run and self.state == "running" and self.nextAt and self.nextAt - GetTime() > 3 then self:ArmTimer(3) end
  end
  self:Refresh()
end

-- the leader: cue the next line for whoever it belongs to
function R:Cue(i, line)
  if not (self.scene and line[5]) then return end
  if self:IsMine(line) then return end
  self:SceneSend(("C\t%s\t%d"):format(self.scene.id, i))
end

function R:EndScene()
  if self.scene then self:SceneSend("S\t" .. self.scene.id); self.scene = nil end
end

---------------------------------------------------------------------------
-- The other players
---------------------------------------------------------------------------
local incoming = {}

function R:JoinScene(inv)
  self.following = inv
  if inv.id then addonSend("J\t" .. inv.id, "WHISPER", inv.from) end
  self:Print(("Joined |cffffd100%s|r with %s. Your lines will be performed when their turn comes."):format(inv.name, inv.from))
  self:Refresh()
end

function R:LeaveScene(silent)
  if not self.following then return end
  if not silent then self:Print("The scene '" .. self.following.name .. "' has ended." .. (self.pending and " Your last line still waits for Deliver." or "")) end
  self.following = nil -- a /say line still waiting for this player's Deliver key stays ready
  self:Refresh()
end

-- a /say or /yell line in a duet waits for this player's Deliver key
function R:DeliverPending()
  local line = self.pending
  self.pending = nil
  if line then self:Perform(line) end
  self:Refresh()
end

local function invite(self, inv)
  local mine = 0
  for _, l in ipairs(inv.script) do if l[5] and isMe(l[5]) then mine = mine + 1 end end
  if mine == 0 then return end
  inv.mine = mine
  if self.db.duetAuto then self:JoinScene(inv) return end
  if StaticPopupDialogs and StaticPopup_Show then
    StaticPopupDialogs.STORYCASTER_DUET = {
      text = "%s invites you to perform \"%s\" with them in StoryCaster. %d line(s) are yours.",
      button1 = "Join", button2 = "No thanks", timeout = 60, whileDead = true, hideOnEscape = true, preferredIndex = 3,
      OnAccept = function(_, data) R:JoinScene(data) end,
      OnCancel = function(_, data) if data and data.id then addonSend("Q\t" .. data.id, "WHISPER", data.from) end end,
    }
    local dialog = StaticPopup_Show("STORYCASTER_DUET", inv.from, inv.name, mine)
    if dialog then dialog.data = inv end
  else
    self:Print(inv.from .. " invites you to a scene. Type /story duet to join scenes automatically.")
  end
end

function R:OnAddonMessage(msg, sender)
  if isMe(sender) then return end
  local kind, id, a, b
  if strsplit then kind, id, a, b = strsplit("\t", msg, 4)
  else kind, id, a, b = msg:match("^(%a)\t([^\t]*)\t?([^\t]*)\t?(.*)$") end
  if not (kind and id) then return end
  if (kind == "O" or kind == "A" or kind == "P" or kind == "N") and self.OnShareMessage then
    self:OnShareMessage(kind, id, a, b, sender)
    return
  end
  if (kind == "J" or kind == "Q") then
    if self.scene and self.scene.id == id then self:DuetAnswer(kind, sender) end
    return
  end
  if kind == "H" then
    incoming[id] = { from = sender, name = a, n = tonumber(b) or 0, chunks = {}, got = 0 }
  elseif kind == "D" then
    local inv = incoming[id]
    local seq = tonumber(a)
    if inv and seq and not inv.chunks[seq] and short(inv.from) == short(sender) then
      inv.chunks[seq] = b or ""
      inv.got = inv.got + 1
      if inv.got == inv.n then
        inv.script = self:Convert((table.concat(inv.chunks):gsub("\a", "|")), "lines", false)
        inv.id = id
        invite(self, inv)
      end
    end
  elseif kind == "G" then
    local f = self.following
    if f and f.id == id then self:Print("The scene begins.") end
  elseif kind == "C" then
    local f = self.following
    if f and f.id == id and short(f.from) == short(sender) then
      local line = f.script[tonumber(a) or 0]
      if line and self:IsMine(line, true) then
        if self:NeedsKey(line) and not self.db.testMode then
          self.pending = line
          self:Print("Your /" .. line[4]:lower() .. " line is ready: press |cffffd100Deliver|r to speak it.")
          self:Refresh()
        elseif self:CanEmote() then
          self:Perform(line)
        end
      end
    end
  elseif kind == "S" then
    local f = self.following
    if f and f.id == id then self:LeaveScene() end
    incoming[id] = nil
  end
end

function R:Comms()
  if C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix then C_ChatInfo.RegisterAddonMessagePrefix(PREFIX)
  elseif RegisterAddonMessagePrefix then RegisterAddonMessagePrefix(PREFIX) end
  local f = CreateFrame("Frame")
  f:RegisterEvent("CHAT_MSG_ADDON")
  f:SetScript("OnEvent", function(_, _, prefix, msg, _, sender)
    if prefix ~= PREFIX or type(msg) ~= "string" then return end
    if issecretvalue and (issecretvalue(msg) or issecretvalue(sender)) then return end
    R:OnAddonMessage(msg, sender)
  end)
end
