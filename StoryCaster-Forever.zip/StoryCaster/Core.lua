-- StoryCaster: write or paste your own roleplay, and it is performed as /emotes on a timer,
-- with real character animations. /story opens the panel.
local ADDON, ns = ...
local R = {}
ns.R = R
_G.StoryCaster = R

R.version = "1.0.1"

local SAMPLE = {
  { "steps forward and lifts a hand in greeting.", "WAVE" },
  { "smiles at {target}. \"Well met. I hoped I would find you here.\"", "TALK" },
  { "glances over one shoulder, then lowers their voice. \"We should talk somewhere quieter.\"", nil },
  { "", "NOD" },
  { "bows, and turns toward the road.", "BOW" },
}

local DEFAULTS = {
  interval = 12, dice = false, diceMin = 5, diceMax = 30,
  loop = false, shuffle = false, testMode = false, pauseInCombat = true,
  animations = true, autoAnim = true, mode = "sentences",
  showBar = true, barPoint = nil, last = "Sample: A Greeting",
  scripts = {}, order = {},
}

local function copyDefaults(src, dst)
  if type(dst) ~= "table" then dst = {} end
  for k, v in pairs(src) do
    if type(v) == "table" then dst[k] = copyDefaults(v, dst[k])
    elseif dst[k] == nil then dst[k] = v end
  end
  return dst
end

function R:Print(msg) DEFAULT_CHAT_FRAME:AddMessage("|cffb48cff[StoryCaster]|r " .. tostring(msg)) end

---------------------------------------------------------------------------
-- Scripts
---------------------------------------------------------------------------
function R:Names() return self.db.order end
function R:Get(name) return name and self.db.scripts[name] end

function R:Save(name, script)
  name = (name or ""):gsub("|", ""):gsub("^%s+", ""):gsub("%s+$", "")
  if name == "" then return false, "Give your script a name first." end
  if #name > 48 then return false, "That name is too long (48 characters at most)." end
  if #script == 0 then return false, "Write or paste at least one line." end
  local new = self.db.scripts[name] == nil
  self.db.scripts[name] = script
  if new then table.insert(self.db.order, name) end
  self.db.last = name
  return true, (new and "Saved" or "Updated") .. " '" .. name .. "': " .. #script .. " emote" .. (#script == 1 and "" or "s") .. "."
end

function R:Delete(name)
  if not self.db.scripts[name] then return false end
  if self.run and self.run.name == name then self:Stop(true) end
  self.db.scripts[name] = nil
  for i, n in ipairs(self.db.order) do if n == name then table.remove(self.db.order, i); break end end
  if self.db.last == name then self.db.last = self.db.order[1] end
  return true
end

---------------------------------------------------------------------------
-- Text and animation
---------------------------------------------------------------------------
function R:Target()
  local t = UnitExists("target") and UnitName("target") or nil
  if t and issecretvalue and issecretvalue(t) then return nil end
  if t and UnitIsUnit and UnitIsUnit("target", "player") then return nil end
  return t
end

function R:Render(text)
  text = (text or ""):gsub("{target}", self:Target() or "someone"):gsub("|", "")
  if #text > self.MAX_LEN then text = (text:sub(1, self.MAX_LEN - 3):match("^(.*)%s") or text:sub(1, self.MAX_LEN - 3)) .. "..." end
  return text
end

local function sendEmote(text)
  if C_ChatInfo and C_ChatInfo.SendChatMessage then C_ChatInfo.SendChatMessage(text, "EMOTE")
  else SendChatMessage(text, "EMOTE") end
end

-- Plays an animated emote. Aimed at nobody, so the game's own line reads "X bows." and not "X bows before Y."
function R:Animate(token, onTarget)
  if not token then return end
  local perform = (C_ChatInfo and C_ChatInfo.PerformEmote) or DoEmote
  if not perform then return end
  pcall(perform, token, onTarget and self:Target() and "target" or "none")
end

function R:CanEmote()
  if C_ChatInfo and C_ChatInfo.InChatMessagingLockdown and C_ChatInfo.InChatMessagingLockdown() then return false, "a boss encounter" end
  if self.db.pauseInCombat and InCombatLockdown() then return false, "combat" end
  return true
end

---------------------------------------------------------------------------
-- The player
---------------------------------------------------------------------------
-- state: nil (idle) | "running" | "paused" | "waiting" (held for combat or an encounter)
local function shuffled(list)
  local out = {}
  for i, v in ipairs(list) do out[i] = v end
  for i = #out, 2, -1 do local j = math.random(i); out[i], out[j] = out[j], out[i] end
  return out
end

function R:NextDelay()
  if self.db.dice then return math.random(self.db.diceMin, math.max(self.db.diceMin, self.db.diceMax)) end
  return self.db.interval
end

function R:CancelTimer() if self.timer then self.timer:Cancel(); self.timer = nil end end

function R:ArmTimer(delay)
  self:CancelTimer()
  self.nextDur, self.nextAt = delay, GetTime() + delay
  self.timer = C_Timer.NewTimer(delay, function() self.timer = nil; self:PostNext() end)
end

function R:Start(name)
  name = (name and name ~= "") and name or self.db.last
  local script = self:Get(name)
  if not script then self:Print("No script called '" .. tostring(name) .. "'. /story list shows yours.") return end
  if #script == 0 then self:Print("That script is empty.") return end
  self:Stop(true)
  self.db.last = name
  self.run = { name = name, lines = self.db.shuffle and shuffled(script) or script, i = 0 }
  self.state = "running"
  self:Print(("Performing |cffffd100%s|r: %d emotes, %s."):format(name, #script,
    self.db.dice and ("random gaps of " .. self.db.diceMin .. "-" .. self.db.diceMax .. "s") or ("one every " .. self.db.interval .. "s")))
  local first = self.run.lines[1]
  if first and first[3] then self:ArmTimer(first[3]); self:Refresh() else self:PostNext() end
end

-- the wait before a line: its own /pause if it has one, otherwise the timer
function R:DelayBefore(line) return (line and line[3]) or self:NextDelay() end

function R:PostNext()
  local run = self.run
  if not run then return end
  self:CancelTimer()
  local ok, why = self:CanEmote()
  if not ok then
    if self.state ~= "waiting" then self:Print("Holding your script during " .. why .. ".") end
    self.state, self.nextAt = "waiting", nil
    self.timer = C_Timer.NewTimer(3, function() self.timer = nil; self:PostNext() end)
    self:Refresh()
    return
  end
  if self.state == "waiting" then self.state = "running"; self:Print("Resuming.") end
  run.i = run.i + 1
  if run.i > #run.lines then
    if self.db.loop then
      local script = self:Get(run.name) or run.lines
      run.lines, run.i = self.db.shuffle and shuffled(script) or script, 1
    else
      self:Finish(); return
    end
  end
  local line = run.lines[run.i]
  local text, anim = self:Render(line[1]), line[2]
  if text:find("^%s*/") then text = "" end -- a slash command is never posted as words
  if self.db.testMode then
    self:Print(("|cffaaaaaa(test %d/%d)|r |cffff8040%s%s|r%s"):format(run.i, #run.lines, text ~= "" and (UnitName("player") .. " ") or "", text,
      anim and (" |cff9f8fff[" .. anim:lower() .. "]|r") or ""))
  else
    if text ~= "" then
      local sent, err = pcall(sendEmote, text)
      if not sent then self:Print("Emote failed: " .. tostring(err)) end
    end
    if anim and self.db.animations then
      if text ~= "" then C_Timer.After(0.4, function() self:Animate(anim) end) else self:Animate(anim) end
    end
  end
  if self.Pulse then self:Pulse(anim) end
  if run.i >= #run.lines and not self.db.loop then
    self.nextAt, self.nextDur = nil, nil
    self.timer = C_Timer.NewTimer(1, function() self.timer = nil; self:Finish() end)
  else
    self:ArmTimer(self:DelayBefore(run.lines[run.i + 1] or run.lines[1]))
  end
  self:Refresh()
end

function R:Finish()
  if not self.run then return end
  self:Print(("|cffffd100%s|r finished."):format(self.run.name))
  self:Stop(true)
end

function R:Pause()
  if self.state ~= "running" and self.state ~= "waiting" then return end
  self:CancelTimer()
  self.state, self.nextAt = "paused", nil
  self:Refresh()
end

function R:Resume()
  if self.state ~= "paused" then return end
  self.state = "running"
  self:ArmTimer(self:DelayBefore(self.run and self.run.lines[self.run.i + 1]))
  self:Refresh()
end

function R:Stop(silent)
  self:CancelTimer()
  local was = self.run
  self.run, self.state, self.nextAt, self.nextDur = nil, nil, nil, nil
  if was and not silent then self:Print("Stopped.") end
  self:Refresh()
end

function R:Skip()
  if not self.run then return end
  if self.state == "paused" then self.state = "running" end
  self:PostNext()
end

function R:TogglePlay()
  if self.state == "paused" then self:Resume()
  elseif self.state then self:Pause()
  else self:Start(self.db.last) end
end

function R:Reschedule()
  if self.state ~= "running" or not self.nextAt then return end
  if self.db.dice then self:ArmTimer(self:NextDelay()); return end
  local elapsed = self.nextDur - (self.nextAt - GetTime())
  self:ArmTimer(math.max(1, self.db.interval - elapsed))
  self.nextDur = self.db.interval
end

function R:SetInterval(v)
  v = math.max(5, math.min(60, math.floor(v + 0.5)))
  if v == self.db.interval then return end
  self.db.interval = v
  if not self.db.dice then self:Reschedule() end
  self:Refresh()
end

function R:SetDice(on) self.db.dice = on and true or false; self:Reschedule(); self:Refresh() end

function R:Refresh() if self.UpdateBar then self:UpdateBar() end end

---------------------------------------------------------------------------
-- Slash commands
---------------------------------------------------------------------------
local HELP = {
  "|cffb48cffStoryCaster|r v%s  -  /story <command>",
  "  (nothing)  show the panel   |   write  open the script window",
  "  start [name] | pause | resume | next | stop",
  "  list  your scripts   |   preview <name>  read it to yourself   |   delete <name>",
  "  anim <emote>  play an animation (bow, wave, cheer...)   |   anims  list them",
  "  interval <5-60>   |   dice [min max]   |   loop | shuffle | test | animations | auto",
  "  reset  move the panel back to the top",
}

function R:Slash(input)
  local cmd, rest = (input or ""):match("^%s*(%S*)%s*(.-)%s*$")
  cmd = cmd:lower()
  local db = self.db
  if cmd == "" or cmd == "show" then db.showBar = true; self:Refresh()
  elseif cmd == "hide" then db.showBar = false; self:Refresh()
  elseif cmd == "help" then for i, l in ipairs(HELP) do self:Print(i == 1 and l:format(self.version) or l) end
  elseif cmd == "write" or cmd == "upload" or cmd == "new" then if self.ToggleWriter then self:ToggleWriter(true) end
  elseif cmd == "start" or cmd == "play" then self:Start(rest)
  elseif cmd == "pause" then self:Pause()
  elseif cmd == "resume" then self:Resume()
  elseif cmd == "next" or cmd == "skip" then self:Skip()
  elseif cmd == "stop" then self:Stop()
  elseif cmd == "list" then
    if #db.order == 0 then self:Print("No scripts yet. /story write") end
    for _, n in ipairs(db.order) do self:Print(("  |cffffd100%s|r  (%d emotes)"):format(n, #db.scripts[n])) end
  elseif cmd == "preview" then
    local s = self:Get(rest ~= "" and rest or db.last)
    if not s then self:Print("Usage: /story preview <script name>") return end
    for i, l in ipairs(s) do
      self:Print(("%d. %s%s%s"):format(i, l[3] and ("|cff888888(pause " .. l[3] .. "s)|r ") or "",
        l[1] ~= "" and (UnitName("player") .. " " .. self:Render(l[1])) or "", l[2] and (" |cff9f8fff[" .. l[2]:lower() .. "]|r") or ""))
    end
  elseif cmd == "delete" or cmd == "del" then
    if self:Delete(rest) then self:Print("Deleted '" .. rest .. "'."); self:Refresh() else self:Print("No script called '" .. rest .. "'.") end
  elseif cmd == "anim" or cmd == "emote" then
    local t = rest:upper()
    if self.ANIM_BY_TOKEN[t] then self:Animate(t, true) else self:Print("Unknown animation. /story anims lists them.") end
  elseif cmd == "anims" then
    local names = {}
    for _, a in ipairs(self.ANIMS) do names[#names + 1] = a[1]:lower() end
    self:Print("Animations: " .. table.concat(names, ", ") .. ". Put one in a line as [bow].")
  elseif cmd == "interval" then
    local n = tonumber(rest)
    if n and n >= 5 and n <= 60 then self:SetInterval(n); if self.SyncSlider then self:SyncSlider() end; self:Print("Timer: " .. db.interval .. "s")
    else self:Print("Usage: /story interval <5-60>") end
  elseif cmd == "dice" then
    local lo, hi = rest:match("^(%d+)%s+(%d+)$")
    lo, hi = tonumber(lo), tonumber(hi)
    if lo and hi and lo >= 3 and hi <= 300 and lo <= hi then db.diceMin, db.diceMax = lo, hi; self:SetDice(true)
    else self:SetDice(not db.dice) end
    self:Print("Random timing " .. (db.dice and ("on (" .. db.diceMin .. "-" .. db.diceMax .. "s)") or "off"))
  elseif cmd == "loop" or cmd == "shuffle" or cmd == "test" or cmd == "animations" or cmd == "auto" then
    local field = ({ loop = "loop", shuffle = "shuffle", test = "testMode", animations = "animations", auto = "autoAnim" })[cmd]
    db[field] = not db[field]
    self:Print(cmd:gsub("^%l", string.upper) .. " " .. (db[field] and "on" or "off") .. (cmd == "test" and db[field] and " (emotes print only to you)" or "") .. ".")
    self:Refresh()
  elseif cmd == "reset" then
    db.barPoint = nil; db.showBar = true
    if self.bar then self.bar:ClearAllPoints(); self.bar:SetPoint("TOP", 0, -110) end
    self:Refresh()
  else self:Print("Unknown command. /story help") end
end

SLASH_STORYCASTER1, SLASH_STORYCASTER2 = "/story", "/storycaster"
SlashCmdList.STORYCASTER = function(msg) R:Slash(msg) end
function StoryCaster_OnAddonCompartmentClick() R.db.showBar = not R.db.showBar; R:Refresh() end

local f = CreateFrame("Frame")
f:RegisterEvent("ADDON_LOADED")
f:RegisterEvent("PLAYER_LOGIN")
f:RegisterEvent("PLAYER_TARGET_CHANGED")
f:SetScript("OnEvent", function(_, event, arg1)
  if event == "ADDON_LOADED" and arg1 == ADDON then
    StoryCasterDB = copyDefaults(DEFAULTS, StoryCasterDB)
    R.db = StoryCasterDB
    if #R.db.order == 0 and not R.db.sampleGiven then
      R.db.scripts["Sample: A Greeting"] = SAMPLE
      table.insert(R.db.order, "Sample: A Greeting")
      R.db.sampleGiven = true
    end
    if not R:Get(R.db.last) then R.db.last = R.db.order[1] end
    -- scripts saved before /pause and other commands were understood are rebuilt once
    local fixed = 0
    for name, script in pairs(R.db.scripts) do
      local new, changed = R:Repair(script)
      if changed then R.db.scripts[name] = new; fixed = fixed + 1 end
    end
    R.repaired = fixed
  elseif event == "PLAYER_LOGIN" then
    R:Refresh()
    R:Print("v" .. R.version .. " loaded. /story shows the panel, /story write makes a script.")
    if (R.repaired or 0) > 0 then R:Print(R.repaired .. " saved script" .. (R.repaired == 1 and "" or "s") .. " updated: /pause lines are now real pauses, not emotes.") end
  elseif event == "PLAYER_TARGET_CHANGED" then
    if R.bar and R.bar:IsShown() then R:Refresh() end
  end
end)
