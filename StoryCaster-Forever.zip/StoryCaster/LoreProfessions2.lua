-- StoryCaster lore library: the rest of the professions. Original writing in StoryCaster's script format.
local ADDON, ns = ...
local R = ns.R
R.LORE = R.LORE or {}
R.LORE.profession = R.LORE.profession or {}
local L = R.LORE.profession

L.Enchanting = { "Enchanting", [[
## The Rod
draws a slender copper rod from a velvet case and turns it slowly in the light.
says, "This little rod is the first thing every enchanter makes. Copper, a touch of magic, and a great deal of patience."
taps the rod against the table, and a faint violet spark leaps from the tip.
says, "Hear that hum? That's the magic listening. It's always listening."
## Disenchanting
picks up a battered old sword and lays it gently on the bench.
says, "Nobody wants this blade anymore. But the magic in it is still good."
passes a hand over the sword, and it crumbles into glittering violet dust.
says, "Strange Dust. The leftovers of a weapon's dreams. I'll make something new from it."
sweeps the dust carefully into a small pouch. [nod]
## The Glow
holds up a cloak that shimmers faintly whenever it moves.
says, "Enchanting is the art of making ordinary things a little bit extraordinary."
says, "A cloak that keeps out the cold. Boots that run a little faster. A sword that never dulls."
says, "Nobody sees the work. They only feel the difference."
## The Shards
lines up glittering shards on the table, each one a different color.
says, "Shards are concentrated magic. Small, sharp, and very expensive."
says, "Drop one and it rolls under the furniture. Every single time. I've lost a fortune under that cabinet."
glares at the cabinet. [shrug]
## Weapon Work
lays a hand on {target}'s weapon, if they'll allow it.
says <mood>, "May I? I'll be gentle. Mostly."
murmurs a few words, and runes glow briefly along the blade before fading.
says, "There. It'll bite a little harder now. Don't thank me. Pay me."
## The Rival School
says, "There are enchanters who use runes, enchanters who use gems, and enchanters who use shouting."
says, "The shouting ones aren't very good. But they're very confident."
chuckles. [chuckle]
## Mistakes
says, "Once I tried to enchant a pair of boots for speed. They ran off without me."
says, "Found them three days later in a field outside Goldshire. Still running."
## Vellum and Scrolls
unrolls a sheet of vellum and traces glowing lines across it with one finger.
says, "Put an enchantment on vellum and anyone can use it later. Very convenient."
says, "Less convenient when the vellum blows away in the wind. Which it does. Often."
## The Feeling
closes their eyes, holding a crystal up to the light. [sigh]
says, "Magic feels different to everyone. To me it feels like warmth just before a sneeze."
says, "That's not poetic. I know. It's true, though."
## Teaching
hands {target} a small, faintly glowing crystal.
says, "Hold it. Feel that? The little buzz? That's the start of everything."
says, "If you don't feel it, that's fine. Not everyone does. Hand it back. Slowly."
## Customers
says, "People bring me the strangest requests. A spoon that's always warm. A hat that never blows off."
says, "I did both. The spoon is lovely. The hat is now permanently attached to a very unhappy gnome."
## Closing Up
snuffs the candles one by one, and the faint violet glow in the room slowly fades.
says, "Every enchantment I make is a little piece of me out in the world."
smiles, packing the copper rod away carefully. [bow]
/s Enchantments for every blade, cloak and boot! Fair prices, mostly safe!
]] }

L.Inscription = { "Inscription", [[
## The Ink
uncorks a small bottle of deep blue ink and breathes in the scent.
says, "Midnight Ink. Ground from herbs, mixed by hand, worth more than it looks."
dips a fine pen and lets a single drop fall back into the bottle.
says, "Scribes say ink remembers every word it ever wrote. I believe them."
## Milling
crushes a handful of dried herbs in a mortar, grinding them to a fine powder.
says, "Every color starts as a plant. Peacebloom gives a pale green. Fadeleaf, something like twilight."
says, "Milling's slow work. Good for thinking. Bad for the wrists."
flexes their wrist with a wince. [flex]
## The Glyph
draws a careful, looping symbol on a slip of parchment.
says, "A glyph is a little rune that changes how a spell behaves. Smaller, faster, brighter."
says, "Every class wants a different glyph. I keep a long list. It's mostly crossed out."
holds the glyph up to dry, admiring the curve of the line.
## The Library
gestures to shelves crammed with scrolls, books and loose pages.
says, "This is my library. Some say it's a mess. I say it's an archive with personality."
says, "Every book here is one I've copied, mended, or argued with."
## Mistakes in Ink
says, "One wrong stroke and the whole page is ruined."
says, "I once spent a week on a glyph and sneezed on the last line."
says, "The glyph worked. It just made everyone who used it sneeze. Very popular at parties."
laughs. [laugh]
## Darkmoon Cards
fans out a deck of beautifully illustrated cards.
says, "Darkmoon Cards. Painted by scribes, collected by fools like me."
says, "Finish a whole deck and something wonderful happens. I've never finished a whole deck."
## Contracts and Scrolls
rolls up a scroll and seals it with a dab of wax.
says, "A scroll is a spell you can carry in your pocket. Read it, and it's spent."
says, "I write them. Other people read them. Then they come back for more. It's a good business."
## Calligraphy
writes {target}'s name in elegant, flowing letters and holds it up.
says <mood>, "Your name. It's a good name to write. Lots of nice curves."
says, "I'll frame it for you, if you like. No charge. Well, a small charge."
## The Tome
lays a hand on an old, heavy tome bound in cracked leather.
says, "This is the oldest book I own. Older than this city."
says, "I've only read half of it. The other half is in a language nobody speaks anymore."
says, "I'm working on it. Slowly. Very slowly."
## The Apprentice
says, "My apprentice once used Ink of the Sea to write a love letter."
says, "Every word kept dripping off the page. Very romantic. Very damp."
## The Quiet
sits for a long moment with the pen hovering above a blank page. [sit]
says, "The blank page is the hardest part. Everything is possible. Nothing is written."
## Closing Up
corks every bottle, stacks the parchment and wipes the pen clean.
says, "A scribe's day is measured in pages. Today was a good one."
/s Glyphs, scrolls, and fine calligraphy! Your name in gold ink, for a fair price!
]] }

L.Jewelcrafting = { "Jewelcrafting", [[
## The Loupe
screws a small brass loupe into one eye and leans close to a rough, uncut stone.
says, "Every gem is hiding something beautiful. My job is to convince it to come out."
turns the stone slowly, searching for the right angle.
says, "There. That's where we'll cut. Right along the line of light."
## Prospecting
pours a handful of raw ore onto the bench and sifts through it with careful fingers.
says, "Prospecting. You crush the ore and see what treasures are hiding inside."
says, "Mostly dust. Sometimes a little gem. Once a very surprised beetle."
holds up a small gem triumphantly. [cheer]
## The Cut
sets a gem in a clamp and begins to cut, one tiny facet at a time.
says, "Each facet catches the light differently. Get the angles right, and it sparkles."
says, "Get them wrong, and it's a very expensive pebble."
## The Colors
lines up a row of polished gems on black velvet: red, blue, yellow, green, purple.
says, "Rubies for strength. Sapphires for the mind. Topaz for speed. Emeralds for hope."
says, "That's not true. But it's how I sell them."
winks. [chuckle]
## Rings
slides a delicate silver ring onto a display stand.
says, "Rings are the heart of the craft. Small, personal, worn for a lifetime."
says, "I've made rings for weddings, for warriors, for one very sentimental murloc."
## The Proposal
lowers their voice. "A young soldier came in last month. Wanted a ring for his sweetheart."
says, "He had almost no money. I made it anyway. Simple silver, one small stone."
says, "She said yes. He came back to tell me. That ring was worth more than any jewel I own."
smiles softly at the memory. [sigh]
## Settings
fits a sparkling gem into a gold necklace setting, bending the prongs gently.
says, "The setting is as important as the gem. A good setting lets the stone breathe."
## Customers
says <mood>, "{target}! Looking for something special? For yourself, or for someone else?"
says, "Don't answer. I can tell. It's for someone else. You have the look."
## The Big Stone
pulls a velvet cloth from a gem the size of a fist. [gasp]
says, "This one I'll never sell. Found it in a cave in the mountains, years ago."
says, "Every jeweler has one stone they keep. This is mine."
covers it again gently.
## Statues and Trinkets
holds up a tiny figurine carved entirely from jade.
says, "Jewelcrafters make more than jewelry. Little statues, trinkets, toys."
says, "This one's a tiny dragon. It's supposed to be fierce. It looks like it wants a nap."
## Dust and Danger
says, "The dust from cutting gets everywhere. My hair. My food. My bed."
says, "I sparkle a little at all times now. It's an occupational hazard."
## Closing Up
wraps each gem in its own scrap of velvet and locks them away.
says, "Gems wait patiently. They've been waiting thousands of years. One more night won't hurt."
/s Rings, necklaces, and gems cut to perfection! Come and sparkle!
]] }

L.Leatherworking = { "Leatherworking", [[
## The Hide
spreads a large, cured hide across the workbench and smooths it flat with both palms.
says, "A good hide is like a good story. You can feel where it's been."
runs a thumb along a faint old scar in the leather.
says, "This one had a fight with something. I'll work around it. Or into it. Scars add character."
## Tanning
stirs a barrel of dark, foul-smelling tanning liquid with a long wooden paddle.
says, "This is the part nobody talks about. The smell."
says, "I can't smell it anymore. My neighbors can. They've stopped visiting."
shrugs. [shrug]
## Cutting
traces a pattern onto the leather with a stick of chalk, then cuts it out with a sharp curved knife.
says, "Measure twice, cut once. Leather doesn't forgive."
says, "Cut too small and you've made a very expensive glove for a child."
## Stitching
punches a row of neat holes along the edge and begins stitching with thick waxed thread.
says, "A good stitch should outlast the wearer. That's the goal."
says, "My first stitches fell apart in a week. My master made me wear them anyway. Lesson learned."
## Armor
holds up a finished leather vest, dark and supple, reinforced at the shoulders.
says, "Leather armor's for those who need to move fast and hit first."
says, "Rogues, hunters, druids. People who don't like to stand still."
taps the reinforced shoulder approvingly. [nod]
## Drums and Kits
lifts a small leather drum and gives it a few quick taps. [dance]
says, "Leatherworkers make war drums too. Big ones. Loud ones."
says, "Beat this before a battle and everyone fights a little harder. Or at least a little louder."
## Armor Kits
says, "And armor kits. Little patches of extra leather to make armor tougher."
says, "Every adventurer wants one. Nobody wants to wait while I make it."
## Exotic Leathers
unrolls a shimmering, scaled hide that catches the light in strange colors. [gasp]
says, "Dragonscale. Rare, beautiful, and very hard to work."
says, "Ten hours just to cut it. The knife needs sharpening every few minutes."
## The Commission
looks {target} up and down with a craftsman's eye.
says <mood>, "You'd suit a dark brown. Something sturdy but not heavy. Give me your measurements."
says, "No, don't worry about the price yet. Worry about the fit. The price comes later."
## The Old Belt
pats a worn leather belt at their own waist.
says, "I made this belt when I was an apprentice. Twenty years ago."
says, "It's been through fire, flood and one very bad bar fight. Still holding."
## Tools
lays out the tools of the trade: awl, mallet, edger, swivel knife, burnisher.
says, "Every tool has a purpose. Every tool has a scar from when I used it wrong."
## Closing Up
rolls up the hides and hangs them on the rack to rest.
says, "Leather keeps you alive out there. I take that seriously."
/s Armor, bags, drums and boots! Built to last, built to fight!
]] }

L.Mining = { "Mining", [[
## The Pick
hefts a heavy iron pick over one shoulder and squints into the dark mouth of a cave.
says, "Down we go. Mind your head. The ceilings in here never warn you."
lights a lantern and hooks it to their belt.
says, "The deeper you go, the better the ore. And the worse the air. Fair trade."
## The Vein
stops at a glittering streak in the rock and runs a gloved hand along it.
says, "There. Copper. See how it shines green at the edges?"
swings the pick, and a chunk of ore breaks free with a satisfying crack. [flex]
says, "That's the sound of a good day."
## Ore Types
lines up chunks of ore in a row: copper, tin, iron, mithril, thorium.
says, "Copper's soft and friendly. Tin's soft and boring. Iron's honest. Mithril's a gift."
says, "Thorium is a nightmare wrapped in a rock. But oh, it's worth it."
## The Dark
holds up the lantern, peering into a passage that goes deeper than the light can reach.
says, "Every miner has a story about something they saw down here in the dark."
says, "Mine's about glowing eyes. Two of them. Very big. Very close."
says, "I don't go down that passage anymore."
## Kobolds
says <mood>, "And the kobolds. Always the kobolds."
says, "They yell 'you no take candle!' and throw rocks. Every single time."
says, "I've never taken a candle in my life. They don't believe me."
laughs. [laugh]
## Smelting
tips a crucible of ore into a roaring furnace and watches it glow.
says, "Ore's no good until it's smelted. The fire takes out everything that isn't metal."
pours the molten metal into a bar mold, sparks spitting. [gasp]
says, "Pure metal. Ready for the smiths."
## The Partner
nods to {target} and offers a spare pick.
says, "Want to try? Just swing at the shiny part. Not your foot. People always hit their foot."
## Gems in the Rock
cracks open a chunk of ore and finds a small gem gleaming inside. [cheer]
says, "Sometimes the mountain gives you a little gift. A gem, tucked inside the stone."
says, "Jewelcrafters pay well for these. I usually keep the pretty ones."
## Cave-ins
grows serious, looking up at the ceiling.
says, "I was caught in a cave-in once. Two days in the dark before they dug me out."
says, "I don't panic underground anymore. Panic uses up the air."
## Miner's Lungs
coughs, a deep rattling sound, and waves a hand. [cower]
says, "Dust. Gets in the lungs. Every old miner has the cough."
says, "Still wouldn't trade it. Nothing feels like breaking open a fresh vein."
## The Song
starts humming a low, steady tune, swinging the pick in rhythm.
says, "Miners sing to keep the rhythm. And to keep the dark from getting too quiet."
## Topside
climbs out into the daylight, blinking and covered in dust from head to toe.
says, "Daylight. I always forget how bright it is."
shakes out a heavy sack of ore with a grin. [cheer]
/s Fresh ore, straight from the mountain! Copper, iron, mithril and more!
]] }

L.Skinning = { "Skinning", [[
## The Knife
draws a curved skinning knife and checks the edge against a thumb.
says, "A dull knife is a dangerous knife. Keep it sharp, keep it clean, keep it close."
slides it back into its sheath with a soft click.
says, "This knife's older than me. Belonged to my grandfather. Still the best I've ever used."
## Respect
kneels beside a fallen beast and lays a hand on its flank for a quiet moment. [kneel]
says, "First, you thank the animal. Always. Out loud if you can."
says, "It gave everything. The least you can do is waste nothing."
## The Work
begins to work the knife carefully, peeling back the hide in long, smooth strokes.
says, "Slow is fast, out here. Rush it and you tear the hide, and then it's worth nothing."
says, "My father could skin a wolf in the time it took me to find the knife."
## Hides
holds up a hide to the light, checking for holes and thin spots.
says, "Light leather from the small beasts. Heavy leather from the big ones."
says, "Rugged leather from the things that tried very hard to kill me."
## Scales and Furs
runs a hand through a thick, luxurious pelt.
says, "Furs for the cold north. Scales from the swamps. Chitin from the bugs."
says, "Skinning a giant spider is the worst. You never forget the smell. Or the legs."
shudders. [cower]
## The Hunter's Friend
says, "Hunters and skinners are old friends. They bring the beasts, I bring the knife."
says, "Sometimes the same person does both. Efficient. Smelly, but efficient."
## Dragonhide
lowers their voice, eyes wide. [gasp]
says, "I skinned a dragon once. Only once. It was already very dead. I checked three times."
says, "Took me a whole day. My hands ached for a week. Best hide I ever sold."
## Salting
packs a fresh hide in coarse salt, rubbing it in with steady hands.
says, "Salt keeps it from rotting until the tanner gets it."
says, "My hands are always cracked from the salt. Occupational hazard."
## The Market
says <mood>, "Leatherworkers fight over my hides at the market, {target}."
says, "Not actually fight. Mostly glare. Some light shoving. It's very civilized."
## The Lesson
hands {target} a small, sharp knife, handle first.
says, "Here. Hold it like this. Gently. You're not stabbing, you're separating."
says, "Don't make that face. Everyone makes that face the first time."
## Waste Nothing
bundles up the bones and sinew with a length of twine.
says, "Bones for the bone-carvers. Sinew for the bowyers. Fat for candles. Nothing goes to waste."
## Closing Up
wipes the knife clean on a cloth and sheathes it with a nod. [nod]
says, "Good hunting today. The leatherworkers will be pleased."
/s Fresh hides and furs! Light, heavy, rugged and rare!
]] }

L.Archaeology = { "Archaeology", [[
## The Survey
unfolds a battered survey tool and peers through its little lens at the horizon.
says, "Somewhere under this ground is a story nobody has read in a thousand years."
plants a small flag in the dirt with great ceremony. [point]
says, "And we're going to dig it up. Very carefully. With a brush."
## The Dig Site
kneels beside a shallow pit and begins brushing away soil with a soft little brush. [kneel]
says, "Slowly, slowly. Rush it and you break something irreplaceable."
says, "I once broke a three-thousand-year-old vase by sneezing. I still think about it."
## The Find
gasps as the brush reveals the edge of something carved and ancient. [gasp]
says, "Look at that. Look at that! Troll work. Very old. Very, very old."
lifts the fragment out as gently as a newborn.
## The Fragments
lays out a dozen broken pieces on a cloth, turning them this way and that.
says, "Archaeology is mostly puzzles. Very old, very dirty puzzles with missing pieces."
says, "This bit goes here. I think. Unless it goes there. Or it's from a different pot entirely."
## Races of Old
says, "Dwarf, troll, night elf, tol'vir, fossil. Every race leaves something behind."
says, "Pots, coins, statues, bones. A little bit of everyone who ever lived."
## The Fossil
holds up a small fossil, a tiny creature curled forever in stone.
says <mood>, "This little thing lived before any of us. Before cities. Before names."
says, "And here it is, in my hand. Doesn't that make you feel small, {target}? In a good way?"
## Rivals
says, "Every archaeologist has a rival. Mine steals my dig sites and leaves rude notes."
says, "Last time he wrote 'too slow' on a rock. I've kept the rock. It's evidence."
## The Rare One
lowers their voice reverently. "Every so often you find something truly rare. A crown. A sword. A story."
says, "I found a little carved bird once. Rare, they said. Priceless, they said."
says, "I put it on my shelf. It's the first thing I see every morning."
## Dust and Danger
says, "Ancient sites have ancient traps. Spikes, falling stones, very angry spirits."
says, "I've been chased by a mummy. Twice. Different mummies."
laughs. [laugh]
## The Journal
opens a dog-eared journal full of sketches and notes.
says, "Every find gets a sketch, a date, and a guess. My guesses are usually wrong."
says, "That's the fun part. Being wrong is how you learn."
## The Lecture
clears their throat and adopts a scholarly tone.
says, "You see, {target}, the past isn't dead. It's just waiting for someone to listen."
says, "And I'm a very good listener. Also a very good digger."
## Packing Up
wraps each fragment in soft cloth and packs them into a crate.
says, "Back to the museum with these. Or my shelf. We'll see."
/s Artifacts, fossils and relics of the ancient world! Ask me about my dig!
]] }

L.FirstAid = { "First Aid", [[
## The Kit
unrolls a worn canvas kit full of bandages, splints, salves and little bottles.
says, "Every adventurer should carry one of these. Most don't. That's why I'm busy."
checks each item in turn, counting under their breath.
says, "Linen bandages, wool bandages, a splint, and one very old bottle of something."
## The Wounded
kneels beside {target} with a look of practiced calm. [kneel]
says <mood>, "Let me see. No, don't hide it. I've seen worse. I've seen much worse."
peels back a torn sleeve carefully.
says, "That's a nasty cut. Hold still. This part stings."
## Bandaging
wraps a bandage around the wound in neat, firm turns.
says, "Not too tight, not too loose. Tight enough to stop the bleeding, loose enough to keep the arm."
ties it off with a small, efficient knot. [nod]
## Linen and Wool
holds up two bandages side by side.
says, "Linen for little scrapes. Wool for the bigger ones. Silk for the really bad days."
says, "Runecloth for when someone's fought a dragon. I keep a lot of runecloth."
## Antivenom
uncorks a small bottle and sniffs it, wincing.
says, "Antivenom. Tastes terrible. Works wonders."
says, "If something bites you in the swamp, drink this first and ask questions later."
## Field Medicine
says, "Healers have the Light. Druids have nature. I have bandages and a steady hand."
says, "No magic. Just knowing where everything goes and what to do when it goes wrong."
## The Battlefield
grows quiet, looking at their own steady hands.
says, "I've patched people up in the middle of battles. Arrows flying, everyone shouting."
says, "You learn to shut it all out. Just you and the wound. Nothing else exists."
## Bedside Manner
says, "Half of first aid is the bandage. The other half is talking."
says, "Keep them calm. Keep them talking. Tell them a joke. A bad one works best."
says, "What do you call a warrior with no bandages? Lucky so far."
chuckles. [chuckle]
## The Splint
lashes a splint to a broken arm with strips of linen.
says, "Broken bones need time. You can't rush them, no matter how loudly the warrior complains."
says, "And they always complain. Warriors are terrible patients."
## The Lesson
hands {target} a roll of bandages.
says, "Here. Practice on me. Wrap my hand. Gently. No, gently. That's a tourniquet."
laughs as the bandage turns into a tangle. [laugh]
## Gratitude
says, "Most people forget who bandaged them, once they're well."
says, "That's fine. It means they're well. That's the whole point."
## Packing Up
rolls the kit closed and slings it over a shoulder.
says, "Back to the road. Somebody out there is about to need me."
/s First aid! Bandages, splints and antivenom! Bring me your scrapes and your bruises!
]] }
