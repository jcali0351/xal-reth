-- StoryCaster: "What are you doing?" A player types their status ("fishing by the lake", "waiting for a friend",
-- "read a book by the fire") and gets 25 lines for it: from the activity library (StatusLines.lua) when the words
-- match one, otherwise 25 lines written around their own words.
local ADDON, ns = ...
local R = ns.R
R.STATUS_COUNT = 25
R.STATUS_GAP = 15

local function trim(s) return (s:gsub("^%s+", ""):gsub("%s+$", "")) end

-- what they typed, as a phrase that reads after "busy with" or "looks up from": "fishing by the lake"
local LEAD = { "^i'?m%s+", "^i%s+am%s+", "^im%s+", "^currently%s+", "^just%s+", "^busy%s+", "^now%s+", "^is%s+", "^am%s+", "^we're%s+", "^we%s+are%s+" }
local PREP = { at = 1, ["in"] = 1, on = 1, by = 1, near = 1, with = 1, under = 1, inside = 1, outside = 1, around = 1, beside = 1 }
local DOUBLE = { sit = 1, run = 1, swim = 1, get = 1, shop = 1, plan = 1, chat = 1, dig = 1, hug = 1, jog = 1, nap = 1, stop = 1, skip = 1, sip = 1, wrap = 1, drop = 1, set = 1, put = 1, cut = 1, hit = 1, win = 1, beg = 1, rob = 1, rub = 1, spin = 1, trek = 1, plot = 1 }

local function gerund(w)
  local low = w:lower()
  if low:sub(-3) == "ing" then return w end
  if DOUBLE[low] then return w .. w:sub(-1) .. "ing" end
  if low:sub(-2) == "ie" then return w:sub(1, -3) .. "ying" end
  if low:sub(-1) == "e" and not low:match("[eoy]e$") and #low > 2 then return w:sub(1, -2) .. "ing" end
  return w .. "ing"
end

function R:StatusPhrase(text)
  local s = trim((text or ""):gsub("[|\r\n]", " "):gsub("%s+", " "))
  s = s:gsub("[%.!]+$", "")
  -- "I'm", "currently", "just" and so on at the front, in any capitals
  for _ = 1, 3 do
    for _, p in ipairs(LEAD) do
      local _, e = s:lower():find(p)
      if e then s = s:sub(e + 1) end
    end
  end
  s = trim(s)
  if s == "" then return nil end
  local first, rest = s:match("^(%S+)%s*(.*)$")
  local low = first:lower()
  if PREP[low] then return "spending time " .. s end
  if low:sub(-3) == "ing" then return s end
  -- a verb at the front becomes its -ing form: "read a book" -> "reading a book"
  return trim(gerund(first) .. " " .. rest)
end

-- the best-matching activity: the most of its words found in what they typed
function R:MatchActivity(text)
  local hay = " " .. (text or ""):lower():gsub("[^%w%s']", " ") .. " "
  local best, score = nil, 0
  for _, a in ipairs(self.ACTIVITIES or {}) do
    local n = 0
    for _, w in ipairs(a.words) do
      if hay:find("%f[%w]" .. w:gsub("(%W)", "%%%1") .. "%f[%W]") then n = n + (w:find(" ") and 2 or 1) end
    end
    if n > score then best, score = a, n end
  end
  return best, score
end

-- 25 lines written around their own words ({act} is the phrase)
local GENERIC = {
  "is {act}, quietly absorbed in it.",
  "carries on {act}, unhurried.",
  "says <mood>, \"Don't mind me. Just {act}.\"",
  "pauses for a moment, then goes back to {act}.",
  "glances up from {act} as {target} comes near.",
  "says, \"Have you ever tried {act}, {target}? You should.\"",
  "hums to themselves while {act}.",
  "stretches, then settles back into {act}. [sigh]",
  "says <mood>, \"There's something peaceful about {act}.\"",
  "loses track of time, {act}.",
  "smiles to themselves, still {act}.",
  "says, \"Give me a moment. I'm in the middle of {act}.\"",
  "frowns in concentration while {act}.",
  "takes a short break from {act} to look around.",
  "says <mood>, \"Some days are for adventure. Today is for {act}.\"",
  "laughs softly at something while {act}. [chuckle]",
  "goes on {act}, as if the rest of the world could wait.",
  "says, \"You're welcome to join me, {target}. I'm only {act}.\"",
  "nods to a passerby without stopping {act}. [nod]",
  "sighs contentedly, {act}. [sigh]",
  "says <mood>, \"I could spend all day {act}.\"",
  "makes a little progress, then a little more, still {act}.",
  "looks up at the sky for a while, then returns to {act}.",
  "says, \"Funny how {act} can clear your head.\"",
  "finally sets it all aside, done with {act} for now. [nod]",
}
R.STATUS_GENERIC = GENERIC

-- the 25 lines for a status, as text: { title, text, activity or nil }
function R:StatusLines(text)
  local a = self:MatchActivity(text)
  if a then
    local out = {}
    for i = 1, math.min(self.STATUS_COUNT, #a.lines) do out[i] = a.lines[i] end
    return a.title, table.concat(out, "\n"), a
  end
  local act = self:StatusPhrase(text)
  if not act then return nil end
  local out = {}
  for i, t in ipairs(GENERIC) do out[i] = (t:gsub("{act}", (act:gsub("%%", "%%%%")))) end
  local title = act:sub(1, 1):upper() .. act:sub(2)
  if #title > 34 then title = title:sub(1, 32) .. "..." end
  return title, table.concat(out, "\n"), nil
end

-- the Ideas tab and /story status: write the 25 lines and show them as an idea to Perform or Edit
function R:WriteStatus(text)
  text = trim(text or "")
  if text == "" then self:Print("Type what you're doing first: fishing by the lake, waiting for a friend, anything.") return nil end
  self.db.status = text
  local title, body, a = self:StatusLines(text)
  if not title then self:Print("I couldn't read that. Try something like: fishing by the lake.") return nil end
  self.statusIdea = { title = "Status: " .. title, text = "## " .. title .. "\n" .. body, status = true, activity = a and a.key }
  self.ideaProfile = nil
  self.ideas = { self.statusIdea }
  self.statusPool = nil
  self:Print(("|cffeec060%s|r: 25 lines ready%s. Perform plays them on your timer; Line says one now."):format(title, a and "" or ", written around your words"))
  self:Refresh()
  return self.statusIdea
end

function R:StatusWait() return math.max(0, (self.statusReady or 0) - GetTime()) end

-- one line from the current status, now (your click), at most once every 15 seconds
function R:StatusLine()
  local idea = self.statusIdea
  if not idea then
    if self.db.status then idea = self:WriteStatus(self.db.status) end
    if not idea then return nil end
  end
  local wait = self:StatusWait()
  if wait > 0 then self:Print(("One line is resting: %ds."):format(math.ceil(wait))) return nil end
  if not self:CanEmote() then self:Print("Not now: you are in combat or a boss fight.") return nil end
  -- a shuffled pool, so lines don't repeat until all 25 have been used
  if not self.statusPool or #self.statusPool == 0 then
    local s = self:Convert(idea.text, "lines", false)
    local pool = {}
    for _, l in ipairs(s) do if (l[1] or "") ~= "" then pool[#pool + 1] = l end end
    for i = #pool, 2, -1 do local j = math.random(i); pool[i], pool[j] = pool[j], pool[i] end
    self.statusPool = pool
  end
  local line = table.remove(self.statusPool)
  if not line then return nil end
  self:Perform(line, true)
  self.statusReady = GetTime() + self.STATUS_GAP
  self:Refresh()
  return line
end
