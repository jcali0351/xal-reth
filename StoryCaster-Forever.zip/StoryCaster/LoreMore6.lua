-- StoryCaster lore library: further scenes for the occasions.
local ADDON, ns = ...
local R = ns.R
R.LORE_MORE = R.LORE_MORE or {}
R.LORE_MORE.occasion = R.LORE_MORE.occasion or {}
local M = R.LORE_MORE.occasion
local function add(k, s) M[k] = (M[k] or "") .. s end

add("Wedding", [[
## The Rings
pats every pocket in turn, growing steadily more alarmed.
says, "The rings. I was given one job. Where are the rings?"
finds them at last in a boot and holds them up in triumph. [cheer]
says, "Found them! Nobody saw that. Nobody tell them about the boot."
## The Families
looks across the aisle, where two families eye each other warily.
says, "Two families, one table. It'll be fine. Probably. Someone hide the good wine."
says, "By the end of the night they'll be singing together. That's what weddings do."
## The First Kiss
claps loudly as the couple kiss, whistling through their fingers. [applaud]
says, "Finally! I've been waiting for that since the day they met!"
## The Bouquet
watches the bouquet sail through the air straight toward them, and steps smartly aside.
says, "Oh, no. Not me. I'm a {class}. I'm married to the road."
watches someone else catch it and shrugs, grinning. [shrug]
## Late Night
sits with the last of the guests as the lanterns burn low.
says, "Look at them, still dancing. Like nobody else in the world exists."
says, "That's how you know. When the whole world can go home and they don't even notice."
## The Last Toast
raises one final cup, voice a little hoarse from singing.
says, "To love that's stubborn. To love that's patient. To love that shows up."
says, "To both of you. Now, somebody find me my other boot."
laughs and drains the cup. [laugh]
## Morning After
says, "Weddings are the best kind of tired. Feet ache, face hurts from smiling."
says, "I'd do it all again tomorrow. Please don't make me do it all again tomorrow."
]])

add("Funeral", [[
## The Procession
walks slowly behind the procession, matching their steps to the slow beat of a drum.
says, "They'd have hated this pace. Always rushing. Always first through the door."
says, "Slow down, they'd say. No, wait, they'd never say that. Speed up, they'd say."
## Their Things
holds up a battered helmet, dented in a dozen places.
says, "They wore this through every battle. Never let anyone repair it."
says, "Said every dent was a story. I know most of them. I'll tell you all of them, one day."
sets the helmet down gently atop the grave. [kneel]
## The Song
begins to sing an old song, voice wavering at first, then steadying.
says, "This was their favorite. They sang it terribly. Every single verse, every single night."
says, "Sing it with me. Badly. That's how they'd want it."
## The Wake
says, "Later we'll gather at the tavern and drink to them until the barkeep throws us out."
says, "It's what they'd want. They'd be the first one thrown out. They usually were."
smiles through tears. [chuckle]
## The Weight
stands alone for a moment, staring at the fresh earth.
says, "Everyone says they're in a better place."
says <mood>, "I just wish the better place was here, with us. Next to me. Late, as always."
## Letting Go
takes a deep, slow breath and lets it out. [sigh]
says, "Grief doesn't end. You just grow bigger around it. That's what my elders told me."
says, "I'll grow. Slowly. For them."
## Walking Away
turns from the grave, then glances back one last time.
says, "Same time next year, old friend. I'll bring the terrible ale."
]])

add("DepartingForBattle", [[
## The Armor
runs a hand over a dented breastplate, remembering each mark.
says, "This one is from the last campaign. This one, the one before."
says, "Every dent is a blow that didn't reach me. I'm grateful for every single one."
## The Young Ones
spots a nervous young recruit fumbling with their gear and walks over.
says, "First battle? Here, your strap's twisted. Let me fix it."
says, "Stay close to me. Watch my back. I'll watch yours. That's how we get home."
claps the recruit on the shoulder. [nod]
## The Plan
unrolls a map across a barrel, pointing out positions.
says, "They'll come through the pass. We hold the line here, at the narrow point."
says, "Archers on the ridge. Healers behind the second rank. Nobody plays hero."
says, "Heroes get statues. I'd rather get supper."
## Prayer
kneels briefly, head bowed, lips moving in silent prayer. [kneel]
says, "Whatever you believe in, now's the time to ask it for a favor."
rises, steadier than before.
## The Horns
lifts their head sharply as war horns sound in the distance. [gasp]
says, "That's the signal. They're coming."
says <mood>, "Right then. Let's go and be brave. Or at least look brave until it turns into the real thing."
## The Watchers
waves to the people watching from the walls, children on shoulders, faces pale.
says, "That's why we go. So they never have to."
says, "Every {race} child should grow up knowing the walls held."
## Steel
draws their weapon in one smooth motion and holds it high.
says, "Steady now. Breathe. Find your feet. Find your friends."
says, "And when it starts, don't stop until it's over."
/y Hold the line!
]])

add("BirthOfAChild", [[
## The Wait
paces the hallway outside a closed door, wringing their hands.
says, "How long does this take? It's been hours. Is it supposed to take hours?"
stops at the door, listens, then resumes pacing. [cower]
says, "I've stormed fortresses with less worry than this."
## The First Cry
freezes as a thin, furious cry rises from behind the door. [gasp]
says, "Is that... is that them? That's them! Listen to those lungs!"
says, "A future warrior. Or a future bard. Either way, very loud."
## Holding Them
holds the baby awkwardly at first, then more naturally, rocking gently.
says, "How do people do this? They're so fragile. And so heavy for something so small."
says, "Oh. They grabbed my finger. Look. They're holding on."
says <mood>, "I think I'd do anything for this little one. Anything at all."
## The Lullaby
hums a soft old lullaby, swaying gently from side to side. [dance]
says, "My mother sang this to me. Her mother sang it to her."
says, "Now I'm singing it to you. It's a terrible song about a goat. You'll love it."
## Promises
whispers to the sleeping baby.
says, "I promise to teach you everything I know. Even how to be a {class}, if you want."
says, "I promise to be there for the scraped knees and the broken hearts."
says, "And I promise never to embarrass you in front of your friends. That one's a lie."
## Celebration
throws open the window and shouts to the street below. [cheer]
says, "Drinks are on me tonight! Everyone! Even you, the grumpy dwarf!"
## Quiet
sits beside the cradle as night falls, watching the tiny chest rise and fall.
says, "Everything's different now. Everything's better."
]])

add("LossOfAFriend", [[
## Their Seat
glances at an empty stool at the tavern bar, the one they always took.
says, "The barkeep keeps it empty. Nobody's said anything. Nobody needs to."
lays a coin on the bar in front of the empty seat. [sigh]
says, "One for you, old friend. Your usual."
## Their Voice
says, "The worst part is I'm starting to forget their voice."
says, "I remember what they said. Not how it sounded."
says <mood>, "I'd give anything to hear them say something stupid one more time."
## The Last Conversation
says, "The last thing I ever said to them was 'see you tomorrow.'"
says, "Such an ordinary thing. I didn't know it was the last thing."
says, "Now I say goodbye properly to everyone. Every time. Just in case."
## Their Family
says, "I wrote to their family. Told them how brave they were. How kind."
says, "I told them about the time they carried me two miles on their back."
says, "I left out the part where they complained the whole way. That's for me to keep."
## Laughing Again
catches themselves laughing at something, then stops, guilty.
says, "Is it wrong to laugh? So soon?"
says, "No. They'd be furious if I stopped laughing. They'd call me boring."
laughs again, softer this time. [laugh]
## Keeping Them Close
says, "I'm naming my next mount after them. They'd hate it."
says, "Which is exactly why I'm doing it."
## Tomorrow
stands and stretches, looking toward the road ahead.
says, "Tomorrow I'll ride out again. I'll see something beautiful and think of them."
says, "That's how it'll be now. And that's all right."
]])

add("RomanceFirstMeeting", [[
## The Accident
bumps into {target} by accident, spilling a drink all over them both. [gasp]
says, "Oh, no. Oh, no, I am so sorry. Here, let me... no, that's making it worse."
dabs uselessly at the stain with a napkin.
says, "I'm usually much more graceful. That's not true. I'm never graceful."
## Introductions
holds out a hand, then realizes it's sticky and wipes it on their trousers first.
says, "Let's try that again. Hello. I'm the clumsy one. And you are?"
repeats the name softly, as if committing it to memory.
says, "That's a good name. It suits you."
## Common Ground
says, "Wait, you've been to the Barrens too? Did you hear about Mankrik's wife?"
says, "Everyone asks about her! I spent three days looking. I still feel bad about it."
laughs. [laugh]
## Nerves
fiddles with a sleeve, glancing up and away.
says, "Sorry. I'm nervous. You're very easy to talk to. That makes me more nervous."
says <mood>, "It's been a long time since I met someone I actually wanted to keep talking to."
## The Walk
says, "Can I walk you home? Or to the inn? Or to the next tavern? Wherever you're going."
says, "I promise not to spill anything else on you. I can't promise. I'll try."
## The Last Look
stops at the corner and turns back to wave one more time. [wave]
says, "Goodnight. Really. Goodnight. I'll stop saying goodnight now."
grins and finally walks away, nearly walking into a lamppost.
says, "I'm fine! Totally fine! That was on purpose!"
## Dreaming
lies awake that night, staring at the ceiling, smiling.
says, "I didn't even ask where they're staying. Brilliant. Absolutely brilliant."
says, "Same tavern tomorrow. Same table. Same terrible ale. It's a plan."
]])

add("RomanceQuietEvening", [[
## The Shooting Star
points suddenly as a star streaks across the sky. [point]
says, "Look! Make a wish. Quick, before it's gone."
closes their eyes tightly for a moment, then opens them and smiles at {target}.
says, "I'm not telling you mine. But it might already be coming true."
## Music
pulls out a small, battered flute and plays a few soft, uncertain notes.
says, "I'm not very good. I only know three songs. Two of them are the same song."
plays on anyway, the music drifting out over the water.
## Being Honest
says <mood>, "Can I tell you something? I don't usually do this. Slow nights. Quiet ones."
says, "My whole life has been roads and battles and noise. This is... nice. Peaceful."
says, "You make the quiet feel full instead of empty."
## Fireflies
watches as fireflies rise from the grass, drifting around them like tiny lanterns.
says, "Oh. Look at that. It's like the whole hill is lighting up just for us."
says, "I'd like to take credit for arranging it. I didn't. But I'd like to."
## The Cold Nose
laughs as {target} shivers, then pulls them closer under the cloak.
says, "Your nose is freezing. How is your nose this cold?"
says, "No, don't move. I'm fine. This is fine. This is better than fine."
## Promises Under Stars
says, "Next time I'll bring spoons. And a better pie. And no geese, I swear it."
says, "There will be a next time, won't there? Please say there will be a next time."
## The Walk Down
walks slowly down the hill, hand in hand, neither in any hurry.
says, "I think this is my favorite place in all of Azeroth now."
says, "Not because of the view. You know why."
]])

add("RomanceConfession", [[
## Practicing
practices in front of a puddle, talking to their own reflection.
says, "I care about you. No. I really like you. No. You are very... adequate."
groans and buries their face in their hands. [cry]
says, "This is harder than fighting a dragon. At least dragons don't expect you to talk."
## The Interruption
starts to speak just as a loud group of adventurers bursts past, shouting about loot.
says, "Of course. Of course that happens now."
waits for them to pass, then tries again.
## The Gift
pulls a small, carefully wrapped gift from a bag and holds it out.
says, "I made this for you. It's a little carving. It's meant to be a bird."
says, "It looks like a potato with wings. I'm a {class}, not a carpenter."
## The Memories
says, "Do you remember the night we got lost in the swamp? Soaking wet, freezing, arguing over the map?"
says, "That was when I knew. Standing in mud up to my knees, laughing so hard I couldn't breathe."
says <mood>, "You turned the worst night into the best one. You always do that."
## The Answer
holds very still, hardly daring to breathe, as {target} answers.
says, "Say that again. Please. Just once more. I want to remember exactly how it sounded."
## The Embrace
pulls {target} into a warm, tight embrace, laughing with relief.
says, "I've wanted to do that for so long. You have no idea."
says, "Or maybe you do. You always see right through me."
## The Future
says, "I don't know what tomorrow brings. Battles, probably. Bad weather. Terrible stew."
says, "But I'd like to face all of it with you. Every bit of it."
squeezes {target}'s hand gently.
]])
