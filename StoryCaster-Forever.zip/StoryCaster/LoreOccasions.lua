-- StoryCaster lore library: occasions. Generic scripts for life's big moments that fit any character:
-- {race} and {class} are yours, {target} is whoever you have targeted, and <mood> follows the Mood button.
local ADDON, ns = ...
local R = ns.R
R.LORE = R.LORE or {}
R.LORE.occasion = R.LORE.occasion or {}
local L = R.LORE.occasion

L.Wedding = { "A Wedding", [[
## Arriving
straightens their finest clothes and steps into the gathering, looking around at the flowers and the lanterns.
says, "I have walked a long road as a {class}. I have never been this nervous."
smiles <mood> at the guests filling the benches.
says, "Look at all of you. Every face here is a friend of theirs. That says everything."
## The Couple
turns toward the couple standing beneath the arch and lets out a slow breath. [sigh]
says, "I remember the day they met. Neither of them would admit it was love."
says, "One of them pretended to need help with a quest. The other pretended to believe it."
chuckles at the memory. [chuckle]
says, "Some of us knew right away. The rest of us had to be told. Repeatedly."
## The Toast
raises a cup high, and the gathering falls quiet.
says, "I'm a {race} of few words. So I'll keep this short."
says, "A home is not walls. It is the person who waits up for you."
says, "May you always have someone to wait up for. May you always come home."
says, "To the couple!" [cheer]
## The Vows
watches as the couple join hands, and blinks hard a few times.
says, "No, I'm not crying. There's dust. Weddings are very dusty."
wipes their eyes discreetly with a sleeve. [cry]
says, "Fine. I'm crying. Everyone cries at weddings. It's the rule."
## Advice
leans in close to the couple, lowering their voice.
says, "A piece of advice from someone who has made every mistake there is."
says, "Never go to sleep angry. Stay up and argue. Then make breakfast together."
says, "And never, ever let them hold the last healing potion. Share it."
## The Dance
holds out a hand toward {target} as the music begins. [bow]
says, "Come on. Nobody dances alone at a wedding. That's the other rule."
sways <mood> to the music, laughing as they step on someone's foot. [dance]
says, "Sorry! I'm better with a weapon than with my feet."
## The Feast
loads a plate high with roast, bread, and three different kinds of cake.
says, "The food at a wedding is the true test of a marriage."
says, "Judging by this cake, they will be very happy for a very long time."
## The Gift
sets a small wrapped package on the gift table.
says, "It's not much. A blanket I had made. Warm enough for two."
says, "For the cold nights. And the warm ones."
## Farewell
watches the couple leave beneath a shower of petals, waving until they are out of sight. [wave]
says, "Look after each other. That's all any of us can do."
/s Long life and a warm home to you both!
]] }

L.Funeral = { "A Funeral", [[
## Gathering
stands quietly at the edge of the gathering, head bowed, hands folded. [bow]
says, "Thank you all for coming. They would have been glad to see so many faces."
says, "They would also have complained about the weather. Loudly."
manages a small, sad smile.
## Who They Were
steps forward and looks out over the mourners.
says, "I knew them for many years. Long enough to know their worst jokes by heart."
says, "They were stubborn. They were loyal. They were always, always late."
says, "If they were here, they'd be late to this, too."
lets out a breath that is almost a laugh. [sigh]
## The Stories
says, "I remember the first time we fought side by side."
says, "I was a young {class}, scared out of my mind. They grinned and said, 'Stay behind me.'"
says, "I stayed behind them for years. I don't know how to stand anywhere else."
## The Loss
falls silent for a long moment, struggling for words.
says <mood>, "There is a place at the campfire that will always be empty now."
says, "We'll keep leaving room for them. Out of habit. Out of love."
wipes their eyes. [cry]
## What They Taught
says, "They taught me that courage isn't the absence of fear. It's going anyway."
says, "They taught me to share my last ration. To carry the wounded. To laugh in the rain."
says, "Every one of us here carries a little of them now. That's how they stay."
## The Customs
says, "My people, the {race}, have our own ways of saying goodbye."
says, "But grief is the same in every tongue. It's just love with nowhere left to go."
## Rest
kneels and lays a single flower beside the grave. [kneel]
says, "Rest now, old friend. You've earned it a thousand times over."
says, "We'll take it from here. We'll do our best. We'll be late, probably."
rises slowly, brushing earth from their knees.
## Comfort
turns to {target} and rests a hand on their shoulder.
says, "It's all right to grieve. It's all right to laugh, too. They'd want both."
says, "Come sit by the fire tonight. We'll tell the stories. All of them. Even the embarrassing ones."
## The Final Toast
raises a cup toward the sky.
says, "To the one who stood in front. May the road beyond be gentle, and may the ale be cold."
drinks, and stands silent a while longer. [salute]
/s Rest well, friend. We remember.
]] }

L.DepartingForBattle = { "Departing for Battle", [[
## The Dawn
stands at the edge of camp as the sun rises, checking their gear one strap at a time.
says, "Every {class} knows this feeling. The quiet before the march."
tightens the last buckle and tests the weight of their weapon.
says, "My hands are steady. My stomach disagrees."
## The Gathering
turns to face the gathered soldiers, raising their voice so it carries.
says, "Listen to me! I know some of you are afraid. So am I."
says, "Fear means you understand what's at stake. Good. Bring it with you. Use it."
says <mood>, "But leave the doubt here. There's no room for it where we're going."
## Who We Fight For
says, "Look to your left. Look to your right. That's who you're fighting for."
says, "Not a banner. Not a king. The person next to you."
says, "Keep them alive. They'll keep you alive. That's the whole of it."
## Last Letters
pulls a folded letter from their coat and holds it a moment before sealing it.
says, "Everyone writes one before a battle. Just in case."
says, "Mine says I'm sorry for the things I never said. And thank you for everything else."
hands the letter to the quartermaster with a nod. [nod]
says, "If I come back, burn it. If I don't, read it slowly."
## The Goodbye
turns to {target} and grips their forearm tightly.
says, "Don't look at me like that. I'll be back before the stew gets cold."
says, "And if I'm not, eat my share. It's terrible stew. You'll be doing me a favor."
manages a crooked grin. [chuckle]
## The Battle Cry
lifts their weapon high, and the light catches the edge. [roar]
says, "For every home behind us! For everyone who can't fight for themselves!"
says, "We are the wall. Let them break against us!"
/y For our homes! For each other!
## The March
falls into step with the column as the drums begin to beat.
says, "One foot, then the other. That's all a march is."
says, "Sing if you know the words. Hum if you don't. Just don't stop walking."
begins humming an old marching song, low and steady.
## The Promise
glances back once at the camp, and the faces watching from it.
says, "I promised someone I'd come home. I keep my promises."
says, "Every {race} I know keeps their promises. Even the stubborn ones. Especially the stubborn ones."
## Onward
faces the horizon, shoulders squared, and does not look back again.
says, "Let's go. They're waiting for us. Let's not keep them waiting."
salutes the camp one last time and marches into the dawn. [salute]
]] }

L.BirthOfAChild = { "The Birth of a Child", [[
## The News
bursts through the door, breathless, eyes wide. [gasp]
says, "It's happened. It's happened! The baby's here!"
grabs {target} by both shoulders and shakes them with joy.
says, "I'm a parent. Me! Can you believe it? I can't believe it."
## First Sight
lowers their voice to a whisper, cradling a tiny bundle wrapped in soft blankets.
says, "Look at them. So small. Ten fingers, ten toes. I counted three times."
says, "They have my nose. I'm sorry, little one. It gets better. A bit."
gazes down at the baby with an expression of pure wonder.
## The Name
says, "We've been arguing about the name for months."
says, "I wanted to name them after a great {class} of legend. My partner said absolutely not."
says, "We compromised. My partner chose. That's how compromise works, I've learned."
laughs softly, careful not to wake the baby. [chuckle]
## Fear
grows quiet, staring at the sleeping child.
says <mood>, "I've faced dragons. I've faced the dead walking. Nothing scared me like this."
says, "Now there's someone in the world who needs me to be good. Every day. Forever."
says, "I hope I'm good enough. I'll try. I'll try so hard."
## The Blessing
lays a gentle hand on the baby's head.
says, "Among my people, the {race}, a newborn gets a blessing on their first day."
says, "May you be braver than me, kinder than me, and much better at saving gold than me."
bows their head over the child for a long moment. [bow]
## Visitors
grins as friends crowd into the room.
says, "Quiet, quiet! Yes, you can hold them. Support the head. No, the other end is the head."
says, "Mind the warrior. He's already crying. He's been crying for an hour."
## Sleep
yawns enormously, eyes heavy. [sigh]
says, "I haven't slept in two days. I'm told I won't sleep for the next eighteen years."
says, "That's fine. I'll sleep when I'm dead. Or when they're grown. Whichever comes first."
## The Future
holds the baby up to the window, where the sun is rising.
says, "Look, little one. That's the world. It's big and strange and sometimes scary."
says, "But it's full of good people too. You'll meet them. I'll introduce you."
## Gratitude
turns to {target} with shining eyes.
says, "Thank you for being here. For all of it. You're family now. No arguments."
/s Everyone, meet the newest member of the family!
]] }

L.LossOfAFriend = { "The Loss of a Friend", [[
## Alone
sits alone at the edge of the camp, staring into the fire. [sit]
says, "I keep looking up, expecting to see them walk in. Late, as usual."
says <mood>, "They're not coming. I know that. My heart hasn't caught up yet."
## The News
says, "I found out from a stranger. A courier with a letter and a blank face."
says, "Just a few lines. Fell at the front. Bravely. They always say bravely."
crumples the letter slowly in one hand.
says, "I hope it was true. I hope it was quick."
## Memories
smiles faintly at something only they can see.
says, "We met in a tavern. They spilled a whole tankard on me and then charged me for it."
says, "I should have walked away. Instead I bought the next round. Best decision I ever made."
laughs, and it turns into something else halfway through. [cry]
## The Things They Left
pulls a small, worn trinket from a pouch: a carved wooden charm.
says, "They gave me this. Said it was lucky. It's a rock with a face scratched into it."
says, "It's not lucky. It never was. I'll carry it forever."
## Anger
clenches a fist, jaw tight.
says, "I should have been there. If I'd been there, maybe..."
says, "No. They'd hate me thinking like that. They'd tell me to stop being dramatic."
lets the fist slowly fall open. [sigh]
## What Now
says, "Everyone says it gets easier. I don't want it to get easier. Not yet."
says, "If it gets easier, it means I'm forgetting. I'm not ready to forget."
## The Comfort of Friends
looks up as {target} sits beside them.
says, "You don't have to say anything. Just... stay a while. That's enough."
says, "They liked you, you know. Said you were the only one who laughed at their jokes."
## Carrying On
says, "As a {class}, I've learned to keep going. Through anything."
says, "So I'll keep going. For both of us now. I'll see the places we never reached."
## The Promise
lifts the little charm toward the stars.
says, "I'll tell everyone your stories. The good ones and the ridiculous ones."
says, "Nobody's going to forget you. I won't let them."
## Rest
tucks the charm away and stands, wiping their face. [nod]
says, "Goodbye, old friend. Save me a seat by whatever fire you're sitting at now."
/s To absent friends.
]] }

L.RomanceFirstMeeting = { "Romance: First Meeting", [[
## The Glance
notices {target} across the room and glances away quickly, then back again.
says, "Sorry. I didn't mean to stare. I was just... you have something on your... no. You don't. Never mind."
looks down, cheeks warming. [shrug]
## The Approach
gathers their courage and walks over, nearly tripping on a chair along the way.
says, "Hello. I'm a {race} {class}, and I'm usually much smoother than this."
says, "That's a lie. I'm never smooth. But I'm very honest. That counts for something."
## Conversation
sits down across from {target}, hands fidgeting on the table.
says, "So. What brings you here? Adventure? Gold? The terrible ale?"
listens carefully, leaning in a little closer. [nod]
says, "Really? Me too. Well, mostly the ale. It's terrible, but it's cheap."
## The Laugh
laughs suddenly, genuinely, at something {target} says. [laugh]
says, "Sorry, that was loud. You're funny. I didn't expect that."
says <mood>, "Most people I meet in taverns just want to fight me. This is nicer."
## The Stories
says, "I once fought a giant spider for three hours. It turned out to be a very large hat stand."
says, "In my defense, it was dark, and the hat stand was very aggressive."
grins sheepishly.
## The Compliment
pauses, looking at {target} a little longer than necessary.
says, "You have a nice laugh. I'd like to hear it again sometime."
says, "That was too much, wasn't it? Forget I said that. Don't forget it. I meant it."
## The Offer
says, "There's a lantern festival in town tomorrow night. Lights on the water and terrible music."
says, "Would you like to go? With me? To the terrible music?"
holds their breath, waiting for an answer.
## The Parting
stands as the evening ends, lingering a moment.
says, "I had a really good time. Better than the giant spider. Much better than the hat stand."
says, "Same table tomorrow? I'll be the one pretending not to watch the door."
bows a little awkwardly, then waves on the way out. [wave]
## After
pauses outside, leaning against the wall with a dazed smile.
says, "Well. That happened."
/s Best night in a long time.
]] }

L.RomanceQuietEvening = { "Romance: A Quiet Evening", [[
## The Spot
spreads a blanket on a hill overlooking the lake, then sets down a basket.
says, "I found this place on a patrol once. I've been saving it for someone special."
pats the blanket beside them, looking up at {target}. [sit]
says, "Sit with me?"
## The Basket
opens the basket and lays out bread, cheese, fruit, and a slightly squashed pie.
says, "I packed it myself. The pie had an accident. The pie is fine. Mostly."
says, "I'm a {class}, not a baker. Please lower your expectations accordingly."
## The Sunset
watches the sun sink low, the lake turning gold, then rose, then deep blue.
says <mood>, "I've seen a thousand sunsets on the road. This is the first one I've really looked at."
says, "I think it's the company."
glances sideways at {target}, then quickly back at the water.
## Stories
says, "Tell me something about you. Something no one else knows."
listens quietly, chin resting on one hand. [nod]
says, "Thank you for telling me. I'll keep it safe."
## Confessions
says, "Here's one of mine. I'm terrified of geese."
says, "Not dragons. Not demons. Geese. They know what they did."
laughs, a little embarrassed. [laugh]
## The Stars
lies back on the blanket as the first stars come out.
says, "My people, the {race}, have a story about the stars."
says, "They say every star is a promise someone made and kept."
points upward. [point]
says, "That bright one there? That's going to be mine. I'm still working on it."
## Closer
shifts a little closer, until their shoulders are just touching.
says, "Is this all right?"
says, "Good. I've been wanting to do that for about three hours."
## The Cold
pulls a cloak from the basket and wraps it around {target}'s shoulders.
says, "It gets cold up here once the sun's gone. I came prepared."
says, "Mostly I came prepared. I forgot spoons. We'll eat the pie with our hands."
## The Moment
grows quiet, simply watching the stars wheel overhead.
says, "I don't want this night to end."
says, "But if it does, I want another one just like it. And another after that."
## Walking Home
packs the basket slowly, reluctant to leave, then offers {target} a hand up.
says, "Let me walk you home. The long way. If that's all right."
/s Best evening I've had in years.
]] }

L.RomanceConfession = { "Romance: The Confession", [[
## Working Up the Courage
paces back and forth, muttering to themselves.
says, "Just say it. Just walk up and say it. It's three words. You've said harder things to dragons."
stops, takes a deep breath, then starts pacing again. [sigh]
## Finding Them
spots {target} and freezes for a moment, then walks over with determined steps.
says, "Hello. Hi. Do you have a moment? It's important. Or it's not. It's important to me."
## The Rambling
says, "So. You know we've been traveling together for a while now. Fighting, camping, eating terrible stew."
says, "And I've been thinking. A lot. Probably too much. About you."
says, "Not in a strange way. In a nice way. I hope it's a nice way."
rubs the back of their neck nervously. [shrug]
## The Truth
stops rambling and looks {target} straight in the eye.
says <mood>, "I care about you. More than a friend should. More than a {class} probably should, out here."
says, "I've known it for a long time. I was afraid to say it in case it ruined everything."
## The Reasons
says, "You make the long roads shorter. You make the cold nights warmer."
says, "When things go wrong, you're the first person I look for."
says, "When things go right, you're the first person I want to tell."
## The Fear
says, "If you don't feel the same, I understand. Truly. Nothing has to change."
says, "I'll still guard your back. I'll still share my rations. I'll still complain about the stew."
says, "I just couldn't go another day without you knowing."
## The Wait
falls silent, holding their breath, waiting for an answer.
says, "You can say something now. Anything. Even 'that was very long'. It was very long."
## Relief
lets out a shaky breath, a smile breaking slowly across their face.
says, "Really? You mean it? You're not just saying it because I look like I'm about to faint?"
laughs, half in relief and half in disbelief. [laugh]
## Together
takes {target}'s hand carefully, as if it might vanish.
says, "Then let's figure it out together. One road at a time."
says, "My people, the {race}, say that a promise made under the open sky can never be broken."
looks up at the sky, then back at {target}. [kneel]
says, "So here's mine. I'll stand beside you. Whatever comes."
## After
rises, still holding their hand, grinning like a fool.
says, "I can't stop smiling. My face hurts. This is your fault."
/s I'm the luckiest {class} in all of Azeroth.
]] }
