-- StoryCaster lore library: further scenes for the newer professions.
local ADDON, ns = ...
local R = ns.R
R.LORE_MORE = R.LORE_MORE or {}
local function add(kind, k, s)
  R.LORE_MORE[kind] = R.LORE_MORE[kind] or {}
  R.LORE_MORE[kind][k] = (R.LORE_MORE[kind][k] or "") .. s
end

add("profession", "Enchanting", [[
## The Old Master
says, "My master was an old elf who could enchant a blade with a whisper."
says, "She told me magic isn't forced. It's invited. Like a cat."
says, "I didn't understand until I tried to force it. The table caught fire."
## The Illusion
waves a hand, and a tiny shimmering butterfly of light flutters up from the bench. [cheer]
says, "Not useful. Not valuable. Just pretty. Every enchanter needs one trick like this."
watches it fade with a fond smile.
## The Ledger
says, "Every enchantment I sell, I write down. Who, what, when."
says, "If a sword I enchanted ever does something terrible, I want to know about it."
says, "So far it's mostly been toasting bread. Very warm swords, mine."
## Tired Eyes
rubs their eyes, which glow faintly violet for a moment. [sigh]
says, "Too long staring at runes. Everything glows for an hour afterward."
says, "It's fine. Free nightlight."
]])

add("profession", "Inscription", [[
## The Map
unrolls a hand-drawn map, each road and river inked with careful precision.
says, "Scribes draw maps too. This one took me a month."
says, "Then someone moved the road. Roads should stay where you draw them."
grumbles under their breath. [shrug]
## The Letter
says, "People come to me to write letters they can't find the words for."
says, "Love letters. Apologies. Goodbyes. I've written them all."
says, "The hardest are the goodbyes. I always cry a little. Ruins the ink."
## Ink Stains
holds up fingers stained every color of the rainbow.
says, "A scribe's hands never come clean. It's how you spot us in a crowd."
says, "That, and the squinting. We squint a lot."
squints dramatically at {target}. [chuckle]
## The Rune of Warding
draws a careful circle of runes on a doorframe, murmuring as they work.
says, "A little ward for the inn. Keeps out bad luck and drafts. Mostly drafts."
steps back to admire the work. [nod]
]])

add("profession", "Jewelcrafting", [[
## The Mistake
says, "My first cut gem shattered into forty pieces. I cried for an hour."
says, "My master swept up the pieces, handed me another stone, and said 'again'."
says, "That's the whole lesson of this craft. Again. Again. Again."
## The Crown
says <mood>, "I was asked to make a crown once. For a minor noble. Very minor."
says, "He wanted rubies. I gave him garnets. He never knew the difference."
says, "Don't tell him. He's still very proud of it."
laughs quietly. [laugh]
## The Light
holds a cut sapphire up to the window, and blue light scatters across the walls. [gasp]
says, "This is why I do it. Just this. Light, broken into pieces, and made beautiful."
## The Gift
presses a small polished stone into {target}'s hand.
says, "Here. Just a little moonstone. It's not worth much. But it's lucky."
says, "Well. I've always been lucky since I started carrying one. Coincidence, probably."
## Steady Hands
holds out both hands, perfectly still. [flex]
says, "No coffee. No ale before noon. A jeweler's hands must never shake."
]])

add("profession", "Leatherworking", [[
## The Saddle
runs a hand over a gleaming new saddle, tooled with swirling patterns.
says, "A saddle for a knight's warhorse. Three weeks of work."
says, "The horse bit me twice during the fitting. I'm choosing not to take it personally."
## Patterns
traces the tooled design with a fingertip: leaves, vines, a running stag.
says, "Every leatherworker has a signature pattern. Mine is the stag."
says, "If you find a stag on your boots, you'll know who made them."
## The Bag
holds up a bag with a surprising number of pockets.
says, "Adventurers always want more pockets. Pockets for potions. Pockets for maps."
says, "One asked for a pocket for his pocket. I made it. He was thrilled."
laughs. [laugh]
## Repairs
inspects a torn strap on {target}'s gear with a critical eye.
says <mood>, "Who stitched this? A troll with mittens?"
says, "Leave it with me. Come back tomorrow. It'll be better than new."
## The Old Craft
says, "Leatherworking is one of the oldest crafts there is. Older than metal."
says, "The first hunters wore hides. We're just doing it with more pockets."
]])

add("profession", "Mining", [[
## Lucky Pick
pats the handle of the pick, worn smooth by years of use.
says, "This pick has found more mithril than any other in the valley."
says, "I carved my initials in the handle. And a little tally for every big find."
says, "Running out of room. Good problem to have."
## The Mountain Speaks
presses an ear to the rock wall and listens. [kneel]
says, "Old miners swear the mountain talks. Little creaks, little groans."
says, "It's telling you where to dig, and where not to. You learn to listen."
## Dwarven Friends
says, "The dwarves taught me everything. They mine like they breathe."
says, "One old dwarf could find a vein of gold with his eyes closed."
says, "He said it hums. I've never heard it hum. I keep listening."
## Rich Strike
strikes a vein and gold dust spills out over their boots. [cheer]
says, "Oh. Oh, that's a good one. That's a very good one."
]])

add("profession", "Skinning", [[
## The Trail
crouches and studies a set of tracks pressed into the mud. [kneel]
says, "A skinner has to be a bit of a tracker too. The best hides are out where nobody goes."
says, "These are fresh. Something big came through here not an hour ago."
says, "Let's hope it's in a good mood."
## The Old Ways
says, "My people say the spirit of the beast lives on in the hide."
says, "That's why you treat it right. Clean it well. Use it well."
says, "A badly made coat is an insult to the wolf who gave it."
## Scars
holds out an arm crossed with old claw marks.
says, "Not every beast is dead when you think it is. Lesson learned."
says, "Always check twice. Then check again. Then poke it with a stick."
laughs ruefully. [laugh]
## The Pelts
spreads out a row of finished pelts, each one different.
says, "Wolf for warmth. Bear for strength. Fox for softness."
says, "And this one's a kodo. Nobody needs this much kodo. I have so much kodo."
sighs at the enormous pile. [sigh]
## Quiet Work
works the knife in silence for a long moment, unhurried and careful.
says <mood>, "People think this work is grim. It's not. It's honest."
]])

add("profession", "Archaeology", [[
## The Map of Sites
spreads a map covered in little circles, crosses and question marks.
says, "Every circle's a dig site. Every cross is a dig site I've emptied."
says, "Every question mark is somewhere I'm not allowed to dig. Yet."
grins conspiratorially at {target}. [chuckle]
## The Museum
says, "I gave my best finds to the museum in Ironforge."
says, "They put a little card next to each one with my name on it."
says, "I go and visit them sometimes. Just to say hello."
## Weather
squints up at a sky full of rain clouds.
says, "Rain is an archaeologist's worst enemy. Turns every dig into soup."
says, "And yet somehow I always find the best things in the mud."
## The Curse
says <mood>, "They say some relics are cursed. I've never believed it."
says, "Although after I found that little skull, my boots kept going missing. Every night."
says, "I put the skull back. The boots stopped disappearing. Coincidence."
## The Thrill
holds up a small, gleaming coin, brushing dirt from its face.
says, "This coin was spent in a market three thousand years ago. Somebody bought bread with it."
says, "Maybe. Or a goat. I like to think it was a goat."
## Patience
sits back on their heels and wipes their brow. [sit]
says, "You can't rush the past. It's waited this long. It can wait for me to get it right."
]])

add("profession", "FirstAid", [[
## The Hospital
says, "I worked in a field hospital once, during the war."
says, "Rows and rows of cots. Never enough bandages. Never enough sleep."
says, "I still dream about it. Not the bad parts. The ones who walked out."
## Herbal Help
pulls a bundle of dried herbs from a pocket.
says, "Herbalists keep me supplied. A little peacebloom in the salve helps it heal faster."
says, "And it smells nicer than the alternative. Trust me on that."
## The Toughest Patient
says <mood>, "The worst patient I ever had was a dwarf with a broken leg."
says, "He refused the splint. Refused the crutch. Tried to walk home."
says, "Got as far as the door. Then he let me help. Stubborn as stone, dwarves."
## Steady Breathing
takes a slow, steady breath and lets it out. [sigh]
says, "First rule of first aid: you stay calm. If you panic, they panic."
says, "Even when it's bad. Especially when it's bad."
## Small Wounds
dabs salve on a tiny scratch on {target}'s hand with exaggerated care.
says, "There. Saved your life. You're welcome."
laughs. [laugh]
]])
