-- StoryCaster lore library: the holidays. Original writing in StoryCaster's script format.
local ADDON, ns = ...
local R = ns.R
R.LORE = R.LORE or {}
R.LORE.holiday = R.LORE.holiday or {}
local L = R.LORE.holiday

L.HallowsEnd = { "Hallow's End", [[
## The Lanterns
lights a carved pumpkin lantern and sets it on the step, its crooked grin flickering orange.
says, "Hallow's End. The one night a year the whole world agrees to be a little spooky."
steps back to admire the lantern's lopsided face.
says, "I meant to carve a fearsome demon. It came out looking surprised. I'm keeping it."
## The Origin
says, "Did you know Hallow's End started with the Forsaken?"
says, "They threw off the Lich King's chains and wanted to celebrate it. Loudly."
says, "Burning the Wickerman, frightening the living, handing out candy. Every culture has its own way of healing."
## Trick or Treat
holds out an empty bag toward {target} with a hopeful look.
says, "Trick or treat!"
waits a beat, then grins.
says, "Fine, you can keep your candy. But I'm warning you, my tricks are terrible."
## The Costume
spins around, showing off a costume made of a bedsheet with two crooked eyeholes. [dance]
says, "Behold! I am a ghost. A terrifying spirit of the night."
says, "I made it myself. I also cannot see where I'm going."
walks directly into a lamppost.
says, "That was intentional. Ghosts walk through things. I am practicing."
## The Headless Horseman
lowers their voice and glances nervously over one shoulder. [cower]
says, "Have you heard about the Headless Horseman?"
says, "Every year he rides out of the Scarlet Monastery, swinging his flaming pumpkin head."
says, "Brave folk go down into the graveyard to fight him. Most come back. Most."
says, "I've never gone. I like my head where it is."
## The Wickerman
gazes toward a towering figure of woven sticks and straw.
says, "At midnight, they set the Wickerman alight. The flames go up higher than the trees."
says, "You toss a little wish into the fire. Something you want to let go of."
says, "Last year I let go of my fear of spiders. This year I'm letting go of my fear of the Horseman."
says, "Next year, probably spiders again."
## Candy
pulls out a handful of wrapped candies and inspects each one.
says, "Tricky Treats. Some taste wonderful. Some turn you into a skeleton for ten minutes."
says, "It's a gamble every single time. That's the fun."
eats one and waits nervously.
says, "Nothing! Lucky. Very lucky."
## Masks
pulls out an assortment of rubbery masks: a gnome, a troll, a tauren.
says, "These are the best. Put one on and you look like a different race for an hour."
says, "I went to Orgrimmar disguised as an orc once. Nobody noticed."
says, "Then I tried to buy something and the masks don't do voices. Very awkward."
## Midnight
looks up at the full moon, pale and enormous over the rooftops.
says, "On Hallow's End, the moon looks closer. Like it wants to join the party."
says, "Happy Hallow's End, friend. Stay spooky. Stay kind."
/s Happy Hallow's End!
]] }

L.WinterVeil = { "Feast of Winter Veil", [[
## The Snow
holds out a gloved hand to catch the falling snowflakes, eyes bright.
says, "Ah, Winter Veil. My favorite time of year."
says, "The snow, the lights, the smell of pine and gingerbread everywhere."
catches a flake on their tongue and grins. [laugh]
## Greatfather Winter
says, "Every year Greatfather Winter comes to Ironforge and Orgrimmar with gifts for everyone."
says, "Big beard, big belly, bigger heart."
says, "Some say the goblins invented him to sell more toys. I don't believe them. Much."
## The Tree
gazes up at a towering evergreen covered in glowing ornaments.
says, "The great tree in Ironforge. Have you seen it? It's taller than the gate."
says, "Every year the dwarves try to make it bigger. Every year it gets a little more crooked."
says, "It's perfect."
## Gifts
pulls a small wrapped package from behind their back and offers it to {target}.
says, "I got you something. It's not much."
says, "It's a snowball. A very special snowball. I've been keeping it in my bag since last year."
says, "It's mostly water now. The thought counts."
## The Smokywood Pastures
says, "The Smokywood Pastures vendors show up every year with sweets and gifts."
says, "Gingerbread cookies. Hot apple cider. Candy canes. Egg nog with a suspicious amount of nutmeg."
sips from a steaming mug and sighs contentedly. [sigh]
## Snowball Fight
scoops up a handful of snow and packs it tight with a mischievous grin.
says, "You know what Winter Veil really means?"
hurls the snowball, then ducks behind a crate. [laugh]
says, "War. Glorious, frosty war."
## Mistletoe
glances up and freezes beneath a sprig of mistletoe hanging from a doorframe.
says, "Oh. Oh dear. Who put that there?"
shuffles out from under it very quickly, blushing. [cower]
says, "Close call."
## The Greench
says, "Every year, the Abominable Greench tries to steal the gifts from the Hillsbrad foothills."
says, "Every year, adventurers chase him off. Every year he comes back."
says, "Honestly, I think he just wants to be invited to the party."
## Old Memories
grows quiet, watching the lights twinkle on the tree.
says, "My family used to gather around a fire every Winter Veil night."
says, "My father told the same terrible joke every year. We groaned every year."
says, "I'd give anything to hear that joke one more time."
smiles softly.
## The Feast
lifts a mug high toward the crowd. [cheer]
says, "To warm hearths, full bellies, and friends who come in out of the cold!"
says, "Happy Winter Veil, everyone!"
/s Happy Winter Veil!
]] }

L.Brewfest = { "Brewfest", [[
## The Gates Open
throws open their arms as the music swells and the crowd rushes through the gates. [cheer]
says, "Brewfest! The finest festival in all of Azeroth!"
says, "Dwarves, goblins, orcs, everyone together, all for the love of a good ale."
## The Brews
lines up a row of tankards on the table, each a different shade of amber and brown.
says, "Every brewery sends its best. Thunderbrew, Barleybrew, Gordok, Drohn's Distillery."
says, "Taste a little of each and decide for yourself. Responsibly. Ish."
sips from the first tankard and smacks their lips. [nod]
## The Rams
says, "The rams! You have to try the ram racing."
says, "You get on a giant ram, you ride as fast as you can, and you try not to fall off."
says, "I've fallen off eleven times. That's a festival record. Nobody's proud of me."
## The Dwarves
says, "The dwarves take Brewfest very seriously. More seriously than war."
says, "I saw two of them argue about hops for four hours. Neither one blinked."
says, "Then they hugged and bought each other a round. That's Brewfest."
## The Dark Iron Raid
lowers their voice.
says, "Every year the Dark Iron dwarves storm the festival trying to steal the kegs."
says, "Their leader, Coren Direbrew, sulks in Blackrock Depths with all the stolen barrels."
says, "Brave folk go down there to take them back. For the good of the festival."
raises a tankard solemnly. [salute]
## The Songs
starts tapping a foot to the rhythm of the band.
says, "Do you know the Brewfest songs? There are about forty. All of them about beer."
sings off key, swaying along. [dance]
says, "Ninety-nine barrels of ale on the wall... no, wait, that one's too long."
## The Food
grabs a pretzel twice the size of their head from a passing vendor.
says, "Brewfest pretzels. Sausages. Roasted chestnuts. Everything salty, so you'll drink more."
says, "It's a conspiracy. A delicious conspiracy."
## The Hangover
winces and rubs their temples.
says, "Brewfest morning is always the hardest part of Brewfest."
says, "I wake up with a hat I don't remember buying and a ram I don't remember adopting."
## The Goblins
says, "The goblins sell their Brewfest pins every year. Very shiny. Very collectible."
says, "Then they buy them back from you at half price next year. Always the hustle."
## The Toast
lifts a frothing tankard toward {target}. [cheer]
says, "To old friends, new brews, and walking home in a mostly straight line."
says, "Happy Brewfest!"
/s Happy Brewfest!
]] }

L.LunarFestival = { "Lunar Festival", [[
## The Elders
lights a small lantern and lets it float gently into the night sky.
says, "The Lunar Festival. The time when we honor our elders, living and departed."
says, "All across Azeroth, the spirits of ancient elders gather in their sacred places."
watches the lantern rise until it's just another star.
## Moonglade
describes Moonglade: a quiet valley, glowing trees, a lake reflecting the stars.
says, "Every year, druids and pilgrims come to Moonglade for the celebration."
says, "It's peaceful there. Even the Horde and the Alliance put down their weapons."
says, "If you listen, you can hear the elders' voices in the wind."
## The Elders' Blessings
says, "You travel the world seeking out the spirits of the elders."
says, "In the mountains, in the deserts, in the old ruined cities."
says, "Each one gives you a blessing and a coin of ancestry."
says, "I have forty-two coins. My grandmother had a hundred and nine."
## Fireworks
lights the fuse of a small firework and steps back quickly. [cower]
watches it burst into a shower of red and gold sparks overhead. [cheer]
says, "Beautiful! Lunar Festival fireworks are the best of the year."
says, "The gnomes make them. Every year they get a little brighter. And a little louder."
## Omen
says, "Long ago, a great beast called Omen rose from the lake in Moonglade."
says, "The druids drove him back, but every Lunar Festival he stirs."
says, "If you set off enough fireworks, he wakes up. And he is not happy about it."
says, "So adventurers do it on purpose. Every year. Because of course they do."
## Family
grows quiet, looking up at the stars.
says, "I always think of my grandfather during the Lunar Festival."
says, "He used to tell me stories under the stars. Long, wandering stories with no real ending."
says, "I didn't realize how much I loved them until he was gone."
lowers their head for a moment. [bow]
## The Feast
says, "Of course there's a feast. Sweet dumplings, rice cakes, little red envelopes."
says, "You give the envelopes to the younger ones. Coins for good luck."
offers {target} a small red envelope.
says, "For luck. Don't spend it all on fireworks."
## Wishes
says, "At the end of the night, you make a wish for the new year."
says, "Mine is always the same. Health for the people I love. And fewer murlocs."
## Farewell
lifts a hand toward the moon in a quiet salute. [salute]
says, "May the elders watch over you, and may your new year be bright."
/s Happy Lunar Festival!
]] }

L.DarkmoonFaire = { "Darkmoon Faire", [[
## The Tents
spreads both arms wide as the striped tents and spinning lights of the Faire come into view.
says, "Step right up, step right up! The Darkmoon Faire is in town!"
says, "Games, prizes, wonders, and the finest fried food in all the known world!"
## Silas Darkmoon
says, "Silas Darkmoon himself runs the whole thing. Top hat, big smile, bigger secrets."
says, "Nobody knows exactly where the Faire goes between visits."
says, "Some say it travels to its own island. Some say it travels through time."
says, "I say it travels wherever the tickets are cheapest."
## The Games
picks up a small bag of rings and eyes a row of bottles with determination.
says, "Ring toss. The classic. How hard can it be?"
throws a ring. It bounces off and rolls under a tent.
says, "Harder than it looks. Much harder."
## The Shooting Gallery
picks up a little toy rifle and squints down the barrel.
says, "Shooting gallery. Hit the targets, win a prize."
fires three times in quick succession, then lowers the rifle with a frown.
says, "I hit the man running the booth. Twice. He was very nice about it."
## The Food
holds up a stick of something deep-fried and golden.
says, "Darkmoon Faire food. Fried everything. Fried bread. Fried cheese. Fried fried things."
takes a big bite and closes their eyes in bliss.
says, "My healer is going to be furious. Worth it."
## Fortune Telling
lowers their voice and glances at a dark tent draped in purple silk.
says, "Have you visited Sayge, the fortune teller?"
says, "He asks you strange questions and gives you a fortune."
says, "Mine said I'd come into great wealth. I haven't yet. But I'm very patient."
## Prizes
proudly holds up a cheap stuffed toy with one button eye.
says, "My prize! Took me forty tickets and two hours."
says, "I could have bought it at the stall for one silver. That's not the point."
## The Carousel
watches the carousel spin, its painted horses and gryphons bobbing up and down.
says, "The carousel always makes me feel like a child again."
says, "Round and round, music playing, nothing to worry about."
## Friends
turns to {target} with a wide grin.
says, "Come on, let's ride it together. Nobody's too old for the carousel."
## The Last Night
watches the lights of the Faire twinkle against the dark sky.
says, "The Faire only stays a week. Then it's gone like a dream."
says, "But it always comes back. That's the best part."
bows with a flourish, like a ringmaster. [bow]
/s Step right up to the Darkmoon Faire!
]] }
