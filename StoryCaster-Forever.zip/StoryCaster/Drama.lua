-- StoryCaster: Drama. Everything Drama Queen Pro and Paranoid RP do, plus Brain Rot, in the panel's Drama slide-out.
--  * Drama: a line of deadpan personal drama every few minutes, in guild chat and/or publicly (an emote, and /say:
--    automatic inside instances, one Deliver press outside). Multi-part sagas. One voice per guild, a Queen Detector,
--    shared with Drama Queen Pro over its own hidden addon channel. Off until you turn it on.
--  * Paranoid: target someone and perform five acts of growing suspicion, as a script on StoryCaster's own timer.
--  * Brain Rot: one click, one random line, said or emoted, at most once every 15 seconds.
local ADDON, ns = ...
local R = ns.R
local DQ_PREFIX = "DramaQueen"
local NETCHAN = "DramaQueenNet"
local DQ_VERSION = "3.3"

local function me() return UnitName("player") or "" end
local function short(n) return type(n) == "string" and (n:gsub("%-.*", "")) or nil end

function R:DramaDB()
  self.db.drama = type(self.db.drama) == "table" and self.db.drama or {}
  local d = self.db.drama
  local defaults = { enabled = false, minutes = 5, sagaChance = 30, toGuild = true, public = false, toEmote = true, toSay = true,
    mainVoice = false, network = false, toasts = true, posted = 0, pos = 1, sagaNext = 1, rotMode = "mix" }
  for k, v in pairs(defaults) do if d[k] == nil then d[k] = v end end
  local n = #((self.DRAMA and self.DRAMA.lines) or {})
  if type(d.order) ~= "table" or #d.order ~= n then
    local o = {}
    for i = 1, n do o[i] = i end
    for i = #o, 2, -1 do local j = math.random(i); o[i], o[j] = o[j], o[i] end
    d.order, d.pos = o, 1
  end
  return d
end

---------------------------------------------------------------------------
-- One voice per guild, and the Queen Detector (compatible with Drama Queen Pro)
---------------------------------------------------------------------------
R.queens, R.dqPeers = {}, {}
local lastHi = {}

local function dqSend(text, dist, target)
  local f = (C_ChatInfo and C_ChatInfo.SendAddonMessage) or SendAddonMessage
  if f and dist then pcall(f, DQ_PREFIX, text, dist, target) end
end
local function netId()
  local d = R.db and R.db.drama
  if not (d and d.network and GetChannelName) then return nil end
  local id = GetChannelName(NETCHAN)
  return (type(id) == "number" and id > 0) and id or nil
end
local function groupDist()
  if IsInGroup and LE_PARTY_CATEGORY_INSTANCE and IsInGroup(LE_PARTY_CATEGORY_INSTANCE) then return "INSTANCE_CHAT" end
  if IsInRaid and IsInRaid() then return "RAID" end
  if IsInGroup and IsInGroup() then return "PARTY" end
end
local function prio() return (R.db.drama and R.db.drama.mainVoice) and 2 or 1 end
local function hiText() return ("HI:%s:%d"):format(DQ_VERSION, (R.db.drama and R.db.drama.posted) or 0) end
local function broadcast(text)
  if IsInGuild and IsInGuild() then dqSend(text, "GUILD") end
  dqSend(text, groupDist())
  local id = netId()
  if id then dqSend(text, "CHANNEL", id) end
end

function R:DramaScan() broadcast("WHO"); broadcast(hiText()) end

function R:DramaLeader()
  local best, bp, now = me(), prio(), GetTime()
  for n, p in pairs(self.dqPeers) do
    if now - p.t > 150 then self.dqPeers[n] = nil
    elseif p.prio > bp or (p.prio == bp and n < best) then best, bp = n, p.prio end
  end
  return best
end

local WHERE = { GUILD = "Guild", PARTY = "Group", RAID = "Raid", INSTANCE_CHAT = "Instance", CHANNEL = "Network", WHISPER = "Whisper" }
function R:QueenSeen(name, dist, ver, posts)
  local q = self.queens[name]
  local isNew = not q
  q = q or { first = GetTime() }
  q.where, q.ver, q.posts, q.t = WHERE[dist] or dist, ver or q.ver or "?", tonumber(posts) or q.posts or 0, GetTime()
  self.queens[name] = q
  if isNew and self.db.drama and self.db.drama.toasts then
    self:Print(("|cffff4fa3Another Drama Queen detected:|r %s (%s)."):format(name, q.where))
  end
  if self.RefreshDrama then self:RefreshDrama() end
end

function R:QueenCounts()
  local total, online, now = 0, 0, GetTime()
  for _, q in pairs(self.queens) do total = total + 1; if now - q.t < 300 then online = online + 1 end end
  return total, online
end

function R:OnDramaAddon(msg, dist, sender)
  if type(msg) ~= "string" or type(sender) ~= "string" then return end
  if issecretvalue and (issecretvalue(msg) or issecretvalue(sender)) then return end
  local who = short(sender)
  if not who or who == me() then return end
  if dist == "GUILD" then
    if msg == "PING" then dqSend("HB:" .. prio(), "GUILD") end
    local p = msg:match("^HB:(%d)")
    if p then self.dqPeers[who] = { prio = tonumber(p), t = GetTime() }; self:QueenSeen(who, "GUILD") end
  end
  if msg == "WHO" then
    if not lastHi[dist] or GetTime() - lastHi[dist] > 10 then
      lastHi[dist] = GetTime()
      if dist == "CHANNEL" then local id = netId(); if id then dqSend(hiText(), "CHANNEL", id) end else dqSend(hiText(), dist) end
    end
    self:QueenSeen(who, dist)
  else
    local ver, posts = msg:match("^HI:([^:]+):(%d+)")
    if ver then self:QueenSeen(who, dist, ver, posts) end
  end
end

function R:DramaNetwork(on)
  local d = self:DramaDB()
  d.network = on and true or false
  if d.network then
    if GetChannelName and GetChannelName(NETCHAN) == 0 and JoinTemporaryChannel then pcall(JoinTemporaryChannel, NETCHAN) end
    C_Timer.After(2, function()
      for i = 1, (NUM_CHAT_WINDOWS or 10) do
        local cf = _G["ChatFrame" .. i]
        if cf then
          if ChatFrame_RemoveChannel then pcall(ChatFrame_RemoveChannel, cf, NETCHAN)
          elseif ChatFrameUtil and ChatFrameUtil.RemoveChannel then pcall(ChatFrameUtil.RemoveChannel, cf, NETCHAN) end
        end
      end
      R:DramaScan()
    end)
  elseif GetChannelName and GetChannelName(NETCHAN) > 0 and LeaveChannelByName then
    pcall(LeaveChannelByName, NETCHAN)
  end
end

---------------------------------------------------------------------------
-- Drama on a timer
---------------------------------------------------------------------------
local ACTIONS = { "sighs.", "stares at their phone.", "rubs their temples.", "takes a long, slow breath.", "shakes their head slowly.",
  "looks up from their phone.", "laughs without smiling.", "goes very quiet for a moment.", "sets their drink down.", "wipes their eyes.",
  "stares into the middle distance.", "pinches the bridge of their nose.", "lets out a shaky breath.", "puts their phone face down.",
  "exhales through their teeth.", "looks around to see who is listening." }

function R:DramaNextLine()
  local d, D = self:DramaDB(), self.DRAMA
  if self.saga then
    self.sagaPart = self.sagaPart + 1
    local t = D.sagas[self.saga][self.sagaPart]
    if self.sagaPart >= #D.sagas[self.saga] then self.saga, self.sagaPart = nil, 0 end
    return t
  end
  if #D.sagas > 0 and math.random(100) <= d.sagaChance then
    self.saga, self.sagaPart = d.sagaNext, 0
    d.sagaNext = d.sagaNext % #D.sagas + 1
    return self:DramaNextLine()
  end
  local t = D.lines[d.order[d.pos]]
  d.pos = d.pos % #d.order + 1
  return t
end

function R:DramaCanSpeak()
  local d = self:DramaDB()
  local guildOK = d.toGuild and IsInGuild and IsInGuild() and self:DramaLeader() == me()
  return d.enabled and self:CanEmote() and (guildOK or d.public)
end

-- manual: your own click (Drama now), which may /say at once
function R:DramaPost(manual)
  local d = self:DramaDB()
  if not manual and not self:DramaCanSpeak() then return false end
  local toGuild = d.toGuild and IsInGuild and IsInGuild() and (manual or self:DramaLeader() == me())
  if not toGuild and not d.public then
    self:Print("Both drama switches are off: turn on Cause drama in guild or Cause drama publicly.")
    return false
  end
  local text = self:DramaNextLine()
  if not text then return false end
  if toGuild then
    dqSend("POST", "GUILD") -- tells Full Support the next guild line is drama
    self:Perform({ text, nil, nil, "GUILD" })
  end
  if d.public and d.toEmote then
    local e = ACTIONS[math.random(#ACTIONS)] .. ' "' .. text .. '"'
    if #e > self.MAX_LEN then e = text end
    self:Perform({ e })
  end
  if d.public and d.toSay then
    local line = { text, nil, nil, "SAY" }
    if manual or (IsInInstance and IsInInstance()) or self.db.testMode then self:Perform(line)
    else
      self.pending = line
      self:Print("|cffff4fa3Drama is waiting to be said:|r press |cffffd100Deliver|r (or Say it in Drama).")
    end
  end
  d.posted = d.posted + 1
  d.last = text
  self.dramaNext = GetTime() + d.minutes * 60
  self:Refresh()
  return true
end

function R:DramaTick()
  local d = self.db and self.db.drama
  if not (d and d.enabled) then return end
  if GetTime() >= (self.dramaNext or 0) then
    if self:DramaCanSpeak() and self:SpamWait() == 0 then self:DramaPost(false); self:NoteAuto()
    else self.dramaNext = GetTime() + 15 end
  end
end

function R:DramaEnable(on)
  local d = self:DramaDB()
  d.enabled = on and true or false
  if d.enabled then self.dramaNext = GetTime() + 5 end
  self:Print("Drama " .. (d.enabled and ("|cffff4fa3on|r: a line every " .. d.minutes .. " minutes.") or "off."))
  self:Refresh()
end

function R:DramaMinutes(n)
  local d = self:DramaDB()
  d.minutes = math.max(1, math.min(60, math.floor(n)))
  if self.dramaNext then self.dramaNext = math.min(self.dramaNext, GetTime() + d.minutes * 60) end
  self:Refresh()
end

---------------------------------------------------------------------------
-- Paranoid: five acts about your target, run as a script on the panel's own timer
---------------------------------------------------------------------------
function R:Suspect()
  if not UnitExists("target") or (UnitIsUnit and UnitIsUnit("target", "player")) then return nil end
  local name = UnitName("target")
  if not name or (issecretvalue and issecretvalue(name)) then return nil end
  local function clean(v, d) if not v or (issecretvalue and issecretvalue(v)) or v == "" then return d end return v end
  local class = clean(UnitClass and UnitClass("target"), "suspect")
  local race = clean(UnitRace and UnitRace("target"), "mysterious")
  local guild = clean(GetGuildInfo and GetGuildInfo("target"), "Guildless Wanderers")
  local zone = clean(GetZoneText and GetZoneText(), "here")
  return { name = name, class = class, race = race, guild = guild, zone = zone }
end

function R:ParanoidScript(s, quiet)
  local function fill(text)
    local function safe(v) return (tostring(v):gsub("%%", "%%%%")) end
    return (text:gsub("{t}", safe(s.name)):gsub("{class}", safe(s.class:lower())):gsub("{race}", safe(s.race))
      :gsub("{guild}", safe(s.guild)):gsub("{zone}", safe(s.zone)))
  end
  local script = {}
  local function add(e, scene)
    local l = { fill(e[1]), e[2], nil, nil, nil, scene }
    l.quiet = quiet or nil
    script[#script + 1] = l
  end
  for _, act in ipairs(self.DRAMA.acts) do
    for i, e in ipairs(act.lines) do add(e, i == 1 and act.name or nil) end
  end
  for i, e in ipairs(self.DRAMA.finale) do add(e, i == 1 and "The Finale" or nil) end
  return script
end

function R:ParanoidStart()
  local s = self:Suspect()
  if not s then self:Print("Target someone first. You cannot be paranoid about nobody.") return end
  local name = ("Paranoid: %s"):format(s.name)
  self.temp = self.temp or {}
  local d = self:DramaDB()
  self.temp[name] = self:ParanoidScript(s, d.paranoidQuiet)
  self.temp[name].opts = { paranoid = true }
  self:Start(name)
  self:Print("Now watching |cffffd100" .. s.name .. "|r." .. (d.paranoidQuiet and " (inner monologue: only you see it)" or ""))
end

-- the next act of the running Paranoid performance
function R:ParanoidSkipAct()
  local run = self.run
  if not (run and run.opts and run.opts.paranoid) then self:Print("Not watching anyone yet.") return end
  for i = run.i + 1, #run.lines do
    if run.lines[i][6] and i > run.i + 1 then self:JumpTo(i) return end
  end
  self:Print("Already in the last act.")
end

---------------------------------------------------------------------------
-- Brain Rot: one click, one line, at most once every 15 seconds
---------------------------------------------------------------------------
R.ROT_GAP = 15
function R:RotWait() return math.max(0, (self.rotReady or 0) - GetTime()) end

function R:BrainRot(mode)
  local wait = self:RotWait()
  if wait > 0 then self:Print(("Brain rot is recharging: %ds."):format(math.ceil(wait))) return nil end
  if not self:CanEmote() then self:Print("Not now: you are in combat or a boss fight.") return nil end
  local D = self.DRAMA
  mode = mode or self:DramaDB().rotMode
  if mode == "mix" then mode = math.random(2) == 1 and "say" or "emote" end
  local who = self:Target() or "bestie"
  local text = D.rot[math.random(#D.rot)]:gsub("%%t", (who:gsub("%%", "%%%%")))
  local line
  if mode == "say" then
    line = { text, nil, nil, "SAY" }
  else
    local a = D.rotActions[math.random(#D.rotActions)]
    line = { a[2] .. ', "' .. text .. '"', a[1] }
  end
  self:Perform(line)
  self.rotReady = GetTime() + self.ROT_GAP
  self.lastRot = text
  self:Refresh()
  return line
end

---------------------------------------------------------------------------
-- Events
---------------------------------------------------------------------------
local ev = CreateFrame("Frame")
ev:RegisterEvent("PLAYER_LOGIN")
ev:RegisterEvent("CHAT_MSG_ADDON")
ev:RegisterEvent("GROUP_ROSTER_UPDATE")
ev:SetScript("OnEvent", function(_, event, a1, a2, a3, a4)
  if event == "PLAYER_LOGIN" then
    if C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix then C_ChatInfo.RegisterAddonMessagePrefix(DQ_PREFIX) end
    R:DramaDB()
    R.dramaNext = GetTime() + 45
    dqSend("PING", (IsInGuild and IsInGuild()) and "GUILD" or nil)
    dqSend("HB:" .. prio(), (IsInGuild and IsInGuild()) and "GUILD" or nil)
    if R.db.drama.network then C_Timer.After(8, function() R:DramaNetwork(true) end) end
    C_Timer.After(5, function() R:DramaScan() end)
  elseif event == "GROUP_ROSTER_UPDATE" and R.db and R.db.drama then
    local d = groupDist()
    if d then dqSend(hiText(), d) end
  elseif event == "CHAT_MSG_ADDON" and a1 == DQ_PREFIX and R.db then
    R:OnDramaAddon(a2, a3, a4)
  end
end)

-- the timer: drama posts, heartbeats every minute and hellos every two
local acc, hb, hi = 0, 0, 0
ev:SetScript("OnUpdate", function(_, el)
  acc = acc + el
  if acc < 1 then return end
  hb, hi = hb + acc, hi + acc
  acc = 0
  if not R.db then return end
  R:DramaTick()
  if hb >= 60 then hb = 0; if IsInGuild and IsInGuild() then dqSend("HB:" .. prio(), "GUILD") end end
  if hi >= 120 then hi = 0; broadcast(hiText()) end
  if R.RefreshDramaTimer then R:RefreshDramaTimer() end
end)
