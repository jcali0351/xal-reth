-- StoryCaster lore library: the professions. Original writing in StoryCaster's script format.
local ADDON, ns = ...
local R = ns.R
R.LORE = R.LORE or {}
R.LORE.profession = R.LORE.profession or {}
local L = R.LORE.profession

L.Blacksmithing = { "Blacksmithing", [[
## The Forge Wakes
rolls up their sleeves and pumps the bellows until the coals glow a deep orange.
says, "A cold forge is just a pile of rocks. A hot one is a promise."
holds a hand over the coals, judging the heat by feel alone.
says, "Too cool and the steel won't move. Too hot and it burns. You learn the difference with your skin."
pumps the bellows twice more, nodding at the color. [nod]
## The First Strike
lifts a glowing bar from the fire with long tongs and sets it on the anvil.
brings the hammer down: one clean ring that echoes off every wall. [flex]
says, "Hear that? A good anvil sings. A bad one thuds. This one sings."
strikes again, turning the bar a quarter with each blow.
says, "Every swing is a decision. You cannot take it back. That's why I love it."
## The Master
says, "My master was a dwarf from Ironforge with a beard full of burn holes."
says, "First year, he only let me sweep. Second year, I could pump the bellows."
says, "Third year, he handed me a hammer and said, 'Now ruin something. It's the only way to learn.'"
laughs at the memory. [laugh]
says, "I ruined a great deal. He was very patient. Mostly."
## Quenching
plunges the blade into a trough of water, and steam explodes upward in a hiss.
says, "The quench is where the steel decides what it will be. Hard, or brittle, or perfect."
lifts the blade out and turns it slowly in the light.
says, "No cracks. Good. Sometimes the steel and I agree."
## The Ores
lines up chunks of ore on the bench: copper, iron, mithril, thorium.
says, "Copper's soft, forgiving. A beginner's friend."
says, "Iron's honest. It tells you when you've hit it wrong."
says, "Mithril's light as a whisper and twice as stubborn."
taps the thorium with a knuckle and winces.
says, "And thorium will break your heart and your hammer if you let it."
## Armor for a Friend
holds up a half-finished breastplate, running a thumb along the edge.
says, "This one's for a friend heading into the Plaguelands next week."
says, "I made the straps twice as thick. I don't trust the ones on the market."
says, "If she comes home, I'll know it was worth every blister."
## The Grind
wipes sweat from their brow with a soot-black forearm.
says, "People think smithing is all glory and gleaming swords. It's mostly sharpening."
says, "Two hundred plain daggers before anyone trusts you with a real blade."
says, "I made four hundred. I'm a slow learner. But I learned it right."
## The Sword
unwraps a long bundle of oilcloth, revealing a sword with a faint ripple in the steel.
says, "Six weeks. Folded over and over. My finest work."
turns it so the light runs along the edge like water.
says, "I'll probably never sell it. Some things you make just to know you can."
## Closing Up
banks the coals and hangs the tongs on their hook, one by one.
says, "Rule of the forge: leave it the way you'd want to find it."
looks over the shop once more, satisfied. [nod]
/s Bring me your dented armor. I'll make it sing again.
]] }

L.Herbalism = { "Herbalism", [[
## Morning Rounds
kneels in the dew-wet grass and parts the leaves with careful fingers. [kneel]
says, "Peacebloom. Silverleaf. And there, hiding under the fern, a little Earthroot."
says, "Herbs don't grow where you want them. They grow where they're happy. You go to them."
pinches off a stem low, leaving the roots in the soil.
says, "Always leave the roots. Take the gift, not the giver."
## Grandmother's Rules
says, "My grandmother taught me herbs before she taught me letters."
says, "Rule one: never pick the first flower you see. It might be the last one."
says, "Rule two: if a plant has teeth, walk away. Walk away faster."
chuckles softly. [chuckle]
says, "Rule three: thank the meadow. Out loud. People will stare. Thank it anyway."
## The Satchel
opens a worn leather satchel stitched with a dozen little pockets.
says, "Every pocket is a different herb. Mix them up and someone's potion goes very wrong."
says, "Mageroyal goes left. Briarthorn goes right, wrapped twice. It bites through cloth."
holds up a pricked finger as evidence.
says, "Yes. It bit through cloth."
## The Rare Ones
lowers their voice as though the forest might hear.
says, "Have you ever seen Black Lotus? I have. Once."
says, "Standing alone on a hilltop in the moonlight. I just looked at it for a while."
says, "Then three other herbalists came running over the ridge. I learned to look faster."
sighs at the memory. [sigh]
## Weather and Soil
crumbles a handful of dirt and sniffs it thoughtfully.
says, "Wet earth means Kingsblood by the riverbanks. Dry means Stranglekelp is out of reach till spring."
says, "An herbalist reads the ground the way a scholar reads a book."
says, "The ground just has worse handwriting."
## The Mount Question
says, "People ask why I don't ride everywhere. I do. But I always get off to walk the last bit."
says, "You miss things from the saddle. Little purple things. Expensive little purple things."
## A Gift for a Healer
ties a small bundle of herbs with a ribbon of grass.
says, "This is for the priest in the next village. Fadeleaf, for fevers."
says, "She doesn't pay much. She doesn't have much. She pays in pie."
says, "It is very good pie."
## Dangers
says, "Herbalism sounds peaceful. Then a bear notices you're picking its favorite berries."
says, "Or a basilisk mistakes you for a very slow rock."
says, "Or a druid stops you to explain that the flower you just picked was a friend of theirs."
laughs. [laugh]
says, "That one was awkward."
## Evening
stands, stretching a sore back, the satchel heavy with the day's harvest.
says, "Full bag, muddy knees, tired feet. A good day."
looks out over the darkening meadow and bows slightly to it. [bow]
/s Thank you, meadow. Same time tomorrow.
]] }

L.Fishing = { "Fishing", [[
## The Cast
plants their feet at the water's edge and flicks the line out in a long, lazy arc.
watches the bobber land with a soft plip and settle on the surface.
says, "There. Now we wait. Fishing is ninety percent waiting and ten percent pretending you meant to."
## The Philosophy
sits down on an overturned crate, rod resting easy in both hands. [sit]
says, "My grandfather said fishing is the art of doing nothing usefully."
says, "You're not lazy. You're fishing. Completely different."
says, "If anyone asks, you're very busy."
## The Bite
leans forward as the bobber dips. Once. Twice.
says, "Easy. Easy. Let it take the bait. Don't rush it."
sees the bobber plunge and yanks the rod back with a whoop.
reels hard, the line singing, grinning ear to ear. [cheer]
## The Catch
holds up a gleaming fish, its scales flashing silver in the light.
says, "Look at that! A Rainbow Fin Albacore! A beauty!"
admires it a moment, then frowns thoughtfully.
says, "Or a very large Sickly Looking Fish. The light is bad. I'm choosing to believe it's an Albacore."
## The Junk
reels in again and pulls up a soggy boot, dripping weed.
says, "Ah. Another boot. That's the third today."
says, "Somewhere out there is a one-legged fisherman who is very confused."
tosses the boot on a growing pile behind them.
## The Big One
gazes out at the deep water with a faraway look.
says, "There's a fish in this lake. Big as a barrel. Older than the village."
says, "The old-timers call it Old Gnasher. Everyone's had it on the line once."
says, "Nobody's ever landed it. I've had it on the line twice."
says, "Third time, Gnasher. Third time."
## Lures
opens a battered tackle box crammed with shiny lures.
says, "Bright Baubles. Nightcrawlers. Aquadynamic Fish Attractors. A gnome sold me that last one."
says, "It hums. I'm not sure the fish like it. I'm not sure I like it."
## The Pools
says, "The trick is the pools. Watch the water for swirls and bubbles."
says, "That's where the schools gather. Cast right into the middle."
says, "Don't cast into the swirl that's actually a murloc. That's a different afternoon."
## Company
glances at {target} and pats the crate beside them.
says, "Sit a while, if you like. Water's calm. Fish are thinking about it."
says, "Best conversations I ever had were with someone holding a rod."
## Sunset
watches the sun sink, the water turning gold, then copper, then violet.
says, "Some days you catch a hundred. Some days you catch nothing."
says, "Both are good days at the water."
reels in slowly and packs up, humming a tune. [wave]
]] }

L.Alchemy = { "Alchemy", [[
## The Bench
sets out a row of glass vials, a mortar and pestle, and a small brass burner.
says, "Alchemy is cooking for people who like danger."
lights the burner, and a little blue flame dances to life.
says, "Rule one: label everything. Rule two: never drink anything that is still bubbling."
## Grinding
drops a handful of dried Peacebloom into the mortar and grinds it into a pale green powder.
says, "Grind it fine, but not too fine. Too fine and it floats away. Then you're inhaling it."
coughs pointedly. [gasp]
says, "Which is how I learned that."
## The Healing Potion
pours the powder into a flask of clear water and swirls it gently.
says, "The humble healing potion. The first thing every alchemist makes."
watches the liquid blush slowly from clear to rose red.
says, "There it is. That color means somebody lives through a bad day."
## Mistakes
says, "Every alchemist has a story about the explosion."
says, "Mine was a fire protection potion. Ironic, really."
touches the ends of their slightly singed hair.
says, "My eyebrows grew back in a week. My pride took longer."
## Transmutation
holds up a gleaming bar of metal and a glowing crystal.
says, "Transmutation. Turning one thing into another. The heart of alchemy."
says, "Iron to gold is the dream. It's been done. Once. Very expensively. By a goblin."
says, "Mostly I turn arcanite into rent money."
## Elixirs
lines up several small bottles in different jewel colors.
says, "Elixir of the Mongoose for agility. Elixir of Giants for strength. Wisdom for the clever."
says, "Adventurers drink them before every fight."
says, "Then they ask me why their tongue is purple. Because you drank purple, friend."
## The Philosopher's Stone
lowers their voice with reverence.
says, "Somewhere in every alchemist's heart is the dream of the Philosopher's Stone."
says, "Some say it's real. Some say it's a metaphor."
says, "I say if it's a metaphor, I want my money back."
## Taste Testing
says, "People ask if I taste my own potions. Of course I do."
says, "How else would I know the frost resistance one tastes like a mint left in a snowbank?"
says, "Or that the invisibility one tastes like nothing at all, which is somehow worse."
## The Customer
glances up at {target} and wipes their hands on a stained apron.
says, "Need something? Healing, mana, courage in a bottle?"
says, "I don't actually sell courage. It's just a strong ale. But people feel braver."
## Cleaning Up
corks the last vial and snuffs out the burner with a pinch.
says, "Everything sealed, labeled, and away from the fireplace."
says, "Good alchemists don't explode. Great alchemists remember why."
bows with a little flourish. [bow]
]] }

L.Tailoring = { "Tailoring", [[
## The Bolt
unrolls a long bolt of linen across the table and smooths it flat with both palms.
says, "Every great robe starts like this. A plain piece of cloth and a lot of hope."
takes a stick of chalk and marks the fabric with quick, sure lines.
says, "Measure twice, cut once. Measure a third time if the customer is a tauren."
## The Needle
threads a needle in one smooth motion, the thread catching the light.
says, "My first needle was a bent fishhook. My first thread was from my own sleeve."
says, "My mother was not pleased about the sleeve. But the doll I made was lovely."
## Cloth
lays out swatches one by one.
says, "Linen. Wool. Silk. Mageweave. Runecloth. Each one tells you about the world."
says, "Linen comes from the gentle places. Runecloth comes off things you'd rather not meet."
says, "Every robe is a little history of where someone has been."
## Stitching
leans close, stitching a seam with tiny, perfect stitches.
says, "A good seam is invisible. A great seam survives a dragon."
says, "I once mended a mage's robe after a fireball went the wrong way."
says, "He wore it into three more battles. My seam held. His hair didn't."
## Bags
holds up a bag stitched with golden thread.
says, "Bags are the real treasure. Everyone wants more space."
says, "Adventurers carry the strangest things. Rocks. Boots. A single chicken feather."
says, "I don't ask. I just make the bags bigger."
## Fashion
says, "Tailoring isn't just armor. It's style."
drapes a shimmering sash over one shoulder and strikes a pose. [flex]
says, "When you walk into the tavern in a fresh robe, people notice."
says, "Mostly they notice the bill. But also the robe."
## The Commission
says, "Last month a young couple asked me to make matching wedding cloaks."
says, "Dark blue, silver stars along the hem. Took me three weeks."
says, "She cried when she saw them. He pretended he didn't."
smiles warmly at the memory.
## Spellthread
holds up a spool that glows with a faint inner light.
says, "Spellthread. Stitched into trousers, it makes a mage's spells stronger."
says, "It also makes the trousers glow in the dark. You get used to it."
## Pricking a Finger
pricks their thumb and sucks on it with a wince.
says, "Every tailor bleeds into their work a little. Literally."
says, "It's fine. It's tradition. Blood is good luck. Mostly it's a stain."
## Finishing
holds up a finished robe, shaking it out so it falls in long, elegant folds.
says, "There. Done. Every stitch where it belongs."
folds it carefully and wraps it in paper.
/s Fresh robes, mended cloaks, bags for every hoard!
]] }

L.Engineering = { "Engineering", [[
## The Workbench
clears a space on a cluttered workbench, sweeping aside gears, springs, and a slightly smoking spark plug.
says, "Ah, my workbench. The most organized chaos in the world."
says, "Everything is exactly where I left it. I just don't know where I left it."
## Goggles
pulls a pair of thick brass goggles down over their eyes and adjusts the lenses with a click.
says, "Rule one of engineering: wear the goggles."
says, "Rule two: wear the goggles. I'm serious about rule one."
## The Gadget
holds up a small whirring contraption covered in dials.
says, "This is my latest invention. It's a... well, it's a work in progress."
presses a button. It beeps, spins, and falls over.
says, "Progress!"
## Explosives
holds up a small round bomb with a fuse, grinning.
says, "Every engineer starts with explosives. It's like a rite of passage."
says, "The first bomb I made went off a little early. I lost my favorite hat."
says, "And part of the ceiling. The landlord and I don't talk anymore."
laughs. [laugh]
## Gnomish or Goblin
says, "Engineers split into two schools: Gnomish and Goblin."
says, "Gnomish engineering is precise, elegant, and works perfectly. Eventually."
says, "Goblin engineering is fast, loud, and works perfectly. Briefly."
## The Mechanical Squirrel
whistles, and a tiny clockwork squirrel scurries up onto the bench.
says, "My first real success. A mechanical squirrel. He doesn't do anything useful."
pats the little machine fondly.
says, "But he never complains. Better company than most people."
## Teleporters
says, "Engineering teleporters. Faster than any flight path. Slightly less safe."
says, "Sometimes you arrive with a chicken's head. Sometimes you arrive upside down."
says, "Once I arrived on fire. Still faster than walking."
## Mounts
says, "The finest work an engineer can do is a mount. A mechanostrider. A flying machine. A chopper."
says, "Mine has a horn that plays three songs. It took six weeks and two burnt eyebrows."
## Repairs
pulls out a wrench and taps a pipe thoughtfully.
says, "People bring me broken things. Toys, tools, robots that won't stop dancing."
says, "Most of the time, you just hit it in the right place."
taps the pipe once, and it sputters to life.
says, "Engineering!"
## Dreams
gazes up at the sky with a wistful expression.
says, "One day I'll build something truly great. A ship that sails through the stars."
says, "Or at least a toaster that doesn't explode. Baby steps."
## Cleanup
switches off a humming machine, which sputters and sighs into silence.
says, "That's enough genius for one day. Too much genius and the building catches fire."
lifts the goggles to their forehead, leaving two clean circles in the soot. [chuckle]
]] }

L.Cooking = { "Cooking", [[
## The Fire
sets a battered iron pan over a crackling campfire and tosses in a knob of butter.
says, "Every great meal starts with a hot pan and an empty stomach."
watches the butter sizzle and foam, nodding approvingly. [nod]
says, "Listen to that. That's the sound of something good about to happen."
## Ingredients
lays out ingredients: a slab of boar meat, a handful of mushrooms, a few wild onions.
says, "Out here you cook with what the land gives you."
says, "Boar from the hills. Mushrooms from the riverbank. Onions from a farmer who wasn't looking."
coughs innocently.
## Spices
uncorks a tiny jar and sprinkles something red over the meat.
says, "Spices are the secret. A pinch of this, a dash of that."
says, "This one is from Stranglethorn. One pinch warms you. Two pinches and you see colors."
## The Recipe Book
pulls out a stained, dog-eared book stuffed with loose pages.
says, "My grandmother's recipe book. Every page is a memory."
says, "Here's her famous Westfall Stew. The recipe just says 'enough' for every ingredient."
says, "Enough salt. Enough potatoes. Enough love. Very helpful, Grandma."
## Tasting
dips a wooden spoon into a simmering pot and blows on it before tasting.
says, "Mmm. Needs more salt."
adds a pinch, tastes again.
says, "Needs more pepper."
adds a dash, tastes again, and smiles.
says, "Needs to be eaten. Immediately."
## Feeding the Raid
says, "Cooking for one is easy. Cooking for a raid of twenty-five hungry adventurers is war."
says, "The warriors want meat. The mages want something fancy. The druid wants a salad."
says, "And the hunter's pet eats everything before anyone else gets to it."
laughs heartily. [laugh]
## Burnt Offerings
holds up a blackened lump on a fork.
says, "Not every attempt is a success. Behold: Charred Wolf Meat."
says, "Technically still edible. Technically."
## Feasts
spreads out a huge platter piled with roasted meats and steaming bread.
says, "A proper feast. Set it down in the middle of the group and watch everyone come running."
says, "There's no magic stronger than a warm meal shared with friends."
## The Secret
leans in close to {target}.
says, "Want to know the real secret of good cooking?"
says, "You cook for someone. Not for the recipe. For someone."
## Serving
ladles stew into a bowl and offers it over with a warm smile.
says, "Here. Eat while it's hot. You look like you need it."
## Cleaning
scrubs the pan clean with sand and a scrap of cloth.
says, "A clean pan is a happy pan. A happy pan makes happy food."
/s Come and get it before the hunter's pet does!
]] }
