-- StoryCaster: Dungeon. One-click phrases for your group: GG, interrupt!, need that?, brb, sorry, grats and more.
-- Each button picks one of a few wordings so you don't repeat yourself, and posts to instance, raid or party chat,
-- whichever your group is. Your click sends it, so it's never automatic; a 1.5 second guard stops double clicks.
local ADDON, ns = ...
local R = ns.R
R.DUNGEON_GAP = 1.5

-- { group title, { { button label, { wordings... } }, ... } }
R.DUNGEON = {
  { "Hello", {
    { "Hello", { "Hello!", "Hi all!", "Hey everyone!", "Hello, hello! o/" } },
    { "Ty for group", { "Thanks for the group!", "Ty for the invite!", "Thanks for having me!" } },
    { "First time", { "First time here, any tips welcome!", "New to this one, bear with me!", "First time, I'll follow your lead." } },
    { "Know it", { "I know the fights, let's go!", "Done this plenty, ready when you are." } },
    { "Have fun", { "Have fun everyone!", "Good luck, have fun!", "glhf!" } },
  } },
  { "Ready", {
    { "Ready?", { "Everyone ready?", "Ready?", "Ready to go?" } },
    { "Ready!", { "Ready!", "Good to go!", "Ready when you are!" } },
    { "Wait", { "Wait one sec!", "Hold on a moment!", "Wait for me please!" } },
    { "Mana", { "Need a sec for mana.", "Drinking, one moment.", "Low mana, wait please." } },
    { "Pulling", { "Pulling!", "Pulling in 3!", "Here we go, pulling!" } },
  } },
  { "Combat", {
    { "Interrupt!", { "Interrupt that cast!", "Kick the caster please!", "Interrupt!" } },
    { "Kick on me", { "I've got the first interrupt.", "I'll take kicks on the caster." } },
    { "Stun!", { "Stun that one!", "Can someone stun?", "Stun please!" } },
    { "Focus", { "Focus the marked target!", "Kill skull first!", "Focus down the healer!" } },
    { "CC", { "CC the moon please!", "Can someone crowd control that one?", "Sheep the moon!" } },
    { "Move!", { "Move out of the bad!", "Get out of the fire!", "Watch your feet!" } },
    { "LoS", { "Line of sight the caster!", "Break line of sight, around the corner!" } },
    { "AoE", { "AoE now!", "Big pack, AoE them down!", "Cleave time!" } },
    { "Careful", { "Careful, big pull ahead.", "Easy here, this part hurts.", "Slow down a little, please!" } },
    { "Defensive", { "Using a defensive!", "Popping cooldowns!", "Big damage incoming, use defensives!" } },
    { "Bloodlust", { "Lust now!", "Popping Heroism!", "Time Warp incoming!" } },
    { "Wipe", { "We're wiping, run!", "Wipe it, reset!", "Let's reset and try again." } },
  } },
  { "Loot", {
    { "Need that?", { "Does anyone need that?", "Need that?", "Anyone want that item?" } },
    { "I need it", { "Could I roll need on that? It's an upgrade for me.", "I'd love that one if nobody needs it!" } },
    { "Greed", { "Greed from me.", "Passing, it's all yours.", "Not for me, go for it!" } },
    { "Trade?", { "Can anyone trade that to me if it's not an upgrade?", "Mind trading that if you don't need it?" } },
    { "Grats!", { "Grats on the loot!", "Congrats!", "Gz!", "Nice drop, grats!" } },
  } },
  { "Breaks", {
    { "brb", { "brb!", "Be right back!", "brb, one sec!" } },
    { "AFK 1 min", { "AFK one minute, sorry!", "Quick AFK, back in a minute!", "Need one minute, sorry!" } },
    { "Back", { "Back!", "I'm back, sorry about that!", "Back, ready to go!" } },
    { "Bio", { "Bio break, back in 2!", "Quick bio, 2 minutes!" } },
    { "Door", { "Someone at the door, one sec!", "Doorbell, brb!" } },
  } },
  { "Sorry", {
    { "Sorry", { "Sorry!", "My bad!", "Oops, sorry everyone!" } },
    { "My fault", { "That one was on me, sorry.", "My fault, sorry about that!" } },
    { "Lag", { "Sorry, lagging badly.", "Huge lag spike, sorry!" } },
    { "Dc", { "Sorry, disconnected!", "Got disconnected, back now!" } },
  } },
  { "Thanks", {
    { "Thanks", { "Thanks!", "Thank you!", "Ty!", "Much appreciated!" } },
    { "Nice heal", { "Great heals!", "Thanks for the heals!", "Healer is a hero!" } },
    { "Nice tank", { "Great tanking!", "Awesome tank, thanks!", "Smooth pulls, tank!" } },
    { "Nice dps", { "Great damage everyone!", "Those numbers, wow!", "Strong dps, nice!" } },
    { "GG", { "GG!", "gg wp!", "GG everyone, great run!", "GG, that was clean!" } },
    { "Great run", { "Great run, everyone!", "That was smooth, well played!", "Fantastic run, thanks all!" } },
  } },
  { "Goodbye", {
    { "Bye", { "Bye!", "Bye all!", "See you!", "Cya!" } },
    { "Ty all", { "Thanks all, have a good one!", "Thanks for the run, everyone!", "Ty all, take care!" } },
    { "Again?", { "Anyone up for another?", "Run it again?", "One more?" } },
    { "Gotta go", { "Sorry, gotta go! Thanks all!", "Have to head out, thanks for the group!" } },
  } },
}

-- where your group talks: instance chat in a finder group, raid, party, or nowhere
function R:GroupChannel()
  if IsInGroup and LE_PARTY_CATEGORY_INSTANCE and IsInGroup(LE_PARTY_CATEGORY_INSTANCE) then return "INSTANCE_CHAT" end
  if IsInRaid and IsInRaid() then return "RAID" end
  if IsInGroup and IsInGroup() then return "PARTY" end
end

function R:DungeonPhrase(group, i)
  local g = self.DUNGEON[group]
  local b = g and g[2][i]
  if not b then return nil end
  local w = b[2]
  local n = math.random(#w)
  -- don't say the very same wording twice in a row
  if #w > 1 and w[n] == self.lastDungeon then n = n % #w + 1 end
  return w[n]
end

function R:DungeonSay(group, i)
  if GetTime() < (self.dungeonReady or 0) then return nil end
  local chan = self:GroupChannel()
  if not chan and not self.db.testMode then self:Print("You're not in a group, so there's nobody to tell.") return nil end
  local text = self:DungeonPhrase(group, i)
  if not text then return nil end
  self:Perform({ text, nil, nil, chan or "PARTY" })
  self.dungeonReady = GetTime() + self.DUNGEON_GAP
  self.lastDungeon = text
  self.lastDungeonChan = chan
  self:Refresh()
  return text
end
