-- StoryCaster: the Pirate lines. Original writing, twelve categories.
-- A line in quotes is spoken (said aloud, or "says, ..." as an emote); any other line is acted as an emote.
-- {target} is your target, <mood> follows the Mood button, and [roar] style tags play an animation.
local ADDON, ns = ...
local R = ns.R
R.PIRATE = R.PIRATE or { cats = {} }
local function cat(key, title, icon, text)
  local lines = {}
  for raw in (text .. "\n"):gmatch("([^\r\n]*)\r?\n") do
    local l = raw:gsub("^%s+", ""):gsub("%s+$", "")
    if l ~= "" then lines[#lines + 1] = l end
  end
  R.PIRATE.cats[#R.PIRATE.cats + 1] = { key = key, title = title, icon = icon, lines = lines }
end

cat("hail", "Greetings and Hails", "e_wave", [[
"Ahoy there, {target}! Ye look like ye've got the sea in yer blood."
"Avast, matey! State yer name and yer business, and make it quick."
"Well shiver me timbers, if it isn't {target}!"
"Ahoy! Is that a friendly face, or a debt collector? I can never tell."
"Hail and well met, ye scallywag. Pull up a barrel."
"Ahoy, landlubber! Ye've wandered a long way from yer cozy hearth."
"Fair winds to ye, {target}, and following seas!"
"Avast! Nobody walks past me without a proper hello. It's the code."
"Ahoy! Lower yer weapon, friend. I only bite on Tuesdays."
"Well blow me down, it's a fine day to meet a fine rogue like ye."
"Ahoy, matey! Ye've the look of someone who's seen a kraken or two."
"Greetings, {target}. Mind the deck. It's slippery, and so am I."
"Ahoy there! Welcome aboard, or near enough."
"Arr, a new face! Tell me, can ye swim? Asking for no reason at all."
"Ahoy! Any friend of the sea is a friend of mine. Are ye a friend of the sea?"
"Look lively, {target}! A captain's arrived. That captain is me."
"Ahoy, me hearty! Ye look thirsty. I know a place."
"Avast ye! Who goes there? Oh, it's ye. Carry on, then."
"Ahoy! I'd tip me hat, but the last time I did, a gull stole it."
"Well, well. {target}. Last I heard, ye were at the bottom of the sea."
"Ahoy! Fancy meeting ye here, in the one tavern I swore I'd never return to."
"Hail, friend! Ye've a sturdy look. Ever thought of a life on the waves?"
"Ahoy, {target}! Have ye come to join me crew, or rob me? Both are fine."
"Avast! I recognize that swagger. Ye've sailed before."
"Ahoy! May yer sails be full and yer rum never run dry."
"Ahoy there, {target}! I've been looking for a sensible face. Ye'll have to do."
"Greetings, ye salty dog!"
"Ahoy! Shake me hand. Not that one, that one's mostly hook."
tips a battered tricorn hat toward {target} with a gap-toothed grin. [bow]
sweeps off their hat in a grand, slightly unsteady bow. [bow]
raises a hand in greeting, the other hand never far from a cutlass. [wave]
squints at {target} through one eye, then the other, then grins. [chuckle]
plants a boot on a barrel and gives {target} a long, piratical once-over.
waves a battered spyglass at {target} like an old friend. [wave]
leans against the mast-that-isn't-there, very casually. [shrug]
bellows "AHOY!" loud enough to scatter every gull in the harbor. [roar]
offers {target} a slightly sticky handshake that smells faintly of rum.
straightens their eyepatch and tries to look respectable. It doesn't take.
clicks their heels together in a salute borrowed from a navy they deserted. [salute]
whistles a sailor's two-note greeting across the deck. [wave]
claps {target} on the shoulder like a long-lost shipmate. [cheer]
squints out from under a hat at least two sizes too large.
nods to {target} with the slow respect one sea dog gives another. [nod]
spits on a palm and offers it for a shake. It's the pirate way.
bows so low the feather on their hat sweeps the floor. [bow]
waves a cutlass in greeting, then realizes and puts it away sheepishly.
grins wide enough to show three gold teeth and one suspicious gap. [laugh]
raises a tankard toward {target} by way of hello. [cheer]
leans in close to {target} and sniffs. "Ye smell of salt. Good." [chuckle]
lifts the eyepatch to get a better look, then lowers it again.
slaps the nearest table in welcome, rattling every mug on it.
hooks a thumb in their belt and nods at {target} like a captain inspecting new crew. [nod]
"Ahoy! Do ye hear that? That's the sound of adventure. Or my stomach."
"Avast, there's a familiar face! Last time I saw ye, ye owed me three doubloons."
"Ahoy, friend. Mind the parrot. He's a better judge of character than I am."
"Ahoy, {target}! Ready to sail into trouble?"
"Hello, sailor. Ahoy, rather. I'm practicing."
"Ahoy! The tide brought ye in. Lucky tide."
]])

cat("boast", "Boasts and Tall Tales", "e_flex", [[
"Did I ever tell ye about the time I wrestled a kraken? I won. Mostly."
"I once sailed through a storm so fierce, the lightning asked ME for directions."
"I've plundered more ports than ye've had hot dinners, {target}."
"They call me the terror of the seven seas. Well, three of them. The other four haven't met me yet."
"I once outran the entire Kul Tiran navy in a rowboat. With one oar."
"I've drunk rum with goblins, gambled with ghosts, and arm-wrestled a murloc."
"There's not a knot I can't tie, a ship I can't sail, or a tavern I haven't been thrown out of."
"I can smell treasure from a mile off. It smells like gold and bad decisions."
"Me ship once sailed so fast she left her own shadow behind in Booty Bay."
"I've been shipwrecked eleven times. The sea keeps giving me back. Says I'm too salty."
"Once I swam from Ratchet to Booty Bay. Took a shortcut through a whale."
"I stared down a sea giant once. He blinked first. They always blink first."
"I've a map tattooed on me back. Can't read it meself. That's the genius of it."
"Every cannonball ever fired at me has missed. I think they're scared of me."
"Me grandmother was a pirate. Me grandfather was her prisoner. Love is strange."
"I once traded a cursed coin for a blessed one. Then traded the blessed one for rum."
"I fought off twenty sailors with nothing but a ladle and a bad attitude."
"I can navigate by the stars. And the moon. And the smell of the nearest tavern."
"They wrote a song about me. It's mostly about me owing them money, but still."
"The sea serpent of the Great Sea? Old friend. We have tea on Thursdays."
"I once sank a ship just by glaring at it."
"I've had me heart broken in nine ports. Still got plenty left."
"Never lost a duel. Lost a few arguments. Never a duel."
"I sailed off the edge of the map once. Came back with better stories."
"Me cutlass has a name. It's a secret. It's also very rude."
"I once bet a dragon I could hold me breath longer than him. Still waiting on me winnings."
"Ye see this scar? Shark. This one? Also a shark. Same shark. We've history."
"I've been to the bottom of the sea and back. The bottom's overrated."
"I once found a whole island made of gold. Lost it in a card game the same night."
"I'm the only pirate alive who can whistle a shanty and a curse at the same time."
"The ocean once tried to drown me. I drank it instead. Tasted terrible."
"Captains tremble when they hear me name. Then they ask me to spell it."
flexes an arm covered in fading anchor tattoos. [flex]
puffs out their chest and strikes a heroic pose on the nearest crate. [flex]
taps a gold tooth meaningfully, as though it proves everything. [chuckle]
rolls up a sleeve to show a scar, and begins a very long story about it.
draws a cutlass and twirls it, nearly losing it on the second twirl.
leans back with a smug grin, waiting for {target} to be impressed.
spreads their arms wide to show just how big the fish was. It keeps getting bigger. [point]
counts off their adventures on their fingers, and runs out of fingers. Twice.
thumps their chest proudly. "Terror of the tides, that's me." [roar]
pulls a battered medal from a pocket. Nobody knows what it's for, least of all them.
shows off a necklace of shark teeth, naming each one fondly.
strikes a dramatic pose as if a painter might be watching. [flex]
lowers their voice to a dramatic whisper for the scary part of the tale.
pauses for effect in the middle of a story, then forgets where it was going. [shrug]
tells the tale with so much arm-waving they knock over a mug. [laugh]
swears on their mother's eyepatch that every word is true. [salute]
laughs so hard at their own story they have to sit down. [laugh]
"Ask anyone in Booty Bay about me. Then run, because they'll want their money back."
"I've seen things on the open sea that'd turn yer hair white. Look at mine. Ye see?"
"I once sailed a ship made entirely of barrels. It was mostly a raft. It was glorious."
"Fear? Never heard of her. Did she sail with Bloodsail?"
"The kraken sends me a card every year. Very thoughtful, for a kraken."
"The sea is me mother, the wind is me father, and the rum is me cousin."
"I'm not saying I'm the greatest pirate ever. I'm letting others say it. Loudly. On me orders."
"I could find treasure in an empty room. In fact, I have. It was under the floorboards."
"Legends don't die, {target}. They just go out for more rum."
"I've been hanged twice. The ropes keep snapping. Ropes respect me."
]])

cat("insult", "Insults and Threats", "e_point", [[
"Ye fight like a seasick parrot, {target}."
"I've met barnacles with more charm than ye."
"Ye couldn't find water if ye fell off a ship."
"Yer breath could strip the paint off a hull."
"Ye've the sea legs of a newborn kodo."
"I've seen better swordplay from a crab with a toothpick."
"Ye scurvy bilge rat!"
"Ye lily-livered landlubber!"
"Ye couldn't steer a rowboat in a bathtub."
"Ye call that a cutlass? I've seen sharper soup spoons."
"Yer ship's so leaky the fish use it as a hallway."
"Ye've less brains than a bucket of chum."
"I'd challenge ye to a battle of wits, but ye came unarmed."
"Ye smell like the bottom of a fish barrel on a hot day."
"Ye're about as frightening as a wet kitten in a tricorn."
"Arr, ye barnacle-brained son of a sea cucumber!"
"I've met mutineers more loyal than ye."
"Ye'd lose a staring contest to a sleeping gull."
"Yer hat's ugly and yer mother's a mermaid. A mean one."
"I'll feed ye to the sharks, and they'll send ye back for being too bitter."
"Walk the plank, ye bilge-sucking scallywag!"
"Ye couldn't tie a knot if the rope did it for ye."
"Ye've got the swagger of a soggy biscuit."
"Ye bring shame to every eyepatch in the realm."
"Even the rats left yer ship, and they've no standards."
"Ye fight like a farmer and ye smell like his cow."
"Avast, ye flea-bitten bucket of bilge water!"
"I've met lighthouses with better conversation than ye."
"Yer map's upside down, and so is yer face."
"Ye're the reason sailors pray for storms."
"Ye've got all the courage of a jellyfish in a jar."
"I'll make ye swab the deck with yer own beard!"
"Say that again and I'll tie ye to the anchor and let ye find the bottom yerself."
"Ye couldn't plunder a lemonade stand."
"Ye've the sense of direction of a drunk compass."
"Even yer parrot's ashamed of ye."
points a cutlass squarely at {target}'s nose. [point]
narrows their one good eye at {target}. [shrug]
spits over the side with tremendous contempt.
snorts loudly in {target}'s direction. [laugh]
rolls their eyes so hard their eyepatch slips.
cracks their knuckles one by one, very slowly. [flex]
mutters something about sharks and looks pointedly at {target}.
draws a finger across their throat, then winks. It's mostly a joke. [point]
throws down a glove. Then picks it back up, because it's their only glove.
growls low in their throat like an angry sea lion. [roar]
paces around {target} slowly, looking them up and down with disdain.
taps the blade of a cutlass against an open palm, meaningfully.
laughs a long, nasty laugh that echoes around the docks. [laugh]
squints at {target} as though measuring them for a plank.
waves a rude gesture common to every port in the realm. [point]
blows a raspberry at {target}, then looks very pleased with themselves.
mimes {target} falling off a ship, with sound effects.
"I'm not saying ye're useless. Ye'd make a fine anchor."
"Ye're about as welcome as a hole in the hull."
"Run along, little guppy, before ye get hurt."
"I've plundered ships with tougher crews than yer whole family."
"Ye look like ye were assembled from spare parts of a shipwreck."
"Arr, I've had more fearsome opponents in a bathtub."
"When ye walk the plank, I'll wave. Politely. Once."
]])

cat("treasure", "Treasure and Plunder", "scroll", [[
"Gold, {target}! Glorious, shining gold!"
"X marks the spot. The trouble is, someone drew a lot of X's on this map."
"Treasure's not about the gold, matey. It's about the gold. It's always the gold."
"Dig here! No, there. No, here again. Keep digging."
"There's a chest buried on this very island, and I mean to find it."
"Pieces of eight! Pieces of eight! Or seven, if ye count me fee."
"Every coin has a story. Most of them are about me stealing it."
"I can hear the treasure calling. It sounds like jingling. And screaming. Mostly jingling."
"Don't tell anyone where it's buried. Not even me. Especially me, after rum."
"One man's trash is another man's plunder."
"A pirate's best friend is a shovel and a map with no rules."
"Share and share alike! I get the share, ye get the alike."
"Fortune favors the bold, and the bold favor fortune."
"This map was drawn by a dying pirate in his own blood. Or ketchup. It's unclear."
"The treasure is cursed, they say. Good. Cursed gold spends the same."
"Divide it evenly? I've never heard such nonsense."
"Doubloons, rubies, emeralds, and one very confused crab."
"Plunder first, ask questions never."
"There's more gold at the bottom of the sea than in every bank in Stormwind."
"Ye don't find treasure, {target}. Treasure finds ye, when ye're not looking."
"A chest full of gold, and the key's at the bottom of a shark. Typical."
"Treasure maps are like rum. The older, the better."
"I'll trade ye this lovely ruby for that ugly ruby. Deal?"
"Gold doesn't buy happiness. But it buys a ship, and that's close."
"Somewhere out there is the Big One. The treasure to end all treasures."
"I once found a chest of gold coins. They were chocolate. Still ate them."
"The rules of plunder: take what ye can, give nothing back, apologize to no one."
"This compass doesn't point north. It points to what I want most. Currently: lunch."
"Keep yer hands off me loot, or lose them."
"There's a fortune in this cave, I can feel it in me bones. And me knees. It's damp."
"Bury it deep, mark it well, and never trust the parrot with the location."
unrolls a stained treasure map across the table, weighing the corners with daggers.
taps a big red X on the map and grins at {target}. [point]
bites a gold coin to check it's real, and winces. It's real.
pulls out a shovel and starts digging with enthusiasm and no plan.
runs their fingers through a handful of coins, letting them jingle. [chuckle]
counts out coins in a whisper, losing track at seventeen. Starts again.
holds a ruby up to the light, eyes sparkling as much as the gem.
throws open an imaginary chest and gasps theatrically. [gasp]
hides a pouch of gold down their boot with a wink. [chuckle]
squints at the map, turns it upside down, and nods. "Ah. That's better."
paces out steps across the deck. "Ten paces from the palm tree... what palm tree?"
pats a bulging coin purse lovingly. [cheer]
pockets something shiny when they think nobody's looking.
holds up an old brass key and gives {target} a mysterious look.
dances a little jig over a newly found chest. [dance]
weighs a gold bar in each hand, then grins like a child. [laugh]
studies the stars, then the map, then the stars again, muttering.
tucks a map into a hidden pocket and taps the side of their nose.
buries a small box in the sand and marks the spot with a lopsided X.
"Plunder ahoy! Fill yer pockets, lads!"
"Every coin we take today is a coin some merchant won't miss. Probably."
"I'll split it with ye, {target}. Ninety for me, ten for ye. Ten percent, not ten coins."
"Gold, jewels, silk, spice. And these very nice spoons."
"The richest pirate isn't the one with the most gold. It's the one who never gets caught."
"Treasure hunting's easy. It's the treasure keeping that's hard."
"That's not just a map, {target}. That's a promise."
"Shiny things! Shiny things everywhere!"
]])

cat("ship", "Ship Life and Sailing", "ship", [[
"Hoist the mainsail! Look lively!"
"All hands on deck! That means ye too, {target}!"
"Batten down the hatches, there's weather coming."
"Trim the sails and mind the boom!"
"Heave ho, me hearties! Put yer backs into it!"
"Weigh anchor! We sail with the tide!"
"Hard to starboard! No, the other starboard!"
"Steady as she goes, helmsman."
"Land ho! Or a very large whale. Either way, steer for it."
"Swab the deck until I can see me reflection in it."
"Who left the rigging in a tangle? Confess now and I'll only keelhaul ye a little."
"There's no finer sound than the creak of a good ship under full sail."
"A ship's like a woman, they say. I say a ship's like a ship. Very wet."
"Man the cannons! Or woman them. Anyone, really. Just do it."
"Reef the topsails before the wind takes them!"
"Full speed ahead! Well, as full as she goes."
"Check the bilge. I heard something gurgle that wasn't me."
"Sound the depth! I'll not run aground twice in one week."
"Ship's biscuits again. I've broken teeth on softer stones."
"The captain's word is law. Unless the captain's asleep. Then it's a suggestion."
"Who's on watch? Somebody wake whoever's on watch."
"Coil that rope properly or I'll coil ye with it!"
"Ye'll learn to love the sea, {target}. Or ye'll learn to swim."
"There's a storm behind us and a reef ahead. Perfect sailing weather."
"Every plank on this ship has a story. Most of them are leaks."
"Raise the colors! Let them know who's coming."
"Fair winds! Fill the sails! Let her fly!"
"Mind the mast. It's been mended four times and it still holds a grudge."
"The sea is calm today. I don't trust it."
"Galley's open! Today's special is fish. Yesterday's special was also fish."
climbs halfway up the rigging and peers out at the horizon. [point]
spins the ship's wheel hard to port, wind whipping their coat.
hauls on a rope with a great heave, boots braced against the deck. [flex]
peers through a brass spyglass, then lowers it slowly. "Trouble."
ties a sailor's knot in three quick movements, then admires it.
scrubs the deck on hands and knees, grumbling about rank and fairness. [kneel]
leans over the rail and breathes in the salt air deeply. [sigh]
checks the compass, frowns, and taps it twice for luck.
hums a working song as they mend a torn sail.
stands at the bow, coat streaming in the wind, looking very dramatic.
coils a rope neatly and hangs it on a peg with great care.
rings the ship's bell to call the watch. [cheer]
squints up at the crow's nest. "Oi! Stop sleeping up there!"
stumbles as the deck rolls, then pretends it was a dance move. [dance]
plants their feet wide on the swaying deck, perfectly balanced.
licks a finger and holds it up to test the wind. [point]
pats the ship's railing affectionately. "Good girl."
watches the wake stretching behind them, lost in thought.
bails water out of the bilge with a bucket, very fast, very worried.
checks the cannon fuses one by one, nodding at each. [nod]
salutes the ship's figurehead as they pass it. [salute]
"Ye never forget yer first ship. Mine sank. I still miss her."
"Sailing's simple. Point the pointy end at where ye want to go."
"Keep her steady through the swells, and she'll carry us home."
"The ship doesn't care who ye were on land. Only how ye haul a rope."
"Out here, {target}, there's no king but the wind."
"When the sea is rough, the crew holds together. That's the real rule."
"Nothing between us and the horizon but water and possibility."
]])

cat("grog", "Grog and the Tavern", "e_cheer", [[
"Barkeep! Rum! Lots of it! And a little more for me friend {target}."
"Why is the rum always gone?"
"Drink up, me hearties! Tomorrow we sail, tonight we sing!"
"A toast! To the sea, the ship, and the ones we left behind!"
"This rum tastes like the bottom of a barrel. Lovely. Another."
"Grog's not a drink, {target}. It's a way of life."
"One more round and then we'll go. Or two. Three at the very most."
"Whoever spilled me rum owes me a rum and an apology. Rum first."
"I'm not drunk, I'm sea-legged. It's a professional condition."
"Pour it to the top, barkeep. I didn't come here for half measures."
"Rum, a fire, and good company. What more could a pirate want? Gold. Also gold."
"To absent friends, and the sharks that have them!"
"There's two kinds of pirates: the ones who can hold their rum, and the ones on the floor."
"Who wants to hear a song? Too late, I'm singing."
"This tavern's seen better days. So have I. Cheers to us both."
"Another round for the house! On {target}'s tab!"
"I drink to forget. I forget what I'm forgetting. So I drink more."
"Rum's the only thing in this world that never betrays ye. Except when it does."
"Arm-wrestle for the next round? Loser pays. I always lose. I always pay. It's a tradition."
"The best ideas start with rum. The worst ideas also start with rum."
"If the room's spinning, ye're doing it right."
"No one leaves until the barrel's empty! And it's a big barrel."
"I once drank a whole cask in Booty Bay. Woke up in Ratchet. Still don't know how."
"Easy on the grog, matey. Save some for the rest of us."
"Here's to the women and the wine and the waves and the wind!"
"Barkeep, what's yer strongest drink? No, stronger. No. Stronger."
"Let's settle this like civilized pirates. With a drinking contest."
"A pirate without rum is just a sad person on a boat."
raises a battered tankard high and roars a toast. [cheer]
slams an empty mug on the table and wipes their mouth on a sleeve.
sways gently, though the tavern floor is perfectly still.
slides a mug down the bar toward {target}, who just about catches it.
tries to stand on a table to make a speech, and thinks better of it.
pours a little rum on the floor for lost shipmates. [salute]
clinks mugs with {target} so hard both slosh over. [cheer]
hiccups loudly in the middle of a very serious sentence.
squints into an empty tankard as though it's personally betrayed them.
leans heavily on the bar, grinning at nobody in particular. [laugh]
challenges the room to an arm-wrestling contest, then loses immediately. [flex]
drapes an arm around {target}'s shoulders, friendly and a little unsteady.
starts a drinking song that only they seem to know the words to.
pounds the table in time to the music, rattling every mug. [dance]
orders another round with a grand wave that knocks over a candle.
falls asleep briefly against the bar, then wakes with a snort.
tips back the last of the rum and sighs happily. [sigh]
spins a coin on the bar and catches it with a flourish.
dances a wobbly jig between the tables. [dance]
pats their pockets for coins, finds only lint and a single button. [shrug]
"It's not the rum talking. It's me. The rum's just helping."
"This tavern's got the best rum and the worst fights. Me favorite combination."
"Never trust a sober pirate, {target}. They're planning something."
"Another! For courage! And thirst! Mostly thirst."
"When I die, bury me with a barrel of rum. And a straw."
"Toast to {target}! The finest drinking companion this side of the Great Sea!"
"Last call? There's no such thing on a pirate's night out."
"A little rum in the morning keeps the scurvy away. That's medicine."
"The bottom of the bottle is where the best stories live."
]])

cat("shanty", "Sea Shanties", "e_dance", [[
"Oh, the wind blows high and the wind blows low, and away to the west we go!"
"Haul away, me lads, haul away! The sea is calling us today!"
"We'll sail the salty sea, me boys, from dawn until the night!"
"Heave her up and away we'll go, heave her up and the wind will blow!"
"Oh, the captain drinks his rum, me boys, and the crew drinks seawater!"
"Pull, me hearties, pull! The waves are high and the hold is full!"
"Farewell to the harbor and farewell to the shore, we're off to the sea forevermore!"
"Oh, the rum is sweet and the wind is strong, and we'll sing this shanty all night long!"
"Ten thousand miles from home we sail, through sun and storm and wind and gale!"
"Way hey, and up she rises! Way hey, and up she rises!"
"What shall we do with a soggy pirate? Throw him in the brig until he's drier!"
"Oh, the anchor's up and the sails are set, we'll be rich men yet, we'll be rich men yet!"
"There once was a ship that sailed the sea, and the crew was jolly as jolly can be!"
"Leave her, Johnny, leave her! The tide is turning now!"
"Oh, the gold is in the chest, me boys, and the chest is in the sea!"
"Blow, ye winds, blow, and carry us home! We've plundered enough and we're ready to roam!"
"The cook burned the stew again, me boys, the cook burned the stew!"
"Sing for the wind and sing for the waves, sing for the sailors in watery graves!"
"Oh, the kraken came a-calling, but we gave him rum instead!"
"We're bound for Booty Bay, me boys, where the rum flows free and the sharks all play!"
"Row, row, row the boat, it's a long way to the shore!"
"Haul on the bowline, the long-tailed bowline, haul on the bowline, haul!"
"Oh, me girl's in Stormwind and me boy's in Ratchet, and me heart's out on the sea!"
"The captain's got a wooden leg, the mate has got a hook, and I've got a parrot who can't read a book!"
"So raise yer mugs and sing along, to the sea, the sea, the sea!"
"Away, away, with fife and drum, here we come with a barrel of rum!"
"And when I die, don't bury me at all, just toss me in the sea and let me sail!"
"We sailed to the edge of the world one day, and the world said: turn around, go away!"
"Oh, a pirate's heart is wild and free, and it beats in time with the rolling sea!"
starts stamping out a rhythm on the deck, clapping along. [applaud]
throws back their head and bellows the chorus at full volume. [cheer]
links arms with {target} and sways in time to the shanty. [dance]
conducts the whole tavern with a turkey leg like a baton.
taps a boot and hums the tune of an old working song.
hauls on an invisible rope in time with the song. [flex]
sings the next verse completely off key, with total confidence.
dances a sailor's hornpipe, arms folded, feet flying. [dance]
pauses mid-verse to take a drink, then picks up exactly where they left off.
waves a mug in the air to the beat, sloshing rum everywhere. [cheer]
claps out the rhythm and nods for {target} to join in. [applaud]
forgets the words to the third verse and makes up new ones about cheese.
holds a long note until they run out of breath and turn purple. [gasp]
spins in a circle at the end of the chorus and nearly falls over. [dance]
sings a soft, slow verse about home, looking out at the sea. [sigh]
whistles the tune between verses. [chuckle]
drums on a barrel with both hands, grinning. [dance]
leads the crew in a rousing chorus, fist pumping in the air. [cheer]
"Everybody sing! Even ye, {target}! Especially ye!"
"Louder! The fish in the deep can't hear ye!"
"That's a working song, matey. Ye sing it while ye haul. So haul!"
"Oh, the sea gives and the sea takes away, but we'll sing on her bosom another day!"
"Then up with the anchor and out with the tide, with the wind at our back and the world open wide!"
"Oh, there's rum in me belly and salt in me hair, and a song on me lips and a song in the air!"
"The night is long and the moon is high, we'll sing our shanties till the dawn breaks the sky!"
"Heave, me lads, heave! Another verse before we leave!"
"Last verse! Everyone together, and mean it this time!"
"That's how ye sing a shanty! From the gut and the heart, both at once!"
"One more! One more! Nobody goes to bed while there's a shanty left in me!"
]])

cat("battle", "Battle and Boarding", "e_roar", [[
"Prepare to be boarded!"
"Fire the cannons! All of them! At once!"
"Draw yer swords, lads! This is what we came for!"
"No quarter! Well, a little quarter. Quarter for the cook, he's good."
"Grappling hooks away! Pull us alongside!"
"Give them a broadside they'll never forget!"
"Surrender yer cargo and nobody gets wet!"
"Ye'll be swimming with the fishes before this day's done!"
"Charge! For gold and glory and the good rum in their hold!"
"Swing across, lads! Don't look down! Don't look at the sharks!"
"Ready the cannons! Aim! Wait for it... FIRE!"
"Hold the line on the deck! Don't let them reach the wheel!"
"I've fought krakens, {target}. Ye're barely a minnow."
"Strike yer colors or we'll strike ye down!"
"That's the last time ye shoot at MY ship!"
"Repel boarders! Push them back over the rail!"
"Fight like the sea itself, lads: relentless and wet!"
"They've got more men, but we've got more spite!"
"Hoist the black flag! Let them know there'll be no mercy today!"
"Arm yerselves! Cutlasses, pistols, belaying pins, frying pans!"
"Right then, ye scurvy dog. En garde!"
"Ye'll not take this ship while I've breath in me body!"
"Aim for the mast! Bring her down!"
"Fire in the hole!"
"Stay together! A crew that fights together sails home together!"
"I'll cut ye down to size, ye overgrown barnacle!"
"Show them what pirates are made of! Mostly rum and stubbornness!"
"Boarding party, with me! The rest, keep those cannons hot!"
"First one aboard gets a double share! Second one gets a single share and a slap!"
"Now that's what I call a proper sea battle!"
draws a cutlass with a ringing sound and grins dangerously. [roar]
swings across on a rope, cutlass in teeth, and lands with a thud. [flex]
ducks as a cannonball whistles overhead, then pops back up laughing. [laugh]
fires a pistol into the air for effect. It's very effective.
crosses blades with {target}, sparks flying. [roar]
leaps onto the rail, sword raised high, roaring defiance. [roar]
kicks a barrel of gunpowder toward the enemy and dives for cover. [cower]
parries a blow, spins, and lands a cheeky slap with the flat of the blade.
fights with a sword in one hand and a mug of rum in the other.
dodges a swing so narrowly it trims their beard. [gasp]
lights a cannon fuse and covers both ears with a grin.
pushes an attacker overboard with a hearty shove. [laugh]
picks up a fallen enemy's hat and tries it on mid-battle.
roars a battle cry that makes the gulls scatter. [roar]
stands back to back with {target}, cutlass at the ready.
wipes their blade on their sleeve and looks for the next challenger.
lands a good punch, then shakes out a very sore hand. [flex]
rolls under a swinging boom and comes up swinging. [cheer]
salutes a worthy opponent before the duel begins. [salute]
climbs the rigging to get a better shot at the enemy captain. [point]
holds a cutlass to an enemy's throat. "Yer cargo, or yer cravat."
plants the black flag on the enemy's deck with a triumphant cheer. [cheer]
"Is that the best ye've got? Me grandmother hits harder, and she's been dead six years!"
"Yield, {target}, and I'll let ye keep yer boots. Probably."
"That's MY rum ye just spilled, and now ye'll pay for it!"
"Ha! Missed me! Missed me again! Ye've the aim of a blind sea turtle!"
"The battle's won, lads! Now for the fun part: counting the loot!"
"Ye fought well. For a landlubber. Now hand over the gold."
"Mercy? I've heard of her. Never met her."
]])

cat("superstition", "Superstitions and Sea Legends", "eye", [[
"Never whistle on a ship, {target}. Ye'll whistle up a storm."
"Bananas on board? Throw them over! Nothing but bad luck, bananas."
"Red sky at night, pirate's delight. Red sky at morning, pirates take warning."
"Never set sail on a Friday. Or a Tuesday. Or any day ending in Y, if ye're superstitious enough."
"A cat aboard is good luck. A black cat is great luck. A cat that talks is a warlock. Throw it over."
"Don't say 'drowned' on deck. The sea might hear ye and take it as a suggestion."
"If ye see a ghost ship, look away. If it looks back, ye're already sailing with it."
"A gold earring pays for yer funeral if the sea takes ye. That's why we wear them."
"The sea remembers every sailor she ever took. Don't give her a reason to remember ye."
"Never change a ship's name. Bad luck follows a renamed ship to the bottom."
"Dolphins swimming alongside? Good omen. Sharks swimming alongside? Also an omen. Different kind."
"There's a sea witch in the Great Sea who'll grant ye a wish. She takes yer shadow as payment."
"They say the Flying Gull sails without a crew, steered by a captain who died a hundred years ago."
"Never cut yer hair at sea. The storm takes it as an offering and demands more."
"Touch the ship's figurehead before a voyage. She watches over us."
"If a gull lands on the mast and stares at ye, ye're the one who'll fall overboard."
"Hear singing on a still night? Plug yer ears, lad. That's no mermaid ye want to meet."
"There's an island that only appears when the moon is full. The treasure there's guarded by the drowned."
"A ship's bell that rings by itself means someone aboard won't see home."
"Never step onto a ship with yer left foot first. Never."
"The kraken can only see what moves. So if ye see one, freeze. And pray."
"Always pour a drop of rum for the sea before ye drink. She gets thirsty too."
"They say there's a lighthouse that guides ships to their doom, not to safety."
"Throwing a coin into the sea buys ye safe passage. Throwing two buys ye a good wind."
"Never point at the moon from a ship. It's rude, and the moon is petty."
"The sea serpent of the north eats only liars. So I sail south."
"Old sailors say the stars move different over the deep water. They're right."
"Never kill an albatross. Never. I don't care how hungry ye are."
"The drowned keep a ledger of every pirate. Pay yer debts before ye die."
"If the compass spins on its own, turn back. Something down there doesn't want ye passing."
knocks three times on the wooden rail for luck. [nod]
throws a pinch of salt over their shoulder, then another to be safe.
kisses a lucky coin and tucks it back into a pocket.
touches the ship's figurehead gently and murmurs a few words. [kneel]
glances nervously at the horizon, then at {target}. "Did ye see that?"
pours a little rum over the rail for the sea. [salute]
clutches a charm hung around their neck as the fog rolls in. [cower]
refuses, very firmly, to whistle. Even when asked nicely.
shivers suddenly. "Someone just walked over me watery grave."
eyes a bunch of bananas with deep suspicion.
tosses a coin into the waves for safe passage.
crosses their fingers behind their back as the ship leaves port.
whispers a sailor's prayer under their breath, eyes closed. [kneel]
points at a strange light on the water, then slowly lowers the finger. [point]
counts the gulls on the mast and frowns at the odd number.
lowers their voice to tell a ghost story, and the candle flickers on cue.
taps the compass nervously as the needle wavers.
hangs a horseshoe over the cabin door for luck. [nod]
refuses to step aboard with their left foot. Takes three attempts. [shrug]
"Laugh if ye like, {target}. The sea doesn't care if ye believe."
"I've seen the ghost ship with me own eye. The other one was closed in terror."
"Every legend's got a bit of truth in it. That's what makes them dangerous."
"The sea has its own rules, and none of them are written down."
"Ye don't have to believe in curses. Curses believe in ye."
"Old salts don't live to be old by ignoring the omens."
"I'm not superstitious. I'm careful. There's a difference. A small one."
"Did ye hear that? No? Good. Neither did I. Let's go."
"Never trust a calm sea, a smiling shark, or a captain who doesn't drink."
]])

cat("parrot", "The Parrot", "parrot", [[
whistles, and a scruffy parrot flutters down to land on their shoulder.
feeds the parrot a cracker. It demands a second one immediately.
"Polly wants a cracker! No, Polly wants yer cracker, {target}."
listens as the parrot screeches "PIECES OF EIGHT!" right in their ear. [cower]
winces as the parrot nibbles their earlobe affectionately.
"Mind the parrot, {target}. He bites. He also lies."
strokes the parrot's feathers gently. The parrot pretends not to enjoy it.
watches the parrot steal a shiny button from {target}'s coat. [laugh]
"He's not a pet. He's me first mate. He outranks most of the crew."
"Say hello to {target}, Captain Feathers. Say hello. Be nice."
groans as the parrot squawks something very rude at {target}. [shrug]
"I didn't teach him that word. He learned it from the cook."
holds out an arm, and the parrot hops down it like a tiny admiral.
"This bird's been to more ports than most sailors. Remembers all of them."
watches the parrot puff up its feathers indignantly at a passing gull.
"He thinks he's a hawk. Don't tell him otherwise."
scolds the parrot for pulling at their hat. The parrot ignores them entirely.
mimics the parrot perfectly: "Squawk! Walk the plank! Squawk!"
laughs as the parrot dances side to side on their shoulder. [dance]
"The parrot knows where the treasure is. He won't tell me. Says I'll waste it."
lets the parrot sip from their mug. Regrets it instantly.
covers the parrot's eyes. "Not in front of the bird."
"He once warned me about a mutiny. Saved me neck. Now he expects crackers for life."
watches the parrot land on {target}'s head and settle in. [chuckle]
"Don't mind him. He likes ye. That's a good sign. Usually."
"Polly says ye owe him an apology. I don't know what for. Neither does he."
whistles a tune and the parrot whistles it back, slightly better. [laugh]
tries to teach the parrot a new word. The parrot says the old rude one instead.
"He's older than me. Older than the ship. Might be older than the sea."
asks the parrot for a song, and gets a single, ear-splitting squawk. [cower]
offers the parrot a seed. The parrot considers it, then takes {target}'s seed instead.
"This bird has survived three shipwrecks and a kraken. And me cooking."
watches the parrot preen itself vainly in a mirror.
"If I fall overboard, the parrot inherits everything. It's in me will."
"He snores. Did ye know parrots snore? I didn't, before Feathers."
ducks as the parrot swoops low over the tavern, screeching. [cower]
"He's a fine judge of character. He hates everyone. So he's never wrong."
gently tucks the sleeping parrot inside their coat.
scolds the parrot for stealing spoons. It drops one, guiltily.
"He talks more sense than half me crew. Fewer words, though."
watches the parrot flap up to the rigging and refuse to come down.
"When he bobs his head like that, he's either happy or about to bite. Good luck."
holds up a cracker and the parrot does a little spin for it. [cheer]
sighs as the parrot squawks "Rum! Rum!" It has clearly been listening.
"Feathers, meet {target}. {target}, meet the most dangerous creature aboard."
pretends to argue with the parrot, and loses. [shrug]
"He's not mine. I'm his. He made that very clear early on."
lets the parrot perch on their finger and talks to it like an old friend.
"He once bit a navy admiral on the nose. I've never been prouder."
watches the parrot puff up and fall asleep mid-squawk. [chuckle]
"Polly wants a cracker. Polly wants gold. Polly wants respect."
scratches the parrot under the chin. Its eyes close blissfully.
"The parrot sees everything. Mind what ye do around him."
"He used to belong to a famous captain. Wouldn't say who. Very discreet bird."
watches the parrot flap off with a gold coin in its beak. "COME BACK HERE!"
"Feathers says it's time for another round. Feathers is always right."
grins as the parrot squawks "Shiver me timbers!" It is very proud of that one.
"He'll outlive us all, {target}. Parrots always do. And they never forget a grudge."
tells the parrot to say goodnight. It says something else entirely. [laugh]
]])

cat("sea", "The Sea and the Weather", "anchor", [[
"Smell that, {target}? Salt and wind and freedom."
"The sea's in a mood today. Best keep our heads down."
"There's a storm on the horizon, and she's coming for us."
"Calm seas never made a skilled sailor."
"The waves are the sea's breathing. Today she's breathing hard."
"Look at that sunset over the water. Worth every storm."
"Fog as thick as pea soup. Keep yer eyes open and yer mouth shut."
"The tide waits for no one, not even a pirate."
"The sea gives everything and asks for everything back."
"There's nothing quite like moonlight on the open ocean."
"Wind's changing. I can feel it in me knee. The wooden one."
"Rain's coming. I can smell it."
"Ye haven't lived till ye've seen a storm from the deck of a ship."
"Doldrums. No wind, no waves, no rum. The worst three things at once."
"Every wave out there's been somewhere we've never seen."
"The sea is the only master I've ever served willingly."
"She's beautiful today, the sea. Beautiful and deadly, like all the best things."
"When the sea goes quiet, that's when ye should worry."
"There's a squall coming in fast! Reef the sails!"
"Stars are bright tonight. Good for navigating. Good for dreaming."
"The ocean doesn't care how tough ye are, {target}. Respect her."
"A good wind is worth more than any treasure."
"I was born on the sea. I'll die on the sea. In between, I'll drink near the sea."
"The deep water's a different color. Darker. Older."
"Hear that? That's the sea talking. She's saying 'go home'. We won't."
"Lightning over the water! Count the seconds! One, two..."
"Sun's barely up and the sea's already showing off."
"Waterspout off the starboard bow! Steer clear!"
"The sea's like rum. Fine in moderation. Deadly in excess. Wonderful either way."
stands at the rail, staring out at the endless blue. [sigh]
breathes in the salt air and smiles for the first time in days.
watches the clouds gather on the horizon, frowning. [point]
pulls their coat tight against the spray. [cower]
squints into the driving rain, gripping the rail with both hands.
leans out over the water, watching the dolphins race alongside. [cheer]
holds their hat on with one hand as the wind gusts hard.
watches a seabird wheel overhead and wishes, briefly, for wings.
dips a hand into the cold sea water and lets it run through their fingers.
stares at the sunset in silence, the waves turning gold.
licks the spray from their lips. "Salty. Perfect."
braces against the rail as a big wave crashes over the bow. [gasp]
watches the stars come out one by one over the dark water.
lies back on the deck and lets the ship rock them gently. [sit]
points out a distant island shrouded in mist. [point]
watches a pod of whales breach in the distance, awestruck. [gasp]
shivers in the cold night wind and tugs a blanket closer.
closes their eyes and listens to the waves slap against the hull.
sniffs the wind like a hound. "Land's close. I can smell it."
waves at a passing ship, far across the water. [wave]
"Out here, {target}, ye see what ye're made of."
"There's peace in the waves, if ye know how to listen."
"The sea never looks the same twice. That's why I love her."
"Every storm ends. Every calm ends too. That's the sea's lesson."
"Some days the sea's a cradle. Some days she's a grave. Most days, she's home."
"I've sailed every ocean in the world, and I've never tired of the view."
"The horizon's always out there, always calling."
"When I die, I want to go back to the sea. She's waiting for me."
"Look at it, {target}. All that water, and every drop of it an adventure."
]])

cat("farewell", "Farewells and Oaths", "e_salute", [[
"Fair winds and following seas, {target}."
"Until we meet again, ye scallywag. And we will."
"I swear on me ship and me rum, I'll not forget this."
"May the wind always be at yer back and the rum never run dry."
"Farewell, matey. Keep yer powder dry and yer cutlass sharp."
"Dead men tell no tales. Living ones tell too many. Goodbye!"
"I'm off to find me fortune. Or someone else's. Whichever's closer."
"Remember me when ye drink yer next rum, {target}."
"The sea is calling, and I must go."
"By me oath as a pirate, I'll come back for ye."
"I swear by the deep and the dark and the drowned, ye have me word."
"Off I go, into the sunset. Very dramatic. Mind me exit."
"Farewell! If I'm not back in a year, I've found the treasure. Or the sharks found me."
"Don't cry, {target}. Pirates always come back. Like bad pennies. And scurvy."
"I'll see ye on the far side of the horizon, friend."
"Keep me seat warm and me mug full. I'll be back."
"Until the tide brings us together again."
"Goodbye, old friend. May the sea be kind to ye."
"I swear on me grandmother's eyepatch: I'll return."
"Every voyage ends. Every voyage starts again. See ye at the next one."
"We'll meet again, {target}, in some tavern at the edge of the world."
"May yer hold be full and yer hull be sound."
"Pirate's oath: what's said in this tavern stays in this tavern."
"I'll not say goodbye. Pirates only say 'until later'."
"Raise the anchor! I've a sea to see and a fortune to make!"
"If ye ever need a ship, a sword, or a terrible song, ye know where to find me."
"Go well, ye magnificent bilge rat."
"Farewell! Don't do anything I wouldn't do. Which leaves ye a lot of room."
"I swear it on the rum. And ye know I take rum seriously."
"Watch the horizon, {target}. One day, ye'll see me sails."
tips their hat to {target} one last time. [bow]
salutes sharply and turns toward the docks. [salute]
waves a battered hat high as they walk away. [wave]
claps {target} on the back and heads for the ship without looking back.
spits in a palm and offers it for a parting handshake.
presses a gold coin into {target}'s hand. "For luck. Don't spend it."
swaggers off toward the harbor, coat flapping in the wind.
bows deeply, a little too deeply, and stumbles slightly on the way up. [bow]
draws a cutlass, raises it in salute, and sheathes it with a flourish. [salute]
hums a farewell shanty as they walk down the pier.
turns at the gangplank, gives one last wave, and boards the ship. [wave]
places a hand over their heart and nods solemnly to {target}. [nod]
leaves a small wrapped trinket on the table and slips out quietly.
shakes {target}'s hand firmly, then pulls them into a rough hug.
blows a kiss toward the tavern as they leave. [kiss]
kneels to kiss the dock goodbye, then hops aboard the ship. [kneel]
raises a final toast to the room, then drains the mug and is gone. [cheer]
whistles for the parrot, who flutters down onto their shoulder for the journey.
tugs the brim of their hat low and disappears into the fog.
stands at the stern, waving until the dock is out of sight. [wave]
"This isn't goodbye, {target}. It's 'see ye at the next shipwreck'."
"Hold fast, friend. Hold fast to everything that matters."
"Take care of yerself. And take care of me rum while I'm gone."
"Ye've been a fine shipmate, {target}. The finest."
"Off with the tide! May we meet in better days and worse taverns!"
"On me honor as a pirate, which isn't worth much, but it's all I've got."
"Goodbye, matey. And remember: never trust a man who says goodbye."
"The sea's waiting, and she's a jealous lass. Farewell!"
"To the open sea, and everyone who sails her!"
]])
