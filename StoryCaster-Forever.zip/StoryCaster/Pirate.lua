-- StoryCaster: themed libraries (Pirate, Love, War, Peace). Each is a set of categories of lines (PirateLines.lua,
-- ThemeLines.lua): one line at a click, said or emoted, at most once every 15 seconds; a dozen as a scene on the
-- panel's timer. Pirate also has an accent for everything you say ("you" becomes "ye", "hello" becomes "ahoy").
local ADDON, ns = ...
local R = ns.R
R.THEME_GAP = 15
R.PIRATE_GAP = R.THEME_GAP
R.THEMEDATA = R.THEMEDATA or {}
R.THEMEDATA.pirate = R.PIRATE

-- how each theme looks and what its big button says
R.THEME_META = {
  { key = "pirate", title = "Pirate", icon = "skull", kind = "pirate", big = "ARR!", bigIcon = "anchor", accent = true,
    blurb = "Pick a category, or just shout ARR!" },
  { key = "love", title = "Love", icon = "heart", kind = "love", big = "Swoon", bigIcon = "heart",
    blurb = "Flirting, courtship, longing and devotion. Pick a category, or let your heart choose." },
  { key = "war", title = "War", icon = "swords", kind = "war", big = "For Glory!", bigIcon = "swords",
    blurb = "Battle cries, taunts, victory and the quiet after. Pick a category, or charge!" },
  { key = "peace", title = "Peace", icon = "dove", kind = "peace", big = "Be Still", bigIcon = "dove",
    blurb = "Calm, kindness, wisdom and mending. Pick a category, or simply breathe." },
  { key = "nsfw", title = "After Dark", frame = "StoryCasterNSFW", icon = "cocktail", kind = "night", big = "Cheers!", bigIcon = "cocktail", adult = true,
    blurb = "Adult-themed nightlife: cheeky, never explicit. Keep public chat within the game's rules." },
}
function R:ThemeMeta(key) for _, m in ipairs(self.THEME_META) do if m.key == key then return m end end end
function R:ThemeData(key) return self.THEMEDATA[key] end

function R:ThemeDB(key)
  self.db.themes = type(self.db.themes) == "table" and self.db.themes or {}
  self.db.themes[key] = type(self.db.themes[key]) == "table" and self.db.themes[key] or {}
  local d = self.db.themes[key]
  if d.mode == nil then d.mode = "mix" end
  return d
end

function R:ThemeCat(theme, key)
  local data = self:ThemeData(theme)
  for _, c in ipairs(data and data.cats or {}) do if c.key == key then return c end end
end

function R:ThemeCount(theme)
  local n = 0
  for _, c in ipairs((self:ThemeData(theme) or {}).cats or {}) do n = n + #c.lines end
  return n
end

-- a shuffled bag per category, so no line comes back until the rest have been used
local bags = {}
function R:ThemeNext(theme, key)
  local data = self:ThemeData(theme)
  local c = key and self:ThemeCat(theme, key) or data.cats[math.random(#data.cats)]
  local id = theme .. ":" .. c.key
  local bag = bags[id]
  if not bag or #bag == 0 then
    bag = {}
    for i = 1, #c.lines do bag[i] = i end
    for i = #bag, 2, -1 do local j = math.random(i); bag[i], bag[j] = bag[j], bag[i] end
    bags[id] = bag
  end
  return c.lines[table.remove(bag)], c
end

-- one line as a script line: spoken ("...") is said, or acted as says <mood>, "..."; anything else is an emote
function R:ThemeLineFor(text, mode)
  local spoken = text:match('^"(.*)"$')
  if spoken and mode == "say" then return { spoken, nil, nil, "SAY" } end
  if spoken then text = 'says <mood>, "' .. spoken .. '"' end
  return (self:Convert(text, "lines", false))[1]
end

function R:ThemeWait() return math.max(0, (self.themeReady or 0) - GetTime()) end

-- one line now (your click): from a category, or from anywhere in the theme
function R:ThemeLine(theme, key, mode)
  local wait = self:ThemeWait()
  if wait > 0 then self:Print(("Easy now: %ds."):format(math.ceil(wait))) return nil end
  if not self:CanEmote() then self:Print("Not now: you are in combat or a boss fight.") return nil end
  mode = mode or self:ThemeDB(theme).mode
  if mode == "mix" then mode = math.random(2) == 1 and "say" or "emote" end
  local text, c = self:ThemeNext(theme, key)
  local line = self:ThemeLineFor(text, mode)
  if not line then return nil end
  self:Perform(line, true)
  self.themeReady = GetTime() + self.THEME_GAP
  self.themeLast = self.themeLast or {}
  self.themeLast[theme] = { cat = c.title, text = (self:Render(line[1]):gsub("<[Mm][Oo][Oo][Dd]>", "")) }
  self:Refresh()
  return line
end

-- a dozen lines from a category, performed on the panel's own timer (not saved to your scripts)
function R:ThemeScene(theme, key)
  local c = self:ThemeCat(theme, key)
  if not c then return end
  local script = {}
  for _ = 1, math.min(12, #c.lines) do
    local line = self:ThemeLineFor((self:ThemeNext(theme, key)), "emote")
    if line then
      if #script == 0 then line[6] = c.title end
      script[#script + 1] = line
    end
  end
  local name = self:ThemeMeta(theme).title .. ": " .. c.title
  self.temp = self.temp or {}
  self.temp[name] = script
  self:Start(name)
end

-- the Pirate names the rest of StoryCaster already uses
function R:PirateDB() return self:ThemeDB("pirate") end
function R:PirateCat(key) return self:ThemeCat("pirate", key) end
function R:PirateCount() return self:ThemeCount("pirate") end
function R:PirateWait() return self:ThemeWait() end
function R:PirateLine(key, mode) return self:ThemeLine("pirate", key, mode) end
function R:PirateScene(key) return self:ThemeScene("pirate", key) end

---------------------------------------------------------------------------
-- The pirate accent
---------------------------------------------------------------------------
local WORDS = {
  hello = "ahoy", hi = "ahoy", hey = "ahoy", yes = "aye", yeah = "aye", yep = "aye", no = "nay", you = "ye", your = "yer",
  yours = "yers", ["you're"] = "ye're", yourself = "yerself", my = "me", myself = "meself", is = "be", are = "be", am = "be",
  friend = "matey", friends = "hearties", buddy = "matey", stop = "avast", wait = "avast", money = "doubloons",
  coins = "doubloons", drink = "grog", beer = "grog", ale = "grog", wine = "grog", ["for"] = "fer", of = "o'", ["and"] = "an'",
  everyone = "all ye scallywags", wow = "shiver me timbers", boss = "cap'n", captain = "cap'n", stranger = "landlubber",
  understand = "savvy", ["isn't"] = "ain't", ["aren't"] = "ain't", food = "grub", tavern = "grog shop", bathroom = "head",
  kitchen = "galley", left = "port", right = "starboard", treasure = "booty", quickly = "smartly", fight = "brawl",
}

local function pirateWord(w)
  local low = w:lower()
  local rep = WORDS[low]
  if not rep and #low > 4 and low:sub(-3) == "ing" then rep = low:sub(1, -2) .. "'" end
  if not rep then return w end
  if w:sub(1, 1):match("%u") then rep = rep:sub(1, 1):upper() .. rep:sub(2) end
  return rep
end

local function speak(s)
  s = s:gsub("[%a][%a']*", pirateWord)
  if math.random(4) == 1 and not s:lower():find("^arr") then s = "Arr, " .. s:sub(1, 1):lower() .. s:sub(2) end
  return s
end

-- what you say, in pirate: a chat line whole, or only the words inside quotes of an emote
function R:PirateSpeak(text, whole)
  local d = self.db and self.db.themes and self.db.themes.pirate
  if not (d and d.accent) or not text or text == "" then return text end
  local out
  if whole then out = speak(text)
  else out = text:gsub('"([^"]*)"', function(q) return '"' .. speak(q) .. '"' end) end
  if #out > self.MAX_LEN then return text end
  return out
end

function R:TogglePirateAccent()
  local d = self:PirateDB()
  d.accent = not d.accent
  self:Print("Pirate accent " .. (d.accent and "|cffeec060on|r: everything ye say comes out like a proper pirate." or "off."))
  self:Refresh()
end
