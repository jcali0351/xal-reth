-- StoryCaster: reactions (answering emotes and words aimed at you) and sending a script straight to a friend.
local ADDON, ns = ...
local R = ns.R

---------------------------------------------------------------------------
-- Reactions
-- One rule per line:   waves = waves back at {sender}. [wave]
-- A word in quotes is something said near you:   "hello" = nods at {sender} in greeting. [nod]
-- Off until you turn them on. They share the anti-spam guard with scripts (never closer than 15 seconds,
-- never more than 4 a minute) and answer the same person at most once a minute.
---------------------------------------------------------------------------
R.DEFAULT_REACTIONS = table.concat({
  "waves = waves back at {sender} with a warm smile. [wave]",
  "bows = returns {sender}'s bow with a graceful one of their own. [bow]",
  "hugs = hugs {sender} back, warmly.",
  "slaps = rubs their cheek and stares at {sender} in disbelief.",
  "cheers = cheers right along with {sender}! [cheer]",
  "kisses = blushes and looks away from {sender}.",
  "salutes = returns {sender}'s salute smartly. [salute]",
  "dances = joins {sender}'s dance without a second thought. [dance]",
  "laughs = laughs along with {sender}. [laugh]",
  "thanks = nods to {sender}. \"Any time.\" [nod]",
  "pokes = swats {sender}'s finger away.",
  "\"hello\" = nods at {sender} in greeting. [nod]",
}, "\n")
R.REACT_PER_SENDER = 60

function R:ParseReactions(text)
  local out = {}
  for line in ((text or "") .. "\n"):gmatch("([^\r\n]*)\r?\n") do
    local trig, reply = line:match("^%s*(.-)%s*=%s*(.-)%s*$")
    if trig and trig ~= "" and reply and reply ~= "" and not line:match("^%s*%-%-") then
      local said = trig:match('^"(.+)"$')
      out[#out + 1] = { kind = said and "say" or "emote", word = (said or trig):lower(), reply = reply }
    end
  end
  return out
end

function R:ReactionText() return self.db.reactionText or self.DEFAULT_REACTIONS end

function R:Reactions()
  local text = self:ReactionText()
  if self.reactCacheText ~= text then self.reactCache, self.reactCacheText = self:ParseReactions(text), text end
  return self.reactCache
end

function R:SetReactions(on)
  self.db.reactions = on and true or false
  self:Print("Reactions " .. (on and "|cff55ff55on|r: emotes and words aimed at you get your answers (once a minute per person)." or "off."))
  self:Refresh()
end

local function hasWord(msg, word)
  word = word:gsub("([%^%$%(%)%%%.%[%]%*%+%-%?])", "%%%1")
  return msg:find("%f[%w]" .. word .. "%f[%W]") or msg:find("%f[%w]" .. word .. "e?s%f[%W]")
end

-- which rule a message sets off, or nil. kind: "emote" (a text emote) or "say"
function R:MatchReaction(kind, msg)
  msg = (msg or ""):lower()
  if kind == "emote" and not msg:find("%f[%a]you%f[%A]") then return nil end -- only emotes aimed at you
  for _, r in ipairs(self:Reactions()) do
    if r.kind == kind and hasWord(msg, r.word) then return r end
  end
end

function R:React(kind, msg, sender)
  if not (self.db and self.db.reactions) then return end
  if type(msg) ~= "string" or type(sender) ~= "string" then return end
  if issecretvalue and (issecretvalue(msg) or issecretvalue(sender)) then return end
  local who = (sender:match("^([^%-]+)") or sender)
  if who:lower() == (UnitName("player") or ""):lower() then return end
  local rule = self:MatchReaction(kind, msg)
  if not rule then return end
  if not self:CanEmote() or self:SpamWait() > 0 then return end
  self.reacted = self.reacted or {}
  local now = GetTime()
  if self.reacted[who:lower()] and now - self.reacted[who:lower()] < self.REACT_PER_SENDER then return end
  local line = self:Convert(rule.reply, "lines", false)[1]
  if not line or line[4] == "SAY" or line[4] == "YELL" then return end -- the game only allows /say from a key press
  self.reacted[who:lower()] = now
  self.renderSender = who
  self:Perform(line)
  self.renderSender = nil
  self:NoteAuto()
end

---------------------------------------------------------------------------
-- Send a script to a friend: offered by whisper over the hidden channel, sent only after they accept
---------------------------------------------------------------------------
local CHUNK, MAX_TEXT = 200, 30000
local outgoing, incoming = {}, {}

-- the name to send to: what was typed, or your target when it is a player
function R:ShareTarget(typed)
  typed = (typed or ""):gsub("%s", "")
  if typed ~= "" then return typed end
  if UnitExists("target") and (not UnitIsPlayer or UnitIsPlayer("target")) and not (UnitIsUnit and UnitIsUnit("target", "player")) then
    local full = GetUnitName and GetUnitName("target", true)
    if type(full) == "string" and full ~= "" and not (issecretvalue and issecretvalue(full)) then return full end
    return self:Target()
  end
end

function R:SendScript(name, to)
  local script = self:Get(name)
  if not script then self:Print("Choose a script to send first.") return end
  to = self:ShareTarget(to)
  if not to then self:Print("Type a name to send to, or target the player.") return end
  local blob = self:ScriptToText(script):gsub("|", "\a") -- a choice's | travels as \a
  if #blob > MAX_TEXT then self:Print("That script is too long to send (about " .. math.floor(MAX_TEXT / 1000) .. ",000 characters at most). Use Share instead.") return end
  local id = tostring(math.random(100000, 999999))
  local chunks = {}
  for i = 1, #blob, CHUNK do chunks[#chunks + 1] = blob:sub(i, i + CHUNK - 1) end
  outgoing[id] = { to = to, name = name, chunks = chunks }
  self.AddonSend(("O\t%s\t%s\t%d;%d"):format(id, (name:gsub("\t", " ")), #chunks, #script), "WHISPER", to)
  self:Print(("Offered |cffffd100%s|r to %s. It is sent when they accept (they need StoryCaster)."):format(name, to))
  return id
end

local function accept(self, data)
  self.AddonSend("A\t" .. data.id, "WHISPER", data.from)
  self:Print("Receiving |cffffd100" .. data.name .. "|r from " .. data.from .. "...")
end

function R:OnShareMessage(kind, id, a, b, sender)
  if kind == "O" then
    local n, lines = (b or ""):match("^(%d+);(%d+)$")
    n, lines = tonumber(n), tonumber(lines)
    if not n or n < 1 or n > MAX_TEXT / CHUNK + 1 then return end
    local data = { id = id, from = sender, name = (a or "Shared script"):sub(1, 40), n = n, lines = lines or 0, chunks = {}, got = 0 }
    incoming[id] = data
    if StaticPopupDialogs and StaticPopup_Show then
      StaticPopupDialogs.STORYCASTER_SEND = {
        text = "%s wants to send you the StoryCaster script \"%s\" (%d lines). Accept it?",
        button1 = "Accept", button2 = "No thanks", timeout = 60, whileDead = true, hideOnEscape = true, preferredIndex = 3,
        OnAccept = function(_, d) accept(R, d) end,
        OnCancel = function(_, d) if d then R.AddonSend("N\t" .. d.id, "WHISPER", d.from) end end,
      }
      local dialog = StaticPopup_Show("STORYCASTER_SEND", sender, data.name, data.lines)
      if dialog then dialog.data = data end
      self.lastOffer = data
    end
  elseif kind == "A" then
    local out = outgoing[id]
    if not out or self.ShortName(out.to) ~= self.ShortName(sender) then return end
    outgoing[id] = nil
    for i, c in ipairs(out.chunks) do
      C_Timer.After((i - 1) * 0.2, function() self.AddonSend(("P\t%s\t%d\t%s"):format(id, i, c), "WHISPER", out.to) end)
    end
    self:Print(("%s accepted: sending |cffffd100%s|r."):format(out.to, out.name))
  elseif kind == "N" then
    local out = outgoing[id]
    if out and self.ShortName(out.to) == self.ShortName(sender) then
      outgoing[id] = nil
      self:Print(out.to .. " said no thanks to |cffffd100" .. out.name .. "|r.")
    end
  elseif kind == "P" then
    local data = incoming[id]
    local seq = tonumber(a)
    if not (data and seq and seq >= 1 and seq <= data.n) or data.chunks[seq] or self.ShortName(data.from) ~= self.ShortName(sender) then return end
    data.chunks[seq] = b or ""
    data.got = data.got + 1
    if data.got < data.n then return end
    incoming[id] = nil
    local script = self:Convert((table.concat(data.chunks):gsub("\a", "|")), "lines", false)
    local who = data.from:match("^([^%-]+)") or data.from
    local name = data.name
    if self:Get(name) then name = (data.name .. " (from " .. who .. ")"):sub(1, 48) end
    local ok, msg = self:Save(name, script)
    if ok then
      self:Print(("Received |cffffd100%s|r from %s: %d lines. It is in your scripts."):format(name, who, #script))
      self:Refresh()
    else
      self:Print("Could not keep the script from " .. who .. ": " .. tostring(msg))
    end
  end
end

---------------------------------------------------------------------------
-- Player Focus: weave another player into whatever you perform, a little at a time
-- Every few emote lines (Light: 5-7, More: 3-4) one mention is added: "says to Brannoc, ..." or a short aside
-- ("..., glancing over at Brannoc."). Never two lines in a row, never when the name is already there.
---------------------------------------------------------------------------
local ASIDES = { "glancing over at %s", "with a quick look toward %s", "with a nod to %s", "half for %s's benefit",
  "as %s looks on", "catching %s's eye", "with a small smile at %s", "making sure %s is listening",
  "without quite looking at %s", "with a sidelong glance at %s", "for %s to hear", "as if %s might understand" }

function R:FocusDB()
  self.db.focus = type(self.db.focus) == "table" and self.db.focus or {}
  local f = self.db.focus
  if f.level == nil then f.level = "light" end
  return f
end

-- who is in focus: the name you set, or your target
function R:FocusName()
  local f = self:FocusDB()
  if not f.on then return nil end
  if f.name and f.name ~= "" then return (f.name:match("^([^%-]+)") or f.name) end
  return self:Target()
end

function R:SetFocus(on, name)
  local f = self:FocusDB()
  if name ~= nil then f.name = (name or ""):gsub("[|%s]", "") end
  if on ~= nil then f.on = on and true or false end
  self.focusGap = nil
  if f.on then
    local who = self:FocusName()
    self:Print("|cffffd100Player Focus on|r" .. (who and (": " .. who .. " will find their way into your scenes, now and then.") or ": target someone, or type a name."))
  else
    self:Print("Player Focus off.")
  end
  self:Refresh()
end

-- add one small mention of the focused player to a rendered emote line, when it's time
function R:WeaveFocus(text, line)
  local who = self:FocusName()
  if not who or (line and line[4]) or not text or text == "" then return text end
  local low, wl = text:lower(), who:lower()
  self.focusSince = (self.focusSince or 0) + 1
  if low:find(wl, 1, true) then self.focusSince = 0; return text end
  local f = self:FocusDB()
  self.focusGap = self.focusGap or (f.level == "more" and math.random(3, 4) or math.random(5, 7))
  if self.focusSince < self.focusGap then return text end
  local out
  if text:find("^says[^,\"]*, \"") and math.random(3) > 1 then
    out = text:gsub("^says([^,\"]*), \"", "says%1 to " .. who:gsub("%%", "%%%%") .. ", \"", 1)
  else
    local aside = ASIDES[math.random(#ASIDES)]:format(who)
    local body, punct = text:match("^(.-)([%.!%?]+)$")
    if body and not body:find("\"$") and not text:find("\"[%.!%?]*$") then out = body .. ", " .. aside .. punct
    elseif not text:find("\"") then out = text .. ", " .. aside .. "." end
  end
  if not out or #out > self.MAX_LEN then return text end
  self.focusSince, self.focusGap = 0, nil
  return out
end

---------------------------------------------------------------------------
-- Backup and restore: every script as one block of text
---------------------------------------------------------------------------
local MARK = "#### StoryCaster script: "
function R:BackupText()
  local out = { "-- StoryCaster backup (" .. #self.db.order .. " scripts). Paste it back with Restore." }
  for _, name in ipairs(self.db.order) do
    local s = self.db.scripts[name]
    if s then
      out[#out + 1] = MARK .. name
      if type(s.opts) == "table" and s.opts.ambient then out[#out + 1] = "-- ambient" end
      out[#out + 1] = self:ScriptToText(s)
    end
  end
  return table.concat(out, "\n")
end

-- adds every script in a backup; a name you already have gets " (restored)"
function R:RestoreText(text)
  local added, cur, buf = 0, nil, {}
  local function flush()
    if not cur then return end
    local body = table.concat(buf, "\n")
    local ambient = body:find("^%-%- ambient\n") ~= nil
    body = body:gsub("^%-%- ambient\n", "")
    local s = self:Convert(body, "lines", false)
    if #s > 0 then
      local name = cur
      if self.db.scripts[name] then name = (cur .. " (restored)"):sub(1, 48) end
      local ok = self:Save(name, s, ambient and { ambient = true, loop = true, shuffle = true, diceMin = 25, diceMax = 70 } or nil)
      if ok then added = added + 1 end
    end
  end
  for line in ((text or "") .. "\n"):gmatch("([^\r\n]*)\r?\n") do
    local name = line:match("^" .. MARK:gsub("%p", "%%%0") .. "(.+)$")
    if name then flush(); cur, buf = name:gsub("^%s+", ""):gsub("%s+$", ""), {}
    elseif cur then buf[#buf + 1] = line end
  end
  flush()
  self:Refresh()
  return added
end

---------------------------------------------------------------------------
-- Events
---------------------------------------------------------------------------
local ev = CreateFrame("Frame")
ev:RegisterEvent("CHAT_MSG_TEXT_EMOTE")
ev:RegisterEvent("CHAT_MSG_SAY")
ev:SetScript("OnEvent", function(_, event, msg, sender)
  if event == "CHAT_MSG_TEXT_EMOTE" then R:React("emote", msg, sender)
  elseif event == "CHAT_MSG_SAY" then R:React("say", msg, sender) end
end)
