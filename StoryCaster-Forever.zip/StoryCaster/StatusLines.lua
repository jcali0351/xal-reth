-- StoryCaster: the status library. 24 everyday activities, 25 lines each (original writing), matched to what a
-- player types in "What are you doing?". Anything else gets 25 lines written around their own words (Status.lua).
local ADDON, ns = ...
local R = ns.R
R.ACTIVITIES = R.ACTIVITIES or {}
local function act(key, title, words, text)
  local lines = {}
  for raw in (text .. "\n"):gmatch("([^\r\n]*)\r?\n") do
    local l = raw:gsub("^%s+", ""):gsub("%s+$", "")
    if l ~= "" then lines[#lines + 1] = l end
  end
  R.ACTIVITIES[#R.ACTIVITIES + 1] = { key = key, title = title, words = words, lines = lines }
end

act("fishing", "Fishing", { "fish", "fishing", "angling", "lake", "pier", "dock", "bobber", "catch", "rod" }, [[
casts a line out over the water and watches the bobber settle.
leans back, rod resting easy in both hands, perfectly content to wait.
says <mood>, "Fishing is mostly waiting. I'm very good at waiting."
watches the bobber dip once, then twice, and holds very still.
reels in a small, wriggling fish and admires it for a moment. [cheer]
lets the little fish go with a splash. "Grow up big. I'll be back."
baits the hook again with careful fingers.
hums a quiet tune to the rhythm of the waves.
squints across the water at a ripple that might be something big.
says, "Every fisher has a story about the one that got away. Mine's still out there."
pulls up a soggy old boot and stares at it in disbelief. [shrug]
adds the boot to a small pile of similar disappointments.
shares a bit of bread with a hopeful duck paddling nearby.
says <mood>, "Pull up a crate, {target}. The fish don't mind company."
feels a sharp tug and yanks the rod back with a whoop. [cheer]
fights a big one for a long minute, line singing, boots braced.
lands a gleaming fish and holds it up proudly. [flex]
says, "Look at the size of it! Nobody will believe me."
wraps the catch in a damp cloth and sets it in the basket.
watches the sunlight glitter on the water, in no hurry at all.
tests the wind with a wet finger. "They'll bite better after the rain."
untangles a knot in the line with the patience of a saint.
yawns and stretches, then casts again. [sigh]
says <mood>, "Best part of fishing? No one expects you to talk."
reels in slowly as the light fades, basket heavier than this morning.
]])

act("cooking", "Cooking", { "cook", "cooking", "baking", "bake", "stew", "kitchen", "food", "meal", "recipe", "chef" }, [[
ties on an apron and rolls up both sleeves.
sets a pan over the fire and drops in a knob of butter.
listens to the butter sizzle with deep satisfaction.
chops onions quickly, eyes watering. [cry]
says <mood>, "It's not tears. It's onions. Mostly onions."
tosses the onions into the pan and stirs with a wooden spoon.
sprinkles in a pinch of salt, then another for luck.
tastes from the spoon, considers, and adds a dash of pepper.
says, "Every good meal starts with a hot pan and an empty stomach."
kneads a lump of dough on a floured board, humming.
slides a loaf into the oven and wipes floury hands on the apron.
checks a simmering pot and nods approvingly. [nod]
shoos a curious cat away from the counter.
says <mood>, "Don't touch that, {target}. It's not ready. It's almost ready. Still no."
stirs the stew slowly, breathing in the steam.
burns one finger on the pot and shakes it out with a hiss. [gasp]
pulls a golden loaf from the oven, the smell filling the room.
says, "Fresh bread. The best smell in the world."
arranges the food on a plate with surprising care.
garnishes it with a little sprig of something green.
says <mood>, "Food is love. You cook for people you care about."
sets a bowl down in front of {target} with a warm smile.
says, "Eat while it's hot. I'll be offended if there's any left."
starts on the washing up, still humming.
leans on the counter, tired and very pleased with the day's work. [sigh]
]])

act("reading", "Reading", { "read", "reading", "book", "books", "library", "tome", "novel", "page", "pages", "study", "studying" }, [[
settles into a comfortable chair with a well-worn book.
opens the book to a marked page and smooths it flat.
reads quietly, lips moving now and then on a difficult word.
turns a page slowly, utterly absorbed.
gasps softly at something on the page. [gasp]
says <mood>, "Oh, no. Oh, they didn't. They did."
looks up from the book, eyes faraway, then dives back in.
tucks their feet up and pulls a blanket over their knees.
runs a finger down a long column of tiny writing.
says, "Just one more chapter. Then I'll stop. Probably."
reaches for a cup of tea without looking up from the page.
laughs quietly at a line, then reads it again. [chuckle]
marks a passage with a scrap of ribbon.
says, "Have you read this one, {target}? You must. Immediately."
frowns at a confusing paragraph and reads it a third time.
holds the book closer to the candle as the light fades.
wipes a tear from one eye, very discreetly. [cry]
says <mood>, "Nobody warned me the dog doesn't make it."
closes the book for a moment, staring at nothing, then opens it again.
flips back several pages to check a detail.
yawns, but keeps reading anyway. [sigh]
says, "Books are just very patient people who wait for you to listen."
reaches the last page and sits in silence for a long moment.
closes the book with a soft, satisfied thump.
says <mood>, "Well. Now I need a new one."
]])

act("tavern", "Drinking at the Tavern", { "tavern", "inn", "drink", "drinking", "ale", "beer", "bar", "pub", "wine", "mead" }, [[
leans on the bar and orders a pint of the house ale.
blows the foam off the top and takes a long, happy sip.
says <mood>, "Ah. That's the stuff. Tastes like a good day."
swirls the ale in the mug, watching the light catch it.
nods to a familiar face across the room. [nod]
taps a foot along with the bard's song.
says, "Barkeep, another when you've a moment. No rush. Some rush."
laughs loudly at a story from the next table. [laugh]
raises a mug toward {target}. [cheer]
says <mood>, "To friends, old and new!"
cracks a handful of roasted nuts and eats them one at a time.
watches a game of cards for a while, offering unhelpful advice.
says, "This tavern has the best ale in the city and the worst stools."
shifts on the wobbly stool, trying to find a level spot.
orders a bowl of stew to go with the next round.
wipes foam from their lip with the back of one hand.
says <mood>, "Pull up a chair, {target}. The night is young."
sings along with the chorus, slightly off key. [dance]
leans back, warm and comfortable, watching the room.
lets out a contented sigh as the fire crackles. [sigh]
says, "There's no problem a good ale and a warm fire can't make smaller."
leaves a coin on the bar for the barkeep.
plays a quick hand of cards and loses cheerfully. [shrug]
says <mood>, "One more. Then home. Probably."
drains the last of the mug and sets it down with a satisfied thump.
]])

act("waiting", "Waiting for Someone", { "wait", "waiting", "meeting", "late", "friend", "date", "someone" }, [[
glances toward the door for the third time in a minute.
taps their fingers on the table in an impatient rhythm.
checks the sky to judge the hour, then sighs. [sigh]
says <mood>, "They said they'd be here by now."
paces a few steps, then sits down again.
straightens their clothes, just in case.
watches every newcomer closely, then looks away.
says, "I'm not worried. I'm just looking at the door. A lot."
orders a drink to pass the time.
rehearses something quietly under their breath.
picks at a loose thread on their sleeve.
says <mood>, "Have you seen anyone come through here, {target}? Tall-ish? Usually late?"
leans back and closes their eyes for a moment.
startles at a sound by the door, then deflates. [shrug]
says, "False alarm. That was a goat."
counts the cracks in the ceiling.
writes a short note, then crumples it.
says <mood>, "Five more minutes. Then I'm leaving. Ten more minutes."
hums to themselves to fill the silence.
watches the candle burn down another finger's width.
stands up suddenly, waving at someone. [wave]
lowers the hand slowly. "Not them. Sorry. Carry on."
says, "Patience is a virtue. I'm told. By patient people."
glances at the door once more, a hopeful look on their face.
smiles at last as a familiar face finally appears. [cheer]
]])

act("guard", "Standing Guard", { "guard", "guarding", "watch", "patrol", "patrolling", "sentry", "duty", "post", "gate" }, [[
stands at attention, eyes scanning the road ahead.
shifts their weight from one foot to the other, still watchful.
rests a hand on the hilt of their weapon.
says <mood>, "Halt. State your business."
squints at a distant figure, then relaxes.
says, "Nothing to see here. Which is how I like it."
salutes a passing officer crisply. [salute]
stamps their feet against the cold.
glances up at the darkening sky.
says <mood>, "Move along, {target}. Nothing to see."
paces slowly along the wall, then back again.
checks the gate's lock with a firm tug.
stifles a yawn and stands up straighter.
says, "Long shift. Quiet shift. I'm not complaining. Much."
watches a cart roll through and waves it on. [wave]
peers into the shadows at a sound, hand on weapon.
says <mood>, "Just a cat. Again. That cat is a menace."
blows on cold fingers to warm them.
shares a nod with the guard across the way. [nod]
says, "Nobody gets past me. Except the cat, apparently."
straightens their armor and resumes the watch.
stares out at the horizon, steady and unmoving.
says <mood>, "Relief should be here soon. Any minute now."
hears the bell for the change of watch and sighs in relief. [sigh]
hands off the post with a salute and a tired smile. [salute]
]])

act("training", "Training and Sparring", { "train", "training", "spar", "sparring", "practice", "practicing", "fight", "exercise", "drill" }, [[
rolls their shoulders and stretches before training.
takes up a practice weapon and gives it a test swing.
runs through a set of drills, slow at first, then faster.
says <mood>, "Again. And again. Until it's in the bones."
strikes the training dummy with a satisfying thwack. [flex]
pauses to wipe the sweat from their brow.
says, "My trainer said I'd thank them one day. That day is not today."
practices footwork, light and quick.
spins and strikes in one smooth motion.
misses the dummy entirely and nearly falls over. [shrug]
says <mood>, "I meant to do that. That was a feint."
raises the practice weapon toward {target} with a grin.
says, "Care to spar? I'll go easy on you. Maybe."
circles {target} slowly, looking for an opening.
blocks a blow and counters with a quick jab.
laughs, breathing hard, after a close exchange. [laugh]
says <mood>, "Good. You're faster than you look."
drinks deeply from a waterskin.
says, "Rest is part of training too. Very important part."
does a set of push-ups in the dirt. [flex]
practices a difficult move, failing, failing, then landing it. [cheer]
says <mood>, "There it is! Did you see that?"
stretches out tired muscles with a groan.
bows to the training dummy out of habit. [bow]
says, "Same time tomorrow. My arms will hate me."
]])

act("crafting", "Crafting at the Forge", { "craft", "crafting", "forge", "smith", "smithing", "hammer", "anvil", "work", "making", "build", "building" }, [[
pumps the bellows until the coals glow bright orange.
sets a bar of metal into the fire and waits.
wipes sweat from their brow with a sooty forearm.
pulls the glowing bar out and lays it on the anvil.
brings the hammer down: one clean ring. [flex]
says <mood>, "Hear that? That's the sound of something becoming useful."
turns the metal and strikes again, steady and sure.
plunges the work into water with a great hiss of steam. [gasp]
holds the piece up to the light, checking the line.
says, "Not bad. Not perfect. Not bad."
measures twice with a battered old ruler.
files a rough edge smooth with patient strokes.
says <mood>, "Making things is the best kind of tired."
glances at {target}. "Hand me those tongs? No, the other tongs."
sets the finished piece aside to cool.
sweeps metal shavings from the bench.
hums a working song in time with the hammer.
says, "My master said every mistake is a lesson. I've had a lot of lessons."
inspects a nick in the hammer and frowns. [shrug]
starts the next piece without a pause.
admires a finished blade, turning it in the light. [cheer]
says <mood>, "Someone's going to carry this a long way. I hope it serves them well."
banks the coals for the night.
hangs the tools on their hooks one by one.
stretches a sore back and smiles at the day's work. [sigh]
]])

act("praying", "Praying and Meditating", { "pray", "praying", "prayer", "meditate", "meditating", "temple", "church", "shrine", "faith", "light" }, [[
kneels quietly and bows their head. [kneel]
closes their eyes and breathes slowly.
murmurs a soft prayer under their breath.
says <mood>, "Give me strength, and patience. Mostly patience."
lights a small candle and sets it before the shrine.
rests their hands on their knees, palms open.
sits in silence, unmoving, for a long while.
breathes in, and out, and lets their shoulders drop. [sigh]
says, "There is peace here. Even a little is enough."
traces a small holy symbol in the air.
listens to the quiet as though it were music.
says <mood>, "I pray for those I've lost, and those I'll meet."
opens their eyes briefly, then closes them again.
offers a few coins to the alms box.
says, "You're welcome to sit with me, {target}. No words needed."
bows their head lower, deep in thought. [bow]
whispers a name, then smiles softly.
lets the candlelight warm their face.
says <mood>, "Whatever you believe in, it helps to be still sometimes."
hums a low, wordless note.
feels the tension leave their body bit by bit.
says, "I always leave lighter than I came."
rises slowly, stiff from kneeling.
touches the shrine gently in thanks. [thank]
walks away with a calmer step than before.
]])

act("resting", "Resting and Relaxing", { "rest", "resting", "relax", "relaxing", "nap", "sleep", "sleeping", "tired", "lazy", "chill", "chilling" }, [[
stretches out on the grass with a long, contented sigh. [sigh]
folds both hands behind their head and closes their eyes.
says <mood>, "Wake me if there's a dragon. Otherwise, don't."
yawns enormously and doesn't bother to cover it.
watches the clouds drift by, naming the shapes.
says, "That one's a gryphon. That one's a loaf of bread."
dozes off for a moment, then jerks awake. [gasp]
pretends they weren't asleep. They were asleep.
pulls a hat down over their eyes.
says <mood>, "Doing nothing is very important work, {target}."
lets the sun warm their face.
listens to the birds and the wind in the leaves.
rolls over onto one side, getting comfortable.
mumbles something about cheese in their sleep.
says, "I've earned this. I'm sure I've earned this."
nibbles on an apple, still lying down.
kicks off their boots and wiggles their toes.
says <mood>, "No quests today. No dungeons. Just this."
drifts in and out of a lazy doze.
smiles at nothing in particular.
says, "I could stay here until next week."
props up on one elbow to watch someone pass, then lies back down.
breathes deeply, completely at ease.
says <mood>, "Five more minutes. Or five more hours."
sits up at last, stretching, much refreshed. [flex]
]])

act("traveling", "Traveling and Exploring", { "travel", "traveling", "travelling", "explore", "exploring", "journey", "road", "wander", "wandering", "adventure", "map" }, [[
shoulders a pack and looks down the long road ahead.
unfolds a worn map and turns it to face the right way.
says <mood>, "According to this, we're... somewhere."
sets off at an easy, steady pace.
pauses at a fork in the road, considering. [shrug]
says, "Left looks prettier. Right looks shorter. Left it is."
whistles a traveling song as they walk.
stops to admire a view from the top of a hill.
says <mood>, "Look at that, {target}. Worth every blister."
fills a waterskin at a cold stream.
checks the sky for rain and keeps walking.
says, "Every road leads somewhere. Most lead to taverns."
marks a new landmark on the map with a stub of charcoal.
picks up an interesting stone and pockets it.
nods to a passing traveler. [nod]
says <mood>, "I've never been this far east. Or is this west?"
climbs over a fallen log with a grunt.
rests on a rock to shake a pebble from one boot.
says, "The best part of a journey is not knowing what's next."
watches the sunset paint the hills gold.
sets up a small camp as night falls.
gazes into the campfire, tired and happy.
says <mood>, "Tomorrow, the mountains. Tonight, sleep."
studies the stars, picking out the way north. [point]
falls asleep to the sound of crickets and a crackling fire.
]])

act("trading", "Shopping and Trading", { "shop", "shopping", "trade", "trading", "market", "buy", "buying", "sell", "selling", "merchant", "auction", "vendor" }, [[
wanders between the market stalls, browsing.
picks up a trinket, examines it, and puts it back.
says <mood>, "How much? For that? Are you serious?"
haggles with a merchant, hands waving.
counts out coins carefully on the counter.
says, "I'll give you half, and a smile. The smile is very valuable."
holds up a bolt of cloth to the light.
sniffs a basket of spices and sneezes. [gasp]
says <mood>, "Oh, that's strong. I'll take two."
tucks a small package into their bag.
compares two nearly identical items for far too long.
says, "{target}, which one? The blue or the slightly different blue?"
tries on a hat and admires themselves in a merchant's mirror. [flex]
puts the hat back after seeing the price. [shrug]
says <mood>, "I came for bread and I'm leaving with a lute. Again."
checks their coin purse and winces.
shakes hands with a merchant on a deal. [nod]
says, "Pleasure doing business. Mostly pleasure."
samples a bit of cheese from a stall and nods approvingly.
juggles several parcels under one arm.
says <mood>, "I definitely needed all of this. Definitely."
drops a parcel and scrambles after a rolling apple.
haggles one final time, triumphant. [cheer]
says, "A bargain! Probably. I'll pretend it was."
heads home, arms full and purse lighter.
]])

act("healing", "Healing and Tending Wounds", { "heal", "healing", "wound", "wounds", "hurt", "injured", "bandage", "medic", "tending", "sick", "nurse" }, [[
kneels beside {target} and opens a worn medical kit. [kneel]
says <mood>, "Hold still. Let me see."
gently peels back a torn sleeve to look at the wound.
says, "That's deep, but you'll live. Probably."
cleans the cut with a cloth and cold water.
says <mood>, "This part stings. Sorry. Not sorry. It's for your own good."
wraps a bandage around the wound in neat, firm turns.
ties the bandage off with a small, practiced knot.
presses a hand gently to a bruise, checking for breaks.
says, "Nothing broken. You're very lucky. Or very stubborn."
mixes a salve in a little wooden bowl.
smooths the salve over a burn with careful fingers.
says <mood>, "Drink this. It tastes terrible. That's how you know it works."
watches the patient closely for a moment.
lays a cool cloth across a fevered brow.
murmurs a soft prayer over the injured. [kneel]
says, "Rest now. Don't argue. Rest."
tidies the kit, counting the bandages left.
says <mood>, "Next time, maybe don't fight the bear."
checks the bandage again an hour later, satisfied. [nod]
offers a sip of water to the wounded.
says, "You'll have a scar. A good one. Tell people it was a dragon."
washes blood from their hands in a basin.
sits back on their heels, exhausted but relieved. [sigh]
says <mood>, "That's everyone. For now."
]])

act("magic", "Studying Magic", { "magic", "spell", "spells", "arcane", "mage", "study", "research", "enchant", "ritual", "scroll" }, [[
spreads an arcane tome open across the desk.
traces a glowing rune in the air with one finger.
says <mood>, "If I've done this right, nothing will explode."
mutters an incantation under their breath.
watches a small flame flicker to life in their palm.
says, "There. Fire. On purpose this time."
jots notes furiously in the margins of a scroll.
frowns at a diagram, turning it upside down.
says <mood>, "Who drew this? A goblin with a grudge?"
carefully pours a shimmering liquid into a vial.
sets the vial down very, very gently.
says, "Arcane is a matter of patterns. And patience. And not sneezing."
sneezes. Something small and blue pops into existence. [gasp]
stares at the little blue thing in silence.
says <mood>, "{target}, do not tell my teacher about this."
tries the spell again, more slowly this time.
adjusts a crystal on the desk by a hair's width.
says, "Magic doesn't care how you feel. Only how precise you are."
blows out a small fire on the corner of a page. [cower]
reads the same paragraph four times, lips moving.
says <mood>, "Oh. Oh, I see now. It was in Thalassian the whole time."
makes the rune glow steadily at last. [cheer]
says, "Success! Mostly! Somewhat!"
closes the tome with a satisfied thump.
rubs tired eyes that glow faintly violet.
]])

act("writing", "Writing Letters", { "write", "writing", "letter", "letters", "journal", "diary", "poem", "poetry", "note", "ink" }, [[
dips a quill into a bottle of ink.
stares at the blank page for a long moment.
writes a few words, then crosses them out.
says <mood>, "How do I say this without sounding foolish?"
writes steadily for a while, quill scratching.
pauses to reread what they've written, mouthing the words.
says, "Dear friend. No. Dearest friend. Too much. Friend."
blots a smudge of ink with the edge of a sleeve.
smiles softly at something they've just written.
says <mood>, "This one's going home. They'll want to know I'm safe."
seals the letter with a dab of wax.
starts another, chewing the end of the quill.
says, "{target}, how do you spell 'definitely'? Everyone gets it wrong."
writes a little doodle in the corner of the page.
reads the letter aloud quietly to themselves.
says <mood>, "Too honest? It's too honest. Leaving it."
folds the paper carefully in thirds.
stares out the window, searching for the right word.
writes a single line, then sets down the quill. [sigh]
says, "Some letters you write and never send."
tucks one letter away in a drawer, unsent.
addresses another with careful, elegant letters.
says <mood>, "Off it goes. I hope it finds them well."
wipes ink from their fingers, which never quite come clean.
blows out the candle beside the finished letters.
]])

act("music", "Playing Music", { "music", "song", "sing", "singing", "lute", "play", "playing", "bard", "flute", "drum", "perform" }, [[
tunes a battered lute, one string at a time.
strums a chord, winces, and tunes again.
says <mood>, "There. Now it only sounds slightly cursed."
begins to play a gentle, rolling tune.
taps a foot along with the rhythm.
sings softly, voice warming as the song goes on.
says, "This one's old. My grandmother taught it to me."
picks up the pace into a lively jig. [dance]
grins as a few people start clapping along. [applaud]
misses a note and turns it into a flourish. [shrug]
says <mood>, "That was intentional. That was jazz."
nods to {target}. "Any requests? Not that one. I know the one you're thinking."
plays a slow, sad melody that hushes the room.
closes their eyes and loses themselves in the music.
holds the final note until it fades away.
says, "Thank you, thank you. Tips are welcome. Very welcome."
plays a short, silly tune that makes a child laugh. [laugh]
retunes the lute again, muttering.
says <mood>, "This one's about a dragon who loved cheese. It's a ballad."
sings a ridiculous verse with complete seriousness.
bows to scattered applause. [bow]
starts another song before anyone can leave.
says, "Music is just stories you can dance to."
plays a quiet tune for themselves as the crowd thins.
rests the lute across their knees, content. [sigh]
]])

act("dancing", "Dancing", { "dance", "dancing", "party", "ball", "jig", "festival", "club" }, [[
starts swaying to the music, a little shy at first.
taps a foot, then both feet, then gives up resisting. [dance]
says <mood>, "Fine. Fine! I'm dancing!"
spins in a slow circle, arms out wide.
does a lively jig that draws a few cheers. [dance]
says, "I learned this from a dwarf. He was very drunk."
holds out a hand toward {target}. "Dance with me?"
twirls {target} around, laughing. [laugh]
steps on someone's foot and apologizes mid-spin.
says <mood>, "Sorry! My feet have a mind of their own."
claps along with the beat between steps. [applaud]
does a very confident move that goes very wrong. [shrug]
says, "That was the advanced version. You wouldn't understand."
catches their breath, cheeks flushed.
jumps back into the dancing as a new song starts. [dance]
links arms with a stranger for a circle dance.
says <mood>, "Faster! Faster! No, slower, I'm dizzy!"
spins one last time and nearly falls over. [laugh]
fans themselves with one hand.
says, "I haven't danced like that in years."
bows dramatically to an imaginary audience. [bow]
dances a slow, gentle step as the music softens.
says <mood>, "One more song. Then I'll sit down. Probably."
leans against the wall, smiling and out of breath. [sigh]
waves to the musicians in thanks. [wave]
]])

act("herbs", "Gathering Herbs", { "herb", "herbs", "flower", "flowers", "garden", "gardening", "gather", "gathering", "plant", "plants", "picking" }, [[
kneels in the grass and parts the leaves carefully. [kneel]
says <mood>, "Peacebloom. And there, Silverleaf. Lovely."
pinches off a stem low, leaving the roots in the soil.
tucks the herb into a small satchel.
sniffs a flower and sneezes violently. [gasp]
says, "Not that one. That one's for enemies."
brushes dirt from their hands onto their knees.
moves along the riverbank, searching.
says <mood>, "Always leave the roots. Take the gift, not the giver."
spots a rare bloom and lets out a small gasp of delight. [gasp]
picks it with exaggerated care.
holds up the bloom to show {target}. "Isn't she beautiful?"
waves away a buzzing bee. [shrug]
says, "We're both here for the flowers. Let's be civil."
hums while sorting herbs into little bundles.
checks the leaves of a plant for blight, frowning.
says <mood>, "Too much rain this year. They'll recover."
sits back on their heels and admires the meadow.
waters a small patch of seedlings from a jug.
says, "Herbs don't grow where you want. They grow where they're happy."
ties a bundle with a blade of grass.
gets their sleeve caught on a thorny bush. [cower]
says <mood>, "Briarthorn. Of course. It bites."
stands and stretches a sore back. [flex]
shoulders the full satchel and smiles at the day's harvest.
]])

act("hunting", "Hunting and Tracking", { "hunt", "hunting", "track", "tracking", "tracks", "prey", "beast", "trap", "bow", "arrow" }, [[
crouches low, studying tracks in the soft mud.
says <mood>, "Something big. Passed here not long ago."
moves silently through the undergrowth.
holds up a hand for silence. [point]
sniffs the wind and turns slowly toward it.
nocks an arrow, perfectly still.
says, "Patience. The forest rewards patience."
watches a deer through the trees, then lowers the bow.
says <mood>, "Not today, friend. Not today."
follows a trail of broken twigs deeper into the woods.
checks a snare and finds it empty. [shrug]
resets the snare with deft fingers.
says, "{target}, step where I step. Quietly."
freezes as a twig snaps underfoot. [cower]
waits a long, tense moment, listening.
says <mood>, "It knows we're here. Clever thing."
spots movement and draws the bowstring back.
lets the arrow fly with a soft thrum.
says, "Good shot. Clean. It didn't suffer."
kneels beside the catch and bows their head in thanks. [kneel]
says <mood>, "Thank you. You'll feed a family tonight."
binds the catch and slings it over a shoulder.
marks the trail on a scrap of map.
says, "The wild gives, if you ask it properly."
heads back toward camp as the light fails.
]])

act("celebrating", "Celebrating", { "celebrate", "celebrating", "party", "birthday", "victory", "festival", "feast", "won", "winning", "cheers" }, [[
raises a glass high above their head. [cheer]
says <mood>, "To us! We did it!"
claps {target} on the back, grinning.
starts a cheer that spreads across the room. [cheer]
says, "Tonight we celebrate! Tomorrow we nurse our heads!"
pops the cork from a bottle with a loud bang. [gasp]
pours drinks for everyone within reach.
dances a little victory jig. [dance]
says <mood>, "I knew we'd pull it off. I had doubts. But I knew."
hugs a friend tightly, laughing.
throws a handful of confetti into the air.
says, "Somebody fetch the musicians! This calls for a song!"
sings along loudly and joyfully. [cheer]
says <mood>, "{target}, you were brilliant. Absolutely brilliant."
lifts a slice of cake in salute.
laughs until tears stream down their face. [laugh]
says, "Best day ever. Best. Day. Ever."
tells the story of the victory, a little bigger each time.
raises another toast to absent friends. [salute]
says <mood>, "May every day be half as good as this one."
links arms with strangers and spins them around. [dance]
collapses happily into a chair. [sit]
says, "I'm exhausted. I'm so happy. I'm exhausted."
watches the party, beaming.
says <mood>, "Same time next year?"
]])

act("grieving", "Grieving", { "sad", "grieve", "grieving", "mourn", "mourning", "loss", "lost someone", "funeral", "crying", "upset", "lonely" }, [[
sits alone, staring at nothing in particular. [sit]
lets out a long, shaky breath. [sigh]
says <mood>, "I keep expecting them to walk through that door."
turns a small keepsake over and over in their hands.
wipes their eyes with the back of a sleeve. [cry]
says, "I'm fine. I'm not fine. I'll be fine."
watches the rain against the window.
says <mood>, "They'd tell me to stop moping. They'd be right."
manages a small, sad smile at a memory.
pulls their cloak tighter, though it isn't cold.
says, "Funny, the little things you miss."
leaves a drink untouched on the table.
says <mood>, "Stay a while, {target}? You don't have to talk."
leans their head against the wall and closes their eyes.
whispers a name, very quietly.
says, "Grief is just love with nowhere to go."
lights a candle and watches it flicker.
breathes slowly, trying to steady themselves.
says <mood>, "Thank you for sitting with me."
laughs once, unexpectedly, at a memory. [laugh]
says, "They had the worst sense of humor. I miss it."
holds the keepsake close to their chest.
says <mood>, "One day at a time. That's what they say."
stands slowly, gathering themselves.
says, "Tomorrow will be a little easier. Maybe."
]])

act("lost", "Lost", { "lost", "directions", "where am i", "confused", "map", "cant find", "can't find", "looking for" }, [[
turns the map one way, then the other, then upside down.
says <mood>, "I'm not lost. I'm exploring with uncertainty."
looks around slowly at completely unfamiliar surroundings.
says, "I'm fairly sure that tree was here an hour ago."
asks a passing squirrel for directions. It does not help. [shrug]
says <mood>, "Excuse me, {target}. Where exactly is... here?"
squints at a signpost that has rotted into illegibility.
says, "This is the third time I've passed this rock."
climbs a small hill to get a better look. [point]
says <mood>, "Ah. More trees. Wonderful."
sits on a stump and considers their life choices. [sit]
pulls out a compass and taps it hard.
says, "The compass is wrong. The compass is always wrong."
follows a path confidently, then stops. [shrug]
says <mood>, "No. This isn't right either."
marks an X on the map to remember where they've been.
realizes the X is now everywhere on the map.
says, "I'll just follow the river. Rivers always go somewhere."
hears distant voices and brightens. [cheer]
says <mood>, "Civilization! Or bandits. Either way, people."
hurries toward the sound, hopeful.
says, "If anyone asks, I took the scenic route."
finally spots a familiar landmark and sighs in relief. [sigh]
says <mood>, "I knew where I was the whole time. Mostly."
folds the map away, vowing never to trust it again.
]])

act("working", "Working a Shift", { "work", "working", "job", "shift", "serving", "barkeep", "bartending", "cleaning", "chores", "busy" }, [[
ties on an apron and gets straight to work.
wipes down the counter with brisk strokes.
says <mood>, "Busy day. No complaints. Several complaints."
carries a tray of mugs through the crowd, balancing carefully.
says, "One ale, one stew, one very small salad. Coming up."
sweeps the floor around the tables.
smiles politely at a rude customer. Through gritted teeth.
says <mood>, "Yes, of course. Right away. Absolutely."
rushes between the tables, a little frazzled.
says, "{target}, can I get you anything? Please say something easy."
scrubs a stubborn stain from a table.
says <mood>, "Who spilled honey on the ceiling? How?"
counts the coins in the till, twice.
leans against the wall for a quick breather. [sigh]
says, "Five minutes. Just five minutes off my feet."
gets called back immediately. [shrug]
stacks clean mugs neatly on the shelf.
says <mood>, "Another day, another copper."
helps a coworker carry a heavy crate.
laughs at a joke from a regular. [laugh]
says, "The regulars make it worth it. Mostly."
mops up a spilled drink with practiced speed.
says <mood>, "Last orders, everyone!"
flips the sign on the door to closed.
unties the apron and stretches, done at last. [flex]
]])

act("pet", "Caring for a Pet", { "pet", "pets", "dog", "cat", "wolf", "companion", "animal", "mount", "horse", "feeding" }, [[
kneels and calls softly to their companion. [kneel]
scratches behind their pet's ears, smiling.
says <mood>, "Who's a good friend? You are. Yes, you."
pulls a treat from a pocket and offers it.
laughs as their pet nearly knocks them over. [laugh]
says, "Easy! Easy. I missed you too."
brushes their companion's coat with long, gentle strokes.
checks a paw for thorns, very carefully.
says <mood>, "There. All better. Brave little thing."
tosses a stick and watches their pet bound after it.
says, "Bring it back. No, bring it back. That's a different stick."
shares their lunch, which was not the plan. [shrug]
says <mood>, "Meet my best friend, {target}. Be nice. They bite. Rarely."
fills a bowl with fresh water.
watches their companion curl up for a nap.
says, "They sleep twenty hours a day and I'm still jealous."
tucks a blanket around their sleeping pet.
says <mood>, "They found me when I needed a friend most."
lets their pet lick their face, laughing. [laugh]
says, "Yes, yes, I love you too. Your breath, less so."
plays tug of war with an old rope.
loses tug of war with an old rope. [shrug]
says <mood>, "Strongest creature in Azeroth, I swear."
rests a hand on their companion's head, quiet and content. [sigh]
says, "Come on, friend. Let's go home."
]])
