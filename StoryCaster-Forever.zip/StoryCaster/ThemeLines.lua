-- StoryCaster: the Love, War and Peace lines. Original writing, six categories each.
-- A line in quotes is spoken (said aloud, or "says, ..." as an emote); any other line is acted as an emote.
local ADDON, ns = ...
local R = ns.R
R.THEMEDATA = R.THEMEDATA or {}
local function theme(key)
  R.THEMEDATA[key] = R.THEMEDATA[key] or { cats = {} }
  return function(ckey, title, icon, text)
    local lines = {}
    for raw in (text .. "\n"):gmatch("([^\r\n]*)\r?\n") do
      local l = raw:gsub("^%s+", ""):gsub("%s+$", "")
      if l ~= "" then lines[#lines + 1] = l end
    end
    table.insert(R.THEMEDATA[key].cats, { key = ckey, title = title, icon = icon, lines = lines })
  end
end

---------------------------------------------------------------------------
-- LOVE
---------------------------------------------------------------------------
local love = theme("love")

love("flirt", "Flirting", "e_chuckle", [[
"Is it warm in here, {target}, or is it just you?"
"I was going to say something clever, but then you looked at me and I forgot every word I know."
"Do you believe in love at first sight, or should I walk past again?"
"I'd fight a dragon for you. A small one. A sleepy one. But still."
"You must be a healer, because I feel better every time you're near."
"If you were a potion, I'd drink you for courage. Is that strange? That sounded strange."
"Are you lost? Because I've been looking for someone like you all my life."
"I'm not saying you're the reason I came to this tavern. But you're the reason I'm staying."
"I'd say you light up the room, but honestly it's more like the whole zone."
"Excuse me, I think you dropped something. My heart. It's right there. By your boot."
"Tell me your name, so I know what to whisper to the stars tonight."
"Careful, {target}. Smile like that and someone might fall for you. Someone like me."
"I'd offer you a drink, but I'd rather offer you the whole evening."
"You have the kind of laugh that makes a person forget to be clever."
"Is this seat taken? It is now. By me. If that's all right."
catches {target}'s eye across the room and holds it a heartbeat too long. [chuckle]
tucks a stray lock of hair behind one ear and looks away, smiling.
leans an elbow on the bar, trying very hard to look casual, and slips slightly. [shrug]
raises a glass toward {target} with a slow, crooked smile. [cheer]
winks at {target}, then immediately blushes at their own boldness.
plucks a flower from a nearby vase and offers it to {target} with a little bow. [bow]
bites their lip, then laughs softly at nothing in particular. [laugh]
wanders past {target} for the third time, as if entirely by accident.
straightens their collar and smooths their hair before walking over.
blows a kiss toward {target}, then pretends it was for someone else entirely. [kiss]
twirls a strand of hair around one finger, watching {target} from under their lashes.
laughs a little too loudly at something {target} says. [laugh]
"I'm not usually this forward. I'm usually much worse."
"If I said you had a beautiful face, would you hold it against me?"
"I had a whole speech prepared. I've lost it. Can I just stand here and admire you?"
"You're trouble, aren't you? The good kind."
"Dance with me. Just one. I promise to step on your feet only twice."
"I've seen a lot of beautiful things on my travels. You win. Easily."
"Your eyes are the exact color of the sky just before a good adventure."
offers {target} their arm with an old-fashioned flourish. [bow]
]])

love("compliment", "Compliments", "mood", [[
"You have a kind face, {target}. The world needs more of those."
"You make difficult things look easy. It's quietly wonderful to watch."
"I like the way you listen. Really listen. Not many people do."
"You carry yourself like someone who has been through storms and kept their light."
"Your laugh could start a festival."
"There's something brave about you. Even standing still."
"You make everyone around you better. I've noticed. I'm sure I'm not the only one."
"I trust you. I don't say that easily."
"You have the warmest hands. Even in this cold."
"You're clever, {target}. Annoyingly, wonderfully clever."
"Anyone would be lucky to stand beside you in a fight. Or at a dance."
"You notice the small things. That's a rare gift."
"I could listen to you talk about anything. Even taxes."
"You make silence feel comfortable. That's the rarest gift of all."
"Your kindness doesn't ask for anything back. I see it, even if nobody says so."
"You're the kind of person bards should write about. Not the dragon-slayers. You."
"Whatever you're doing with your hair today, keep doing it."
"You light up when you talk about the things you love. It's lovely to see."
"I feel safe around you. I didn't know how much I needed that."
"There's no one I'd rather share a bad meal and a long road with."
smiles warmly at {target}, the kind of smile that reaches all the way to the eyes.
looks at {target} with open admiration and doesn't bother to hide it.
nods slowly, as if agreeing with something beautiful only they can hear. [nod]
touches {target}'s arm lightly as they pass, a small, kind gesture.
gives {target} a slow, appreciative once-over and a nod of approval. [nod]
claps softly for {target}, unprompted and entirely sincere. [applaud]
places a hand over their heart while {target} speaks. [thank]
beams at {target} like they've just done something marvelous. [cheer]
"Has anyone told you today that you're wonderful? Let me be the first."
"You have a way of making strangers feel like old friends."
"Your armor's dented, your boots are muddy, and you still look magnificent."
"You're the reason I believe there's still good in the world."
"If kindness were gold, you'd be the richest person in Azeroth."
"I hope you know how much you matter. To all of us. To me."
"You're not just good company. You're the best company."
"You walked in and the whole room got a little warmer."
]])

love("court", "Courtship", "bulb", [[
"Would you walk with me, {target}? There's a quiet spot by the lake I'd like to show you."
"I brought you something. It isn't much. I saw it and thought of you."
"Have dinner with me. I can't cook, but I know someone who can."
"I'd like to court you properly. Flowers, letters, the whole terrible business."
"May I write to you while I'm away? I promise long letters and bad poetry."
"There's a festival next week. Lanterns, music, terrible food. Will you come with me?"
"I spoke to your friends. They said you like moonflowers. So, here. Moonflowers."
"Tell me everything about you. Start anywhere. I have all night."
"I'd like to know your favorite song, your worst fear, and how you take your tea."
"I'm not good at this. But I'd like to get better at it. With you."
"Can I see you again tomorrow? And the day after? I'm getting ahead of myself."
"I asked the innkeeper to save us the table by the fire. I hope that's all right."
"I wrote you a poem. Please don't read it in front of me. Or at all. Actually, read it."
"Let me walk you home. The long way. If you don't mind."
"I'd ride across the whole continent for an evening with you. Thankfully, you're right here."
offers {target} a small bouquet of wildflowers, slightly squashed from the journey. [bow]
pulls out a chair for {target} with a nervous little smile.
presents a carefully wrapped gift, then fidgets while it's opened.
walks beside {target}, close enough that their hands almost touch.
holds open the door for {target} and bows them through. [bow]
slips a folded love letter into {target}'s hand and hurries away, blushing.
spreads a blanket on the grass and sets out a little picnic for two. [sit]
lights a candle on the table between them and smiles shyly.
offers {target} a hand up onto the horse behind them.
plays a soft, slightly out-of-tune song on a borrowed lute for {target}.
shares the last sweet roll, breaking it carefully in half for {target}.
drapes their cloak around {target}'s shoulders against the evening chill.
kneels to pick up something {target} dropped, and hands it back with a smile. [kneel]
"I've been practicing this all day. Hello. You look lovely. That's all I had."
"Would you like to dance? I'm terrible. It'll be memorable."
"Your parents would like me. I'm very polite. I'll bring cake."
"There's no rush. I'm happy to take this slowly. As long as it's with you."
"I've never been so nervous about a walk in the park."
"The stars came out early tonight. I think they wanted to see you too."
"Same time next week? I'll bring better flowers."
]])

love("longing", "Longing", "e_cry", [[
"I keep looking for your face in every crowd."
"The days are longer when you're not here."
"I wrote you three letters tonight. I burned them all. They said too much."
"Every road I travel seems to lead back to thoughts of you."
"I don't know how to tell you what you mean to me. So I say nothing. Again."
"Do you ever think of me, {target}, the way I think of you?"
"The moon's the same one you see from wherever you are. That helps, a little."
"I'd trade every treasure I own for one more evening by the fire with you."
"I miss you most at dusk, when the light goes soft."
"You were here a moment ago, and the room still feels warm."
"I keep the letter you sent in my pocket. It's worn thin now. I've read it too many times."
"If I'm quiet when you're near, it's because I'm trying to remember everything."
"Some people walk into your life and rearrange all the furniture."
"I'd wait a hundred years for you. I'd complain, but I'd wait."
"Is it foolish, to miss someone who's standing right in front of you?"
gazes out the window at the falling rain, lost in thought. [sigh]
turns a small keepsake over and over in their hands.
watches {target} from across the room, then looks away before they notice.
sighs softly and rests their chin in one hand. [sigh]
traces a name in the dust on the table, then wipes it away quickly.
holds a pressed flower between two fingers, remembering. [sigh]
starts to say something to {target}, then stops, and shakes their head. [no]
reads an old letter by candlelight, a small smile on their lips.
stares at the empty seat beside them for a long, quiet moment.
hums a song they once danced to, very quietly.
looks up at the stars and whispers a name.
rests a hand on the place over their heart, as if it aches. [sigh]
"Funny how a voice can stay with you long after it's gone quiet."
"I wish I'd said it when I had the chance."
"Every song in this tavern seems to be about you tonight."
"I'll keep a candle in the window. Just in case."
"Absence is a strange thing. It takes up so much room."
"I'm fine. I'm always fine. I just think about you a great deal."
"You'll never know how often you're the reason I smile."
"If wishing worked, you'd already be here."
"I hope wherever you are tonight, you're warm and someone's making you laugh."
]])

love("heartbreak", "Heartbreak", "e_cry", [[
"I suppose this is goodbye, then."
"I don't blame you. I just wish it had ended differently."
"You were the best part of every day. I'll have to learn new days now."
"It's all right. It isn't, but it will be."
"I gave you everything I had. I'd do it again. That's the worst part."
"I'm not angry. I'm just very, very tired."
"Don't apologize. You can't help who you love. Neither can I."
"I'll be fine, {target}. Eventually. Ask me again next year."
"We had something good. Let's not ruin the memory of it."
"I hope they make you happy. I truly do."
"Funny. I knew all along. I just didn't want to know."
"I'm keeping the good memories. You can't have those back."
"Go on. Don't look back. It'll be easier for both of us."
"The heart mends, they say. Slowly. Crookedly. But it mends."
"I loved you. Past tense is going to take some getting used to."
stares into an untouched drink, very still. [sigh]
turns away so {target} won't see their eyes fill. [cry]
takes off a small ring and sets it gently on the table.
laughs, but it cracks halfway through. [cry]
wipes their eyes quickly with the back of a hand and straightens up.
walks out into the rain without a cloak, and doesn't seem to notice.
crumples a letter in one fist, then smooths it out again, carefully.
sits alone by the fire long after everyone else has gone to bed. [sit]
tries to smile at {target}, and almost manages it.
packs a small bag in silence, one folded shirt at a time.
lets out a long, shaky breath and closes their eyes. [sigh]
shakes their head slowly, a sad, knowing smile. [no]
orders a strong drink and doesn't touch it.
"Some doors close quietly. This one slammed."
"I'll put the kettle on. Tea doesn't fix anything, but it's something to do."
"I'm not going to cry in a tavern. I'm going to cry in a field. Like a dignified person."
"One day I'll look back and be glad. Today is not that day."
"Tell me a joke, {target}. A bad one. I need to remember how to laugh."
"I'll sleep on it. Probably for a month."
"Hearts are stubborn things. Mine's still waiting for a letter that won't come."
]])

love("devotion", "Devotion", "heart", [[
"Wherever you go, {target}, I'll follow."
"I choose you. Today, tomorrow, and every day after that."
"Through every storm and every winter, I'll be right here."
"You don't have to be strong all the time. Lean on me."
"There's nothing in this world I wouldn't do for you."
"I've faced dragons and demons, and none of them scared me like the thought of losing you."
"Grow old with me. Gray hair, creaky knees, terrible jokes. All of it."
"You are my home. Not a house. Not a city. You."
"I'd give my last potion for you without thinking twice."
"My heart has your name written on every wall."
"Whatever comes, we face it together."
"I promise to make you laugh at least once a day. Even the bad days."
"I loved you yesterday. I love you more today. Tomorrow's looking good too."
"You've seen me at my worst, and you stayed. I'll never forget that."
"If the world ends, I want to be holding your hand when it does."
takes {target}'s hand and holds it, simply and firmly.
kneels before {target}, eyes shining. [kneel]
rests their forehead gently against {target}'s for a long, quiet moment.
wraps {target} in a warm, unhurried embrace.
presses a soft kiss to {target}'s hand. [kiss]
stands at {target}'s side, shoulder to shoulder, ready for anything.
brushes a strand of hair from {target}'s face with tender care.
laughs softly with {target}, their foreheads almost touching. [laugh]
holds {target} close as the music plays, swaying gently. [dance]
watches {target} sleep by the fireside, and quietly adds another log. [sit]
places a single rose in {target}'s hands without a word.
draws their cloak around both of them against the cold.
looks at {target} as if they hung every star in the sky.
"You are the best thing that has ever happened to me."
"Every adventure is better with you. Every quiet night is better with you."
"I'll love you until the stars burn out. And then I'll complain about the dark."
"Thank you, {target}. For being exactly who you are."
"I don't need the whole world. I just need you in it."
"Marry me. Or don't. But stay. Please stay."
"This is the happiest I've ever been. Right here. Right now. With you."
]])

---------------------------------------------------------------------------
-- WAR
---------------------------------------------------------------------------
local war = theme("war")

war("cry", "Battle Cries", "e_roar", [[
"For honor! For glory! For everyone back home!"
"Stand fast! Not one step back!"
"With me! Charge!"
"Victory or death! And I'm not planning on death!"
"Hold the line! Hold it!"
"Raise your shields! Here they come!"
"For the Alliance!"
"For the Horde!"
"Blood and thunder!"
"No retreat! No surrender!"
"Today we fight! Tomorrow we feast!"
"Steel yourselves! Let them break upon us!"
"Strike now, while they falter!"
"Ride! Ride for glory!"
"Let them hear us all the way to the mountains!"
"Forward! For every fallen friend!"
"They'll write songs about this day!"
"Show them what we're made of!"
"Shields up! Blades out! Hearts strong!"
"This is our land! Our home! Our fight!"
lets out a battle cry that echoes across the field. [roar]
raises a weapon high above their head, rallying everyone nearby. [cheer]
beats a fist against their chest like a war drum. [roar]
thrusts a banner into the air, the colors snapping in the wind. [salute]
bellows wordlessly, shaking the very air. [roar]
slams a weapon against a shield again and again, building the rhythm. [flex]
points their blade at the enemy line, eyes blazing. [point]
throws back their head and roars with every ounce of breath. [roar]
charges forward without looking back, war cry ringing out. [roar]
lifts a horn to their lips and blows a long, defiant blast.
"Who's with me? Everyone? Good!"
"Let's finish this, once and for all!"
"Fear is a choice. Choose fury!"
"Every one of you is worth ten of them! Prove it!"
"Glory awaits the bold! Be bold!"
"For our families! For our future!"
]])

war("before", "Before the Battle", "e_salute", [[
"Check your straps. Check them twice. A loose buckle has killed more soldiers than any sword."
"Eat something. You'll need the strength."
"Write your letters now. Just in case."
"Look at the person beside you. That's who you're fighting for."
"Breathe. In, and out. Steady hands win battles."
"Scared? Good. Fear keeps you sharp. Just don't let it hold the reins."
"I've seen worse odds. Not many. But I've seen worse."
"When the horns sound, we move as one."
"Whatever happens out there, I'm proud to stand with you, {target}."
"The plan is simple: we hold the bridge until the reinforcements come."
"Stay together. Watch each other's backs. Come home."
"Sharpen your blades. Sharpen your minds."
"I won't lie to you. It'll be hard. But we've done hard before."
"Say your prayers to whatever you believe in. Then pick up your weapon."
"Tomorrow, we fight. Tonight, we remember why."
sharpens a blade with slow, steady strokes, lost in thought.
checks every buckle of their armor, one by one.
kneels to offer a quiet prayer before the fight. [kneel]
grips {target}'s forearm tightly, a soldier's farewell and promise. [nod]
stares out across the empty field where the battle will be.
tightens their gauntlets and flexes their fingers. [flex]
paints a stripe of war paint across their face with two fingers.
tests the weight of their weapon, swinging it in a slow arc.
looks up at the gray sky and takes a long, slow breath. [sigh]
tucks a small keepsake into their armor, close to their heart.
shares a quiet joke with the soldier beside them, and they both laugh nervously. [laugh]
stands tall as the commander rides past, saluting crisply. [salute]
writes a short letter by firelight and folds it carefully.
nods to {target}, a silent promise passing between them. [nod]
"No heroics. Do your job, keep your head, and we'll get through."
"The enemy is just as scared as we are. Remember that."
"I'll see you on the other side of this, {target}."
"Whatever comes, we meet it standing."
"The waiting's the worst part. Soon it'll be over."
"Remember: we fight to protect, not to destroy."
]])

war("fray", "In the Fray", "swords", [[
"On your left!"
"Behind you!"
"Fall back to the second line!"
"Healer! I need a healer over here!"
"Push! Push them back!"
"Watch the flank! They're coming around!"
"Archers, loose!"
"Close ranks! Shield wall!"
"I've got this one! Help the others!"
"Keep moving! Don't stop!"
"Down! Get down!"
"Take the hill! Take it now!"
"They're breaking! Keep pressing!"
"Cover me!"
"Stay with me, {target}! Stay close!"
"Regroup! Regroup on me!"
ducks under a wild swing and answers with a quick counterstrike.
blocks a heavy blow with a raised shield, staggering back a step.
parries, pivots, and strikes in one smooth motion.
pulls a wounded ally back behind the line.
plants their feet and braces for the charge. [flex]
dives aside as an arrow whistles past. [gasp]
fights back to back with {target}, blades flashing.
shoves an attacker back with the rim of a shield.
wipes the sweat and dust from their eyes and keeps fighting.
spins away from a blow, cloak flaring. [dance]
roars and throws themselves into the thick of the fighting. [roar]
grabs {target} by the collar and pulls them out of harm's way.
stumbles, recovers, and raises their weapon again.
locks blades with an enemy, straining with all their strength. [flex]
points out the enemy commander to {target} with a sharp gesture. [point]
"Is that all you've got?"
"I'm still standing! Come on!"
"Almost there! One more push!"
"Keep your shield up, {target}!"
]])

war("taunt", "Taunts", "e_point", [[
"Is that the best your army can do?"
"I've fought kobolds with more courage than you."
"Come on, then! I haven't got all day!"
"You call that a charge? I've seen faster snails."
"Run home to your mother, recruit."
"Your armor's shiny. Shame about the soldier inside it."
"I'll give you the first swing. You'll need it."
"Your banner's ugly and your strategy is worse."
"I've had harder fights with my morning porridge."
"Surrender now and I'll only laugh at you a little."
"Are you here to fight, or to admire the scenery?"
"I've seen scarecrows with more backbone."
"Swing harder. I barely felt that."
"You fight like you're afraid of breaking a nail."
"Is your general always this bad, or is today special?"
laughs in the face of the enemy line. [laugh]
beckons {target} forward with one finger and a confident grin.
yawns theatrically in the middle of the battlefield.
taps their own chin, daring the enemy to strike. [point]
spins a weapon lazily, unimpressed. [shrug]
salutes the enemy mockingly. [salute]
shakes their head at the enemy's formation, tutting loudly. [no]
plants their weapon in the ground and folds their arms.
flexes theatrically at the enemy ranks. [flex]
waves cheerfully at the enemy archers. [wave]
roars a challenge across the field. [roar]
points at the enemy champion, then draws a slow line across the ground.
"I'll be waiting. Bring friends. You'll need them."
"Your grandchildren will tell stories about how badly you lost today."
"Next time, send someone who can actually fight."
"I almost feel sorry for you. Almost."
"Go on, {target}, tell them how this ends. I'm sure they'd like to know."
"Fight me. I dare you. I double dare you."
"Your battle cry needs work. Very squeaky."
]])

war("victory", "Victory", "e_cheer", [[
"We did it! The field is ours!"
"Victory! Glorious victory!"
"Raise the banner! Let them see who holds this ground!"
"Tonight we feast, and tomorrow we tell the tale!"
"They ran! Did you see them run?"
"That's how it's done! That's how it's done!"
"Well fought, everyone. Truly. Well fought."
"I knew we'd win. I had my doubts. But I knew."
"Drinks are on me tonight! All of them!"
"We'll remember this day for the rest of our lives."
"Couldn't have done it without you, {target}."
"History will remember us. Or at least the tavern will."
"They'll be singing about this for years. Badly. But singing."
"Look at us. Battered, bruised, and victorious."
"The day is won! Go home to your families!"
lets out a whoop of triumph and punches the air. [cheer]
plants the banner at the top of the hill, the wind snapping it open.
lifts {target} off their feet in a rough, joyful hug.
collapses onto the grass, laughing with exhaustion and relief. [laugh]
raises their weapon to the sky in salute. [salute]
dances a clumsy victory jig among the cheering soldiers. [dance]
claps every passing soldier on the shoulder. [cheer]
sheathes their weapon with a satisfied snap.
bows to the cheering crowd, grinning ear to ear. [bow]
shakes {target}'s hand, then pulls them into a hug.
roars in triumph alongside the rest of the army. [roar]
throws their helmet into the air and catches it, beaming.
"For every soldier who stood with us today. Thank you."
"Rest well tonight. You've earned it."
"This one's for the history books, {target}."
"We fought as one, and we won as one."
"Not bad for a bunch of farmers and tavern brawlers, eh?"
"Let's go home. We've done enough for one day."
"The war isn't over. But today, we won."
]])

war("after", "The Aftermath", "e_kneel", [[
"So many good people. Gone in a single afternoon."
"We won. It doesn't feel like winning."
"Help me with the wounded. There are still so many."
"Bury them with their weapons. They'd want that."
"I'll write to their families. Someone has to."
"I need to sit down. Just for a moment."
"Is it over? Truly over?"
"Remember their names. All of them."
"War takes everything, even from the winners."
"I keep hearing the horns. Even now."
"Thank you for staying beside me, {target}. I couldn't have done it alone."
"Let's never do that again. Please."
"Tonight we mourn. Tomorrow we rebuild."
"They fought for a world without war. Let's build it for them."
"I'm so tired, {target}. Bone-deep tired."
walks slowly across the quiet battlefield, head bowed.
kneels beside a fallen comrade and closes their eyes gently. [kneel]
sits on a broken cart, staring at nothing. [sit]
helps a limping soldier back toward the camp.
lays a single flower on a fresh grave. [kneel]
cleans their blade slowly, saying nothing.
rests a hand on {target}'s shoulder, a silent comfort.
stares at their trembling hands until they finally go still. [sigh]
salutes the line of fallen soldiers, one by one. [salute]
sits by the campfire long into the night, unable to sleep. [sit]
carves a name into a wooden marker with careful strokes.
breathes in the cold evening air, grateful simply to be breathing. [sigh]
quietly shares their rations with a young recruit.
"The songs never mention this part."
"I'll carry them with me. Every one."
"Peace had better be worth it."
"When this is over, I'm going to plant a garden. A very quiet garden."
"Rest easy, friends. We've got it from here."
"Let's go home, {target}. Let's go home."
]])

---------------------------------------------------------------------------
-- PEACE
---------------------------------------------------------------------------
local peace = theme("peace")

peace("greet", "Peaceful Greetings", "e_wave", [[
"Peace be with you, {target}."
"Well met, friend. Sit, rest a while."
"May your road be gentle today."
"Welcome. There's always room for one more by this fire."
"Light keep you, traveler."
"Good morning. The sun came up for both of us. That's a good start."
"Come in from the cold. You look like you've walked a long way."
"Be at ease. Nobody here wishes you harm."
"Hello, {target}. It's good to see a friendly face."
"May you find what you're looking for, and a little more besides."
"Rest your feet. The world can wait a moment."
"You're welcome here. Whoever you are, whatever you carry."
"Peace and good bread to you."
"Ah, a new friend. Wonderful."
"Greetings, and may your burdens be lighter by evening."
bows gently, palms pressed together. [bow]
raises an open hand in greeting, showing it holds no weapon. [wave]
offers {target} a warm cup of tea without a word.
smiles serenely and makes room on the bench. [sit]
nods to {target} with quiet warmth. [nod]
places a hand over their heart in greeting. [thank]
lays down their weapon and steps forward, empty-handed.
greets {target} with a soft, unhurried bow. [bow]
pours a second cup and slides it toward {target}.
waves to {target} across the meadow, smiling. [wave]
"There is always time for kindness."
"Whatever brought you here, I'm glad it did."
"Sit with me. We needn't say anything at all."
"No titles, no banners here. Just people."
"May the Light, the Earth Mother, or whatever you hold dear watch over you."
"You're safe here, {target}."
"Rest. You've earned it."
"Peace isn't the absence of trouble. It's company in the middle of it."
"Hello, friend. It's a beautiful day to be kind."
]])

peace("calm", "Stillness", "e_nod", [[
"Breathe with me. In. And out."
"Let it go, {target}. Whatever it is, let it go for a moment."
"The river doesn't hurry, and still it reaches the sea."
"Be still. Listen. Can you hear the wind in the trees?"
"There's no rush. There never really is."
"All storms pass. Even the ones inside us."
"Close your eyes. Just for a breath."
"Nothing needs doing right now. Nothing at all."
"Feel the ground beneath you. It's holding you up. It always has."
"Quiet the mind, and the heart follows."
"Each breath is a small new beginning."
"Let your shoulders drop. You've been carrying them up by your ears."
"The moment is enough. You are enough."
"Even a mountain was once just a pebble that waited."
"Be gentle with yourself today."
sits cross-legged on the grass and closes their eyes. [sit]
breathes slowly and deeply, chest rising and falling. [sigh]
rests their hands on their knees, palms open to the sky.
listens to the birdsong with a small, contented smile.
lets out a long, slow breath, and their whole body softens. [sigh]
watches the clouds drift by, utterly unhurried.
traces slow circles in the water with one finger.
hums a single low note, steady and calm.
sits so still a small bird lands beside them. [sit]
gazes into the candle flame, perfectly at peace.
rests a calming hand on {target}'s shoulder.
closes their eyes and turns their face to the sun. [sigh]
lets the wind tug at their hair without minding at all.
"There. Doesn't that feel better?"
"Stillness isn't doing nothing. It's making room."
"Your heart knows the way. Let it lead for a while."
"The world will still be there when you open your eyes."
"Peace is a habit. Practice it a little every day."
"Be like water, {target}. Soft, patient, unstoppable."
]])

peace("wisdom", "Wisdom", "lore", [[
"The strongest people I've known were also the gentlest."
"A kind word costs nothing and can change everything."
"We are all walking each other home."
"Anger is a fire you hold by the burning end."
"You don't have to win every argument. Some aren't worth the ground they're fought on."
"Small kindnesses add up to a life well lived."
"The best time to plant a tree was long ago. The second best time is today."
"Listen twice as much as you speak. You have two ears for a reason."
"Forgiveness isn't for them. It's for you."
"Everyone you meet is fighting a battle you know nothing about."
"Be the kind of person you needed when you were young."
"Pride builds walls. Humility builds bridges."
"Patience is not waiting. It's how you behave while you wait."
"A gentle answer turns away wrath."
"The way you treat those who can do nothing for you says everything."
"Every ending is a beginning in disguise."
"Wealth is not what you hold. It's what you can let go of."
"Courage is not loud. Sometimes it's the quiet voice that says 'try again tomorrow'."
strokes their chin thoughtfully, considering {target}'s question. [nod]
smiles knowingly and pours another cup of tea.
nods slowly, eyes crinkling with gentle amusement. [nod]
draws a small circle in the dust and studies it for a long moment.
gazes into the fire as if reading something written there.
taps the side of their nose wisely, then forgets what they were going to say. [chuckle]
sets down their staff and settles in to tell a long story. [sit]
pauses, letting the silence say what words cannot.
"My teacher told me that. I didn't understand it until I was very old."
"Ask the question again, {target}. Slower. You already know the answer."
"There's an old saying: the bamboo that bends is stronger than the oak that resists."
"Don't believe everything you think."
"The past is a teacher, not a jailer."
"What you seek is seeking you."
"Be kind. It's never wrong."
"Life is long, if you know how to use it."
"Even the wise were fools once. They just kept going."
]])

peace("mend", "Mending Quarrels", "people", [[
"Let's put down our weapons and talk, {target}. Just talk."
"I'm sorry. I was wrong, and I'm sorry."
"We've both said things we didn't mean. Let's start again."
"Whatever happened between us, I'd rather have you as a friend."
"Can we find a middle path? There's always a middle path."
"I don't want to fight anymore. Do you?"
"Hear me out, and I'll hear you out. That's fair, isn't it?"
"There's no shame in shaking hands."
"Let's leave the past where it belongs. Behind us."
"I forgive you. And I hope you can forgive me."
"We want the same things, really. We just disagree on the road."
"No winner, no loser. Just two people who want this to end."
"Let's sit down together. Bread first, arguments later."
"Your side and my side. How about our side?"
"I'd rather be kind than right."
holds out an open hand toward {target}, waiting. [wave]
lowers their weapon slowly and sets it on the ground.
bows their head in apology. [bow]
sits down across from {target} and gestures for them to join. [sit]
offers {target} half of a loaf of bread, a gesture as old as time.
waits patiently, saying nothing, giving {target} time to speak.
shakes {target}'s hand firmly, and holds it a moment longer. [nod]
smiles tentatively, hopefully, at {target}.
places a hand on their heart as they speak, sincere. [thank]
laughs softly as the tension finally breaks. [laugh]
pulls {target} into a reluctant, then genuine, hug.
pours two cups of ale and slides one across. [cheer]
"I've missed you, you stubborn fool."
"Truce? Truce."
"There. Was that so hard? Yes. Yes, it was. But we did it."
"I'm glad we talked, {target}."
"Friends again?"
"Next time, let's argue over something small. Like whose turn it is to cook."
"Peace takes more courage than war. Thank you for being brave."
]])

peace("bless", "Blessings", "mood", [[
"May your path be clear and your burdens light."
"May the Light warm you in the darkest night."
"May the Earth Mother hold you steady."
"May your heart find what it's searching for."
"May your hearth always be warm and your table always full."
"May you never walk alone, {target}."
"May you be safe, may you be well, may you be at peace."
"May the stars watch over you wherever you sleep tonight."
"May every road you take bring you home again."
"May you find rest when you need it, and strength when you don't."
"May your friends be true and your enemies few."
"May kindness follow you all the days of your life."
"May your wounds heal and your scars tell good stories."
"May the wind be gentle at your back."
"May you laugh often and love much."
raises a hand over {target} in a quiet blessing.
bows deeply, palms together, a silent prayer for {target}'s safety. [bow]
places a small charm in {target}'s hand and closes their fingers around it.
kneels and whispers a blessing to the earth. [kneel]
lights a small candle and sets it in the window for {target}.
touches {target}'s forehead lightly with two fingers in blessing.
sprinkles a pinch of dried herbs into the fire, murmuring softly.
looks up at the sky and asks it to watch over {target}. [sigh]
smiles warmly and hums an old song of protection.
ties a small ribbon around {target}'s wrist for luck.
"Go with my blessing, {target}."
"You carry my good wishes wherever you go."
"The world is better with you in it."
"May all your days be gentle ones."
"Peace go with you, and peace stay with you."
"Bless you, friend. Truly."
"May you always find your way back to the light."
"Walk softly, live kindly, rest well."
]])

peace("rest", "Rest and Nature", "ambient", [[
"Listen to the brook. It's been singing that same song for a thousand years."
"There's nothing like the smell of rain on warm stone."
"Look, {target}. The first star of evening."
"Let's just sit here and watch the sun go down."
"The flowers don't hurry, and still they bloom."
"I could lie in this meadow forever."
"Hear that? The world, breathing."
"The trees have seen so much. They don't seem worried."
"Every leaf is a small miracle, if you look closely."
"I think the fish here are happier than we are."
"The moon's out early tonight. It wanted to see the lake."
"There's a quiet here you can't find anywhere else."
"Even the wind seems to be taking its time today."
"Let's not talk for a while. Let's just listen."
"Nature doesn't hurry, yet everything is accomplished."
lies back in the soft grass, hands folded behind their head. [sit]
dips their bare feet into the cool stream and sighs happily. [sigh]
watches a butterfly settle on their outstretched finger.
breathes in the scent of pine and wildflowers.
picks a daisy and tucks it behind {target}'s ear.
skips a smooth stone across the still lake, counting the hops. [cheer]
leans back against a tree trunk and closes their eyes. [sit]
watches the fireflies rise from the meadow as dusk falls.
cups water from the spring and drinks deeply.
listens to the rain patter on the roof, a contented smile on their face.
scatters a handful of seeds for the birds and watches them gather.
watches the clouds drift by, naming the shapes they make. [point]
plucks a blade of grass and whistles through it.
"I'll make tea. We'll sit. That's the whole plan."
"This is what we fight for, {target}. Moments like this."
"The world is beautiful when we let it be."
"Rest now. Tomorrow will come soon enough."
"Some days the best thing you can do is nothing at all."
"Look at that sky. Worth every hard mile."
"Let's stay until the stars come out."
]])
