-- StoryCaster: the Lore library. Ready-made roleplay for every class, faction and race,
-- picked from three dropdowns in the Lore window (/story lore). Loaded after the Lore*.lua files.
local ADDON, ns = ...
local R = ns.R
R.LORE = R.LORE or {}
R.LORE_MORE = R.LORE_MORE or {}

R.LORE_KINDS = { { "class", "Class" }, { "faction", "Faction" }, { "race", "Race" }, { "profession", "Profession" }, { "holiday", "Holiday" }, { "occasion", "Occasion" } }

local ORDER = {
  class = { "WARRIOR", "PALADIN", "HUNTER", "ROGUE", "PRIEST", "DEATHKNIGHT", "SHAMAN", "MAGE", "WARLOCK",
    "MONK", "DRUID", "DEMONHUNTER", "EVOKER" },
  faction = { "Alliance", "Horde", "Neutral" },
  race = { "Human", "Dwarf", "NightElf", "Gnome", "Draenei", "Worgen", "VoidElf", "LightforgedDraenei",
    "DarkIronDwarf", "KulTiran", "Mechagnome",
    "Orc", "Scourge", "Tauren", "Troll", "BloodElf", "Goblin", "Nightborne", "HighmountainTauren",
    "MagharOrc", "ZandalariTroll", "Vulpera",
    "Pandaren", "Dracthyr", "EarthenDwarf" },
  profession = { "Alchemy", "Blacksmithing", "Enchanting", "Engineering", "Herbalism", "Inscription", "Jewelcrafting",
    "Leatherworking", "Mining", "Skinning", "Tailoring", "Cooking", "Fishing", "Archaeology", "FirstAid" },
  holiday = { "HallowsEnd", "WinterVeil", "Brewfest", "LunarFestival", "DarkmoonFaire" },
  occasion = { "Wedding", "Funeral", "DepartingForBattle", "BirthOfAChild", "LossOfAFriend", "RomanceFirstMeeting",
    "RomanceQuietEvening", "RomanceConfession" },
}

-- the holiday in season (by the calendar on your computer), for the Holiday dropdown to start on
local SEASONS = {
  { "WinterVeil", 12, 16, 12, 31 }, { "WinterVeil", 1, 1, 1, 2 }, { "LunarFestival", 1, 20, 2, 12 },
  { "Brewfest", 9, 20, 10, 6 }, { "HallowsEnd", 10, 18, 11, 1 },
}
function R:HolidayInSeason()
  local t = date and date("*t")
  if type(t) ~= "table" then return nil end
  local md = t.month * 100 + t.day
  for _, s in ipairs(SEASONS) do
    if md >= s[2] * 100 + s[3] and md <= s[4] * 100 + s[5] then return s[1] end
  end
  if t.day <= 7 then return "DarkmoonFaire" end -- the Faire opens the first week of each month
end

-- your first profession that has lore
local PROF_WORDS = { blacksmith = "Blacksmithing", herbalis = "Herbalism", fishing = "Fishing", alchem = "Alchemy",
  tailor = "Tailoring", engineer = "Engineering", cooking = "Cooking", enchant = "Enchanting", inscription = "Inscription",
  jewel = "Jewelcrafting", leather = "Leatherworking", mining = "Mining", skinning = "Skinning", archaeolog = "Archaeology",
  ["first aid"] = "FirstAid" }
local PROF_PRIMARY = { "Alchemy", "Blacksmithing", "Enchanting", "Engineering", "Herbalism", "Inscription", "Jewelcrafting",
  "Leatherworking", "Mining", "Skinning", "Tailoring" }
local function profKey(name)
  if type(name) ~= "string" then return nil end
  for w, key in pairs(PROF_WORDS) do if name:lower():find(w, 1, true) then return key end end
end
-- your first profession that has lore: a main profession first, then cooking, fishing and the rest
function R:MyProfession()
  local found = {}
  if GetProfessions then
    local ok, a, b, c, d, e = pcall(GetProfessions)
    if ok then
      for _, idx in ipairs({ a, b, c, d, e }) do
        local key = idx and GetProfessionInfo and profKey((GetProfessionInfo(idx)))
        if key then found[#found + 1] = key end
      end
    end
  end
  -- older clients (Forever): the skill list
  if #found == 0 and GetNumSkillLines and GetSkillLineInfo then
    for i = 1, (GetNumSkillLines() or 0) do
      local key = profKey((GetSkillLineInfo(i)))
      if key then found[#found + 1] = key end
    end
  end
  for _, k in ipairs(found) do for _, p in ipairs(PROF_PRIMARY) do if k == p then return k end end end
  return found[1]
end

-- every key of a kind that has lore, in the order above, then any others alphabetically
function R:LoreKeys(kind)
  local set, out, seen = self.LORE[kind] or {}, {}, {}
  for _, k in ipairs(ORDER[kind] or {}) do
    if set[k] then out[#out + 1] = k; seen[k] = true end
  end
  local extra = {}
  for k in pairs(set) do if not seen[k] then extra[#extra + 1] = k end end
  table.sort(extra)
  for _, k in ipairs(extra) do out[#out + 1] = k end
  return out
end

function R:LoreTitle(kind, key)
  local e = self.LORE[kind] and self.LORE[kind][key]
  return e and e[1] or tostring(key)
end

function R:LoreText(kind, key)
  local e = self.LORE[kind] and self.LORE[kind][key]
  if not e then return nil end
  local more = self.LORE_MORE[kind] and self.LORE_MORE[kind][key]
  local text = "\n" .. e[2] .. (more and ("\n" .. more) or "")
  -- every spoken line takes the panel's mood: says <mood>, "..."
  text = text:gsub("\n(%s*)says, ", "\n%1says <mood>, ")
  return (text:gsub("^\n", ""))
end

function R:LoreScript(kind, key)
  local text = self:LoreText(kind, key)
  if not text then return {} end
  return (self:Convert(text, "lines", false))
end

function R:LoreName(kind, key) return "Lore: " .. self:LoreTitle(kind, key) end

-- your own class, faction and race, as the starting choice in each dropdown
function R:LoreDefault(kind)
  local key
  if kind == "class" then key = UnitClass and select(2, UnitClass("player"))
  elseif kind == "race" then key = UnitRace and select(2, UnitRace("player"))
  elseif kind == "faction" then key = UnitFactionGroup and UnitFactionGroup("player")
  elseif kind == "profession" then key = self:MyProfession()
  elseif kind == "holiday" then key = self:HolidayInSeason() end
  if key and self.LORE[kind] and self.LORE[kind][key] then return key end
  return self:LoreKeys(kind)[1]
end

-- saves the set as "Lore: <title>" (refreshing it with the original text) and performs it
function R:PerformLore(kind, key)
  local name = self:LoreName(kind, key)
  local ok, msg = self:Save(name, self:LoreScript(kind, key))
  if not ok then self:Print(msg) return end
  self:Start(name)
end

function R:PreviewLore(kind, key)
  local script = self:LoreScript(kind, key)
  self:Print(("|cffffd100%s|r: %d lines"):format(self:LoreName(kind, key), #script))
  for i, l in ipairs(script) do
    self:Print(("%d. %s%s"):format(i, l[6] and ("|cffffd100## " .. l[6] .. "|r  ") or "",
      self.LineLabel and self:LineLabel(l) or self:LineToText(l)))
  end
end

-- favorites: marked with a star, and listed first in each dropdown
function R:IsLoreFav(kind, key)
  return type(self.db.loreFav) == "table" and self.db.loreFav[kind .. ":" .. key] or false
end

function R:ToggleLoreFav(kind, key)
  self.db.loreFav = type(self.db.loreFav) == "table" and self.db.loreFav or {}
  local k = kind .. ":" .. key
  self.db.loreFav[k] = (not self.db.loreFav[k]) or nil
  return self.db.loreFav[k] or false
end

-- one line from a set, posted now (your click), at most once every 15 seconds
R.LORE_LINE_GAP = 15
function R:LoreLineWait() return math.max(0, (self.loreLineReady or 0) - GetTime()) end

function R:SayLoreLine(kind, key)
  local wait = self:LoreLineWait()
  if wait > 0 then self:Print(("One line is resting: %ds."):format(math.ceil(wait))) return nil end
  if not self:CanEmote() then self:Print("Not now: you are in combat or a boss fight.") return nil end
  local pool = {}
  for _, l in ipairs(self:LoreScript(kind, key)) do
    if (l[1] or "") ~= "" and not l.go and not l.choice then pool[#pool + 1] = l end
  end
  if #pool == 0 then return nil end
  local line = pool[math.random(#pool)]
  self:Perform(line)
  self.loreLineReady = GetTime() + self.LORE_LINE_GAP
  self:Refresh()
  return line
end

-- finds a key by a typed name ("blood elf", "dk", "horde")
function R:FindLore(word)
  word = (word or ""):lower():gsub("[%s'%-]", "")
  if word == "" then return nil end
  local alias = { dk = "DEATHKNIGHT", dh = "DEMONHUNTER", undead = "Scourge", forsaken = "Scourge", earthen = "EarthenDwarf",
    neutral = "Neutral", unaligned = "Neutral", blacksmith = "Blacksmithing", herbalist = "Herbalism", fisher = "Fishing",
    alchemist = "Alchemy", tailor = "Tailoring", engineer = "Engineering", cook = "Cooking", hallowsend = "HallowsEnd",
    enchanter = "Enchanting", scribe = "Inscription", jeweler = "Jewelcrafting", jeweller = "Jewelcrafting", leatherworker = "Leatherworking",
    miner = "Mining", skinner = "Skinning", archaeologist = "Archaeology", firstaid = "FirstAid", medic = "FirstAid",
    wintersveil = "WinterVeil", darkmoon = "DarkmoonFaire", lunar = "LunarFestival" }
  for _, kd in ipairs(self.LORE_KINDS) do
    for _, k in ipairs(self:LoreKeys(kd[1])) do
      local t = self:LoreTitle(kd[1], k):lower():gsub("[%s'%-]", "")
      if k:lower() == word or t == word or (alias[word] and alias[word] == k) then return kd[1], k end
    end
  end
end
