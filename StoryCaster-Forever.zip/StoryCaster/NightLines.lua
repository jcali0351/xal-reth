-- StoryCaster: After Dark (18+). Adult-themed nightlife comedy: drinking, go-go dancing, cheeky flirting, dares,
-- brawls and hangovers. Suggestive at most, never explicit. Hidden behind a one-time 18+ confirmation.
local ADDON, ns = ...
local R = ns.R
R.THEMEDATA = R.THEMEDATA or {}
R.THEMEDATA.nsfw = { cats = {} }
local function cat(ckey, title, icon, text)
  local lines = {}
  for raw in (text .. "\n"):gmatch("([^\r\n]*)\r?\n") do
    local l = raw:gsub("^%s+", ""):gsub("%s+$", "")
    if l ~= "" then lines[#lines + 1] = l end
  end
  table.insert(R.THEMEDATA.nsfw.cats, { key = ckey, title = title, icon = icon, lines = lines })
end

cat("drink", "Drinking", "cocktail", [[
"Barkeep! Something strong, something cold, and something I'll regret!"
"Shots! Everybody! On {target}'s tab!"
"I'm not drunk. I'm emotionally hydrated."
"One more drink and I'll be ready to tell everyone how much I love them."
"Line them up. I'm not leaving until I can see two of you, {target}."
"This ale tastes like poor decisions. Pour me another."
"Who ordered the flaming drink? Ah. Me. I'm on fire. Wonderful."
"To bad ideas and good company!"
"I only drink on days ending in Y."
"Water? I've heard of it. Fish do unspeakable things in it."
"If you see me dancing on a table, mind your own business and hand me another drink."
"The first round is for courage. The second is for fun. The fifth is for the story."
"Bottoms up! Mostly mine."
"My doctor said to cut back. So I'm drinking out of a smaller mug. A taller, smaller mug."
"Is the room spinning, or is that just the music?"
"Tonight, I am not a hero of Azeroth. Tonight, I am a person with a drink."
"Keep them coming until I start singing. Then keep them coming faster, so I stop."
"Last call? I don't recognize that authority."
slams back a shot and slaps the empty glass upside down on the bar. [cheer]
orders a drink that's on fire, and blows it out with great ceremony.
raises a glass to {target} and drains it in one go. [cheer]
sways happily on the barstool, grinning at absolutely nothing. [laugh]
licks salt from a wrist, takes a shot, and bites a lime with a dramatic wince. [gasp]
balances a full drink on their head and walks the length of the bar. [flex]
tries to wink at the barkeep and blinks with both eyes instead.
challenges {target} to a drinking contest and loses round one. [laugh]
hiccups in the middle of a very serious toast.
pours a drink, misses the glass, and pretends that was the plan. [shrug]
clinks glasses with everyone within reach, and some people out of reach. [cheer]
stacks empty tankards into a tottering tower, very proud of it.
whispers to the drink before drinking it, apparently for luck.
toasts the ceiling, the floor, and finally {target}. [cheer]
"I'd tell you a secret, but I've had six of these, so it'll be all the secrets."
"Pour one for me and one for my bad decisions. We're both thirsty."
]])

cat("gogo", "Go-Go Dancing", "e_dance", [[
"Somebody turn the music up! I feel a dance coming on!"
"Watch out, {target}. These hips don't lie. They exaggerate."
"Clear the floor! I'm going in!"
"If you've got it, flaunt it. If you don't, flaunt it anyway."
"I didn't come here to stand around. I came here to be seen."
"Is this table sturdy? Asking for my dance career."
"Dance with me, {target}! I promise I'm only a little bit dangerous."
"The music's in my bones. Also in my feet. Mostly in my feet."
"Shake what the Earth Mother gave you!"
"I've been told I dance like nobody's watching. Everybody's watching. I'm fine with it."
"Tip the dancer! The dancer is me!"
"That beat is calling my name. Loudly."
climbs onto a table and starts dancing to cheers from the crowd. [dance]
spins in a slow circle, arms over their head, eyes closed. [dance]
shimmies across the floor toward {target}, hips swinging. [dance]
strikes a pose under the spotlight and holds it a beat too long. [flex]
dances back to back with {target}, both of them laughing. [laugh]
flips their hair dramatically as the music drops. [dance]
does an extremely confident move that goes slightly wrong, and turns it into another move. [shrug]
twirls a scarf over their head and lets it fly into the crowd. [cheer]
moonwalks across the tavern floor with surprising grace. [dance]
leans into the music, snapping fingers, eyes half closed.
shakes their shoulders in time with the drums, grinning. [dance]
pulls {target} onto the dance floor by both hands. [dance]
does a little spin and bows to a smattering of applause. [bow]
dances on top of the bar until the barkeep gives a very pointed look. [dance]
wiggles their eyebrows at {target} while dancing. [chuckle]
bumps hips with {target} in time with the beat. [dance]
"One more song! One more!"
"My feet hurt, my hair's a mess, and I've never been happier."
"Don't stop the music! I'll know!"
"That was a performance, {target}. Applause is welcome. So are coins."
"I need water. And a fan. And another song."
]])

cat("flirt", "Cheeky Flirting", "heart", [[
"Is it hot in here, or did you just walk in, {target}?"
"I'd buy you a drink, but I'd rather spend the money on a second one for later."
"My place or yours? I mean the inn. I'm in room four. It has a lovely view of the stables."
"Careful, {target}. Keep looking at me like that and I'll have to start charging."
"I've got a reputation to uphold, and frankly, so do you."
"Come here often? Don't answer that. I can tell by the way you hold your drink."
"I'm not saying you're dangerous, but I'd follow you into a dungeon. Unarmed."
"You look like trouble. I love trouble. Trouble is my favorite thing."
"If I wink at you, it's on purpose. If I wink with both eyes, I've had too much."
"Save me a dance. Or two. Or the whole evening."
"I'd tell you you're gorgeous, but I suspect you already own a mirror."
"Behave yourself, {target}. Or don't. I'm not your mother."
"I've got a terrible idea. Want to hear it? You'll love it."
"I'm a simple person. I see someone attractive, I buy them a drink, I make it weird."
winks at {target} and slides a drink across the bar. [chuckle]
leans in close to {target} and whispers something that makes them laugh. [laugh]
bites their lip and looks {target} up and down, very slowly.
twirls a strand of hair and smiles at {target} over the rim of a glass.
blows {target} a kiss, then pretends to catch it back. [kiss]
raises one eyebrow at {target}, a whole conversation in a single look.
fans themselves dramatically as {target} walks past. [gasp]
drapes an arm along the bar beside {target}, very casually. [chuckle]
writes their room number on a napkin and slides it over with a wink.
pats the empty stool beside them with a meaningful look at {target}.
laughs a little too long at {target}'s joke. [laugh]
adjusts their collar and gives {target} a slow, smoldering look.
"I'm not flirting. I'm being extra friendly in your general direction."
"You're welcome to stare. Everyone else is."
"Tell me your name, so I know what to shout across the tavern later."
"I'd make a pass at you, but I'm afraid you'd intercept it."
"You and me, {target}, and a very bad decision. What do you say?"
]])

cat("crawl", "Bar Crawl and Nightlife", "e_cheer", [[
"Next tavern! Everyone grab your coat, and someone grab mine, I can't find my arms!"
"Seven taverns, seven drinks, seven terrible stories. Let's go!"
"This place is dead. I know a better one with a goblin who sells questionable drinks."
"Who's buying the next round? Not me. I spent my gold on a hat."
"The night is young, and so are we. Relatively."
"I've lost my friends, my coin purse and my dignity. Great night so far!"
"Has anyone seen my shoe? I had two when we started."
"Taxi! Gryphon! Anything with wings that won't judge me!"
"We are not leaving until someone starts crying or singing. Ideally both."
"I love you all. I mean it. I've had a lot to drink, but I mean it."
"That bouncer looked at me funny. I'm going to look at him funnier."
"Pub quiz! I know nothing, but I'm very confident!"
"Every tavern in town has a picture of me on the wall. It's not flattering."
leads the group out the door, singing loudly and off key. [cheer]
links arms with {target} and stumbles down the street, laughing. [laugh]
tries to open the tavern door the wrong way four times. [shrug]
buys a round for a group of complete strangers. [cheer]
loses a shoe in the street and decides to carry on without it.
dances down the road between taverns, very pleased with themselves. [dance]
leans heavily on {target} for support, swearing they're fine.
falls asleep on a bench for five minutes, then wakes up ready for more.
argues with a lamppost and loses. [no]
challenges a guard to a staring contest and wins, somehow. [flex]
orders food at three in the morning and eats it with deep gratitude. [sit]
writes everyone's name on the tavern wall, spelling most of them wrong.
hugs the barkeep goodnight. The barkeep did not ask for a hug.
"One more tavern. Then bed. Then another tavern."
"Tonight we make memories. Tomorrow we try to remember them."
"Don't let me text my ex. I mean, don't let me send a letter to my ex."
"Somebody hold my drink. And my hair. And my hand."
"Best. Night. Ever. Until next week."
]])

cat("dare", "Dares and Games", "random", [[
"Truth or dare, {target}? Choose wisely."
"I dare you to kiss the next person who walks in. Unless it's the barkeep's husband."
"Never have I ever... been thrown out of this exact tavern. Oh. Wait. Drink for me."
"Spin the bottle! Whoever it lands on buys the next round!"
"I bet you five gold you can't eat that pepper without crying."
"Dare: go tell that stranger they look like a lost gnome prince."
"Arm wrestle me for the last drink. Winner takes all."
"Two truths and a lie. I've wrestled a bear, I've been married twice, and I'm sober right now."
"Dice! Highest roll picks the next song, lowest roll sings it."
"Drink every time someone says 'Leeroy'. We'll be legless by midnight."
"I dare you to sing a love song to the barkeep. With feeling."
"Strip poker? I mean strip-your-armor-for-repairs poker. Very tame. Very boring. Deal me in."
spins an empty bottle on the table and watches it slow to a stop, pointing at {target}. [point]
slaps a gold coin on the table. "Your move, {target}."
rolls a pair of dice and whoops at the result. [cheer]
eats an enormously spicy pepper on a dare and turns bright red. [gasp]
accepts a dare without hearing what it is, which is a mistake.
whispers a dare to {target}, then laughs at the look on their face. [laugh]
deals out a hand of cards with a suspicious amount of confidence.
loses a bet and has to wear a ridiculous hat for the rest of the night. [shrug]
drinks a mystery shot of something green on a dare. [gasp]
balances a coin on their nose to win a bet, and wins. [flex]
calls a bluff, and it was not a bluff. [cry]
reads {target}'s fortune from the bottom of an empty mug, very seriously.
"Your turn, {target}. Truth, or dare?"
"I've never lost a bet. I've lost a lot of money, but never a bet."
"Loser buys the next round. Winner buys the one after. Everyone wins."
"No backing out now. A dare is a dare."
"Double or nothing? Double or nothing."
]])

cat("brawl", "Bar Brawls", "e_roar", [[
"Did you just spill my drink? You spilled my drink."
"Somebody hold my ale. This won't take long."
"Take that back! Take it back or I'll make you take it back!"
"Bar fight! Bar fight!"
"I'm not angry. I'm just going to throw a chair. Calmly."
"Not the face! Anything but the face!"
"Who threw that? Who threw that mug? I'm going to find out."
"Okay, everyone, let's calm down and talk about this. That was a lie. Fight!"
"I've been in nicer fights in a monastery."
"Duck, {target}! Incoming bench!"
"Don't make me put my drink down."
"Fight's over! I won! Mostly by hiding!"
rolls up their sleeves and cracks their knuckles. [flex]
ducks as a chair flies overhead. [cower]
throws a punch, misses, and spins all the way around. [shrug]
smashes a bottle on the bar for effect, then apologizes to the barkeep.
leaps over the bar to escape a very angry dwarf.
swings from the chandelier, whooping, until it creaks ominously. [cheer]
puts someone in a headlock while finishing their drink with the other hand. [flex]
crawls under a table and keeps drinking through the whole fight. [sit]
breaks up the fight by buying everyone a round. [cheer]
gets knocked into a barrel and comes up laughing. [laugh]
dramatically shoves {target} out of the way of a flying tankard.
stands on a table and roars at the whole tavern. [roar]
"I'd like to formally apologize for the table. And the window. And the bard."
"That was fun. Same time next week?"
"Barkeep, put the damages on {target}'s tab."
"I don't remember starting that. I definitely finished it."
"My knuckles hurt, my pride is bruised, and I'd do it all again."
]])

cat("morning", "The Morning After", "e_cry", [[
"Why is the sun so loud?"
"Where am I? Why is there a goat in this room?"
"I'm never drinking again. Until tonight."
"Did I really sing on the bar? Don't tell me. I don't want to know."
"Who keeps hitting a gong inside my head?"
"My mouth tastes like a kobold's boot."
"Someone tell me why I'm wearing a lampshade and a pirate hat."
"I woke up married to a goblin. We're working it out."
"Coffee. Coffee now. Coffee forever."
"Please stop talking, {target}. Your voice is so bright."
"I found a note in my pocket that says 'don't trust the parrot'. I don't own a parrot."
"Was that tattoo there yesterday? Why does it say 'Gerald'?"
"The barkeep says I owe him forty gold and an apology to the bard."
"Every part of me hurts. Even my hair hurts."
groans and pulls a pillow over their head. [cry]
squints painfully at the morning light, shielding their eyes.
drinks an entire jug of water in one go and sighs. [sigh]
stumbles out of a closet they don't remember entering.
checks their pockets and finds a cheese wheel, a stranger's ring and a note. [shrug]
lies very still on the floor, staring at the ceiling, contemplating life. [sit]
whispers "never again" to nobody in particular.
discovers they're wearing someone else's boots. [gasp]
eats an enormous, greasy breakfast with the focus of a holy ritual. [sit]
winces at every footstep in the tavern. [cower]
counts the remaining coins in their purse and quietly weeps. [cry]
flinches as {target} opens the curtains. [cower]
"What happened last night? Actually, no. Let it stay a mystery."
"Remind me of this moment the next time I order shots."
"I need a healer. Not for wounds. For regret."
"Did anyone get my good side in the portrait? Did I have a good side?"
"Same time tonight?"
]])
