-- StoryCaster lore library: further scenes for the professions and holidays.
local ADDON, ns = ...
local R = ns.R
R.LORE_MORE = R.LORE_MORE or {}
local function add(kind, k, s)
  R.LORE_MORE[kind] = R.LORE_MORE[kind] or {}
  R.LORE_MORE[kind][k] = (R.LORE_MORE[kind][k] or "") .. s
end

add("profession", "Blacksmithing", [[
## The Apprentice
waves over a nervous young apprentice and hands them the hammer. [wave]
says, "Your turn. Don't be gentle. Steel doesn't respect gentle."
watches the first clumsy blow glance off the anvil.
says, "Good! Terrible, but good. Again."
says, "The first hundred swings are for the arm. The next thousand are for the eye."
## The Mark
holds up a finished dagger and points to a tiny symbol stamped near the hilt.
says, "Every smith has a mark. This little star is mine."
says, "Years from now, someone will find this blade in a ruin and wonder who made it."
says, "I hope they think, 'Whoever it was, they knew what they were doing.'"
## Burns
holds out forearms crisscrossed with old, pale burn scars.
says, "Every one of these is a lesson. This one: don't reach over the forge."
says, "This one: don't trust a goblin's tongs."
says, "And this one: don't show off for a pretty customer."
laughs ruefully. [laugh]
## The Grindstone
pedals the grindstone, sparks spraying in a bright fan as the edge takes shape.
says, "An edge is just two surfaces meeting in perfect agreement."
says, "Most people could learn a lot from that."
]])

add("profession", "Herbalism", [[
## The Druid
says, "Once a druid caught me picking Goldthorn in Feralas."
says, "I thought I was in trouble. Instead he showed me where three more patches grew."
says, "He said, 'You take only what you need. The forest notices that.'"
smiles at the memory.
## Drying
hangs bundles of herbs upside down from the rafters, tying each with twine.
says, "Most herbs dry best in the dark with a little breeze."
says, "My cottage smells like a meadow all year round. Visitors either love it or sneeze."
sneezes, as if on cue. [gasp]
## The Map
unfolds a hand-drawn map dotted with tiny symbols and notes.
says, "Twenty years of notes. Every patch I've ever found."
says, "Mountain Silversage on the north cliff. Dreamfoil by the old shrine."
says, "This map is worth more to me than gold. Please don't tell the other herbalists."
## Seasons
says, "Spring is for tender leaves. Summer for flowers. Autumn for roots."
says, "Winter is for drying, sorting, and drinking tea while you plan for spring."
says, "An herbalist never really stops. We just slow down with the world."
## Teaching
crouches beside {target} and points to a small blue flower. [kneel]
says, "This one. Smell it. Remember it. It will save someone's life one day."
]])

add("profession", "Fishing", [[
## The Contest
says, "Every Sunday in Booty Bay, there's a fishing contest."
says, "First one to catch the prize fish wins a pile of gold and the envy of the whole port."
says, "I came second once. Second! By four seconds. To a gnome with a mechanical rod."
shakes a fist at the sea in mock outrage.
## The Cooking
says, "Of course, the best part of fishing is eating what you catch."
says, "A little salt, a little fire, a little squeeze of lemon if you're feeling fancy."
says, "Nothing tastes better than a fish you waited three hours for."
## Weather
squints up at a sky full of dark clouds.
says, "Rain's coming. Good. Fish bite better in the rain."
says, "I'll be soaked to the bone, cold, and happy."
## The Dawn
says, "The best fishing is at dawn. Mist on the water, birds just waking up."
says, "Everyone else in the world is still asleep. It feels like the lake is yours alone."
breathes in the cool morning air deeply. [sigh]
## The Teaching
hands {target} a spare rod with a gentle smile.
says, "Here. Hold it loose, like a cup of tea. Flick from the wrist."
says, "Don't worry if you only catch boots. Everyone starts with boots."
says, "Welcome to the waiting. You'll love it."
]])

add("profession", "Alchemy", [[
## The Lab Notes
pulls out a thick notebook covered in smudges and scorch marks.
says, "Every alchemist keeps notes. Every reaction, every color, every disaster."
flips to a page marked with a large, angry red X.
says, "This one turned my cat green for a week. He forgave me. Eventually."
## Flasks
holds up a gleaming flask that swirls with silver light.
says, "Flasks are the pinnacle. They last for hours, even through death."
says, "Raiders line up outside my door every week for these."
says, "I could charge a fortune. I mostly charge in good stories."
## Smells
sniffs a bubbling vial and wrinkles their nose.
says, "Some potions smell like roses. Some smell like a troll's boot."
says, "The troll's boot ones work better. I don't know why. Nobody does."
## The Rival
says, "There's an alchemist in the next town who swears her mana potions are better than mine."
says, "Every year we have a contest. Every year it ends in a tie and a small fire."
chuckles. [chuckle]
says, "I'd miss her if she ever retired."
## The Gift
presses a small red vial into {target}'s hand.
says, "Keep that. Just in case. You never know when a bad day will find you."
]])

add("profession", "Tailoring", [[
## The Shop
gestures proudly around a small shop hung with robes, cloaks, and colorful scarves.
says, "Every piece in here was made by hand. These two hands."
says, "My fingers are covered in needle pricks. My heart is covered in thread."
says, "That sounded better in my head. But it's true."
## Measurements
pulls out a long measuring tape and approaches {target} with a professional look.
says, "Hold still. Arms out. I'll just get a few quick measurements."
measures quickly, humming to themselves.
says, "Hmm. You'd look lovely in a deep green. Trust me on this."
## The Disaster
says, "Once a warrior asked me to make him a robe. A warrior. In a robe."
says, "He wanted to look 'mysterious.' I tried my best. He looked like a very muscular curtain."
laughs. [laugh]
says, "He loved it. Wore it to every raid. That's what matters."
## Dyes
lines up little pots of dye: crimson, sapphire, forest green, deep violet.
says, "Color is the soul of a garment. Choose wrong and even silk looks sad."
says, "These come from flowers, berries, and one very confused octopus."
]])

add("profession", "Engineering", [[
## The Blueprint
unrolls a huge, tattered blueprint covered in scribbles, arrows, and crossed-out ideas.
says, "This is the plan. Or at least, the plan for the plan."
points at a large circle in the middle labeled with a question mark.
says, "And this is where the magic happens. I'll figure it out later."
## The Robot
says, "I once built a robot to do my chores. Sweep, wash dishes, fold laundry."
says, "It decided the best way to clean the house was to throw everything outside."
says, "It wasn't wrong. But it wasn't right either."
## Safety
taps the goggles hanging around their neck.
says, "These have saved my eyes eleven times. I've counted."
says, "Twelve if you count the time the soup exploded. That was cooking, not engineering. Same rules apply."
## The Dream Machine
says, "One day I'll build a flying ship with room for the whole guild."
says, "Big engines, a little galley, a deck for watching sunsets."
says, "Mostly I want the sunsets. The engines are just how you get there."
gazes upward with a faraway smile.
## Teaching
hands {target} a small wrench.
says, "Here. Every engineer needs one. Now we're practically colleagues."
]])

add("profession", "Cooking", [[
## The Market
browses a market stall, sniffing melons and squeezing peaches.
says, "Shopping is half of cooking. You can't make good food from sad vegetables."
holds up a plump tomato with satisfaction.
says, "This one. This one has dreams."
## The Kitchen Disaster
says, "My first time cooking for my family, I made Crispy Bat Wing."
says, "I didn't know you were supposed to cook it until it stopped twitching."
shudders. [cower]
says, "We had bread that night. Just bread."
## Comfort Food
says, "Every culture has its comfort food. Dwarves have their stew. Pandaren have dumplings."
says, "Trolls have something spicy enough to melt iron. Orcs have roast meat on a bone."
says, "And after a long day, every single one of them tastes like home."
## The Mentor
says, "I learned from an old innkeeper in Goldshire. Tiny woman, enormous ladle."
says, "She used to say, 'Food doesn't fix anything. But it helps you face it.'"
says, "I think about that every time I cook."
## The Invitation
pulls up an extra stool and pats it for {target}.
says, "Sit. Eat. Tell me about your day. The stew will keep."
]])

add("holiday", "HallowsEnd", [[
## The Haunted House
says, "Some folk turn their whole house into a haunted house for the night."
says, "Cobwebs, creaking doors, a cousin hiding in the closet with a sheet over their head."
says, "My cousin jumped out at a paladin once. The paladin blessed him. Very confusing for everyone."
laughs. [laugh]
## The Apple Bobbing
leans over a barrel of water bobbing with apples and takes a deep breath.
says, "Apple bobbing. The most dignified sport in all of Azeroth."
plunges face first into the barrel and comes up spluttering, an apple in their teeth. [cheer]
## Ghost Stories
sits by a candle and lowers their voice to a whisper. [sit]
says, "Have you heard about the ghost of Darkshire? A woman who walks the road at midnight."
says, "She asks travelers if they've seen her husband. If you say no, she weeps."
says, "If you say yes, she follows you home. So I always say 'maybe.' Safest answer."
## Sweets
says, "Hallow's End is the only time of year my dentist is busier than the healers."
]])

add("holiday", "WinterVeil", [[
## The Toy Train
sets a little wooden toy train on the floor and watches it chug around in a circle.
says, "Every Winter Veil, someone in town gets a toy train."
says, "And every Winter Veil, someone else steps on it at three in the morning."
says, "It's a tradition. A painful tradition."
## Snowmen
rolls a lumpy snowball across the ground until it's waist high.
says, "Every snowman needs a carrot nose, two coal eyes, and a sense of purpose."
plants a carrot in the middle and steps back to admire it.
says, "His name is Gerald. He guards the inn. He will melt bravely in the spring."
## The Carolers
listens as a group of carolers sings outside the tavern window.
says, "Listen to them. Terrible. Absolutely terrible."
says, "And the best thing I've heard all year."
hums along under their breath, smiling.
## The Gift Exchange
says, "This year our guild drew names for a gift exchange."
says, "I got a warrior. I made her a scarf in her colors."
says, "She cried a little. Warriors pretend they don't. They do."
]])

add("holiday", "Brewfest", [[
## The Brewmasters
watches a stout dwarf with a magnificent beard pour a tankard with great ceremony.
says, "That's a master brewer. Forty years making the same ale."
says, "Every year he says it's his best batch. Every year he's right."
says, "Brewing isn't just a craft. It's a kind of patience you can drink."
## The Barking
says, "There's a contest for who can shout 'Brewfest!' the loudest."
takes a deep breath and bellows at the top of their lungs. [roar]
says, "I think I won. I can't hear anything now, so I'll assume so."
## The Kodo Kombo
says, "The orcs have their own Brewfest stall, Drohn's Distillery."
says, "Their ale tastes like a war drum sounds."
says, "One mug and you're ready to charge a mountain. Two and you think you are a mountain."
## The Walk Home
sways a little and grins sheepishly.
says, "The walk home is always the longest part of Brewfest."
says, "It's because the road keeps moving."
## Memories
says, "My first Brewfest, I won a mug. My second, a hat. My third, a friend for life."
says, "The friend was the best prize."
raises a tankard toward {target} with a warm grin. [cheer]
says, "Here's to the next one. Same table, same friends, new brews."]])

add("holiday", "LunarFestival", [[
## The Last Lantern
holds the last lantern of the night for a long moment before letting it go.
says, "This one is for everyone I didn't get to say goodbye to."
watches it rise until it's lost among the stars. [sigh]
]])

add("holiday", "LunarFestival", [[
## The Lanterns
lights another paper lantern and hands it carefully to {target}.
says, "Here. Make a wish, then let it go."
watches the lantern drift up into the dark, glowing softly.
says, "My people say every lantern carries a message to someone who's gone."
## The Elder's Coin
holds up a small, warm coin stamped with an ancient face.
says, "A coin of ancestry. I got this one from an elder in the Barrens."
says, "The spirit told me, 'The road is long, but you are never walking it alone.'"
tucks the coin away carefully. [bow]
## The Dance
starts a slow, graceful dance under the moonlight. [dance]
says, "The old dance of the Lunar Festival. Slow steps, wide arms, like the moon moving across the sky."
says, "My grandmother danced it every year until she was a hundred and three."
## Cleaning
says, "Before the festival, you clean your whole house. Sweep out the old year."
says, "Every speck of dust is a bad memory. Out it goes."
says, "My house is very clean this year. It was a hard year."
## Starlight
says, "The stars are brighter during the Lunar Festival. Or maybe we just look up more."
]])

add("holiday", "DarkmoonFaire", [[
## The Strongman
watches a huge, muscled performer lift a barrel over his head with one hand.
says, "The strongman! Every year he lifts bigger things. Last year it was a kodo."
says, "The kodo was not pleased. It sat on him afterward."
laughs. [laugh]
## The Cannon
says, "You can get shot out of a cannon at the Faire."
says, "They shoot you over the water, and you try to land in the target."
says, "I landed in the target! Then I landed in the water. Then I landed in the infirmary."
## The Pet Battles
says, "The Faire has pet battles too. Little critters squaring off against each other."
says, "My squirrel lost to a very determined turtle. He still won't talk about it."
## Darkmoon Cards
fans out a handful of strange, beautiful cards.
says, "Darkmoon Cards. Collect a whole deck, turn it in, and get something powerful."
says, "I'm one card short. Always one card short. Every single month."
## The Ferris Wheel
gazes up at the great wheel turning slowly against the stars.
says, "From the top of the wheel, you can see the whole island lit up below."
says, "It's the most beautiful thing. Shame about the smell of fried cheese drifting up."
]])
