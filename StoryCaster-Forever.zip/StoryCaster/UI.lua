-- StoryCaster: the panel (player, timer, animated emote buttons), the script menu and the writing window.
local ADDON, ns = ...
local R = ns.R
local WHITE = "Interface\\Buttons\\WHITE8X8"
local FONT = "Fonts\\FRIZQT__.TTF"
local ACCENT = { 0.71, 0.55, 1.0 }

---------------------------------------------------------------------------
-- Little building blocks
---------------------------------------------------------------------------
local function Grad(tex, a, b, alpha)
  tex:SetTexture(WHITE)
  if tex.SetGradient and CreateColor then
    if pcall(tex.SetGradient, tex, "VERTICAL", CreateColor(a[1], a[2], a[3], alpha or 1), CreateColor(b[1], b[2], b[3], alpha or 1)) then return end
  end
  tex:SetVertexColor(b[1], b[2], b[3], alpha or 1)
end

local function Edge(f, r, g, b, a)
  f.edges = f.edges or {}
  local spec = { { "TOPLEFT", "TOPRIGHT", nil, 1 }, { "BOTTOMLEFT", "BOTTOMRIGHT", nil, 1 }, { "TOPLEFT", "BOTTOMLEFT", 1 }, { "TOPRIGHT", "BOTTOMRIGHT", 1 } }
  for i, p in ipairs(spec) do
    local t = f.edges[i]
    if not t then
      t = f:CreateTexture(nil, "BORDER")
      t:SetPoint(p[1]); t:SetPoint(p[2])
      if p[3] then t:SetWidth(p[3]) end
      if p[4] then t:SetHeight(p[4]) end
      f.edges[i] = t
    end
    t:SetColorTexture(r, g, b, a or 1)
  end
end

local function Glass(f, alpha)
  local bg = f:CreateTexture(nil, "BACKGROUND")
  bg:SetAllPoints()
  Grad(bg, { 0.03, 0.02, 0.06 }, { 0.10, 0.07, 0.17 }, alpha or 0.94)
  Edge(f, 0.42, 0.33, 0.62, 1)
  local rule = f:CreateTexture(nil, "ARTWORK")
  rule:SetPoint("TOPLEFT", 1, -1); rule:SetPoint("TOPRIGHT", -1, -1); rule:SetHeight(2)
  rule:SetColorTexture(ACCENT[1], ACCENT[2], ACCENT[3], 0.9)
end

local function Text(parent, size, r, g, b, flags)
  local fs = parent:CreateFontString(nil, "OVERLAY")
  fs:SetFont(FONT, size, flags or "")
  fs:SetTextColor(r or 1, g or 1, b or 1)
  fs:SetJustifyH("LEFT")
  return fs
end

local function Tip(w, title, body)
  w:SetScript("OnEnter", function(self)
    GameTooltip:SetOwner(self, "ANCHOR_TOP")
    GameTooltip:SetText(title, 1, 0.85, 0.4)
    if body then GameTooltip:AddLine(body, 0.9, 0.9, 0.9, true) end
    GameTooltip:Show()
  end)
  w:SetScript("OnLeave", function() GameTooltip:Hide() end)
end

-- a flat button with a label; kind: "primary" (accent), "emote", or plain
local function Btn(parent, label, w, h, onClick, kind)
  local b = CreateFrame("Button", nil, parent)
  b:SetSize(w, h)
  b.bg = b:CreateTexture(nil, "BACKGROUND")
  b.bg:SetAllPoints()
  b.hl = b:CreateTexture(nil, "HIGHLIGHT")
  b.hl:SetAllPoints()
  b.hl:SetColorTexture(1, 1, 1, 0.12)
  b.text = Text(b, h >= 24 and 11 or 10, 1, 1, 1)
  b.text:SetPoint("CENTER")
  b.text:SetJustifyH("CENTER")
  b.text:SetText(label)
  function b:Kind(k)
    if k == "primary" then Grad(self.bg, { 0.35, 0.20, 0.62 }, { 0.58, 0.40, 0.95 }); Edge(self, 0.85, 0.75, 1, 1)
    elseif k == "on" then Grad(self.bg, { 0.12, 0.35, 0.18 }, { 0.20, 0.55, 0.28 }); Edge(self, 0.5, 0.95, 0.6, 1)
    elseif k == "emote" then Grad(self.bg, { 0.10, 0.07, 0.18 }, { 0.20, 0.14, 0.32 }); Edge(self, 0.45, 0.36, 0.68, 1)
    else Grad(self.bg, { 0.08, 0.06, 0.13 }, { 0.15, 0.12, 0.22 }); Edge(self, 0.36, 0.30, 0.50, 1) end
  end
  b:Kind(kind)
  b:SetScript("OnMouseDown", function(self) self.text:SetPoint("CENTER", 1, -1) end)
  b:SetScript("OnMouseUp", function(self) self.text:SetPoint("CENTER", 0, 0) end)
  b:SetScript("OnClick", onClick)
  return b
end

local function Bar(parent, w, h, r, g, b)
  local sb = CreateFrame("StatusBar", nil, parent)
  sb:SetSize(w, h)
  sb:SetStatusBarTexture(WHITE)
  sb:SetStatusBarColor(r, g, b)
  sb:SetMinMaxValues(0, 1)
  sb:SetValue(0)
  local bg = sb:CreateTexture(nil, "BACKGROUND")
  bg:SetAllPoints()
  bg:SetColorTexture(1, 1, 1, 0.08)
  return sb
end

---------------------------------------------------------------------------
-- The panel
---------------------------------------------------------------------------
local PW, PH = 470, 286

function R:BuildBar()
  local p = CreateFrame("Frame", "StoryCasterPanel", UIParent)
  p:SetSize(PW, PH)
  if self.db.barPoint then local t = self.db.barPoint; p:SetPoint(t[1], UIParent, t[2], t[3], t[4])
  else p:SetPoint("TOP", 0, -110) end
  p:SetFrameStrata("MEDIUM")
  p:SetClampedToScreen(true)
  p:SetMovable(true)
  p:EnableMouse(true)
  p:RegisterForDrag("LeftButton")
  p:SetScript("OnDragStart", p.StartMoving)
  p:SetScript("OnDragStop", function(f)
    f:StopMovingOrSizing()
    local a, _, b, x, y = f:GetPoint()
    R.db.barPoint = { a, b, x, y }
  end)
  Glass(p)

  -- a soft light that flares on every emote
  p.flare = p:CreateTexture(nil, "ARTWORK")
  p.flare:SetPoint("TOPLEFT", 1, -3); p.flare:SetPoint("TOPRIGHT", -1, -3); p.flare:SetHeight(60)
  Grad(p.flare, ACCENT, ACCENT, 1)
  if p.flare.SetGradient and CreateColor then pcall(p.flare.SetGradient, p.flare, "VERTICAL", CreateColor(ACCENT[1], ACCENT[2], ACCENT[3], 0), CreateColor(ACCENT[1], ACCENT[2], ACCENT[3], 0.35)) end
  p.flare:SetBlendMode("ADD")
  p.flare:SetAlpha(0)
  local fa = p.flare:CreateAnimationGroup()
  local a1 = fa:CreateAnimation("Alpha"); a1:SetFromAlpha(0); a1:SetToAlpha(1); a1:SetDuration(0.12); a1:SetOrder(1)
  local a2 = fa:CreateAnimation("Alpha"); a2:SetFromAlpha(1); a2:SetToAlpha(0); a2:SetDuration(1.2); a2:SetOrder(2)
  p.flareAnim = fa

  -- header
  local head = Text(p, 13, 0.85, 0.78, 1, "OUTLINE")
  head:SetPoint("TOPLEFT", 14, -10)
  head:SetText("StoryCaster")
  p.title = Text(p, 12, 1, 0.85, 0.4)
  p.title:SetPoint("TOPLEFT", 14, -30)
  p.title:SetWidth(PW - 140)
  if p.title.SetWordWrap then p.title:SetWordWrap(false) end
  p.sub = Text(p, 10, 0.75, 0.72, 0.85)
  p.sub:SetPoint("TOPRIGHT", -14, -32)
  p.sub:SetJustifyH("RIGHT")
  local close = Btn(p, "x", 18, 18, function() R.db.showBar = false; R:Refresh(); R:Print("Panel hidden. /story brings it back.") end)
  close:SetPoint("TOPRIGHT", -6, -6)
  Tip(close, "Hide the panel", "/story brings it back. A script that is playing keeps going.")

  p.progress = Bar(p, PW - 28, 5, 1, 0.82, 0.35)
  p.progress:SetPoint("TOPLEFT", 14, -48)
  p.preview = Text(p, 11, 0.86, 0.84, 0.95)
  p.preview:SetPoint("TOPLEFT", 14, -58)
  p.preview:SetWidth(PW - 28)
  p.preview:SetHeight(30)
  p.preview:SetJustifyV("TOP")
  p.countdown = Bar(p, PW - 28, 4, ACCENT[1], ACCENT[2], ACCENT[3])
  p.countdown:SetPoint("TOPLEFT", 14, -92)

  -- controls
  local y = -104
  p.play = Btn(p, "Play", 62, 24, function() R:TogglePlay() end, "primary")
  p.play:SetPoint("TOPLEFT", 14, y)
  Tip(p.play, "Play / Pause", "Perform the chosen script, or pause it.")
  local nx = Btn(p, "Next", 52, 24, function() R:Skip() end)
  nx:SetPoint("LEFT", p.play, "RIGHT", 6, 0)
  Tip(nx, "Next", "Post the next emote right now.")
  local st = Btn(p, "Stop", 52, 24, function() R:Stop() end)
  st:SetPoint("LEFT", nx, "RIGHT", 6, 0)
  p.pick = Btn(p, "Scripts", 76, 24, function() R:ToggleMenu() end)
  p.pick:SetPoint("LEFT", st, "RIGHT", 14, 0)
  Tip(p.pick, "Your scripts", "Choose a script. Right-click one in the list to start it at once.")
  local wr = Btn(p, "Write a Script", 112, 24, function() R:ToggleWriter(true) end, "primary")
  wr:SetPoint("LEFT", p.pick, "RIGHT", 6, 0)
  Tip(wr, "Write a Script", "Paste or type your roleplay. It becomes emotes automatically.")

  -- timer
  y = -138
  p.sliderLabel = Text(p, 10, 0.85, 0.82, 0.95)
  p.sliderLabel:SetPoint("TOPLEFT", 14, y)
  local sl = CreateFrame("Slider", nil, p)
  sl:SetOrientation("HORIZONTAL")
  sl:SetSize(170, 12)
  sl:SetPoint("TOPLEFT", 14, y - 14)
  sl:SetMinMaxValues(5, 60)
  sl:SetValueStep(1)
  if sl.SetObeyStepOnDrag then sl:SetObeyStepOnDrag(true) end
  local track = sl:CreateTexture(nil, "BACKGROUND")
  track:SetPoint("LEFT"); track:SetPoint("RIGHT"); track:SetHeight(4)
  track:SetColorTexture(1, 1, 1, 0.15)
  local thumb = sl:CreateTexture(nil, "OVERLAY")
  thumb:SetColorTexture(ACCENT[1], ACCENT[2], ACCENT[3], 1)
  thumb:SetSize(10, 14)
  sl:SetThumbTexture(thumb)
  sl:EnableMouseWheel(true)
  sl:SetScript("OnMouseWheel", function(s, d) s:SetValue(s:GetValue() + d) end)
  sl:SetScript("OnValueChanged", function(_, v) if not R.building then R:SetInterval(v) end end)
  Tip(sl, "Timer", "Seconds between emotes, 5 to 60. The mouse wheel moves it one second at a time.")
  p.slider = sl
  p.dice = Btn(p, "Random", 64, 20, function() R:SetDice(not R.db.dice) end)
  p.dice:SetPoint("TOPLEFT", 196, y - 8)
  Tip(p.dice, "Random timing", "Every gap becomes a random 5 to 30 seconds. /story dice 8 20 changes the range.")
  local function toggle(label, field, x, tip)
    local b = Btn(p, label, 50, 20, function() R.db[field] = not R.db[field]; R:Refresh() end)
    b:SetPoint("TOPLEFT", x, y - 8)
    b.field = field
    Tip(b, label, tip)
    return b
  end
  p.toggles = {
    toggle("Loop", "loop", 266, "Start the script again when it ends."),
    toggle("Shuffle", "shuffle", 320, "Perform the lines in a random order."),
    toggle("Test", "testMode", 374, "Emotes print only to you, so you can rehearse."),
  }

  -- animated emote buttons
  local lbl = Text(p, 10, 0.85, 0.78, 1)
  lbl:SetPoint("TOPLEFT", 14, -178)
  lbl:SetText("ANIMATED EMOTES")
  p.animToggle = Btn(p, "Animations in scripts", 136, 16, function() R.db.animations = not R.db.animations; R:Refresh() end)
  p.animToggle:SetPoint("TOPRIGHT", -14, -175)
  Tip(p.animToggle, "Animations in scripts", "Play the animation tagged on each line ([bow]) while a script runs. The buttons below always work.")
  local cols, bw, bh, gap = 6, 70, 22, 5
  local x0 = (PW - (cols * bw + (cols - 1) * gap)) / 2
  for i = 1, 18 do
    local a = R.ANIMS[i]
    local b = Btn(p, a[2], bw, bh, function(self, button) R:Animate(a[1], true); R:Pulse(a[1]) end, "emote")
    local col, row = (i - 1) % cols, math.floor((i - 1) / cols)
    b:SetPoint("TOPLEFT", x0 + col * (bw + gap), -196 - row * (bh + gap))
    Tip(b, a[2], "Play the /" .. a[1]:lower() .. " animation. In a script, write [" .. a[1]:lower() .. "] on a line.")
  end

  p:SetScript("OnUpdate", function(f, el)
    f.acc = (f.acc or 0) + el
    if f.acc < 0.1 then return end
    f.acc = 0
    if R.state == "running" and R.nextAt and R.nextDur and R.run then
      local remain = math.max(0, R.nextAt - GetTime())
      f.countdown:SetValue(remain / R.nextDur)
      f.sub:SetText(("%d / %d   |cffc9b4ffnext in %ds|r"):format(R.run.i, #R.run.lines, math.ceil(remain)))
    end
  end)
  self.bar = p
  self:SyncSlider()
end

function R:SyncSlider()
  if not self.bar then return end
  self.building = true
  self.bar.slider:SetValue(self.db.interval)
  self.building = false
end

function R:Pulse()
  local p = self.bar
  if p and p:IsShown() then p.flareAnim:Stop(); p.flareAnim:Play() end
end

local function lineText(self, l)
  if not l then return "" end
  local t = l[1] ~= "" and (UnitName("player") .. " " .. self:Render(l[1])) or ""
  if l[2] then t = t .. (t ~= "" and "  " or "") .. "|cff9f8fff[" .. l[2]:lower() .. "]|r" end
  if l[3] then t = "|cff888888(pause " .. l[3] .. "s)|r " .. t end
  return t
end

function R:UpdateBar()
  if not self.db then return end
  if not self.db.showBar then if self.bar then self.bar:Hide() end return end
  if not self.bar then self:BuildBar() end
  local p = self.bar
  p:Show()
  local run = self.run
  local name = run and run.name or self.db.last
  local script = self:Get(name)
  p.title:SetText(name or "No script yet: press Write a Script")
  if run then
    p.progress:SetValue(run.i / #run.lines)
    if self.state == "paused" then p.sub:SetText(("%d / %d   |cffffaa00paused|r"):format(run.i, #run.lines))
    elseif self.state == "waiting" then p.sub:SetText(("%d / %d   |cffff5555holding|r"):format(run.i, #run.lines)) end
    local nxt = run.lines[run.i + 1]
    p.preview:SetText(nxt and ("|cffb48cffNext:|r " .. lineText(self, nxt)) or "|cffb48cffLast line performed.|r")
    p.play.text:SetText(self.state == "paused" and "Play" or "Pause")
    if self.state ~= "running" then p.countdown:SetValue(0) end
  else
    p.progress:SetValue(0)
    p.countdown:SetValue(0)
    p.sub:SetText(script and ("%d emotes   |cff999999ready|r"):format(#script) or "")
    p.preview:SetText(script and script[1] and ("|cffb48cffFirst:|r " .. lineText(self, script[1])) or "|cff999999Write a script, or choose one from Scripts.|r")
    p.play.text:SetText("Play")
  end
  local dice = self.db.dice
  p.sliderLabel:SetText(dice and ("|cff777777Timer: " .. self.db.interval .. "s (random is on)|r") or ("Timer: |cffffffff" .. self.db.interval .. "s|r between emotes"))
  p.slider:SetAlpha(dice and 0.4 or 1)
  p.dice:Kind(dice and "on" or nil)
  p.dice.text:SetText(dice and (self.db.diceMin .. "-" .. self.db.diceMax .. "s") or "Random")
  for _, b in ipairs(p.toggles) do b:Kind(self.db[b.field] and "on" or nil) end
  p.animToggle:Kind(self.db.animations and "on" or nil)
  if self.menu and self.menu:IsShown() then self:RefreshMenu() end
end

---------------------------------------------------------------------------
-- The script menu
---------------------------------------------------------------------------
local ROWS = 10
function R:ToggleMenu()
  if not self.menu then
    local m = CreateFrame("Frame", "StoryCasterMenu", self.bar)
    m:SetSize(250, ROWS * 22 + 34)
    m:SetPoint("TOPLEFT", self.bar.pick, "BOTTOMLEFT", 0, -4)
    m:SetFrameStrata("DIALOG")
    m:EnableMouse(true)
    m:EnableMouseWheel(true)
    Glass(m, 0.98)
    m.head = Text(m, 10, 0.85, 0.78, 1)
    m.head:SetPoint("TOPLEFT", 10, -8)
    m.offset = 0
    m.rows = {}
    for i = 1, ROWS do
      local b = Btn(m, "", 232, 20, nil)
      b:SetPoint("TOPLEFT", 9, -24 - (i - 1) * 22)
      b.text:ClearAllPoints(); b.text:SetPoint("LEFT", 8, 0); b.text:SetJustifyH("LEFT")
      b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
      b:SetScript("OnClick", function(self, button)
        if not self.name then return end
        R.db.last = self.name
        if button == "RightButton" then R:Start(self.name) end
        m:Hide(); R:Refresh()
      end)
      m.rows[i] = b
    end
    m:SetScript("OnMouseWheel", function(_, d)
      m.offset = math.max(0, math.min(math.max(0, #R.db.order - ROWS), m.offset - d))
      R:RefreshMenu()
    end)
    m:Hide()
    self.menu = m
  end
  self.menu:SetShown(not self.menu:IsShown())
  if self.menu:IsShown() then self:RefreshMenu() end
end

function R:RefreshMenu()
  local m = self.menu
  local order = self.db.order
  m.head:SetText(#order == 0 and "No scripts yet" or ("Your scripts (" .. #order .. ")  ·  right-click to start"))
  for i, b in ipairs(m.rows) do
    local name = order[i + m.offset]
    b.name = name
    if name then
      b:Show()
      b.text:SetText((name == self.db.last and "|cffffd100" or "") .. name .. "|r  |cff888888" .. #self.db.scripts[name] .. "|r")
      b:Kind(name == self.db.last and "emote" or nil)
    else b:Hide() end
  end
end

---------------------------------------------------------------------------
-- The writing window
---------------------------------------------------------------------------
local WW, WH = 520, 470
local MODES = {
  { "sentences", "One per sentence", "Each sentence becomes its own emote." },
  { "lines", "One per line", "Each line you typed becomes one emote." },
  { "fill", "Fill each emote", "Sentences are packed together up to the chat limit, a paragraph at a time." },
}

function R:ToggleWriter(show)
  if not self.writer then self:BuildWriter() end
  local w = self.writer
  if show == true or not w:IsShown() then w:Show(); self:RefreshWriter() else w:Hide() end
end

function R:BuildWriter()
  local f = CreateFrame("Frame", "StoryCasterWriter", UIParent)
  f:SetSize(WW, WH)
  f:SetPoint("CENTER", 0, 30)
  f:SetFrameStrata("DIALOG")
  f:SetToplevel(true)
  f:SetClampedToScreen(true)
  f:EnableMouse(true)
  f:SetMovable(true)
  f:RegisterForDrag("LeftButton")
  f:SetScript("OnDragStart", f.StartMoving)
  f:SetScript("OnDragStop", f.StopMovingOrSizing)
  tinsert(UISpecialFrames, "StoryCasterWriter")
  Glass(f, 0.97)

  local head = Text(f, 14, 0.85, 0.78, 1, "OUTLINE")
  head:SetPoint("TOPLEFT", 16, -12)
  head:SetText("Write a Script")
  local help = Text(f, 10, 0.80, 0.78, 0.88)
  help:SetPoint("TOPLEFT", 16, -32)
  help:SetWidth(WW - 32)
  if help.SetWordWrap then help:SetWordWrap(true) end
  help:SetText("Paste or type your roleplay (Ctrl+V). Write it after your name, the way emotes read: \"walks to the door.\" " ..
    "Put an animation anywhere in a line, like [bow] or [wave]; a line with only [nod] just plays the animation. " ..
    "{target} becomes your target's name. /pause 4 on its own line waits 4 seconds; /bow plays the bow.")
  local close = Btn(f, "x", 18, 18, function() f:Hide() end)
  close:SetPoint("TOPRIGHT", -6, -6)

  local nl = Text(f, 10, 0.85, 0.82, 0.95)
  nl:SetPoint("TOPLEFT", 16, -78)
  nl:SetText("Script name")
  local name = CreateFrame("EditBox", nil, f, "InputBoxTemplate")
  name:SetSize(260, 20)
  name:SetPoint("LEFT", nl, "RIGHT", 12, 0)
  name:SetAutoFocus(false)
  name:SetMaxLetters(48)
  name:SetScript("OnEscapePressed", function(b) b:ClearFocus() end)
  name:SetScript("OnEnterPressed", function(b) b:ClearFocus() end)
  name:SetScript("OnTabPressed", function() f.edit:SetFocus() end)
  f.name = name

  -- how the text is cut into emotes
  f.modeBtns = {}
  for i, m in ipairs(MODES) do
    local b = Btn(f, m[2], 120, 20, function() R.db.mode = m[1]; R:RefreshWriter() end)
    b:SetPoint("TOPLEFT", 16 + (i - 1) * 126, -102)
    b.mode = m[1]
    Tip(b, m[2], m[3])
    f.modeBtns[i] = b
  end
  f.auto = Btn(f, "Auto animate", 100, 20, function() R.db.autoAnim = not R.db.autoAnim; R:RefreshWriter() end)
  f.auto:SetPoint("TOPRIGHT", -16, -102)
  Tip(f.auto, "Auto animate", "Lines that say bows, waves, laughs, nods, kneels, cries, cheers and so on play that animation, even without a [tag].")

  local box = CreateFrame("Frame", nil, f)
  box:SetPoint("TOPLEFT", 16, -130)
  box:SetPoint("BOTTOMRIGHT", -16, 110)
  local bbg = box:CreateTexture(nil, "BACKGROUND")
  bbg:SetAllPoints()
  bbg:SetColorTexture(0.01, 0.01, 0.03, 0.9)
  Edge(box, 0.36, 0.30, 0.50, 1)
  local scroll = CreateFrame("ScrollFrame", "StoryCasterWriterScroll", box, "UIPanelScrollFrameTemplate")
  scroll:SetPoint("TOPLEFT", 6, -6)
  scroll:SetPoint("BOTTOMRIGHT", -26, 6)
  local edit = CreateFrame("EditBox", nil, scroll)
  edit:SetMultiLine(true)
  edit:SetAutoFocus(false)
  edit:SetFontObject(ChatFontNormal)
  edit:SetWidth(WW - 74)
  edit:SetMaxLetters(0)
  edit:SetTextInsets(4, 4, 4, 4)
  edit:SetScript("OnEscapePressed", function(b) b:ClearFocus() end)
  edit:SetScript("OnTextChanged", function(b)
    if ScrollingEdit_OnTextChanged then ScrollingEdit_OnTextChanged(b, scroll) end
    R:RefreshWriter()
  end)
  if ScrollingEdit_OnCursorChanged then edit:SetScript("OnCursorChanged", ScrollingEdit_OnCursorChanged) end
  if ScrollingEdit_OnUpdate then edit:SetScript("OnUpdate", function(b, el) ScrollingEdit_OnUpdate(b, el, scroll) end) end
  scroll:SetScrollChild(edit)
  box:EnableMouse(true)
  box:SetScript("OnMouseDown", function() edit:SetFocus() end)
  f.edit = edit

  f.status = Text(f, 10, 0.86, 0.84, 0.95)
  f.status:SetPoint("BOTTOMLEFT", 16, 72)
  f.status:SetWidth(WW - 32)
  f.status:SetHeight(32)
  f.status:SetJustifyV("TOP")
  if f.status.SetWordWrap then f.status:SetWordWrap(true) end

  local function convert() return R:Convert(f.edit:GetText(), R.db.mode, R.db.autoAnim) end
  local function save()
    local ok, msg = R:Save(f.name:GetText(), (convert()))
    R:Print(msg)
    if ok then R:Refresh() end
    return ok
  end
  local saveB = Btn(f, "Save", 70, 24, function() save() end, "primary")
  saveB:SetPoint("BOTTOMLEFT", 16, 40)
  local goB = Btn(f, "Save and Perform", 130, 24, function() if save() then f:Hide(); R:Start(R.db.last) end end, "primary")
  goB:SetPoint("LEFT", saveB, "RIGHT", 6, 0)
  local prevB = Btn(f, "Preview in Chat", 116, 24, function()
    local script = convert()
    if #script == 0 then R:Print("Nothing to preview yet.") return end
    for i, l in ipairs(script) do R:Print(("%d. %s"):format(i, lineText(R, l))) end
  end)
  prevB:SetPoint("LEFT", goB, "RIGHT", 6, 0)
  Tip(prevB, "Preview", "Shows every emote in your own chat window only.")
  local clr = Btn(f, "Clear", 60, 24, function() f.edit:SetText(""); f.name:SetText("") end)
  clr:SetPoint("BOTTOMRIGHT", -16, 40)

  local loadB = Btn(f, "Load", 60, 22, function()
    local n = f.name:GetText():gsub("^%s+", ""):gsub("%s+$", "")
    local s = R:Get(n) or R:Get(R.db.last)
    if not s then R:Print("Type the name of a saved script to load it.") return end
    if not R:Get(n) then n = R.db.last; f.name:SetText(n) end
    f.edit:SetText(R:ScriptToText(s))
    R.db.mode = "lines"
    R:RefreshWriter()
    R:Print("Loaded '" .. n .. "' for editing (one emote per line).")
  end)
  loadB:SetPoint("BOTTOMLEFT", 16, 12)
  Tip(loadB, "Load", "Load the script named above (or the one chosen on the panel) to edit it.")
  local delB = Btn(f, "Delete", 60, 22, function()
    local n = f.name:GetText():gsub("^%s+", ""):gsub("%s+$", "")
    if R:Delete(n) then R:Print("Deleted '" .. n .. "'."); R:Refresh() else R:Print("No script called '" .. n .. "'.") end
    R:RefreshWriter()
  end)
  delB:SetPoint("LEFT", loadB, "RIGHT", 6, 0)
  f.saved = Text(f, 10, 0.7, 0.68, 0.8)
  f.saved:SetPoint("LEFT", delB, "RIGHT", 12, 0)
  f:Hide()
  self.writer = f
end

function R:RefreshWriter()
  local f = self.writer
  if not f then return end
  for _, b in ipairs(f.modeBtns) do b:Kind(self.db.mode == b.mode and "on" or nil) end
  f.auto:Kind(self.db.autoAnim and "on" or nil)
  local script, split, skipped = self:Convert(f.edit:GetText(), self.db.mode, self.db.autoAnim)
  local anims = 0
  for _, l in ipairs(script) do if l[2] then anims = anims + 1 end end
  local msg = ("|cff55ff55%d emote%s|r, |cffc9b4ff%d with an animation|r"):format(#script, #script == 1 and "" or "s", anims)
  if split > 0 then msg = msg .. ("  |cffffcc00%d long piece%s split to fit chat|r"):format(split, split == 1 and "" or "s") end
  if skipped > 0 then msg = msg .. ("  |cff999999%d skipped|r"):format(skipped) end
  if script[1] then msg = msg .. "\n|cffb48cffFirst:|r " .. lineText(self, script[1]) end
  f.status:SetText(msg)
  f.saved:SetText(#self.db.order .. " saved script" .. (#self.db.order == 1 and "" or "s"))
end
