-- StoryCaster: the panel (player, timing, animated emotes, Lore Library, Ideas, More), the script and scene menus,
-- the line editor, the share window, the writing window and the Drama slide-out.
-- The look: deep navy glass in a gold frame with corner flourishes; gold accents glow and sparkle,
-- buttons light up gold and lift their icon on hover, and flash with a burst of sparkles on click.
local ADDON, ns = ...
local R = ns.R
local WHITE = "Interface\\Buttons\\WHITE8X8"
local FONT = "Fonts\\FRIZQT__.TTF"
local SERIF = "Fonts\\MORPHEUS.TTF"
local MEDIA = "Interface\\AddOns\\StoryCaster\\media\\"
local ACCENT = { 0.71, 0.55, 1.0 }
local GOLD = { 0.93, 0.76, 0.38 }
local GOLD_HI = { 1, 0.90, 0.62 }
local LAV = { 0.80, 0.72, 1.0 }

---------------------------------------------------------------------------
-- Little building blocks
---------------------------------------------------------------------------
local function Grad(tex, a, b, alpha)
  tex:SetTexture(WHITE)
  if tex.SetGradient and CreateColor then
    if pcall(tex.SetGradient, tex, "VERTICAL", CreateColor(a[1], a[2], a[3], alpha or 1), CreateColor(b[1], b[2], b[3], alpha or 1)) then return end
  end
  tex:SetVertexColor(b[1], b[2], b[3], alpha or 1)
end

local function Edge(f, r, g, b, a)
  f.edges = f.edges or {}
  local spec = { { "TOPLEFT", "TOPRIGHT", nil, 1 }, { "BOTTOMLEFT", "BOTTOMRIGHT", nil, 1 }, { "TOPLEFT", "BOTTOMLEFT", 1 }, { "TOPRIGHT", "BOTTOMRIGHT", 1 } }
  for i, p in ipairs(spec) do
    local t = f.edges[i]
    if not t then
      t = f:CreateTexture(nil, "BORDER")
      t:SetPoint(p[1]); t:SetPoint(p[2])
      if p[3] then t:SetWidth(p[3]) end
      if p[4] then t:SetHeight(p[4]) end
      f.edges[i] = t
    end
    t:SetColorTexture(r, g, b, a or 1)
  end
end

-- a horizontal gradient on a texture; false if this client cannot draw one
local function HGrad(tex, a, b)
  tex:SetTexture(WHITE)
  if tex.SetGradient and CreateColor then
    return pcall(tex.SetGradient, tex, "HORIZONTAL", CreateColor(a[1], a[2], a[3], a[4]), CreateColor(b[1], b[2], b[3], b[4]))
  end
  return false
end

-- a line of light, brightest in the middle and fading at both ends (violet, or gold with gold = true)
local function GlowLine(f, y, h, alpha, add, gold, x0, x1)
  local c = gold and GOLD or ACCENT
  local c0 = { c[1], c[2], c[3], 0 }
  local c1 = gold and { GOLD_HI[1], GOLD_HI[2], GOLD_HI[3], alpha } or { 0.92, 0.82, 1, alpha }
  local l = f:CreateTexture(nil, "ARTWORK", nil, 3)
  local r = f:CreateTexture(nil, "ARTWORK", nil, 3)
  if x0 then
    local mid = (x0 + x1) / 2
    l:SetPoint("TOPLEFT", f, "TOPLEFT", x0, y); l:SetSize(mid - x0, h)
    r:SetPoint("TOPLEFT", f, "TOPLEFT", mid, y); r:SetSize(x1 - mid, h)
  else
    l:SetPoint("TOPLEFT", f, "TOPLEFT", 1, y); l:SetPoint("TOPRIGHT", f, "TOP", 0, y); l:SetHeight(h)
    r:SetPoint("TOPLEFT", f, "TOP", 0, y); r:SetPoint("TOPRIGHT", f, "TOPRIGHT", -1, y); r:SetHeight(h)
  end
  if not (HGrad(l, c0, c1) and HGrad(r, c1, c0)) then
    l:SetColorTexture(c[1], c[2], c[3], alpha * 0.5)
    r:SetColorTexture(c[1], c[2], c[3], alpha * 0.5)
  end
  if add then l:SetBlendMode("ADD"); r:SetBlendMode("ADD") end
  return l, r
end

local function Text(parent, size, r, g, b, flags, font)
  local fs = parent:CreateFontString(nil, "OVERLAY")
  fs:SetFont(font or FONT, size, flags or "")
  fs:SetTextColor(r or 1, g or 1, b or 1)
  fs:SetJustifyH("LEFT")
  return fs
end

-- tooltips sit on top of any hover effect a frame already has
local function Tip(w, title, body)
  local function enter(self)
    GameTooltip:SetOwner(self, "ANCHOR_TOP")
    GameTooltip:SetText(title, 1, 0.85, 0.4)
    if body then GameTooltip:AddLine(body, 0.9, 0.9, 0.9, true) end
    GameTooltip:Show()
  end
  local function leave() GameTooltip:Hide() end
  if w.HookScript and w:GetScript("OnEnter") then
    w:HookScript("OnEnter", enter); w:HookScript("OnLeave", leave)
  else
    w:SetScript("OnEnter", enter); w:SetScript("OnLeave", leave)
  end
end

---------------------------------------------------------------------------
-- Sparkles: a pool of little gold stars that twinkle on the gold accents and burst from clicks
---------------------------------------------------------------------------
local FX = { pool = {}, anchors = {} }
R.FX = FX
function FX:Layer()
  if not self.layer then
    local l = CreateFrame("Frame", "StoryCasterFX", UIParent)
    l:SetFrameStrata("TOOLTIP")
    l:SetAllPoints(UIParent)
    if l.EnableMouse then l:EnableMouse(false) end
    self.layer = l
  end
  return self.layer
end

function FX:Get()
  for _, s in ipairs(self.pool) do if not s.tex.busy then return s end end
  if #self.pool >= 40 then return nil end
  local t = self:Layer():CreateTexture(nil, "OVERLAY")
  t:SetTexture(MEDIA .. "sparkle")
  t:SetBlendMode("ADD")
  t:Hide()
  local ag = t:CreateAnimationGroup()
  local a1 = ag:CreateAnimation("Alpha"); a1:SetFromAlpha(0); a1:SetToAlpha(1); a1:SetOrder(1)
  local a2 = ag:CreateAnimation("Alpha"); a2:SetFromAlpha(1); a2:SetToAlpha(0); a2:SetOrder(2)
  local rot = ag:CreateAnimation("Rotation"); rot:SetOrder(1)
  local mv = ag:CreateAnimation("Translation"); mv:SetOrder(2)
  ag:SetScript("OnFinished", function() t:Hide(); t.busy = false end)
  local s = { tex = t, ag = ag, a1 = a1, a2 = a2, rot = rot, mv = mv }
  t.busy = false
  self.pool[#self.pool + 1] = s
  return s
end

-- one sparkle at x, y from the bottom left of a region
function FX:Sparkle(region, x, y, size, color, drift)
  if not (R.db and R.db.fx ~= false) or not region then return end
  local s = self:Get()
  if not s then return end
  local t = s.tex
  t.busy = true
  t:ClearAllPoints()
  t:SetPoint("CENTER", region, "BOTTOMLEFT", x, y)
  size = size or math.random(10, 18)
  t:SetSize(size, size)
  color = color or GOLD_HI
  t:SetVertexColor(color[1], color[2], color[3], 1)
  t:SetAlpha(0)
  local d = 0.25 + math.random() * 0.25
  s.a1:SetDuration(d); s.a2:SetDuration(d * 1.6)
  s.rot:SetDegrees(math.random(2) == 1 and 90 or -90); s.rot:SetDuration(d)
  local dx, dy = 0, 0
  if drift then dx, dy = drift[1], drift[2] end
  s.mv:SetOffset(dx, dy); s.mv:SetDuration(d * 1.6)
  t:Show()
  s.ag:Stop(); s.ag:Play()
end

-- a burst of sparkles flying out from around a frame (on click)
function FX:Burst(region, n, color)
  if not region or not region.GetWidth then return end
  local w, h = region:GetWidth() or 40, region:GetHeight() or 20
  for _ = 1, n or 6 do
    local side = math.random(4)
    local x, y
    if side == 1 then x, y = math.random() * w, h elseif side == 2 then x, y = math.random() * w, 0
    elseif side == 3 then x, y = 0, math.random() * h else x, y = w, math.random() * h end
    local dx, dy = (x - w / 2) / math.max(1, w) * 28, (y - h / 2) / math.max(1, h) * 22
    self:Sparkle(region, x, y, math.random(8, 16), color, { dx, dy })
  end
end

-- the gold accents that twinkle on their own now and then: { region, width, height } (sparkles land on their edges)
function FX:Anchor(region, kind) self.anchors[#self.anchors + 1] = { region = region, kind = kind } end

function FX:Twinkle()
  if #self.anchors == 0 then return end
  local a = self.anchors[math.random(#self.anchors)]
  local r = a.region
  if not (r and r.IsVisible and r:IsVisible()) then return end
  local w, h = r:GetWidth() or 0, r:GetHeight() or 0
  if w <= 0 then return end
  if a.kind == "edge" then
    local side = math.random(4)
    if side == 1 then self:Sparkle(r, math.random() * w, h) elseif side == 2 then self:Sparkle(r, math.random() * w, 0)
    elseif side == 3 then self:Sparkle(r, 0, math.random() * h) else self:Sparkle(r, w, math.random() * h) end
  else
    self:Sparkle(r, math.random() * w, math.random() * h, math.random(8, 14))
  end
end

---------------------------------------------------------------------------
-- Frames
---------------------------------------------------------------------------
-- gold corner flourishes (one texture, flipped for each corner) that slowly glow
local function Corners(f, size, alpha)
  local spec = { { "TOPLEFT", 0, 1, 0, 1, 2, -2 }, { "TOPRIGHT", 1, 0, 0, 1, -2, -2 }, { "BOTTOMLEFT", 0, 1, 1, 0, 2, 2 }, { "BOTTOMRIGHT", 1, 0, 1, 0, -2, 2 } }
  f.corners = {}
  for i, s in ipairs(spec) do
    local t = f:CreateTexture(nil, "OVERLAY", nil, 5)
    t:SetTexture(MEDIA .. "corner")
    t:SetTexCoord(s[2], s[3], s[4], s[5])
    t:SetSize(size, size)
    t:SetPoint(s[1], s[6], s[7])
    t:SetAlpha(alpha or 1)
    local ag = t:CreateAnimationGroup()
    ag:SetLooping("BOUNCE")
    local g = ag:CreateAnimation("Alpha"); g:SetFromAlpha(0.7 * (alpha or 1)); g:SetToAlpha(alpha or 1); g:SetDuration(1.6 + i * 0.35)
    if g.SetSmoothing then g:SetSmoothing("IN_OUT") end
    ag:Play()
    f.corners[i] = t
  end
end

-- the StoryCaster glass: deep navy, a gold frame with corner flourishes, and an optional header strip
local function Glass(f, alpha, header, corner)
  local bg = f:CreateTexture(nil, "BACKGROUND")
  bg:SetAllPoints()
  Grad(bg, { 0.035, 0.045, 0.085 }, { 0.075, 0.085, 0.145 }, alpha or 0.96)
  -- a faint violet haze rising from the bottom
  local haze = f:CreateTexture(nil, "BACKGROUND", nil, 1)
  haze:SetPoint("BOTTOMLEFT", 1, 1); haze:SetPoint("BOTTOMRIGHT", -1, 1); haze:SetHeight(110)
  haze:SetTexture(WHITE)
  if haze.SetGradient and CreateColor and pcall(haze.SetGradient, haze, "VERTICAL", CreateColor(0.30, 0.14, 0.55, 0.16), CreateColor(0.30, 0.14, 0.55, 0)) then
  else haze:Hide() end
  -- the gold frame: a dark outer line, then gold, then a faint gold line inside
  Edge(f, GOLD[1] * 0.75, GOLD[2] * 0.75, GOLD[3] * 0.75, 0.95)
  local inner = CreateFrame("Frame", nil, f)
  inner:SetPoint("TOPLEFT", 4, -4); inner:SetPoint("BOTTOMRIGHT", -4, 4)
  if inner.EnableMouse then inner:EnableMouse(false) end
  Edge(inner, GOLD[1], GOLD[2], GOLD[3], 0.22)
  f.inner = inner
  Corners(f, corner or 44)
  if header then
    local hg = f:CreateTexture(nil, "BACKGROUND", nil, 3)
    hg:SetPoint("TOPLEFT", 1, -1); hg:SetPoint("TOPRIGHT", -1, -1); hg:SetHeight(header)
    hg:SetTexture(WHITE)
    if hg.SetGradient and CreateColor and pcall(hg.SetGradient, hg, "VERTICAL", CreateColor(0.10, 0.08, 0.20, 0.55), CreateColor(0.02, 0.02, 0.05, 0.85)) then
    else hg:SetVertexColor(0.02, 0.02, 0.05, 0.8) end
    GlowLine(f, -header, 1, 0.75, false, true)
  end
  FX:Anchor(f, "edge")
end

-- the button palette: background top, bottom, edge, text colour
local KINDS = {
  default = { { 0.11, 0.12, 0.20 }, { 0.07, 0.08, 0.13 }, { 0.30, 0.29, 0.44 }, { 0.92, 0.90, 0.98 } },
  primary = { { 0.25, 0.17, 0.48 }, { 0.15, 0.10, 0.32 }, { 0.62, 0.50, 0.98 }, { 0.96, 0.93, 1 } },
  on = { { 0.12, 0.30, 0.17 }, { 0.07, 0.17, 0.10 }, { 0.40, 0.85, 0.50 }, { 0.80, 1, 0.84 } },
  go = { { 0.10, 0.32, 0.15 }, { 0.05, 0.18, 0.08 }, { 0.38, 0.90, 0.46 }, { 0.72, 1, 0.76 } },
  blue = { { 0.11, 0.20, 0.44 }, { 0.06, 0.11, 0.26 }, { 0.42, 0.62, 1 }, { 0.86, 0.92, 1 } },
  stop = { { 0.42, 0.09, 0.10 }, { 0.22, 0.04, 0.05 }, { 0.95, 0.36, 0.36 }, { 1, 0.78, 0.76 } },
  key = { { 0.40, 0.29, 0.08 }, { 0.22, 0.15, 0.04 }, { 1, 0.80, 0.36 }, { 1, 0.92, 0.66 } },
  drama = { { 0.44, 0.07, 0.28 }, { 0.24, 0.03, 0.15 }, { 1, 0.48, 0.76 }, { 1, 0.84, 0.94 } },
  love = { { 0.48, 0.10, 0.22 }, { 0.26, 0.04, 0.12 }, { 1, 0.55, 0.68 }, { 1, 0.86, 0.90 } },
  war = { { 0.38, 0.10, 0.06 }, { 0.20, 0.05, 0.03 }, { 0.95, 0.55, 0.30 }, { 1, 0.84, 0.70 } },
  peace = { { 0.12, 0.32, 0.22 }, { 0.06, 0.18, 0.12 }, { 0.70, 0.95, 0.75 }, { 0.90, 1, 0.92 } },
  studio = { { 0.13, 0.09, 0.26 }, { 0.07, 0.05, 0.15 }, { 0.62, 0.50, 0.98 }, { 0.86, 0.80, 1 } },
  studioOn = { { 0.32, 0.21, 0.62 }, { 0.18, 0.11, 0.40 }, { 0.88, 0.78, 1 }, { 1, 0.96, 1 } },
  library = { { 0.06, 0.19, 0.15 }, { 0.03, 0.10, 0.08 }, { 0.38, 0.86, 0.62 }, { 0.78, 1, 0.88 } },
  libraryOn = { { 0.10, 0.38, 0.28 }, { 0.05, 0.21, 0.15 }, { 0.62, 1, 0.80 }, { 0.92, 1, 0.95 } },
  stage = { { 0.23, 0.06, 0.15 }, { 0.12, 0.03, 0.08 }, { 1, 0.50, 0.70 }, { 1, 0.82, 0.90 } },
  stageOn = { { 0.48, 0.11, 0.30 }, { 0.27, 0.05, 0.16 }, { 1, 0.74, 0.87 }, { 1, 0.95, 0.98 } },
  night = { { 0.22, 0.04, 0.26 }, { 0.08, 0.02, 0.12 }, { 1, 0.30, 0.80 }, { 1, 0.80, 0.96 } },
  pirate = { { 0.05, 0.26, 0.28 }, { 0.02, 0.13, 0.15 }, { 0.95, 0.78, 0.40 }, { 1, 0.90, 0.66 } },
  emote = { { 0.09, 0.10, 0.17 }, { 0.06, 0.07, 0.12 }, { 0.24, 0.23, 0.37 }, { 0.86, 0.84, 0.96 } },
  tab = { { 0, 0, 0 }, { 0, 0, 0 }, nil, { 0.62, 0.60, 0.70 } },
}

-- a button: label, optional icon (a file in media/), kind (see KINDS), and the gold hover, lift and click sparkle
local function Btn(parent, label, w, h, onClick, kind, icon, opts)
  local b = CreateFrame("Button", nil, parent)
  b:SetSize(w, h)
  opts = opts or {}
  b.bg = b:CreateTexture(nil, "BACKGROUND")
  b.bg:SetAllPoints()
  -- glass: a soft shine over the upper half
  b.shine = b:CreateTexture(nil, "BORDER", nil, 1)
  b.shine:SetPoint("TOPLEFT", 1, -1); b.shine:SetPoint("TOPRIGHT", -1, -1); b.shine:SetHeight(math.floor(h / 2))
  b.shine:SetTexture(WHITE)
  if b.shine.SetGradient and CreateColor and pcall(b.shine.SetGradient, b.shine, "VERTICAL", CreateColor(1, 1, 1, 0), CreateColor(1, 1, 1, 0.07)) then
  else b.shine:SetVertexColor(1, 1, 1, 0.04) end
  -- the hover glow: gold light rising from the bottom edge
  b.glow = b:CreateTexture(nil, "BORDER", nil, 2)
  b.glow:SetAllPoints()
  b.glow:SetTexture(WHITE)
  if b.glow.SetGradient and CreateColor and pcall(b.glow.SetGradient, b.glow, "VERTICAL", CreateColor(GOLD[1], GOLD[2], GOLD[3], 0.30), CreateColor(GOLD[1], GOLD[2], GOLD[3], 0.02)) then
  else b.glow:SetVertexColor(GOLD[1], GOLD[2], GOLD[3], 0.15) end
  b.glow:SetBlendMode("ADD")
  b.glow:SetAlpha(0)
  -- the click flash
  b.flash = b:CreateTexture(nil, "OVERLAY", nil, 6)
  b.flash:SetAllPoints()
  b.flash:SetColorTexture(1, 0.95, 0.8, 0.35)
  b.flash:SetBlendMode("ADD")
  b.flash:SetAlpha(0)
  local fa = b.flash:CreateAnimationGroup()
  local f1 = fa:CreateAnimation("Alpha"); f1:SetFromAlpha(1); f1:SetToAlpha(0); f1:SetDuration(0.35)
  b.flashAnim = fa
  -- the icon and the label
  local stacked = opts.stacked
  if icon then
    b.icon = b:CreateTexture(nil, "ARTWORK")
    local isz = opts.iconSize or math.floor(h * (stacked and 0.5 or 0.56))
    b.icon:SetSize(isz, isz)
    b.icon:SetTexture(MEDIA .. icon)
  end
  b.text = Text(b, opts.size or (h >= 24 and 11 or 10), 1, 1, 1)
  b.text:SetJustifyH("CENTER")
  b.text:SetText(label)
  function b:Place(dy)
    dy = (dy or 0) + (self.baseDy or 0)
    self.text:ClearAllPoints()
    if self.icon then
      self.icon:ClearAllPoints()
      if stacked then
        self.icon:SetPoint("TOP", 0, -5 + dy)
        self.text:SetPoint("BOTTOM", 0, 5)
      elseif (self.text:GetText() or "") == "" then
        self.icon:SetPoint("CENTER", 0, dy)
      else
        local tw = self.text:GetStringWidth() or 0
        local iw = self.icon:GetWidth() or 0
        local total = iw + 6 + tw
        self.icon:SetPoint("LEFT", self, "CENTER", -total / 2, dy)
        self.text:SetPoint("LEFT", self.icon, "RIGHT", 6, -dy)
      end
    else
      self.text:SetPoint("CENTER", 0, dy)
    end
  end
  local setText = b.text.SetText
  b.text.SetText = function(fs, t) setText(fs, t); b:Place() end
  function b:Kind(k)
    self.kind = k or "default"
    local c = KINDS[self.kind] or KINDS.default
    if self.kind == "tab" then
      self.bg:SetColorTexture(0, 0, 0, 0)
      self.shine:Hide()
      Edge(self, 0, 0, 0, 0)
    else
      self.shine:Show()
      Grad(self.bg, c[1], c[2], 0.95)
      Edge(self, c[3][1], c[3][2], c[3][3], 0.95)
    end
    self.base = c
    self.text:SetTextColor(c[4][1], c[4][2], c[4][3])
    if self.icon then
      local ic = (self.kind == "default" or self.kind == "emote" or self.kind == "tab") and LAV or c[4]
      self.icon:SetVertexColor(ic[1], ic[2], ic[3])
    end
  end
  b:Kind(kind)
  b:Place()
  b:SetScript("OnEnter", function(self)
    if self.IsEnabled and self:IsEnabled() == false then return end
    self.glow:SetAlpha(1)
    if self.kind ~= "tab" then Edge(self, GOLD_HI[1], GOLD_HI[2], GOLD_HI[3], 1) end
    self.text:SetTextColor(GOLD_HI[1], GOLD_HI[2], GOLD_HI[3])
    if self.icon then self.icon:SetVertexColor(GOLD_HI[1], GOLD_HI[2], GOLD_HI[3]); self:Place(2) end
    if math.random(3) == 1 then FX:Sparkle(self, math.random() * self:GetWidth(), self:GetHeight(), 10) end
  end)
  b:SetScript("OnLeave", function(self)
    self.glow:SetAlpha(0)
    self:Kind(self.kind)
    self:Place()
  end)
  b:SetScript("OnMouseDown", function(self) self:Place(-1) end)
  b:SetScript("OnMouseUp", function(self) self:Place(self:IsMouseOver() and 2 or 0) end)
  local function pop() b.flashAnim:Stop(); b.flashAnim:Play(); FX:Burst(b, opts.burst or 5) end
  b:SetScript("OnClick", function(_, ...) pop(); if onClick then onClick(b, ...) end end)
  -- SetScript("OnClick", f) later still keeps the flash and the burst
  local setScript = b.SetScript
  b.SetScript = function(self, what, fn)
    if what == "OnClick" and fn then
      return setScript(self, what, function(_, ...) pop(); fn(b, ...) end)
    end
    return setScript(self, what, fn)
  end
  return b
end

local function Bar(parent, w, h, r, g, b)
  local sb = CreateFrame("StatusBar", nil, parent)
  sb:SetSize(w, h)
  sb:SetStatusBarTexture(WHITE)
  sb:SetStatusBarColor(r, g, b)
  -- darker at the start, bright at the leading edge
  local t = sb.GetStatusBarTexture and sb:GetStatusBarTexture()
  if t and t.SetGradient and CreateColor then
    pcall(t.SetGradient, t, "HORIZONTAL", CreateColor(r * 0.45, g * 0.45, b * 0.45, 1), CreateColor(math.min(1, r * 1.15), math.min(1, g * 1.15), math.min(1, b * 1.15), 1))
  end
  sb:SetMinMaxValues(0, 1)
  sb:SetValue(0)
  local bg = sb:CreateTexture(nil, "BACKGROUND")
  bg:SetAllPoints()
  bg:SetColorTexture(1, 1, 1, 0.08)
  return sb
end

local function Section(parent, h)
  local f = CreateFrame("Frame", nil, parent)
  f:SetHeight(h)
  f:SetPoint("LEFT"); f:SetPoint("RIGHT")
  return f
end

-- a line as people read it: who, where, the words, the animation, the pause before it
function R:LineLabel(l)
  if not l then return "" end
  if l.choice or l.go then return "|cffffd100" .. self:LineToText(l) .. "|r" end
  local parts = {}
  if l.mood then parts[#parts + 1] = "|cffff9fd0(mood: " .. l.mood:lower() .. ")|r" end
  if l[3] then parts[#parts + 1] = "|cff888888(pause " .. l[3] .. "s)|r" end
  if l[5] then parts[#parts + 1] = "|cff7fd8ff[" .. l[5] .. "]|r" end
  if l[1] ~= "" then
    if l[4] then parts[#parts + 1] = "|cffffd27f" .. (self.CHANNEL_SLASH[l[4]] or "/s") .. "|r " .. self:Render(l[1])
    else parts[#parts + 1] = (l[5] or UnitName("player")) .. " " .. self:Render(l[1]) end
  end
  if l[2] then parts[#parts + 1] = "|cff9f8fff[" .. l[2]:lower() .. "]|r" end
  return table.concat(parts, " ")
end

-- the class whose crest shows beside the script title: a running Lore class set, otherwise your own
local function CrestClass(name)
  local t = name and name:match("^Lore: (.+)$")
  if t and R.LORE and R.LORE.class then
    for k, e in pairs(R.LORE.class) do if e[1] == t then return k end end
  end
  return UnitClass and select(2, UnitClass("player"))
end

---------------------------------------------------------------------------
-- The panel
---------------------------------------------------------------------------
local PW, HEAD, PAD = 540, 70, 16
local BW = math.floor((PW - PAD * 2 - 5 * 8) / 6) -- six buttons across

function R:BuildBar()
  local p = CreateFrame("Frame", "StoryCasterPanel", UIParent)
  p:SetSize(PW, 400)
  if self.db.barPoint then local t = self.db.barPoint; p:SetPoint(t[1], UIParent, t[2], t[3], t[4])
  else p:SetPoint("TOP", 0, -100) end
  p:SetFrameStrata("MEDIUM")
  p:SetClampedToScreen(true)
  p:SetMovable(true)
  p:EnableMouse(true)
  p:RegisterForDrag("LeftButton")
  p:SetScript("OnDragStart", p.StartMoving)
  p:SetScript("OnDragStop", function(f)
    f:StopMovingOrSizing()
    local a, _, b, x, y = f:GetPoint()
    R.db.barPoint = { a, b, x, y }
  end)
  Glass(p, nil, HEAD, 52)
  -- the panel fades and settles in when it opens
  local open = p:CreateAnimationGroup()
  local o1 = open:CreateAnimation("Alpha"); o1:SetFromAlpha(0); o1:SetToAlpha(1); o1:SetDuration(0.25)
  local o2 = open:CreateAnimation("Translation"); o2:SetOffset(0, -6); o2:SetDuration(0); o2:SetOrder(1)
  local o3 = open:CreateAnimation("Translation"); o3:SetOffset(0, 6); o3:SetDuration(0.25); o3:SetOrder(2)
  p.openAnim = open
  p:SetScript("OnShow", function(f) f.openAnim:Stop(); f.openAnim:Play() end)

  -- a soft light under the header that flares on every line. It lives in its own frame that is hidden
  -- except while the flash plays, so it can never be left behind as a bar.
  local fl = CreateFrame("Frame", nil, p)
  fl:SetPoint("TOPLEFT", 1, -HEAD - 2); fl:SetPoint("TOPRIGHT", -1, -HEAD - 2); fl:SetHeight(10)
  GlowLine(fl, 0, 10, 0.35, true, true)
  fl:Hide()
  local fa = fl:CreateAnimationGroup()
  local a1 = fa:CreateAnimation("Alpha"); a1:SetFromAlpha(0); a1:SetToAlpha(1); a1:SetDuration(0.12); a1:SetOrder(1)
  local a2 = fa:CreateAnimation("Alpha"); a2:SetFromAlpha(1); a2:SetToAlpha(0); a2:SetDuration(1.2); a2:SetOrder(2)
  fa:SetScript("OnPlay", function() fl:Show() end)
  fa:SetScript("OnFinished", function() fl:Hide() end)
  fa:SetScript("OnStop", function() fl:Hide() end)
  p.flare, p.flareAnim = fl, fa

  -- header: the logo in a slowly turning gold ring with a breathing violet glow
  local lx, ly = PAD + 30, -HEAD / 2
  local glow = p:CreateTexture(nil, "ARTWORK", nil, 1)
  glow:SetTexture(MEDIA .. "orb")
  glow:SetVertexColor(0.62, 0.40, 1, 0.9)
  glow:SetBlendMode("ADD")
  glow:SetSize(84, 84)
  glow:SetPoint("CENTER", p, "TOPLEFT", lx, ly)
  local gb = glow:CreateAnimationGroup()
  gb:SetLooping("BOUNCE")
  local g1 = gb:CreateAnimation("Alpha"); g1:SetFromAlpha(0.45); g1:SetToAlpha(1); g1:SetDuration(1.8)
  if g1.SetSmoothing then g1:SetSmoothing("IN_OUT") end
  gb:Play()
  local logo = p:CreateTexture(nil, "ARTWORK", nil, 2)
  logo:SetSize(44, 44)
  logo:SetPoint("CENTER", p, "TOPLEFT", lx, ly)
  logo:SetTexture("Interface\\AddOns\\StoryCaster\\logo")
  p.logo = logo
  local ring = p:CreateTexture(nil, "ARTWORK", nil, 3)
  ring:SetTexture(MEDIA .. "ring")
  ring:SetSize(60, 60)
  ring:SetPoint("CENTER", p, "TOPLEFT", lx, ly)
  local rg = ring:CreateAnimationGroup()
  rg:SetLooping("REPEAT")
  local r1 = rg:CreateAnimation("Rotation"); r1:SetDegrees(-360); r1:SetDuration(28)
  rg:Play()
  p.ring = ring
  local ringHit = CreateFrame("Frame", nil, p)
  ringHit:SetSize(60, 60); ringHit:SetPoint("CENTER", p, "TOPLEFT", lx, ly)
  FX:Anchor(ringHit, "edge")
  local head = Text(p, 24, 0.94, 0.92, 0.98, nil)
  head:SetPoint("LEFT", p, "TOPLEFT", PAD + 70, ly + 4)
  head:SetText("StoryCaster")
  p.head = head
  -- the gold line under the name, with a light that sweeps along it
  local ulw = 190
  local ul = CreateFrame("Frame", nil, p)
  ul:SetSize(ulw, 8)
  ul:SetPoint("TOPLEFT", p, "TOPLEFT", PAD + 62, ly - 14)
  GlowLine(ul, -3, 2, 0.95, false, true, 0, ulw)
  if ul.SetClipsChildren then
    ul:SetClipsChildren(true)
    local sw = ul:CreateTexture(nil, "OVERLAY")
    sw:SetSize(40, 6)
    sw:SetPoint("LEFT", ul, "LEFT", -44, -1)
    if not HGrad(sw, { 1, 1, 1, 0 }, { 1, 0.95, 0.8, 0.9 }) then sw:SetColorTexture(1, 1, 1, 0.4) end
    sw:SetBlendMode("ADD")
    local sa = sw:CreateAnimationGroup()
    sa:SetLooping("REPEAT")
    local m1 = sa:CreateAnimation("Translation"); m1:SetOffset(ulw + 90, 0); m1:SetDuration(1.4); m1:SetOrder(1)
    if m1.SetSmoothing then m1:SetSmoothing("IN_OUT") end
    local m2 = sa:CreateAnimation("Alpha"); m2:SetFromAlpha(1); m2:SetToAlpha(1); m2:SetDuration(3.2); m2:SetOrder(2)
    sa:Play()
  end
  FX:Anchor(ul, "fill")
  -- right side: progress, Drama, compact, close
  local close = Btn(p, "", 30, 30, function() R.db.showBar = false; R:Refresh(); R:Print("Panel hidden. /story brings it back.") end, "key", "close", { iconSize = 16 })
  close:SetPoint("RIGHT", p, "TOPRIGHT", -14, ly)
  Tip(close, "Hide the panel", "/story brings it back. A script that is playing keeps going.")
  p.close = close
  p.compactBtn = Btn(p, "", 30, 30, function() R.db.compact = not R.db.compact; R:Refresh() end, "key", "minus", { iconSize = 16 })
  p.compactBtn:SetPoint("RIGHT", close, "LEFT", -6, 0)
  Tip(p.compactBtn, "Compact mode", "Fold the panel down to its header and play controls, or open it again.")
  -- the theme bar: Drama, Pirate, Love, War, Peace, Dungeon
  self:BuildThemeBar(p)

  -- the script card: the title in gold with its crest, progress as a gold line, the next line, the countdown
  local body = Section(p, 120)
  p.body = body
  local card = CreateFrame("Frame", nil, body)
  card:SetPoint("TOPLEFT", PAD, -10); card:SetPoint("BOTTOMRIGHT", -PAD, 2)
  local cbg = card:CreateTexture(nil, "BACKGROUND")
  cbg:SetAllPoints()
  Grad(cbg, { 0.07, 0.07, 0.13 }, { 0.10, 0.10, 0.18 }, 0.85)
  Edge(card, GOLD[1], GOLD[2], GOLD[3], 0.30)
  p.card = card
  local CW = PW - PAD * 2
  p.crestRing = card:CreateTexture(nil, "ARTWORK", nil, 2)
  p.crestRing:SetTexture(MEDIA .. "ring")
  p.crestRing:SetSize(50, 50)
  p.crestRing:SetPoint("TOPRIGHT", -10, -6)
  p.crest = card:CreateTexture(nil, "ARTWORK", nil, 1)
  p.crest:SetSize(38, 38)
  p.crest:SetPoint("CENTER", p.crestRing, "CENTER")
  FX:Anchor(p.crestRing, "fill")
  -- progress and timing ("53 / 56 • next in 53s"), at the card's top right beside the crest
  p.sub = Text(card, 12, 0.74, 0.72, 0.84)
  p.sub:SetPoint("TOPRIGHT", card, "TOPRIGHT", -70, -17)
  p.sub:SetJustifyH("RIGHT")
  p.title = Text(card, 19, GOLD_HI[1], GOLD_HI[2], GOLD_HI[3], nil, SERIF)
  p.title:SetPoint("TOPLEFT", 14, -12)
  p.title:SetWidth(CW - 270)
  if p.title.SetWordWrap then p.title:SetWordWrap(false) end
  p.progress = Bar(card, CW - 90, 2, GOLD[1], GOLD[2], GOLD[3])
  p.progress:SetPoint("TOPLEFT", 14, -40)
  GlowLine(card, -41, 1, 0.5, false, true, 14, CW - 76)
  p.preview = Text(card, 12, 0.90, 0.88, 0.96)
  p.preview:SetPoint("TOPLEFT", 14, -52)
  p.preview:SetWidth(CW - 28)
  p.preview:SetHeight(36)
  p.preview:SetJustifyV("TOP")
  if p.preview.SetSpacing then p.preview:SetSpacing(4) end
  if p.preview.SetWordWrap then p.preview:SetWordWrap(true) end
  -- choose-your-path buttons, shown in place of the next line when a ?? line is reached
  p.choiceBtns = {}
  for i = 1, 4 do
    local b = Btn(card, "", 100, 28, function() R:Choose(i) end, "key", nil, { burst = 8 })
    b:Hide()
    p.choiceBtns[i] = b
  end
  p.countdown = Bar(card, CW - 28, 3, ACCENT[1], ACCENT[2], ACCENT[3])
  p.countdown:SetPoint("BOTTOMLEFT", 14, 8)

  -- Player Focus
  self:BuildFocus(p)

  -- controls: playing
  local row1 = Section(p, 46)
  p.row1 = row1
  p.play = Btn(row1, "Play", BW, 32, function() R:TogglePlay() end, "go", "play")
  p.play:SetPoint("TOPLEFT", PAD, -8)
  Tip(p.play, "Play / Pause", "Perform the chosen script, or pause it.")
  p.deliver = Btn(row1, "Deliver", BW, 32, function() R:Deliver() end, "blue", "deliver")
  p.deliver:SetPoint("LEFT", p.play, "RIGHT", 8, 0)
  Tip(p.deliver, "Deliver", "Post the next line right now. /say and /yell lines wait for this button (or your Deliver key): the game only allows them from a key press. Bind it under Key Bindings > AddOns > StoryCaster.")
  local nx = Btn(row1, "Next", BW, 32, function() R:Skip() end, nil, "next")
  nx:SetPoint("LEFT", p.deliver, "RIGHT", 8, 0)
  Tip(nx, "Next", "Skip ahead to the next line now.")
  local st = Btn(row1, "Stop", BW, 32, function() R:Stop() end, "stop", "stop")
  st:SetPoint("LEFT", nx, "RIGHT", 8, 0)
  p.pick = Btn(row1, "Scripts", BW, 32, function() R:ToggleMenu("scripts") end, nil, "scripts")
  p.pick:SetPoint("LEFT", st, "RIGHT", 8, 0)
  Tip(p.pick, "Your scripts", "Choose a script. Right-click one in the list to start it at once.")
  p.scenes = Btn(row1, "Scenes", BW, 32, function() R:ToggleMenu("scenes") end, nil, "scenes")
  p.scenes:SetPoint("LEFT", p.pick, "RIGHT", 8, 0)
  Tip(p.scenes, "Scenes", "Jump to a scene. A line like  ## Act Two  starts a scene in your script.")

  -- controls: writing
  local row2 = Section(p, 42)
  p.row2 = row2
  local W2 = { 122, 106, 88, 96, 0 }
  W2[5] = PW - PAD * 2 - 4 * 8 - W2[1] - W2[2] - W2[3] - W2[4]
  local wr = Btn(row2, "Write a Script", W2[1], 30, function() R:ToggleWriter(true) end, "primary", "write")
  wr:SetPoint("TOPLEFT", PAD, -4)
  Tip(wr, "Write a Script", "Paste or type your roleplay. It becomes lines automatically. A script a friend shared is pasted here too.")
  local ed = Btn(row2, "Edit Lines", W2[2], 30, function() R:ToggleLines(true) end, "primary", "lines")
  ed:SetPoint("LEFT", wr, "RIGHT", 8, 0)
  Tip(ed, "Edit Lines", "Every line of the chosen script as a row: start from it, test it, move it up or down, or delete it.")
  local sh = Btn(row2, "Share", W2[3], 30, function() R:Share(R.db.last) end, "primary", "share")
  sh:SetPoint("LEFT", ed, "RIGHT", 8, 0)
  Tip(sh, "Share", "Copy the chosen script as text for a friend or Discord. They paste it into Write a Script.")
  p.ambient = Btn(row2, "Ambient", W2[4], 30, function()
    if R.run and R.run.opts and R.run.opts.ambient then R:Stop() else R:Start("Ambient: Idle") end
  end, "primary", "ambient")
  p.ambient:SetPoint("LEFT", sh, "RIGHT", 8, 0)
  Tip(p.ambient, "Ambient", "A quiet loop of small idle actions in random order, every 25 to 70 seconds. Edit the 'Ambient: Idle' script to make it yours.")
  p.mood = Btn(row2, "Mood", W2[5], 30, function(b) R:OpenMoodList(b) end, "primary", "mood")
  p.mood:SetPoint("LEFT", p.ambient, "RIGHT", 8, 0)
  Tip(p.mood, "Mood", "Choose how your character feels. Every <mood> in a script becomes a phrase for that mood as the line is posted: says <mood>, \"...\" might become says through gritted teeth. Change it any time; the next line feels it. The Lore Library scripts already have <mood> in them.")

  -- timing: the label, a slider between gold diamonds with a glowing knob, and the six switches
  local timer = Section(p, 86)
  p.timer = timer
  p.sliderLabel = Text(timer, 12, 0.80, 0.78, 0.88)
  p.sliderLabel:SetPoint("TOPLEFT", PAD + 2, -14)
  -- while the panel is being built the slider's own events must not touch your timer
  -- (setting its range fires a change to the lowest value, which used to reset the timer to the minimum)
  self.building = true
  local sx = PAD + 190
  local sl = CreateFrame("Slider", nil, timer)
  sl:SetOrientation("HORIZONTAL")
  sl:SetSize(PW - sx - PAD - 22, 18)
  sl:SetPoint("TOPLEFT", sx + 11, -10)
  sl:SetMinMaxValues(R.MIN_GAP, 60)
  sl:SetValueStep(1)
  if sl.SetObeyStepOnDrag then sl:SetObeyStepOnDrag(true) end
  local track = sl:CreateTexture(nil, "BACKGROUND")
  track:SetPoint("LEFT"); track:SetPoint("RIGHT"); track:SetHeight(4)
  track:SetColorTexture(1, 1, 1, 0.12)
  for i, pt in ipairs({ "LEFT", "RIGHT" }) do
    local d = timer:CreateTexture(nil, "ARTWORK")
    d:SetTexture(MEDIA .. "diamond")
    d:SetSize(16, 16)
    d:SetPoint("CENTER", sl, pt, i == 1 and -9 or 9, 0)
    local dh = CreateFrame("Frame", nil, timer)
    dh:SetSize(16, 16); dh:SetPoint("CENTER", d, "CENTER")
    FX:Anchor(dh, "fill")
  end
  local thumb = sl:CreateTexture(nil, "OVERLAY", nil, 3)
  thumb:SetTexture(MEDIA .. "orb")
  thumb:SetVertexColor(0.86, 0.78, 1)
  thumb:SetSize(20, 20)
  sl:SetThumbTexture(thumb)
  local core = sl:CreateTexture(nil, "OVERLAY", nil, 4)
  core:SetColorTexture(0.55, 0.38, 0.95, 1)
  core:SetSize(8, 8)
  core:SetPoint("CENTER", thumb, "CENTER")
  -- the filled part of the track, and a glow around the knob that breathes
  local fill = sl:CreateTexture(nil, "ARTWORK")
  fill:SetPoint("LEFT", sl, "LEFT")
  fill:SetPoint("RIGHT", thumb, "CENTER")
  fill:SetHeight(4)
  if not HGrad(fill, { 0.30, 0.16, 0.62, 0.9 }, { 0.72, 0.56, 1, 1 }) then fill:SetColorTexture(ACCENT[1], ACCENT[2], ACCENT[3], 0.9) end
  local tg = sl:CreateTexture(nil, "ARTWORK", nil, 2)
  tg:SetSize(40, 40)
  tg:SetPoint("CENTER", thumb, "CENTER")
  tg:SetTexture(MEDIA .. "orb")
  tg:SetBlendMode("ADD")
  tg:SetVertexColor(0.66, 0.45, 1, 0.8)
  local tga = tg:CreateAnimationGroup()
  tga:SetLooping("BOUNCE")
  local t1 = tga:CreateAnimation("Alpha"); t1:SetFromAlpha(0.45); t1:SetToAlpha(1); t1:SetDuration(1.2)
  tga:Play()
  sl:EnableMouseWheel(true)
  sl:SetScript("OnMouseWheel", function(s, d) s:SetValue(s:GetValue() + d) end)
  sl:SetScript("OnEnter", function() thumb:SetSize(24, 24) end)
  sl:SetScript("OnLeave", function() thumb:SetSize(20, 20) end)
  sl:SetScript("OnValueChanged", function(_, v)
    if R.building then return end
    R:SetInterval(v)
  end)
  Tip(sl, "Timer", "Seconds between lines, " .. R.MIN_GAP .. " to 60. The mouse wheel moves it one second at a time. StoryCaster never posts lines faster than one every " .. R.MIN_GAP .. " seconds on its own, so chat never sees spam.")
  p.slider = sl
  local toggles = {
    { "Random", "dice", "random", "Every gap becomes a random 15 to 25 seconds. /story dice 15 40 changes the range." },
    { "Auto pace", "autoPace", "autopace", "Longer lines get more time: about one second for every 15 characters, plus a moment to breathe." },
    { "Manual", "manual", "manual", "No timer: every line waits for Deliver (or your Deliver key), like a teleprompter." },
    { "Loop", "loop", "loop", "Start the script again when it ends." },
    { "Shuffle", "shuffle", "shuffle", "Perform the lines in a random order (never in duets)." },
    { "Test", "testMode", "test", "Lines print only to you, so you can rehearse." },
  }
  p.toggles = {}
  for i, t in ipairs(toggles) do
    local b = Btn(timer, t[1], BW, 28, function()
      if t[2] == "dice" then R:SetDice(not R.db.dice) else R.db[t[2]] = not R.db[t[2]]; R:Refresh() end
    end, nil, t[3])
    b:SetPoint("TOPLEFT", PAD + (i - 1) * (BW + 8), -44)
    b.field = t[2]
    Tip(b, t[1], t[4])
    p.toggles[i] = b
  end

  -- the tabs: Lore Library, Animated Emotes, Ideas, More
  self:BuildTabs(p)

  -- animated emotes: three small switches, then eighteen tiles with a picture over the name
  local emo = Section(p, 198)
  p.emotes = emo
  p.animToggle = Btn(emo, "Animations in scripts", 150, 22, function() R.db.animations = not R.db.animations; R:Refresh() end)
  p.animToggle:SetPoint("TOPRIGHT", -PAD, -8)
  local all = Btn(emo, "All emotes", 104, 22, function(b) R:OpenEmoteList(b) end, "key", "search")
  all:SetPoint("RIGHT", p.animToggle, "LEFT", -8, 0)
  Tip(all, "All emotes", "Every emote in the game, with a search box. Click one to play it at your target. /story emotes opens it too.")
  p.allEmotes = all
  p.random = Btn(emo, "Random", 86, 22, function() R:RandomEmote() end, "go", "random")
  p.random:SetPoint("RIGHT", all, "LEFT", -8, 0)
  Tip(p.random, "Random emote", "Plays a random emote from every emote in the game, at your target. It rests for " .. R.RANDOM_GAP .. " seconds after each one, so chat never sees spam.")
  Tip(p.animToggle, "Animations in scripts", "Play the animation tagged on each line ([bow]) while a script runs. The buttons below always work.")
  local lbl = Text(emo, 10, 0.62, 0.60, 0.72)
  lbl:SetPoint("TOPLEFT", PAD + 2, -14)
  lbl:SetText("At your target.")
  local ICON = { WAVE = "e_wave", BOW = "e_bow", NOD = "e_nod", NO = "e_no", TALK = "e_talk", POINT = "e_point", LAUGH = "e_laugh",
    CHUCKLE = "e_chuckle", CHEER = "e_cheer", APPLAUD = "e_clap", SALUTE = "e_salute", KNEEL = "e_kneel", CRY = "e_cry",
    SHRUG = "e_shrug", DANCE = "e_dance", ROAR = "e_roar", FLEX = "e_flex", GASP = "e_gasp" }
  local th, gap = 50, 6
  p.emoteTiles = {}
  for i = 1, 18 do
    local a = R.ANIMS[i]
    local b = Btn(emo, a[2], BW, th, function() R:Animate(a[1], true); R:Pulse(a[1]) end, "emote", ICON[a[1]], { stacked = true, iconSize = 24, size = 10 })
    local col, row = (i - 1) % 6, math.floor((i - 1) / 6)
    b:SetPoint("TOPLEFT", PAD + col * (BW + 8), -38 - row * (th + gap))
    Tip(b, a[2], "Play the /" .. a[1]:lower() .. " animation. In a script, write [" .. a[1]:lower() .. "] on a line, or /" .. a[1]:lower() .. " on its own line.")
    p.emoteTiles[i] = b
  end

  -- the Lore Library, Ideas and More tabs
  self:BuildLoreSection(p)
  self:BuildIdeasSection(p)
  self:BuildMoreSection(p)
  -- the three flyouts under the player: Studio, Library, Stage
  self:BuildFlyouts(p)

  local twinkle = 0
  p:SetScript("OnUpdate", function(f, el)
    -- gold sparkles now and then on the frame, the crest, the title line and the slider's diamonds
    twinkle = twinkle - el
    if twinkle <= 0 then
      twinkle = 0.45 + math.random() * 0.9
      FX:Twinkle()
    end
    R:SlideTabLine(el)
    f.acc = (f.acc or 0) + el
    if f.acc < 0.1 then return end
    f.acc = 0
    R:RefreshRandom()
    if R.state == "running" and R.nextAt and R.nextDur and R.run then
      local remain = math.max(0, R.nextAt - GetTime())
      f.countdown:SetValue(remain / R.nextDur)
      f.sub:SetText(("|cffeec060%d / %d|r  |cffb48cff•|r  next in %ds"):format(R.run.i, #R.run.lines, math.ceil(remain)))
    end
  end)
  self.bar = p
  self.building = false
  self:SyncSlider()
  self:BuildMinimap()
end

-- The mini player and its three flyouts.
-- The player (header, script card, play controls and three toggles) is always shown. Studio, Library and Stage
-- slide down from behind it (one layer lower, so they come out from underneath), each a framed area of its own;
-- open together, they stack under the player into one console.
local FLYOUTS = {
  { "studio", "Studio", "write", "Write, edit and share scripts, the mood, Player Focus, and the timer and its switches." },
  { "library", "Library", "lore", "The Lore Library, Animated Emotes, Ideas and More." },
  { "stage", "Stage", "scenes", "Drama, Pirate, Love, War, Peace, After Dark and Dungeon." },
}
R.FLYOUTS = FLYOUTS

function R:FlyoutOpen(key)
  self.db.flyouts = type(self.db.flyouts) == "table" and self.db.flyouts or { studio = true, library = true, stage = true }
  return self.db.flyouts[key]
end

function R:SetFlyout(key, open)
  self:FlyoutOpen(key)
  if open == nil then open = not self.db.flyouts[key] end
  self.db.flyouts[key] = open and true or false
  self:Refresh()
end

function R:BuildFlyouts(p)
  -- the toggles along the bottom of the player
  local tg = Section(p, 50)
  p.toggles = tg
  local w = math.floor((PW - PAD * 2 - 2 * 8) / 3)
  local CAPTION = { studio = "Write  ·  Mood  ·  Timer", library = "Lore  ·  Emotes  ·  Ideas", stage = "Themes  ·  Drama  ·  Dungeon" }
  p.flyBtns = {}
  for i, fo in ipairs(FLYOUTS) do
    local key = fo[1]
    local b = Btn(tg, fo[2], w, 40, function() R:SetFlyout(key) end, key, fo[3], { iconSize = 17, size = 12 })
    b:SetPoint("TOPLEFT", PAD + (i - 1) * (w + 8), -4)
    b.baseDy = 6
    b:Place()
    local c = KINDS[key][3]
    -- a bright stripe across the top in the area's colour
    b.stripe = b:CreateTexture(nil, "OVERLAY", nil, 2)
    b.stripe:SetPoint("TOPLEFT", 1, -1); b.stripe:SetPoint("TOPRIGHT", -1, -1); b.stripe:SetHeight(3)
    if not HGrad(b.stripe, { c[1], c[2], c[3], 0.35 }, { c[1], c[2], c[3], 1 }) then b.stripe:SetColorTexture(c[1], c[2], c[3], 0.9) end
    -- the caption under the name
    b.caption = Text(b, 9, c[1], c[2], c[3])
    b.caption:SetPoint("BOTTOM", 0, 5)
    b.caption:SetJustifyH("CENTER")
    b.caption:SetText(CAPTION[key])
    -- a soft glow in the area's colour that breathes while it's open
    b.halo = b:CreateTexture(nil, "BACKGROUND", nil, -2)
    b.halo:SetPoint("TOPLEFT", -5, 5); b.halo:SetPoint("BOTTOMRIGHT", 5, -5)
    b.halo:SetTexture(WHITE)
    b.halo:SetVertexColor(c[1], c[2], c[3], 0.35)
    b.halo:SetBlendMode("ADD")
    local ha = b.halo:CreateAnimationGroup()
    ha:SetLooping("BOUNCE")
    local h1 = ha:CreateAnimation("Alpha"); h1:SetFromAlpha(0.25); h1:SetToAlpha(0.9); h1:SetDuration(1.3)
    if h1.SetSmoothing then h1:SetSmoothing("IN_OUT") end
    b.haloAnim = ha
    b.halo:Hide()
    b.arrow = Text(b, 10, c[1], c[2], c[3])
    b.arrow:SetPoint("TOPRIGHT", -8, -8)
    Tip(b, fo[2], fo[4] .. " Click to open or close.")
    p.flyBtns[fo[1]] = b
  end
  -- the three areas
  p.flys = {}
  for i, fo in ipairs(FLYOUTS) do
    local f = CreateFrame("Frame", "StoryCaster" .. fo[2] .. "Flyout", UIParent)
    f:SetFrameStrata("LOW")
    f:SetFrameLevel(40 - i * 10)
    f:SetWidth(PW)
    f:SetHeight(40)
    f:SetClampedToScreen(true)
    f:EnableMouse(true)
    -- dragging an area moves the whole player
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", function() p:StartMoving() end)
    f:SetScript("OnDragStop", function()
      p:StopMovingOrSizing()
      local a, _, b, x, y = p:GetPoint()
      R.db.barPoint = { a, b, x, y }
    end)
    Glass(f, nil, nil, 40)
    -- it drops down out from behind what's above it and fades in; closing tucks it back up
    local open = f:CreateAnimationGroup()
    local o0 = open:CreateAnimation("Translation"); o0:SetOffset(0, 26); o0:SetDuration(0); o0:SetOrder(1)
    local o1 = open:CreateAnimation("Translation"); o1:SetOffset(0, -26); o1:SetDuration(0.26); o1:SetOrder(2)
    if o1.SetSmoothing then o1:SetSmoothing("OUT") end
    local oa = open:CreateAnimation("Alpha"); oa:SetFromAlpha(0); oa:SetToAlpha(1); oa:SetDuration(0.26); oa:SetOrder(2)
    open:SetScript("OnFinished", function() FX:Burst(f, 4); if f.landAnim then f.landAnim:Stop(); f.landAnim:Play() end end)
    local close = f:CreateAnimationGroup()
    local c1 = close:CreateAnimation("Translation"); c1:SetOffset(0, 22); c1:SetDuration(0.18)
    if c1.SetSmoothing then c1:SetSmoothing("IN") end
    local ca = close:CreateAnimation("Alpha"); ca:SetFromAlpha(1); ca:SetToAlpha(0); ca:SetDuration(0.18)
    close:SetScript("OnFinished", function() f:Hide(); f.closing = false; R:LayoutFlyouts() end)
    f.openAnim, f.closeAnim = open, close
    -- a gold flash along the top edge as it lands
    local land = CreateFrame("Frame", nil, f)
    land:SetPoint("TOPLEFT", 1, -1); land:SetPoint("TOPRIGHT", -1, -1); land:SetHeight(8)
    GlowLine(land, 0, 3, 0.9, true, true)
    land:SetAlpha(0)
    local la = land:CreateAnimationGroup()
    local l1 = la:CreateAnimation("Alpha"); l1:SetFromAlpha(0); l1:SetToAlpha(1); l1:SetDuration(0.1); l1:SetOrder(1)
    local l2 = la:CreateAnimation("Alpha"); l2:SetFromAlpha(1); l2:SetToAlpha(0); l2:SetDuration(0.7); l2:SetOrder(2)
    f.landAnim = la
    f:Hide()
    f.open = false
    f.key = fo[1]
    p.flys[fo[1]] = f
  end
  -- move the sections into their areas
  local homes = { studio = { p.row2, p.focus, p.timer }, library = { p.tabs, p.emotes, p.lore, p.ideas, p.more }, stage = { p.themebar } }
  for key, list in pairs(homes) do
    for _, s in ipairs(list) do s:SetParent(p.flys[key]) end
  end
  p:HookScript("OnHide", function() for _, f in pairs(p.flys) do f:Hide(); f.open = false end end)
end

-- the sections each open area shows, top to bottom
function R:FlyoutSections(key)
  local p = self.bar
  if key == "studio" then return { p.row2, p.focus, p.timer } end
  if key == "stage" then return { p.themebar } end
  local tabs = { lore = p.lore, more = p.more, ideas = p.ideas }
  return { p.tabs, tabs[self.db.tab] or p.emotes }
end

-- stack the open areas under the player, each anchored to the one above
function R:LayoutFlyouts()
  local p = self.bar
  if not (p and p.flys) then return end
  local above = p
  for _, fo in ipairs(FLYOUTS) do
    local key = fo[1]
    local f = p.flys[key]
    local want = self.db.showBar and p:IsShown() and self:FlyoutOpen(key)
    -- lay out its sections (all of them hidden first, then the ones in use)
    for _, s in ipairs(key == "library" and { p.tabs, p.emotes, p.lore, p.ideas, p.more } or self:FlyoutSections(key)) do s:Hide() end
    local y = -8
    for _, s in ipairs(self:FlyoutSections(key)) do
      s:ClearAllPoints()
      s:SetPoint("TOPLEFT", f, "TOPLEFT", 0, y)
      s:SetPoint("TOPRIGHT", f, "TOPRIGHT", 0, y)
      s:Show()
      y = y - s:GetHeight()
    end
    f:SetHeight(-y + 10)
    if want then
      f:ClearAllPoints()
      f:SetPoint("TOPLEFT", above, "BOTTOMLEFT", 0, 3)
      if not f.open then
        f.open = true
        f.closing = false
        f.closeAnim:Stop()
        f:Show()
        f.openAnim:Stop(); f.openAnim:Play()
      end
      above = f
    elseif f.open then
      f.open = false
      f.closing = true
      f.openAnim:Stop()
      f.closeAnim:Stop(); f.closeAnim:Play()
      if f.closing then above = f end -- the ones below wait until it has tucked away
    end
  end
  if p.flyBtns then
    for key, b in pairs(p.flyBtns) do
      local on = self:FlyoutOpen(key)
      b:Kind(on and (key .. "On") or key)
      b.arrow:SetText(on and "^" or "v")
      if on then b.halo:Show(); if not b.haloAnim:IsPlaying() then b.haloAnim:Play() end else b.haloAnim:Stop(); b.halo:Hide() end
    end
  end
end

-- the player itself: header, script card (unless compact), play controls, toggles
function R:LayoutBar()
  local p = self.bar
  local y = -HEAD
  local compact = self.db.compact
  p.body:SetShown(not compact)
  for _, s in ipairs(compact and { p.row1, p.toggles } or { p.body, p.row1, p.toggles }) do
    s:ClearAllPoints()
    s:SetPoint("TOPLEFT", p, "TOPLEFT", 0, y)
    s:SetPoint("TOPRIGHT", p, "TOPRIGHT", 0, y)
    s:Show()
    y = y - s:GetHeight()
  end
  p:SetHeight(-y + 8)
  p.compactBtn.icon:SetTexture(MEDIA .. (compact and "more" or "minus"))
  if not self:FlyoutOpen("library") or self.db.tab ~= "lore" then if self.loreList then self.loreList:Hide() end end
  self:LayoutFlyouts()
end

function R:SyncSlider()
  if not self.bar then return end
  self.building = true
  self.bar.slider:SetValue(self.db.interval)
  self.building = false
end

function R:Pulse()
  local p = self.bar
  if p and p:IsShown() then
    p.flareAnim:Stop(); p.flare:Show(); p.flareAnim:Play()
    if p.card then FX:Burst(p.card, 3) end
  end
end

function R:UpdateBar()
  if not self.db then return end
  if not self.db.showBar then
    if self.bar then self.bar:Hide(); for _, f in pairs(self.bar.flys or {}) do f:Hide(); f.open = false end end
    return
  end
  if not self.bar then self:BuildBar() end
  local p = self.bar
  p:Show()
  self:LayoutBar()
  local run, f = self.run, self.following
  local name = run and run.name or self.db.last
  local script = self:Get(name)
  local function sub(i, n, state) return ("|cffeec060%d / %d|r  |cffb48cff•|r  %s"):format(i, n, state) end
  if f then
    p.title:SetText("Duet: " .. f.name)
    p.sub:SetText(self.pending and "|cffffd27fyour line: press Deliver|r" or ("|cff7fd8ff" .. f.mine .. " lines are yours, with " .. f.from .. "|r"))
    p.preview:SetText(self.pending and ("|cffb48cffReady:|r " .. self:LineLabel(self.pending)) or "|cffb48cffWaiting for your cue.|r")
    p.progress:SetValue(0); p.countdown:SetValue(0)
  elseif run then
    p.title:SetText(name)
    p.progress:SetValue(run.i / #run.lines)
    if self.scene and self.scene.waiting then p.sub:SetText("|cff7fd8ff" .. self:DuetWaitingText() .. "|r")
    elseif self.state == "paused" then p.sub:SetText(sub(run.i, #run.lines, "|cffffaa00paused|r"))
    elseif self.state == "waiting" then p.sub:SetText(sub(run.i, #run.lines, "|cffff5555holding|r"))
    elseif self.state == "key" then p.sub:SetText(sub(run.i, #run.lines, "|cffffd27fpress Deliver|r"))
    elseif self.state == "choice" then p.sub:SetText(sub(run.i, #run.lines, "|cffffd100choose your path|r")) end
    local nxt = run.lines[run.i + 1]
    p.preview:SetText(nxt and ("|cffb48cffNext:|r " .. self:LineLabel(nxt)) or "|cffb48cffLast line performed.|r")
    if self.state ~= "running" then p.countdown:SetValue(0) end
  else
    p.title:SetText(name or "No script yet: press Write a Script")
    p.progress:SetValue(0)
    p.countdown:SetValue(0)
    p.sub:SetText(script and ("|cffeec060%d lines|r  |cffb48cff•|r  ready"):format(#script) or "")
    p.preview:SetText(script and script[1] and ("|cffb48cffFirst:|r " .. self:LineLabel(script[1])) or "|cff999999Write a script, or choose one from Scripts.|r")
  end
  -- the crest of the class this script is about (or your own)
  local cls = CrestClass(name)
  local tc = cls and CLASS_ICON_TCOORDS and CLASS_ICON_TCOORDS[cls]
  if tc then
    p.crest:SetTexture("Interface\\TargetingFrame\\UI-Classes-Circles")
    p.crest:SetTexCoord(tc[1], tc[2], tc[3], tc[4])
    p.crest:Show(); p.crestRing:Show()
  else
    p.crest:Hide(); p.crestRing:Hide()
  end
  -- a choice waiting: its options as buttons where the next line usually shows
  local ch = self.state == "choice" and self.choice
  local n = ch and math.min(#ch, #p.choiceBtns) or 0
  local cw = PW - PAD * 2 - 28
  local bw = n > 0 and math.floor((cw - (n - 1) * 8) / n) or 0
  for i, b in ipairs(p.choiceBtns) do
    if i <= n then
      b:SetWidth(bw)
      b:ClearAllPoints()
      b:SetPoint("TOPLEFT", 14 + (i - 1) * (bw + 8), -52)
      b.text:SetText(ch[i][1])
      b:Show()
    else b:Hide() end
  end
  if n > 0 then p.preview:Hide() else p.preview:Show() end
  local playing = self.state == "running" or self.state == "waiting"
  p.play.text:SetText(playing and "Pause" or "Play")
  p.play.icon:SetTexture(MEDIA .. (playing and "pause" or "play"))
  p.deliver:Kind((self.state == "key" or self.pending) and "key" or "blue")
  local scenes = self:Scenes(script)
  p.scenes:SetAlpha(#scenes > 0 and 1 or 0.45)
  p.ambient:Kind(run and run.opts and run.opts.ambient and "on" or "primary")
  local dice = self.db.dice
  p.sliderLabel:SetText((dice or self.db.autoPace or self.db.manual) and ("|cff777777Timer: " .. self.db.interval .. "s (" .. (self.db.manual and "Manual" or dice and "Random" or "Auto pace") .. " is on)|r")
    or ("Timer: |cffb48cff" .. self.db.interval .. "s|r between lines"))
  p.slider:SetAlpha((dice or self.db.autoPace or self.db.manual) and 0.4 or 1)
  for _, b in ipairs(p.toggles) do
    b:Kind(self.db[b.field] and "primary" or nil)
    if b.field == "dice" then b.text:SetText(dice and (self.db.diceMin .. "-" .. self.db.diceMax .. "s") or "Random") end
  end
  p.animToggle:Kind(self.db.animations and "on" or nil)
  p.mood.text:SetText(self.db.mood or "Mood")
  p.mood:Kind(self.db.mood and "key" or "primary")
  self:RefreshTabs()
  if self.db.tab == "lore" then self:RefreshLore() end
  if self.db.tab == "more" then self:RefreshMore() end
  if self.db.tab == "ideas" then self:RefreshIdeas() end
  self:RefreshFocus()
  self:RefreshDrama()
  self:RefreshPirate()
  self:RefreshReactions()
  if self.menu and self.menu:IsShown() then self:RefreshMenu() end
  if self.lines and self.lines:IsShown() then self:RefreshLines() end
end

---------------------------------------------------------------------------
-- The script and scene menus
---------------------------------------------------------------------------
local ROWS = 10
function R:ToggleMenu(kind)
  if not self.menu then
    local m = CreateFrame("Frame", "StoryCasterMenu", self.bar)
    m:SetSize(270, ROWS * 24 + 38)
    m:SetFrameStrata("DIALOG")
    m:EnableMouse(true)
    m:EnableMouseWheel(true)
    Glass(m, 0.98)
    m.head = Text(m, 10, 0.85, 0.78, 1)
    m.head:SetPoint("TOPLEFT", 12, -10)
    m.offset = 0
    m.rows = {}
    for i = 1, ROWS do
      local b = Btn(m, "", 250, 22, nil)
      b:SetPoint("TOPLEFT", 10, -28 - (i - 1) * 24)
      b.text:ClearAllPoints(); b.text:SetPoint("LEFT", 8, 0); b.text:SetJustifyH("LEFT")
      b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
      b:SetScript("OnClick", function(self, button)
        if m.kind == "scenes" then
          if self.index then R:JumpTo(self.index) end
        elseif self.name then
          R.db.last = self.name
          if button == "RightButton" then R:Start(self.name) end
        end
        m:Hide(); R:Refresh()
      end)
      m.rows[i] = b
    end
    m:SetScript("OnMouseWheel", function(_, d)
      m.offset = math.max(0, math.min(math.max(0, (m.count or 0) - ROWS), m.offset - d))
      R:RefreshMenu()
    end)
    m:Hide()
    self.menu = m
  end
  local m = self.menu
  if m:IsShown() and m.kind == kind then m:Hide() return end
  m.kind, m.offset = kind, 0
  m:ClearAllPoints()
  m:SetPoint("TOPLEFT", kind == "scenes" and self.bar.scenes or self.bar.pick, "BOTTOMLEFT", 0, -4)
  m:Show()
  self:RefreshMenu()
end

function R:RefreshMenu()
  local m = self.menu
  local items = {}
  if m.kind == "scenes" then
    local script = self:Get(self.run and self.run.name or self.db.last)
    for i, s in ipairs(self:Scenes(script)) do items[i] = { label = i .. ". " .. s[2], index = s[1] } end
    m.head:SetText(#items == 0 and "No scenes. Add a line like  ## Act Two" or "Jump to a scene")
  else
    for i, n in ipairs(self.db.order) do
      items[i] = { label = (n == self.db.last and "|cffffd100" or "") .. n .. "|r  |cff888888" .. #self.db.scripts[n] .. "|r", name = n }
    end
    m.head:SetText(#items == 0 and "No scripts yet" or ("Your scripts (" .. #items .. ")  ·  right-click to start"))
  end
  m.count = #items
  for i, b in ipairs(m.rows) do
    local it = items[i + m.offset]
    b.name, b.index = it and it.name, it and it.index
    if it then b:Show(); b.text:SetText(it.label); b:Kind(it.name and it.name == self.db.last and "emote" or nil) else b:Hide() end
  end
end

---------------------------------------------------------------------------
-- The line editor
---------------------------------------------------------------------------
local LROWS = 12
function R:ToggleLines(show, name)
  if name and self:Get(name) then self.db.last = name end
  if not self.lines then self:BuildLines() end
  if show == true or not self.lines:IsShown() then self.lines.offset = 0; self.lines:Show(); self:RefreshLines() else self.lines:Hide() end
end

function R:BuildLines()
  local f = CreateFrame("Frame", "StoryCasterLines", UIParent)
  f:SetSize(600, LROWS * 28 + 92)
  f:SetPoint("CENTER", 0, 20)
  f:SetFrameStrata("DIALOG")
  f:SetToplevel(true)
  f:SetClampedToScreen(true)
  f:EnableMouse(true)
  f:EnableMouseWheel(true)
  f:SetMovable(true)
  f:RegisterForDrag("LeftButton")
  f:SetScript("OnDragStart", f.StartMoving)
  f:SetScript("OnDragStop", f.StopMovingOrSizing)
  tinsert(UISpecialFrames, "StoryCasterLines")
  Glass(f, 0.97, 40)
  f.head = Text(f, 13, 0.88, 0.80, 1, "OUTLINE")
  f.head:SetPoint("LEFT", f, "TOPLEFT", 16, -20)
  local close = Btn(f, "x", 20, 20, function() f:Hide() end)
  close:SetPoint("RIGHT", f, "TOPRIGHT", -10, -20)
  f.help = Text(f, 10, 0.75, 0.72, 0.85)
  f.help:SetPoint("BOTTOMLEFT", 16, 14)
  f.help:SetWidth(568)
  f.help:SetText("Start begins the script at that line. Test prints it to you only. Up and down move it; x deletes it. Write a Script edits the words.")
  f.rows = {}
  local function script() return R:Get(R.db.last) end
  for i = 1, LROWS do
    local row = CreateFrame("Frame", nil, f)
    row:SetSize(568, 24)
    row:SetPoint("TOPLEFT", 16, -52 - (i - 1) * 28)
    local bg = row:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(1, 1, 1, i % 2 == 0 and 0.04 or 0.02)
    row.num = Text(row, 10, 0.6, 0.58, 0.7)
    row.num:SetPoint("LEFT", 4, 0)
    row.num:SetWidth(26)
    row.text = Text(row, 10, 0.9, 0.88, 0.96)
    row.text:SetPoint("LEFT", 32, 0)
    row.text:SetWidth(360)
    if row.text.SetWordWrap then row.text:SetWordWrap(false) end
    local function act(fn) return function() local s = script(); local n = row.index; if s and n and s[n] then fn(s, n) end end end
    local bStart = Btn(row, "Start", 46, 20, act(function(_, n) f:Hide(); R:Start(R.db.last, n) end), "primary")
    bStart:SetPoint("RIGHT", -128, 0)
    local bTest = Btn(row, "Test", 40, 20, act(function(s, n)
      local was = R.db.testMode; R.db.testMode = true; R:Perform(s[n]); R.db.testMode = was
    end))
    bTest:SetPoint("LEFT", bStart, "RIGHT", 4, 0)
    local bUp = Btn(row, "^", 22, 20, act(function(s, n) if n > 1 then s[n], s[n - 1] = s[n - 1], s[n]; R:Refresh() end end))
    bUp:SetPoint("LEFT", bTest, "RIGHT", 4, 0)
    local bDown = Btn(row, "v", 22, 20, act(function(s, n) if n < #s then s[n], s[n + 1] = s[n + 1], s[n]; R:Refresh() end end))
    bDown:SetPoint("LEFT", bUp, "RIGHT", 4, 0)
    local bDel = Btn(row, "x", 22, 20, act(function(s, n)
      if R.run and R.run.name == R.db.last then R:Print("Stop the script before deleting lines.") return end
      if #s == 1 then R:Print("A script needs at least one line. Delete the whole script with /story delete.") return end
      table.remove(s, n); R:Refresh()
    end))
    bDel:SetPoint("LEFT", bDown, "RIGHT", 4, 0)
    Tip(bDel, "Delete this line")
    f.rows[i] = row
  end
  f:SetScript("OnMouseWheel", function(_, d)
    local s = R:Get(R.db.last)
    f.offset = math.max(0, math.min(math.max(0, (s and #s or 0) - LROWS), f.offset - d * 3))
    R:RefreshLines()
  end)
  f.offset = 0
  f:Hide()
  self.lines = f
end

function R:RefreshLines()
  local f = self.lines
  local s = self:Get(self.db.last)
  f.head:SetText(s and ("Edit Lines: " .. self.db.last .. "  |cff888888" .. #s .. " lines, scroll for more|r") or "Edit Lines: choose a script first")
  for i, row in ipairs(f.rows) do
    local n = i + f.offset
    local l = s and s[n]
    row.index = l and n
    if l then
      row:Show()
      row.num:SetText(n .. ".")
      row.text:SetText((l[6] and ("|cffffd100## " .. l[6] .. "|r  ") or "") .. self:LineLabel(l))
    else row:Hide() end
  end
end

---------------------------------------------------------------------------
-- Sharing
---------------------------------------------------------------------------
function R:Share(name)
  local s = self:Get(name)
  if not s then self:Print("Choose a script to share first.") return end
  if not self.share then
    local f = CreateFrame("Frame", "StoryCasterShare", UIParent)
    f:SetSize(520, 360)
    f:SetPoint("CENTER", 0, 30)
    f:SetFrameStrata("DIALOG")
    f:SetToplevel(true)
    f:EnableMouse(true)
    f:SetMovable(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", f.StartMoving)
    f:SetScript("OnDragStop", f.StopMovingOrSizing)
    tinsert(UISpecialFrames, "StoryCasterShare")
    Glass(f, 0.97, 40)
    f.head = Text(f, 13, 0.88, 0.80, 1, "OUTLINE")
    f.head:SetPoint("LEFT", f, "TOPLEFT", 16, -20)
    local close = Btn(f, "x", 20, 20, function() f:Hide() end)
    close:SetPoint("RIGHT", f, "TOPRIGHT", -10, -20)
    local help = Text(f, 10, 0.80, 0.78, 0.88)
    help:SetPoint("TOPLEFT", 16, -52)
    help:SetWidth(488)
    if help.SetSpacing then help:SetSpacing(3) end
    help:SetText("It is already selected: press Ctrl+C to copy, then paste it to a friend, into Discord or a document. " ..
      "To use a shared script: open Write a Script, paste it, name it and press Save.")
    local box = CreateFrame("Frame", nil, f)
    box:SetPoint("TOPLEFT", 16, -88)
    box:SetPoint("BOTTOMRIGHT", -16, 16)
    local bbg = box:CreateTexture(nil, "BACKGROUND")
    bbg:SetAllPoints()
    bbg:SetColorTexture(0.01, 0.01, 0.03, 0.9)
    Edge(box, 0.36, 0.30, 0.50, 1)
    local scroll = CreateFrame("ScrollFrame", "StoryCasterShareScroll", box, "UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", 6, -6)
    scroll:SetPoint("BOTTOMRIGHT", -26, 6)
    local edit = CreateFrame("EditBox", nil, scroll)
    edit:SetMultiLine(true)
    edit:SetAutoFocus(false)
    edit:SetFontObject(ChatFontNormal)
    edit:SetWidth(452)
    edit:SetScript("OnEscapePressed", function() f:Hide() end)
    edit:SetScript("OnTextChanged", function(b, user) if user then b:SetText(f.textValue or ""); b:HighlightText() end end)
    scroll:SetScrollChild(edit)
    f.edit = edit
    self.share = f
  end
  local f = self.share
  f.head:SetText("Share: " .. name)
  f.textValue = "-- StoryCaster script: " .. name .. "\n" .. self:ScriptToText(s)
  f:Show()
  f.edit:SetText(f.textValue)
  f.edit:SetFocus()
  f.edit:HighlightText()
end

---------------------------------------------------------------------------
-- The writing window
---------------------------------------------------------------------------
local WW, WH = 540, 520
local MODES = {
  { "sentences", "One per sentence", "Each sentence becomes its own line." },
  { "lines", "One per line", "Each line you typed becomes one line." },
  { "fill", "Fill each emote", "Sentences are packed together up to the chat limit, a paragraph at a time." },
}

function R:ToggleWriter(show)
  if not self.writer then self:BuildWriter() end
  local w = self.writer
  if show == true or not w:IsShown() then w:Show(); self:RefreshWriter() else w:Hide() end
end

function R:BuildWriter()
  local f = CreateFrame("Frame", "StoryCasterWriter", UIParent)
  f:SetSize(WW, WH)
  f:SetPoint("CENTER", 0, 30)
  f:SetFrameStrata("DIALOG")
  f:SetToplevel(true)
  f:SetClampedToScreen(true)
  f:EnableMouse(true)
  f:SetMovable(true)
  f:RegisterForDrag("LeftButton")
  f:SetScript("OnDragStart", f.StartMoving)
  f:SetScript("OnDragStop", f.StopMovingOrSizing)
  tinsert(UISpecialFrames, "StoryCasterWriter")
  Glass(f, 0.97, 40)

  local head = Text(f, 14, 0.88, 0.80, 1, "OUTLINE")
  head:SetPoint("LEFT", f, "TOPLEFT", 16, -20)
  head:SetText("Write a Script")
  local close = Btn(f, "x", 20, 20, function() f:Hide() end)
  close:SetPoint("RIGHT", f, "TOPRIGHT", -10, -20)
  local help = Text(f, 10, 0.80, 0.78, 0.88)
  help:SetPoint("TOPLEFT", 16, -52)
  help:SetWidth(WW - 32)
  if help.SetWordWrap then help:SetWordWrap(true) end
  if help.SetSpacing then help:SetSpacing(3) end
  help:SetText("Paste or type your roleplay (Ctrl+V), written after your name the way emotes read: \"walks to the door.\" " ..
    "[bow] plays an animation. /pause 4 waits. /s, /y, /p, /ra or /g lines are said in that chat. [Name] at the start gives a line to a duet partner. " ..
    "## Act Two starts a scene. {target} {name} {zone} {time} fill themselves in, {smiles|grins} picks one, and <mood> takes the mood chosen on the panel.")

  local nl = Text(f, 10, 0.85, 0.82, 0.95)
  nl:SetPoint("TOPLEFT", 16, -122)
  nl:SetText("Script name")
  local name = CreateFrame("EditBox", nil, f, "InputBoxTemplate")
  name:SetSize(270, 20)
  name:SetPoint("LEFT", nl, "RIGHT", 12, 0)
  name:SetAutoFocus(false)
  name:SetMaxLetters(48)
  name:SetScript("OnEscapePressed", function(b) b:ClearFocus() end)
  name:SetScript("OnEnterPressed", function(b) b:ClearFocus() end)
  name:SetScript("OnTabPressed", function() f.edit:SetFocus() end)
  f.name = name

  f.modeBtns = {}
  for i, m in ipairs(MODES) do
    local b = Btn(f, m[2], 124, 22, function() R.db.mode = m[1]; R:RefreshWriter() end)
    b:SetPoint("TOPLEFT", 16 + (i - 1) * 130, -148)
    b.mode = m[1]
    Tip(b, m[2], m[3])
    f.modeBtns[i] = b
  end
  f.auto = Btn(f, "Auto animate", 104, 22, function() R.db.autoAnim = not R.db.autoAnim; R:RefreshWriter() end)
  f.auto:SetPoint("TOPRIGHT", -16, -148)
  Tip(f.auto, "Auto animate", "Lines that say bows, waves, laughs, nods, kneels, cries, cheers and so on play that animation, even without a [tag].")

  local box = CreateFrame("Frame", nil, f)
  box:SetPoint("TOPLEFT", 16, -182)
  box:SetPoint("BOTTOMRIGHT", -16, 118)
  local bbg = box:CreateTexture(nil, "BACKGROUND")
  bbg:SetAllPoints()
  bbg:SetColorTexture(0.01, 0.01, 0.03, 0.9)
  Edge(box, 0.36, 0.30, 0.50, 1)
  local scroll = CreateFrame("ScrollFrame", "StoryCasterWriterScroll", box, "UIPanelScrollFrameTemplate")
  scroll:SetPoint("TOPLEFT", 6, -6)
  scroll:SetPoint("BOTTOMRIGHT", -26, 6)
  local edit = CreateFrame("EditBox", nil, scroll)
  edit:SetMultiLine(true)
  edit:SetAutoFocus(false)
  edit:SetFontObject(ChatFontNormal)
  edit:SetWidth(WW - 74)
  edit:SetMaxLetters(0)
  edit:SetTextInsets(4, 4, 4, 4)
  edit:SetScript("OnEscapePressed", function(b) b:ClearFocus() end)
  edit:SetScript("OnTextChanged", function(b)
    if ScrollingEdit_OnTextChanged then ScrollingEdit_OnTextChanged(b, scroll) end
    -- a pasted shared script names itself
    local shared = (b:GetText() or ""):match("^%-%- StoryCaster script: ([^\r\n]+)")
    if shared and (f.name:GetText() or "") == "" then f.name:SetText(shared) end
    R:RefreshWriter()
  end)
  if ScrollingEdit_OnCursorChanged then edit:SetScript("OnCursorChanged", ScrollingEdit_OnCursorChanged) end
  if ScrollingEdit_OnUpdate then edit:SetScript("OnUpdate", function(b, el) ScrollingEdit_OnUpdate(b, el, scroll) end) end
  scroll:SetScrollChild(edit)
  box:EnableMouse(true)
  box:SetScript("OnMouseDown", function() edit:SetFocus() end)
  f.edit = edit

  f.status = Text(f, 10, 0.86, 0.84, 0.95)
  f.status:SetPoint("BOTTOMLEFT", 16, 78)
  f.status:SetWidth(WW - 32)
  f.status:SetHeight(32)
  f.status:SetJustifyV("TOP")
  if f.status.SetWordWrap then f.status:SetWordWrap(true) end
  if f.status.SetSpacing then f.status:SetSpacing(3) end

  local function text() return (f.edit:GetText() or ""):gsub("^%-%- StoryCaster script: [^\r\n]*\r?\n", "") end
  local function convert() return R:Convert(text(), R.db.mode, R.db.autoAnim) end
  local function save()
    local ok, msg = R:Save(f.name:GetText(), (convert()))
    R:Print(msg)
    if ok then R:Refresh() end
    return ok
  end
  local saveB = Btn(f, "Save", 70, 26, function() save() end, "primary")
  saveB:SetPoint("BOTTOMLEFT", 16, 42)
  local goB = Btn(f, "Save and Perform", 132, 26, function() if save() then f:Hide(); R:Start(R.db.last) end end, "primary")
  goB:SetPoint("LEFT", saveB, "RIGHT", 8, 0)
  local prevB = Btn(f, "Preview in Chat", 118, 26, function()
    local script = convert()
    if #script == 0 then R:Print("Nothing to preview yet.") return end
    for i, l in ipairs(script) do R:Print(("%d. %s%s"):format(i, l[6] and ("|cffffd100## " .. l[6] .. "|r  ") or "", R:LineLabel(l))) end
  end)
  prevB:SetPoint("LEFT", goB, "RIGHT", 8, 0)
  Tip(prevB, "Preview", "Shows every line in your own chat window only.")
  local clr = Btn(f, "Clear", 62, 26, function() f.edit:SetText(""); f.name:SetText("") end)
  clr:SetPoint("BOTTOMRIGHT", -16, 42)

  local loadB = Btn(f, "Load", 62, 22, function()
    local n = f.name:GetText():gsub("^%s+", ""):gsub("%s+$", "")
    if not R:Get(n) then n = R.db.last; f.name:SetText(n or "") end
    local s = R:Get(n)
    if not s then R:Print("Type the name of a saved script to load it.") return end
    f.edit:SetText(R:ScriptToText(s))
    R.db.mode = "lines"
    R:RefreshWriter()
    R:Print("Loaded '" .. n .. "' for editing (one line per line).")
  end)
  loadB:SetPoint("BOTTOMLEFT", 16, 12)
  Tip(loadB, "Load", "Load the script named above (or the one chosen on the panel) to edit it.")
  local delB = Btn(f, "Delete", 62, 22, function()
    local n = f.name:GetText():gsub("^%s+", ""):gsub("%s+$", "")
    if R:Delete(n) then R:Print("Deleted '" .. n .. "'."); R:Refresh() else R:Print("No script called '" .. n .. "'.") end
    R:RefreshWriter()
  end)
  delB:SetPoint("LEFT", loadB, "RIGHT", 8, 0)
  f.saved = Text(f, 10, 0.7, 0.68, 0.8)
  f.saved:SetPoint("LEFT", delB, "RIGHT", 12, 0)
  f:Hide()
  self.writer = f
end

function R:RefreshWriter()
  local f = self.writer
  if not f then return end
  for _, b in ipairs(f.modeBtns) do b:Kind(self.db.mode == b.mode and "on" or nil) end
  f.auto:Kind(self.db.autoAnim and "on" or nil)
  local raw = (f.edit:GetText() or ""):gsub("^%-%- StoryCaster script: [^\r\n]*\r?\n", "")
  local script, split, skipped = self:Convert(raw, self.db.mode, self.db.autoAnim)
  local anims, chat, pauses = 0, 0, 0
  for _, l in ipairs(script) do
    if l[2] then anims = anims + 1 end
    if l[4] then chat = chat + 1 end
    if l[3] then pauses = pauses + 1 end
  end
  local cast = self:CastOf(script)
  local msg = ("|cff55ff55%d line%s|r  |cffc9b4ff%d animated|r  |cffffd27f%d chat|r  |cff888888%d pauses|r"):format(#script, #script == 1 and "" or "s", anims, chat, pauses)
  if #cast > 0 then msg = msg .. "  |cff7fd8ffduet with " .. table.concat(cast, ", ") .. "|r" end
  if split > 0 then msg = msg .. ("  |cffffcc00%d split to fit|r"):format(split) end
  if skipped > 0 then msg = msg .. ("  |cff999999%d skipped|r"):format(skipped) end
  if script[1] then msg = msg .. "\n|cffb48cffFirst:|r " .. self:LineLabel(script[1]) end
  f.status:SetText(msg)
  f.saved:SetText(#self.db.order .. " saved script" .. (#self.db.order == 1 and "" or "s"))
end

---------------------------------------------------------------------------
-- The tabs under the timer (Animated Emotes, Lore Library) and the Lore Library itself
---------------------------------------------------------------------------
local ROWS_PER_COL = 13

-- a small NEW badge on a button's corner
local function NewBadge(b)
  local badge = CreateFrame("Frame", nil, b)
  badge:SetSize(34, 14)
  badge:SetPoint("CENTER", b, "TOPRIGHT", -14, 1)
  badge:SetFrameLevel(b:GetFrameLevel() + 3)
  local bbg = badge:CreateTexture(nil, "BACKGROUND")
  bbg:SetAllPoints()
  bbg:SetColorTexture(0.85, 0.14, 0.32, 1)
  Edge(badge, 1, 0.75, 0.82, 1)
  local bt = Text(badge, 8, 1, 1, 1, "OUTLINE")
  bt:SetPoint("CENTER")
  bt:SetText("NEW")
  return badge
end

-- text tabs on a faint line, with a gold underline that glides to the open one
local TABS = { { "lore", "Lore Library", "lore" }, { "emotes", "Animated Emotes", "e_wave" }, { "ideas", "Ideas", "bulb" }, { "more", "More", "more" } }
function R:BuildTabs(p)
  local tabs = Section(p, 38)
  p.tabs = tabs
  local line = tabs:CreateTexture(nil, "ARTWORK")
  line:SetPoint("BOTTOMLEFT", PAD, 2); line:SetPoint("BOTTOMRIGHT", -PAD, 2); line:SetHeight(1)
  line:SetColorTexture(GOLD[1], GOLD[2], GOLD[3], 0.25)
  local TW = math.floor((PW - PAD * 2) / #TABS)
  p.tabBtns = {}
  for i, t in ipairs(TABS) do
    local b = Btn(tabs, t[2], TW, 30, function() R:ShowTab(t[1]) end, "tab", t[3], { size = 12, iconSize = 16 })
    b:SetPoint("BOTTOMLEFT", PAD + (i - 1) * TW, 3)
    b.key = t[1]
    p.tabBtns[t[1]] = b
  end
  p.tabEmotes, p.tabLore, p.tabMore, p.tabIdeas = p.tabBtns.emotes, p.tabBtns.lore, p.tabBtns.more, p.tabBtns.ideas
  Tip(p.tabLore, "Lore Library", "Ready-made roleplay, 50 lines or more: every class, faction, race, profession, holiday and life's big occasions.")
  Tip(p.tabEmotes, "Animated Emotes", "Eighteen animation buttons, every emote in the game, and a random one.")
  Tip(p.tabIdeas, "Ideas", "Read another player's RP profile (Total RP 3 or MyRolePlay) for openers made from it, or get a random scene prompt.")
  Tip(p.tabMore, "More", "Reactions, sending a script, your voice, backup, your RP name, sparkles and the minimap button.")
  -- the gold underline, with a glow under it
  local ul = CreateFrame("Frame", nil, tabs)
  ul:SetSize(TW - 24, 6)
  local bar = ul:CreateTexture(nil, "OVERLAY")
  bar:SetPoint("LEFT"); bar:SetPoint("RIGHT"); bar:SetHeight(2)
  if not HGrad(bar, { GOLD[1], GOLD[2], GOLD[3], 0.2 }, { GOLD_HI[1], GOLD_HI[2], GOLD_HI[3], 1 }) then bar:SetColorTexture(GOLD[1], GOLD[2], GOLD[3], 1) end
  local bar2 = ul:CreateTexture(nil, "OVERLAY")
  bar2:SetPoint("LEFT", ul, "CENTER"); bar2:SetPoint("RIGHT"); bar2:SetHeight(2)
  if not HGrad(bar2, { GOLD_HI[1], GOLD_HI[2], GOLD_HI[3], 1 }, { GOLD[1], GOLD[2], GOLD[3], 0.2 }) then bar2:Hide() end
  bar:ClearAllPoints(); bar:SetPoint("LEFT"); bar:SetPoint("RIGHT", ul, "CENTER"); bar:SetHeight(2)
  local halo = ul:CreateTexture(nil, "ARTWORK")
  halo:SetPoint("TOPLEFT", -6, 8); halo:SetPoint("BOTTOMRIGHT", 6, -2)
  halo:SetTexture(WHITE)
  if halo.SetGradient and CreateColor and pcall(halo.SetGradient, halo, "VERTICAL", CreateColor(GOLD[1], GOLD[2], GOLD[3], 0.28), CreateColor(GOLD[1], GOLD[2], GOLD[3], 0)) then
  else halo:SetVertexColor(GOLD[1], GOLD[2], GOLD[3], 0.12) end
  halo:SetBlendMode("ADD")
  p.tabLine, p.tabLineX, p.tabW = ul, nil, TW
  FX:Anchor(ul, "fill")

  -- the Lore tab breathes gold until it has been opened, with a sheen and a NEW badge
  local lt = p.tabLore
  local glow = lt:CreateTexture(nil, "BACKGROUND", nil, -1)
  glow:SetPoint("TOPLEFT", 10, -2); glow:SetPoint("BOTTOMRIGHT", -10, 2)
  glow:SetTexture(WHITE)
  glow:SetVertexColor(GOLD[1], GOLD[2], GOLD[3], 0.35)
  glow:SetBlendMode("ADD")
  local ga = glow:CreateAnimationGroup()
  ga:SetLooping("BOUNCE")
  local g1 = ga:CreateAnimation("Alpha"); g1:SetFromAlpha(0.1); g1:SetToAlpha(0.8); g1:SetDuration(1.1)
  if g1.SetSmoothing then g1:SetSmoothing("IN_OUT") end
  lt.glow, lt.glowAnim = glow, ga
  if lt.SetClipsChildren then
    lt:SetClipsChildren(true)
    local sheen = lt:CreateTexture(nil, "OVERLAY")
    sheen:SetSize(34, 30)
    sheen:SetPoint("LEFT", lt, "LEFT", -40, 0)
    if not HGrad(sheen, { 1, 1, 1, 0 }, { 1, 1, 1, 0.35 }) then sheen:SetColorTexture(1, 1, 1, 0.2) end
    sheen:SetBlendMode("ADD")
    local sa = sheen:CreateAnimationGroup()
    sa:SetLooping("REPEAT")
    local s1 = sa:CreateAnimation("Translation"); s1:SetOffset(TW + 60, 0); s1:SetDuration(1.0); s1:SetOrder(1)
    local s2 = sa:CreateAnimation("Alpha"); s2:SetFromAlpha(0); s2:SetToAlpha(0); s2:SetDuration(2.6); s2:SetOrder(2)
    lt.sheen, lt.sheenAnim = sheen, sa
  end
  lt.badge = NewBadge(lt)
  p.tabMore.badge = NewBadge(p.tabMore)
  p.tabIdeas.badge = NewBadge(p.tabIdeas)
end

-- the underline glides toward the open tab
function R:SlideTabLine(el)
  local p = self.bar
  if not (p and p.tabLine and p.tabs:IsShown()) then return end
  local b = p.tabBtns[self.db.tab] or p.tabEmotes
  local i = 0
  for n, t in ipairs(TABS) do if p.tabBtns[t[1]] == b then i = n end end
  local target = PAD + (i - 1) * p.tabW + 12
  p.tabLineX = p.tabLineX or target
  p.tabLineX = p.tabLineX + (target - p.tabLineX) * math.min(1, (el or 1) * 12)
  p.tabLine:ClearAllPoints()
  p.tabLine:SetPoint("BOTTOMLEFT", p.tabs, "BOTTOMLEFT", p.tabLineX, 1)
end

function R:ShowTab(which)
  self:FlyoutOpen("library")
  self.db.flyouts.library = true
  self.db.tab = which
  if which == "lore" then self.db.loreSeen = true end
  if which == "more" then self.db.moreSeen = true end
  if which == "ideas" then self.db.ideasSeen = true end
  self:Refresh()
end

function R:RefreshTabs()
  local p = self.bar
  if not p or not p.tabLore then return end
  local tab = p.tabBtns[self.db.tab] and self.db.tab or "emotes"
  for key, b in pairs(p.tabBtns) do
    if key == tab then
      b.text:SetTextColor(GOLD_HI[1], GOLD_HI[2], GOLD_HI[3])
      if b.icon then b.icon:SetVertexColor(GOLD_HI[1], GOLD_HI[2], GOLD_HI[3]) end
      b.base = { nil, nil, nil, GOLD_HI }
    else
      b:Kind("tab")
    end
  end
  self:SlideTabLine(0) -- placed the first time; after that it glides in OnUpdate
  local lt = p.tabLore
  -- glowing and shining while it waits to be noticed; once open, it settles
  if tab == "lore" or self.db.loreSeen then
    lt.glowAnim:Stop(); lt.glow:Hide()
    if lt.sheen then lt.sheenAnim:Stop(); lt.sheen:Hide() end
  else
    lt.glow:Show()
    if not lt.glowAnim:IsPlaying() then lt.glowAnim:Play() end
    if lt.sheen then
      lt.sheen:Show()
      if not lt.sheenAnim:IsPlaying() then lt.sheenAnim:Play() end
    end
  end
  if self.db.loreSeen then lt.badge:Hide() else lt.badge:Show() end
  if self.db.moreSeen then p.tabMore.badge:Hide() else p.tabMore.badge:Show() end
  if self.db.ideasSeen then p.tabIdeas.badge:Hide() else p.tabIdeas.badge:Show() end
end

-- /story lore, or anything else that wants the Lore Library in view
function R:ToggleLore(show)
  self.db.showBar = true
  self.db.compact = false
  if show == false or (show == nil and self.db.tab == "lore" and self.bar and self.bar:IsShown()) then self.db.tab = "emotes"
  else self.db.tab = "lore"; self.db.loreSeen = true end
  self:Refresh()
end

function R:LoreChoice(kind)
  self.db.lore = type(self.db.lore) == "table" and self.db.lore or {}
  local k = self.db.lore[kind]
  if not (k and self.LORE[kind] and self.LORE[kind][k]) then k = self:LoreDefault(kind); self.db.lore[kind] = k end
  return k
end

-- the list that drops down under a choice: one or more columns of names
function R:OpenLoreList(kind, anchor)
  local list = self.loreList
  if not list then
    list = CreateFrame("Frame", "StoryCasterLoreList", self.bar)
    list:SetFrameStrata("DIALOG")
    list:SetClampedToScreen(true)
    list:EnableMouse(true)
    Glass(list, 0.98)
    list.items = {}
    tinsert(UISpecialFrames, "StoryCasterLoreList")
    self.loreList = list
  end
  if list:IsShown() and list.kind == kind then list:Hide() return end
  list.kind = kind
  for _, b in ipairs(list.items) do b:Hide() end
  local keys = self:LoreKeys(kind)
  local cur = self:LoreChoice(kind)
  local cols = math.ceil(#keys / ROWS_PER_COL)
  local rows = math.min(#keys, ROWS_PER_COL)
  local IW, IH = 164, 20
  for i, k in ipairs(keys) do
    local b = list.items[i]
    if not b then b = Btn(list, "", IW, IH); list.items[i] = b end
    b.text:SetText(self:LoreTitle(kind, k))
    b:Kind(k == cur and "on" or "emote")
    b:ClearAllPoints()
    local col, row = math.floor((i - 1) / ROWS_PER_COL), (i - 1) % ROWS_PER_COL
    b:SetPoint("TOPLEFT", 6 + col * (IW + 4), -6 - row * (IH + 2))
    b:SetScript("OnClick", function()
      R.db.lore[kind] = k
      list:Hide()
      R:RefreshLore()
    end)
    b:Show()
  end
  list:SetSize(12 + cols * IW + (cols - 1) * 4, 12 + rows * IH + (rows - 1) * 2)
  list:ClearAllPoints()
  list:SetPoint("TOPLEFT", anchor, "BOTTOMLEFT", 0, -2)
  list:Show()
end

-- the Random buttons count down while they rest
function R:RefreshRandom()
  local wait = self:RandomWait()
  for _, b in ipairs({ self.bar and self.bar.random, self.emoteList and self.emoteList.random }) do
    if b then
      if wait > 0 then b.text:SetText(("Random %ds"):format(math.ceil(wait))); b:Kind(nil); b:SetAlpha(0.6)
      else b.text:SetText("Random"); b:Kind("go"); b:SetAlpha(1) end
    end
  end
end

-- every emote in the game: a search box and pages of buttons; a click plays it at your target
local EC, ER, EW, EH = 6, 12, 78, 20
function R:OpenEmoteList(anchor)
  local f = self.emoteList
  if not f then
    f = CreateFrame("Frame", "StoryCasterEmotes", UIParent)
    f:SetSize(12 + EC * EW + (EC - 1) * 4 + 12, 96 + ER * (EH + 3))
    f:SetFrameStrata("DIALOG")
    f:SetToplevel(true)
    f:SetClampedToScreen(true)
    f:EnableMouse(true)
    f:SetMovable(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", f.StartMoving)
    f:SetScript("OnDragStop", f.StopMovingOrSizing)
    tinsert(UISpecialFrames, "StoryCasterEmotes")
    Glass(f, 0.97, 40)
    local head = Text(f, 14, 0.88, 0.80, 1, "OUTLINE")
    head:SetPoint("LEFT", f, "TOPLEFT", 16, -20)
    head:SetText("All Emotes")
    local close = Btn(f, "x", 20, 20, function() f:Hide() end)
    close:SetPoint("RIGHT", f, "TOPRIGHT", -10, -20)
    f.random = Btn(f, "Random", 84, 20, function() R:RandomEmote() end, "go")
    f.random:SetPoint("RIGHT", close, "LEFT", -8, 0)
    Tip(f.random, "Random emote", "A random emote from this whole list, at your target. It rests for " .. R.RANDOM_GAP .. " seconds after each one.")
    -- keeps the countdown moving while the panel is hidden
    f:SetScript("OnUpdate", function(s, el)
      s.acc = (s.acc or 0) + el
      if s.acc >= 0.2 then s.acc = 0; R:RefreshRandom() end
    end)
    local sl = Text(f, 10, 0.85, 0.82, 0.95)
    sl:SetPoint("TOPLEFT", 16, -56)
    sl:SetText("Search")
    local search = CreateFrame("EditBox", nil, f, "InputBoxTemplate")
    search:SetSize(180, 20)
    search:SetPoint("LEFT", sl, "RIGHT", 12, 0)
    search:SetAutoFocus(false)
    search:SetScript("OnEscapePressed", function(b) b:ClearFocus() end)
    search:SetScript("OnEnterPressed", function(b) b:ClearFocus() end)
    search:SetScript("OnTextChanged", function() f.page = 1; R:RefreshEmoteList() end)
    f.search = search
    f.count = Text(f, 10, 0.70, 0.66, 0.80)
    f.count:SetPoint("LEFT", search, "RIGHT", 12, 0)
    f.prev = Btn(f, "<", 26, 20, function() f.page = f.page - 1; R:RefreshEmoteList() end)
    f.next = Btn(f, ">", 26, 20, function() f.page = f.page + 1; R:RefreshEmoteList() end)
    f.next:SetPoint("TOPRIGHT", -16, -54)
    f.prev:SetPoint("RIGHT", f.next, "LEFT", -40, 0)
    f.pageText = Text(f, 10, 0.85, 0.82, 0.95)
    f.pageText:SetPoint("CENTER", f.prev, "RIGHT", 20, 0)
    f.pageText:SetJustifyH("CENTER")
    f.items = {}
    for i = 1, EC * ER do
      local b = Btn(f, "", EW, EH, nil, "emote")
      local col, row = (i - 1) % EC, math.floor((i - 1) / EC)
      b:SetPoint("TOPLEFT", 12 + col * (EW + 4), -84 - row * (EH + 3))
      b:SetScript("OnEnter", function(self)
        if not self.token then return end
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:SetText("/" .. self.label, 1, 0.85, 0.4)
        GameTooltip:AddLine("Click to play it" .. (R:Target() and (" at " .. R:Target()) or "") .. ".", 0.9, 0.9, 0.9, true)
        GameTooltip:Show()
      end)
      b:SetScript("OnLeave", function() GameTooltip:Hide() end)
      b:SetScript("OnClick", function(self) if self.token then R:Animate(self.token, true); R:Pulse() end end)
      f.items[i] = b
    end
    f.page = 1
    f:SetPoint("CENTER", 0, 40)
    f:Hide()
    self.emoteList = f
  end
  if f:IsShown() then f:Hide() return end
  if anchor then f:ClearAllPoints(); f:SetPoint("TOP", anchor, "BOTTOM", 0, -6) end
  f:Show()
  self:RefreshEmoteList()
end

function R:RefreshEmoteList()
  local f = self.emoteList
  if not f then return end
  local q = (f.search:GetText() or ""):lower():gsub("^/", ""):gsub("%s+", "")
  local shown = {}
  for _, e in ipairs(self:AllEmotes()) do
    if q == "" or e[2]:find(q, 1, true) then shown[#shown + 1] = e end
  end
  local per = EC * ER
  local pages = math.max(1, math.ceil(#shown / per))
  f.page = math.max(1, math.min(f.page or 1, pages))
  for i, b in ipairs(f.items) do
    local e = shown[(f.page - 1) * per + i]
    if e then
      b.token, b.label = e[1], e[2]
      b.text:SetText(e[2])
      b:Kind(self.ANIM_BY_TOKEN[e[1]] and "primary" or "emote")
      b:Show()
    else
      b.token = nil
      b:Hide()
    end
  end
  f.count:SetText(#shown .. " emote" .. (#shown == 1 and "" or "s"))
  f.pageText:SetText(f.page .. " / " .. pages)
  f.prev:SetAlpha(f.page > 1 and 1 or 0.35)
  f.next:SetAlpha(f.page < pages and 1 or 0.35)
end

-- the Mood list: None and the ten moods, each with a taste of what it says
function R:OpenMoodList(anchor)
  local list = self.moodList
  if not list then
    list = CreateFrame("Frame", "StoryCasterMoodList", self.bar)
    list:SetFrameStrata("DIALOG")
    list:SetClampedToScreen(true)
    list:EnableMouse(true)
    Glass(list, 0.98)
    list.items = {}
    tinsert(UISpecialFrames, "StoryCasterMoodList")
    list:Hide()
    self.moodList = list
  end
  if list:IsShown() then list:Hide() return end
  local choices = { { nil, "None", "<mood> is left out" } }
  for _, m in ipairs(self.MOODS) do choices[#choices + 1] = { m[1], m[1], m[2][1] .. ", " .. m[2][3] .. "..." } end
  local IW, IH = 250, 22
  for i, c in ipairs(choices) do
    local b = list.items[i]
    if not b then
      b = Btn(list, "", IW, IH)
      b.text:ClearAllPoints(); b.text:SetPoint("LEFT", 8, 0); b.text:SetJustifyH("LEFT")
      b.hint = Text(b, 9, 0.70, 0.66, 0.80)
      b.hint:SetPoint("RIGHT", -8, 0); b.hint:SetJustifyH("RIGHT")
      list.items[i] = b
    end
    b.text:SetText(c[2])
    b.hint:SetText(c[3])
    b:Kind(self.db.mood == c[1] and "on" or "emote")
    b:ClearAllPoints()
    b:SetPoint("TOPLEFT", 6, -6 - (i - 1) * (IH + 2))
    b:SetScript("OnClick", function()
      R:SetMood(c[1])
      list:Hide()
      R:Print(c[1] and ("Mood: |cffffd100" .. c[1] .. "|r. The next line feels it.") or "Mood off: <mood> is left out.")
    end)
    b:Show()
  end
  list:SetSize(12 + IW, 12 + #choices * IH + (#choices - 1) * 2)
  list:ClearAllPoints()
  list:SetPoint("TOPLEFT", anchor, "BOTTOMLEFT", 0, -2)
  list:Show()
end

---------------------------------------------------------------------------
-- The Lore Library tab: a row per kind (dropdown, favorite star, Perform, Preview, Edit, one Line)
---------------------------------------------------------------------------
local LROW = 31
function R:BuildLoreSection(p)
  local f = Section(p, 46 + #self.LORE_KINDS * LROW)
  p.lore = f
  local intro = Text(f, 10, 0.80, 0.78, 0.88)
  intro:SetPoint("TOPLEFT", PAD, -10)
  intro:SetWidth(PW - PAD * 2 - 96)
  if intro.SetWordWrap then intro:SetWordWrap(true) end
  if intro.SetSpacing then intro:SetSpacing(2) end
  intro:SetText("Ready-made roleplay in scenes, 50 lines or more, starting on your own character. * marks a favorite. " ..
    "Line says one line from it now.")
  local back = Btn(f, "<  Back", 84, 22, function() R:ShowTab("emotes") end, "primary")
  back:SetPoint("TOPRIGHT", -PAD, -8)
  Tip(back, "Back", "Close the Lore Library and go back to the emote buttons. The Lore Library tab opens it again.")
  f.back = back
  f.rows = {}
  for i, kd in ipairs(self.LORE_KINDS) do
    local kind, label = kd[1], kd[2]
    local y = -42 - (i - 1) * LROW
    local lab = Text(f, 10, GOLD[1], GOLD[2], GOLD[3], "OUTLINE")
    lab:SetPoint("TOPLEFT", PAD, y - 7)
    lab:SetText(label)
    local dd = Btn(f, "", 150, 24, nil)
    dd:SetPoint("TOPLEFT", PAD + 66, y)
    dd.text:ClearAllPoints(); dd.text:SetPoint("LEFT", 8, 0); dd.text:SetJustifyH("LEFT")
    dd.text:SetWidth(108)
    if dd.text.SetWordWrap then dd.text:SetWordWrap(false) end
    dd.arrow = Text(dd, 10, ACCENT[1], ACCENT[2], ACCENT[3])
    dd.arrow:SetPoint("RIGHT", -7, 0)
    dd.arrow:SetText("v")
    dd.count = Text(dd, 8, 0.62, 0.60, 0.72)
    dd.count:SetPoint("RIGHT", dd.arrow, "LEFT", -4, 0)
    dd:SetScript("OnMouseDown", nil); dd:SetScript("OnMouseUp", nil)
    dd:SetScript("OnClick", function(b) R:OpenLoreList(kind, b) end)
    Tip(dd, label, "Click to choose a " .. label:lower() .. ". Favorites are listed first.")
    local star = Btn(f, "*", 22, 24, function() R:ToggleLoreFav(kind, R:LoreChoice(kind)); R:RefreshLore() end)
    star:SetPoint("LEFT", dd, "RIGHT", 4, 0)
    Tip(star, "Favorite", "Mark this one as a favorite: it is listed first and starred.")
    local go = Btn(f, "Perform", 62, 24, function() R:PerformLore(kind, R:LoreChoice(kind)) end, "go")
    go:SetPoint("LEFT", star, "RIGHT", 4, 0)
    Tip(go, "Perform", "Saves it to your scripts as 'Lore: ...' and performs it with your timer settings.")
    local pv = Btn(f, "Preview", 58, 24, function() R:PreviewLore(kind, R:LoreChoice(kind)) end)
    pv:SetPoint("LEFT", go, "RIGHT", 4, 0)
    Tip(pv, "Preview", "Shows every line in your own chat window only.")
    local ed = Btn(f, "Edit", 42, 24, function()
      local k = R:LoreChoice(kind)
      R.db.mode = "lines"
      R:ToggleWriter(true)
      R.writer.name:SetText("My " .. R:LoreTitle(kind, k))
      R.writer.edit:SetText(R:LoreText(kind, k))
      R:RefreshWriter()
    end)
    ed:SetPoint("LEFT", pv, "RIGHT", 4, 0)
    Tip(ed, "Edit", "Opens it in Write a Script under a name of your own, to change any line and save it as yours.")
    local one = Btn(f, "Line", 48, 24, function() R:SayLoreLine(kind, R:LoreChoice(kind)) end, "key")
    one:SetPoint("LEFT", ed, "RIGHT", 4, 0)
    Tip(one, "Say one line", "Posts one random line from it right now. It rests " .. R.LORE_LINE_GAP .. " seconds after each one.")
    f.rows[kind] = { dd = dd, star = star, one = one }
  end
end

function R:RefreshLore()
  local f = self.bar and self.bar.lore
  if not f then return end
  local wait = self:LoreLineWait()
  for _, kd in ipairs(self.LORE_KINDS) do
    local kind = kd[1]
    local row = f.rows[kind]
    local k = self:LoreChoice(kind)
    local fav = self:IsLoreFav(kind, k)
    row.dd.text:SetText((fav and "|cffffd100*|r " or "") .. self:LoreTitle(kind, k))
    row.dd.count:SetText(#self:LoreScript(kind, k))
    row.star:Kind(fav and "key" or nil)
    row.one.text:SetText(wait > 0 and (math.ceil(wait) .. "s") or "Line")
    row.one:SetAlpha(wait > 0 and 0.6 or 1)
  end
end

---------------------------------------------------------------------------
-- Player Focus: a strip under the script card, gold and glowing while it's on
---------------------------------------------------------------------------
function R:BuildFocus(p)
  local f = Section(p, 46)
  p.focus = f
  local strip = CreateFrame("Frame", nil, f)
  strip:SetPoint("TOPLEFT", PAD, -6); strip:SetPoint("BOTTOMRIGHT", -PAD, 2)
  local bg = strip:CreateTexture(nil, "BACKGROUND")
  bg:SetAllPoints()
  strip.bg = bg
  local glow = strip:CreateTexture(nil, "BORDER")
  glow:SetAllPoints()
  glow:SetTexture(WHITE)
  if glow.SetGradient and CreateColor and pcall(glow.SetGradient, glow, "HORIZONTAL", CreateColor(GOLD[1], GOLD[2], GOLD[3], 0.22), CreateColor(GOLD[1], GOLD[2], GOLD[3], 0.02)) then
  else glow:SetVertexColor(GOLD[1], GOLD[2], GOLD[3], 0.10) end
  glow:SetBlendMode("ADD")
  local ga = glow:CreateAnimationGroup()
  ga:SetLooping("BOUNCE")
  local g1 = ga:CreateAnimation("Alpha"); g1:SetFromAlpha(0.35); g1:SetToAlpha(1); g1:SetDuration(1.4)
  strip.glow, strip.glowAnim = glow, ga
  p.focusStrip = strip
  FX:Anchor(strip, "edge")
  local icon = strip:CreateTexture(nil, "ARTWORK")
  icon:SetTexture(MEDIA .. "eye")
  icon:SetSize(22, 22)
  icon:SetPoint("LEFT", 8, 0)
  strip.icon = icon
  local lab = Text(strip, 12, GOLD_HI[1], GOLD_HI[2], GOLD_HI[3], "OUTLINE")
  lab:SetPoint("LEFT", icon, "RIGHT", 6, 0)
  lab:SetText("Player Focus")
  strip.label = lab
  strip.toggle = Btn(strip, "Off", 58, 26, function() R:SetFocus(not R:FocusDB().on) end, nil, nil, { burst = 8 })
  strip.toggle:SetPoint("LEFT", 144, 0)
  Tip(strip.toggle, "Player Focus", "Weaves another player into whatever you perform, a little at a time: a 'says to them' here, a glance their way there. Never two lines in a row, and never when they're already named. {target} and {focus} use them too.")
  local box = CreateFrame("EditBox", nil, strip, "InputBoxTemplate")
  box:SetSize(112, 20)
  box:SetPoint("LEFT", strip.toggle, "RIGHT", 14, 0)
  box:SetAutoFocus(false)
  box:SetMaxLetters(40)
  box:SetScript("OnEscapePressed", function(b) b:ClearFocus() end)
  box:SetScript("OnEnterPressed", function(b) b:ClearFocus(); R:SetFocus(true, b:GetText()) end)
  strip.box = box
  strip.hint = Text(strip, 10, 0.55, 0.53, 0.65)
  strip.hint:SetPoint("LEFT", box, "LEFT", 2, 0)
  strip.hint:SetText("your target")
  local use = Btn(strip, "Target", 74, 24, function()
    local t = R:Target()
    if not t then R:Print("Target a player first, or type a name.") return end
    R:SetFocus(true, t)
  end, "key", "people", { iconSize = 14 })
  use:SetPoint("LEFT", box, "RIGHT", 8, 0)
  Tip(use, "Focus on your target", "Keeps your current target in focus, even after you target someone else. Leave the name empty to follow whoever you target.")
  strip.light = Btn(strip, "Light", 46, 22, function() R:FocusDB().level = "light"; R:Refresh() end)
  strip.more = Btn(strip, "More", 46, 22, function() R:FocusDB().level = "more"; R:Refresh() end)
  strip.more:SetPoint("RIGHT", -6, 0)
  strip.light:SetPoint("RIGHT", strip.more, "LEFT", -4, 0)
  Tip(strip.light, "Light", "A mention every 5 to 7 lines.")
  Tip(strip.more, "More", "A mention every 3 to 4 lines.")
end

function R:RefreshFocus()
  local p = self.bar
  local s = p and p.focusStrip
  if not s then return end
  local f = self:FocusDB()
  local on = f.on
  s.toggle.text:SetText(on and "On" or "Off")
  s.toggle:Kind(on and "key" or nil)
  Grad(s.bg, on and { 0.20, 0.15, 0.06 } or { 0.08, 0.08, 0.14 }, on and { 0.11, 0.08, 0.04 } or { 0.05, 0.05, 0.10 }, 0.9)
  Edge(s, GOLD[1], GOLD[2], GOLD[3], on and 0.9 or 0.35)
  if on then s.glow:Show(); if not s.glowAnim:IsPlaying() then s.glowAnim:Play() end else s.glowAnim:Stop(); s.glow:Hide() end
  s.icon:SetVertexColor(on and GOLD_HI[1] or 0.6, on and GOLD_HI[2] or 0.58, on and GOLD_HI[3] or 0.7)
  if not s.box:HasFocus() then s.box:SetText(f.name or "") end
  local empty = (s.box:GetText() or "") == ""
  if empty then
    local t = self:Target()
    s.hint:SetText(t and ("target: " .. t) or "your target")
    s.hint:Show()
  else s.hint:Hide() end
  s.light:Kind(f.level ~= "more" and "primary" or nil)
  s.more:Kind(f.level == "more" and "primary" or nil)
end

---------------------------------------------------------------------------
-- The Ideas tab: openers made from another player's RP profile, or random prompts
---------------------------------------------------------------------------
function R:BuildIdeasSection(p)
  local f = Section(p, 246)
  p.ideas = f
  local read = Btn(f, "Read target's profile", 196, 30, function() R:ReadTargetIdeas() end, "primary", "eye", { burst = 8 })
  read:SetPoint("TOPLEFT", PAD, -8)
  Tip(read, "Read their profile", "Reads your target's Total RP 3 or MyRolePlay profile (name, title, race, home, eyes, what they're up to, their About text) and writes three openers from it. Nothing is sent anywhere.")
  local prompt = Btn(f, "Give me a prompt", 168, 30, function() R:PromptIdeas() end, "key", "bulb", { burst = 8 })
  prompt:SetPoint("LEFT", read, "RIGHT", 8, 0)
  Tip(prompt, "Prompts", "Three random scene ideas to start from, with {target} and <mood> ready.")
  local back = Btn(f, "<  Back", 84, 26, function() R:ShowTab("emotes") end, "primary")
  back:SetPoint("TOPRIGHT", -PAD, -10)
  f.summary = Text(f, 11, 0.86, 0.84, 0.95)
  f.summary:SetPoint("TOPLEFT", PAD + 2, -46)
  f.summary:SetWidth(PW - PAD * 2 - 4)
  f.summary:SetHeight(44)
  f.summary:SetJustifyV("TOP")
  if f.summary.SetSpacing then f.summary:SetSpacing(3) end
  f.cards = {}
  for i = 1, 3 do
    local c = CreateFrame("Frame", nil, f)
    c:SetPoint("TOPLEFT", PAD, -94 - (i - 1) * 50)
    c:SetSize(PW - PAD * 2, 44)
    local cb = c:CreateTexture(nil, "BACKGROUND")
    cb:SetAllPoints()
    Grad(cb, { 0.07, 0.07, 0.13 }, { 0.10, 0.10, 0.18 }, 0.85)
    Edge(c, GOLD[1], GOLD[2], GOLD[3], 0.3)
    c.title = Text(c, 13, GOLD_HI[1], GOLD_HI[2], GOLD_HI[3], nil, SERIF)
    c.title:SetPoint("TOPLEFT", 10, -6)
    c.line = Text(c, 10, 0.74, 0.72, 0.84)
    c.line:SetPoint("TOPLEFT", 10, -26)
    c.line:SetWidth(PW - PAD * 2 - 170)
    if c.line.SetWordWrap then c.line:SetWordWrap(false) end
    c.go = Btn(c, "Perform", 74, 26, function() R:PerformIdea(R.ideas and R.ideas[i]) end, "go", "play", { iconSize = 13 })
    c.go:SetPoint("RIGHT", -64, 0)
    c.edit = Btn(c, "Edit", 52, 26, function() R:EditIdea(R.ideas and R.ideas[i]) end, nil, "write", { iconSize = 13 })
    c.edit:SetPoint("RIGHT", -8, 0)
    c:Hide()
    f.cards[i] = c
  end
end

function R:RefreshIdeas()
  local f = self.bar and self.bar.ideas
  if not f then return end
  local p = self.ideaProfile
  if p then f.summary:SetText(self:ProfileSummary(p))
  elseif self.ideas then f.summary:SetText("|cffeec060Prompts|r  ·  three scenes to start from. Press again for three more.")
  else
    local t = self:Target()
    f.summary:SetText((t and ("Target: |cffeec060" .. t .. "|r. ") or "Target another player, ") ..
      "then read their RP profile for openers made from it, or ask for a prompt.\n|cff888888Works with Total RP 3 and MyRolePlay; without them it uses what the game shows.|r")
  end
  for i, c in ipairs(f.cards) do
    local idea = self.ideas and self.ideas[i]
    if idea then
      c.title:SetText(idea.title)
      local first = (idea.text:match("^([^\n]+)") or ""):gsub("%[%a+%]", "")
      c.line:SetText((self:Render(first)))
      c:Show()
    else c:Hide() end
  end
end

---------------------------------------------------------------------------
-- The More tab
---------------------------------------------------------------------------
local MROW = 31
function R:BuildMoreSection(p)
  local f = Section(p, 22 + 8 * MROW)
  p.more = f
  local rows = 0
  local function row(label, tip)
    rows = rows + 1
    local y = -8 - (rows - 1) * MROW
    local l = Text(f, 11, GOLD_HI[1], GOLD_HI[2], GOLD_HI[3])
    l:SetPoint("TOPLEFT", PAD + 2, y - 7)
    l:SetText(label)
    local n = Text(f, 9, 0.62, 0.60, 0.72)
    n:SetPoint("TOPLEFT", PAD + 330, y - 8)
    n:SetWidth(PW - PAD * 2 - 330)
    if n.SetWordWrap then n:SetWordWrap(false) end
    n:SetText(tip or "")
    return y, n
  end
  local function at(b, y, x) b:SetPoint("TOPLEFT", PAD + (x or 130), y) end
  local back = Btn(f, "<  Back", 84, 22, function() R:ShowTab("emotes") end, "primary")
  back:SetPoint("TOPRIGHT", -PAD, -8)
  f.back = back

  local y = row("Reactions", "Answer emotes aimed at you.")
  f.react = Btn(f, "Off", 60, 24, function() R:SetReactions(not R.db.reactions) end); at(f.react, y)
  Tip(f.react, "Reactions", "When someone waves, bows, hugs (and more) at you, or says a word you chose near you, your character answers. At most once a minute per person, never faster than one line every 15 seconds.")
  local er = Btn(f, "Edit", 60, 24, function() R:ToggleReactions(true) end, nil, "write", { iconSize = 13 }); at(er, y, 196)

  y = row("Send a script", "Empty name: your target.")
  local to = CreateFrame("EditBox", nil, f, "InputBoxTemplate")
  to:SetSize(110, 20)
  to:SetPoint("TOPLEFT", PAD + 136, y - 2)
  to:SetAutoFocus(false)
  to:SetScript("OnEscapePressed", function(b) b:ClearFocus() end)
  to:SetScript("OnEnterPressed", function(b) b:ClearFocus(); R:SendScript(R.db.last, b:GetText()) end)
  f.to = to
  local send = Btn(f, "Send", 64, 24, function() R:SendScript(R.db.last, to:GetText()) end, "primary", "deliver", { iconSize = 13 }); at(send, y, 254)
  Tip(send, "Send a script", "Offers the script chosen on the panel to a friend. Type their name, or leave it empty to send to your target. They must have StoryCaster and accept it.")

  y, f.voiceNote = row("My voice", "")
  local ev = Btn(f, "Edit my voice", 126, 24, function() R:ToggleVoice(true) end, "primary", "write", { iconSize = 13 }); at(ev, y)
  Tip(ev, "My voice", "This character's title, catchphrase and own words for each mood. {title} and {catchphrase} fill themselves in.")

  y = row("Mood animations", "Angry roars, Sad cries, now and then.")
  f.moodAnim = Btn(f, "On", 60, 24, function() R.db.moodAnims = (R.db.moodAnims == false); R:Refresh() end); at(f.moodAnim, y)
  Tip(f.moodAnim, "Mood animations", "Now and then a line with <mood> also plays a fitting animation. At most one every " .. R.MOOD_ANIM_GAP .. " seconds.")

  y = row("Backup", "All your scripts as text.")
  local bk = Btn(f, "Back up / Restore", 150, 24, function() R:ToggleBackup(true) end, "key", "backup", { iconSize = 13 }); at(bk, y)
  Tip(bk, "Backup", "Every script as one block of text to keep in a file or Discord. Paste one back and press Restore to bring them all back.")

  y = row("RP name", "{name} and {title} from Total RP 3 or MyRolePlay.")
  f.rpName = Btn(f, "On", 60, 24, function() R.db.rpName = (R.db.rpName == false); R:Refresh() end); at(f.rpName, y)
  f.rpShow = Text(f, 10, 0.80, 0.78, 0.88)
  f.rpShow:SetPoint("TOPLEFT", PAD + 198, y - 8)
  f.rpShow:SetWidth(126)
  if f.rpShow.SetWordWrap then f.rpShow:SetWordWrap(false) end

  y = row("Sparkles", "The gold glints and click bursts.")
  f.fx = Btn(f, "On", 60, 24, function() R.db.fx = (R.db.fx == false); R:Refresh() end); at(f.fx, y)

  y = row("Minimap button", "Left: panel. Right: Drama. Shift: Lore.")
  f.mini = Btn(f, "On", 60, 24, function() R.db.minimap = (R.db.minimap == false); R:BuildMinimap(); R:Refresh() end); at(f.mini, y)
end

function R:RefreshMore()
  local f = self.bar and self.bar.more
  if not f then return end
  local function sw(b, on) b.text:SetText(on and "On" or "Off"); b:Kind(on and "on" or nil) end
  sw(f.react, self.db.reactions)
  sw(f.moodAnim, self.db.moodAnims ~= false)
  sw(f.rpName, self.db.rpName ~= false)
  sw(f.fx, self.db.fx ~= false)
  sw(f.mini, self.db.minimap ~= false)
  local n, t = self:RPName()
  f.rpShow:SetText(n and ("|cffeec060" .. n .. "|r" .. (t and (", " .. t) or "")) or "|cff777777no RP profile found|r")
  local v = self:Voice()
  local own = 0
  for _ in pairs(v.moods) do own = own + 1 end
  f.voiceNote:SetText(((v.title and v.title ~= "") and v.title or "No title yet") ..
    ((v.catch and v.catch ~= "") and ("  ·  \"" .. v.catch .. "\"") or "") .. (own > 0 and ("  ·  " .. own .. " mood" .. (own == 1 and "" or "s")) or ""))
end

---------------------------------------------------------------------------
-- Backup window
---------------------------------------------------------------------------
function R:ToggleBackup(show)
  if not self.backupWin then
    local f = CreateFrame("Frame", "StoryCasterBackup", UIParent)
    f:SetSize(560, 440)
    f:SetPoint("CENTER", 0, 40)
    f:SetFrameStrata("DIALOG")
    f:SetToplevel(true)
    f:SetClampedToScreen(true)
    f:EnableMouse(true)
    f:SetMovable(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", f.StartMoving)
    f:SetScript("OnDragStop", f.StopMovingOrSizing)
    tinsert(UISpecialFrames, "StoryCasterBackup")
    Glass(f, 0.97, 40)
    local head = Text(f, 14, GOLD_HI[1], GOLD_HI[2], GOLD_HI[3], "OUTLINE")
    head:SetPoint("LEFT", f, "TOPLEFT", 18, -20)
    head:SetText("Backup and Restore")
    local close = Btn(f, "", 24, 24, function() f:Hide() end, "key", "close", { iconSize = 12 })
    close:SetPoint("RIGHT", f, "TOPRIGHT", -12, -20)
    local hp = Text(f, 10, 0.80, 0.78, 0.88)
    hp:SetPoint("TOPLEFT", 18, -52)
    hp:SetWidth(524)
    if hp.SetWordWrap then hp:SetWordWrap(true) end
    hp:SetText("To back up: everything is selected, press Ctrl+C and keep it in a file or Discord. To restore: clear the box, paste a backup (Ctrl+V) and press Restore. Scripts you already have are kept; a restored copy gets ' (restored)'.")
    local box = CreateFrame("Frame", nil, f)
    box:SetPoint("TOPLEFT", 18, -88); box:SetPoint("BOTTOMRIGHT", -18, 50)
    local bbg = box:CreateTexture(nil, "BACKGROUND")
    bbg:SetAllPoints()
    bbg:SetColorTexture(0.01, 0.01, 0.03, 0.9)
    Edge(box, GOLD[1], GOLD[2], GOLD[3], 0.3)
    local scroll = CreateFrame("ScrollFrame", "StoryCasterBackupScroll", box, "UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", 6, -6); scroll:SetPoint("BOTTOMRIGHT", -26, 6)
    local edit = CreateFrame("EditBox", nil, scroll)
    edit:SetMultiLine(true)
    edit:SetAutoFocus(false)
    edit:SetFontObject(ChatFontNormal)
    edit:SetWidth(490)
    edit:SetMaxLetters(0)
    edit:SetScript("OnEscapePressed", function(b) b:ClearFocus() end)
    scroll:SetScrollChild(edit)
    f.edit = edit
    local restore = Btn(f, "Restore", 100, 28, function()
      local n = R:RestoreText(f.edit:GetText())
      R:Print(n > 0 and ("Restored " .. n .. " script" .. (n == 1 and "" or "s") .. ".") or "No scripts found in that text.")
    end, "key", "backup")
    restore:SetPoint("BOTTOMLEFT", 18, 12)
    local fresh = Btn(f, "Fresh backup", 120, 28, function() f.edit:SetText(R:BackupText()); f.edit:HighlightText() end, "primary", "scroll")
    fresh:SetPoint("LEFT", restore, "RIGHT", 8, 0)
    local clr = Btn(f, "Clear", 70, 28, function() f.edit:SetText(""); f.edit:SetFocus() end)
    clr:SetPoint("BOTTOMRIGHT", -18, 12)
    f:Hide()
    self.backupWin = f
  end
  local f = self.backupWin
  if show == true or not f:IsShown() then
    f:Show()
    f.edit:SetText(self:BackupText())
    f.edit:SetFocus()
    f.edit:HighlightText()
  else f:Hide() end
end

---------------------------------------------------------------------------
-- Minimap button: left click the panel, right click Drama, shift-click the Lore Library; drag it around the map
---------------------------------------------------------------------------
function R:BuildMinimap()
  if self.db.minimap == false then if self.miniBtn then self.miniBtn:Hide() end return end
  if not (Minimap and type(Minimap) == "table" and Minimap.GetWidth) then return end
  local b = self.miniBtn
  if not b then
    b = CreateFrame("Button", "StoryCasterMinimapButton", Minimap)
    b:SetSize(32, 32)
    b:SetFrameStrata("MEDIUM")
    b:SetFrameLevel(8)
    b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    b:RegisterForDrag("LeftButton")
    local bg = b:CreateTexture(nil, "BACKGROUND")
    bg:SetSize(22, 22); bg:SetPoint("CENTER")
    bg:SetTexture("Interface\\Minimap\\UI-Minimap-Background")
    local icon = b:CreateTexture(nil, "ARTWORK")
    icon:SetSize(20, 20); icon:SetPoint("CENTER")
    icon:SetTexture("Interface\\AddOns\\StoryCaster\\logo")
    local border = b:CreateTexture(nil, "OVERLAY")
    border:SetSize(54, 54); border:SetPoint("TOPLEFT")
    border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    b:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
    local function place()
      local a = math.rad(R.db.minimapAngle or 210)
      local r = (Minimap:GetWidth() or 140) / 2 + 6
      b:ClearAllPoints()
      b:SetPoint("CENTER", Minimap, "CENTER", math.cos(a) * r, math.sin(a) * r)
    end
    b.place = place
    b:SetScript("OnDragStart", function(s)
      s:SetScript("OnUpdate", function()
        local mx, my = Minimap:GetCenter()
        local cx, cy = GetCursorPosition()
        local sc = Minimap:GetEffectiveScale()
        if mx and cx then R.db.minimapAngle = math.deg(math.atan2(cy / sc - my, cx / sc - mx)); place() end
      end)
    end)
    b:SetScript("OnDragStop", function(s) s:SetScript("OnUpdate", nil) end)
    b:SetScript("OnClick", function(_, button)
      if button == "RightButton" then R:ToggleDrama()
      elseif IsShiftKeyDown and IsShiftKeyDown() then R:ToggleLore(true)
      else R.db.showBar = not R.db.showBar; R:Refresh() end
    end)
    b:SetScript("OnEnter", function(s)
      GameTooltip:SetOwner(s, "ANCHOR_LEFT")
      GameTooltip:SetText("StoryCaster", 0.93, 0.76, 0.38)
      GameTooltip:AddLine("Click: show or hide the panel", 1, 1, 1)
      GameTooltip:AddLine("Right-click: Drama", 1, 1, 1)
      GameTooltip:AddLine("Shift-click: Lore Library", 1, 1, 1)
      GameTooltip:AddLine("Drag: move this button", 0.7, 0.7, 0.7)
      GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    self.miniBtn = b
  end
  b.place()
  b:Show()
end

-- a window with a big text box (Reactions, and the mood words in My voice)
local function TextWindow(name, title, help, w, h, boxTop)
  local f = CreateFrame("Frame", name, UIParent)
  f:SetSize(w, h)
  f:SetPoint("CENTER", 0, 40)
  f:SetFrameStrata("DIALOG")
  f:SetToplevel(true)
  f:SetClampedToScreen(true)
  f:EnableMouse(true)
  f:SetMovable(true)
  f:RegisterForDrag("LeftButton")
  f:SetScript("OnDragStart", f.StartMoving)
  f:SetScript("OnDragStop", f.StopMovingOrSizing)
  tinsert(UISpecialFrames, name)
  Glass(f, 0.97, 40)
  local head = Text(f, 14, 0.88, 0.80, 1, "OUTLINE")
  head:SetPoint("LEFT", f, "TOPLEFT", 16, -20)
  head:SetText(title)
  local close = Btn(f, "x", 20, 20, function() f:Hide() end)
  close:SetPoint("RIGHT", f, "TOPRIGHT", -10, -20)
  local hp = Text(f, 10, 0.80, 0.78, 0.88)
  hp:SetPoint("TOPLEFT", 16, -52)
  hp:SetWidth(w - 32)
  if hp.SetWordWrap then hp:SetWordWrap(true) end
  if hp.SetSpacing then hp:SetSpacing(3) end
  hp:SetText(help)
  local box = CreateFrame("Frame", nil, f)
  box:SetPoint("TOPLEFT", 16, boxTop)
  box:SetPoint("BOTTOMRIGHT", -16, 48)
  local bbg = box:CreateTexture(nil, "BACKGROUND")
  bbg:SetAllPoints()
  bbg:SetColorTexture(0.01, 0.01, 0.03, 0.9)
  Edge(box, 0.36, 0.30, 0.50, 1)
  local scroll = CreateFrame("ScrollFrame", name .. "Scroll", box, "UIPanelScrollFrameTemplate")
  scroll:SetPoint("TOPLEFT", 6, -6)
  scroll:SetPoint("BOTTOMRIGHT", -26, 6)
  local edit = CreateFrame("EditBox", nil, scroll)
  edit:SetMultiLine(true)
  edit:SetAutoFocus(false)
  edit:SetFontObject(ChatFontNormal)
  edit:SetWidth(w - 74)
  edit:SetMaxLetters(0)
  edit:SetTextInsets(4, 4, 4, 4)
  edit:SetScript("OnEscapePressed", function(b) b:ClearFocus() end)
  if ScrollingEdit_OnTextChanged then edit:SetScript("OnTextChanged", function(b) ScrollingEdit_OnTextChanged(b, scroll) end) end
  if ScrollingEdit_OnCursorChanged then edit:SetScript("OnCursorChanged", ScrollingEdit_OnCursorChanged) end
  scroll:SetScrollChild(edit)
  box:EnableMouse(true)
  box:SetScript("OnMouseDown", function() edit:SetFocus() end)
  f.edit = edit
  f:Hide()
  return f
end

function R:ToggleReactions(show)
  if not self.reactWin then
    local f = TextWindow("StoryCasterReactions", "Reactions",
      "One per line:  waves = waves back at {sender}. [wave]    A word in quotes is something said near you:  \"hello\" = nods at {sender}. " ..
      "{sender} is who it came from. Emotes count only when aimed at you. Lines starting with -- are ignored.", 540, 420, -104)
    local save = Btn(f, "Save", 70, 26, function()
      R.db.reactionText = f.edit:GetText()
      R:Print("Reactions saved: " .. #R:Reactions() .. " rule" .. (#R:Reactions() == 1 and "" or "s") .. ".")
      f:Hide()
    end, "primary")
    save:SetPoint("BOTTOMLEFT", 16, 12)
    local def = Btn(f, "Put back the defaults", 150, 26, function() f.edit:SetText(R.DEFAULT_REACTIONS) end)
    def:SetPoint("LEFT", save, "RIGHT", 8, 0)
    f.toggle = Btn(f, "", 120, 26, function() R:SetReactions(not R.db.reactions); R:RefreshReactions() end)
    f.toggle:SetPoint("BOTTOMRIGHT", -16, 12)
    self.reactWin = f
  end
  local f = self.reactWin
  if show == true or not f:IsShown() then
    f.edit:SetText(self:ReactionText())
    f:Show()
    self:RefreshReactions()
  else f:Hide() end
end

function R:RefreshReactions()
  local f = self.reactWin
  if not f then return end
  f.toggle.text:SetText(self.db.reactions and "Reactions: On" or "Reactions: Off")
  f.toggle:Kind(self.db.reactions and "on" or nil)
end

function R:ToggleVoice(show)
  if not self.voiceWin then
    local f = TextWindow("StoryCasterVoice", "My Voice",
      "For this character only. {title} and {catchphrase} in any script fill in from here. Below, give any mood your own words, " ..
      "one mood per line:  Angry: through clenched teeth, coldly, with a dangerous smile   Moods you leave out use the built-in words.", 540, 460, -170)
    local tl = Text(f, 10, 0.85, 0.82, 0.95)
    tl:SetPoint("TOPLEFT", 16, -110)
    tl:SetText("Title")
    local title = CreateFrame("EditBox", nil, f, "InputBoxTemplate")
    title:SetSize(170, 20)
    title:SetPoint("LEFT", tl, "RIGHT", 12, 0)
    title:SetAutoFocus(false)
    title:SetMaxLetters(48)
    title:SetScript("OnEscapePressed", function(b) b:ClearFocus() end)
    f.title = title
    local cl = Text(f, 10, 0.85, 0.82, 0.95)
    cl:SetPoint("TOPLEFT", 16, -138)
    cl:SetText("Catchphrase")
    local catch = CreateFrame("EditBox", nil, f, "InputBoxTemplate")
    catch:SetSize(380, 20)
    catch:SetPoint("LEFT", cl, "RIGHT", 12, 0)
    catch:SetAutoFocus(false)
    catch:SetMaxLetters(160)
    catch:SetScript("OnEscapePressed", function(b) b:ClearFocus() end)
    f.catch = catch
    local save = Btn(f, "Save", 70, 26, function() R:SaveVoice(f.title:GetText(), f.catch:GetText(), f.edit:GetText()); f:Hide() end, "primary")
    save:SetPoint("BOTTOMLEFT", 16, 12)
    self.voiceWin = f
  end
  local f = self.voiceWin
  if show == true or not f:IsShown() then
    local v = self:Voice()
    f.title:SetText(v.title or "")
    f.catch:SetText(v.catch or "")
    local lines = {}
    for _, m in ipairs(self.MOODS) do
      local own = v.moods[m[1]]
      if type(own) == "table" and #own > 0 then lines[#lines + 1] = m[1] .. ": " .. table.concat(own, ", ") end
    end
    f.edit:SetText(table.concat(lines, "\n"))
    f:Show()
  else f:Hide() end
end

-- title, catchphrase, and "Mood: words, words" lines
function R:SaveVoice(title, catch, moodText)
  local v = self:Voice()
  v.title = (title or ""):gsub("|", ""):gsub("^%s+", ""):gsub("%s+$", "")
  v.catch = (catch or ""):gsub("|", ""):gsub("^%s+", ""):gsub("%s+$", "")
  v.moods = {}
  for line in ((moodText or "") .. "\n"):gmatch("([^\r\n]*)\r?\n") do
    local name, words = line:match("^%s*(%a+)%s*:%s*(.-)%s*$")
    local m = name and self:MoodList(name)
    if m and words ~= "" then
      local list = {}
      for raw in (words .. ","):gmatch("([^,]*),") do
        local w = raw:gsub("|", ""):gsub("^%s+", ""):gsub("%s+$", "")
        if w ~= "" then list[#list + 1] = w end
      end
      if #list > 0 then v.moods[m[1]] = list end
    end
  end
  self:Print("Your voice is saved for this character.")
  self:Refresh()
end

---------------------------------------------------------------------------
-- Drama: a slide-out beside the panel with three pages
---------------------------------------------------------------------------
local DW, DH = 340, 470
local PINK = { 1, 0.42, 0.72 }

function R:ToggleDrama(show)
  if not self.dramaWin then self:BuildDrama() end
  local f = self.dramaWin
  if show == true or (show == nil and not f:IsShown()) then
    self.db.showBar = true
    self:Refresh()
    self:HideSlideouts("drama") -- one slide-out at a time
    f:Show()
    f.slide:Stop(); f.slide:Play()
    self:ShowDramaPage(self.db.dramaPage or "queen")
  else f:Hide() end
end

function R:BuildDrama()
  local f = CreateFrame("Frame", "StoryCasterDrama", self.bar)
  f:SetSize(DW, DH)
  f:SetPoint("TOPLEFT", self.bar, "TOPRIGHT", 6, 0)
  f:SetClampedToScreen(true)
  f:EnableMouse(true)
  Glass(f, 0.97, 40)
  -- a pink wash over the glass
  local wash = f:CreateTexture(nil, "BACKGROUND", nil, 4)
  wash:SetPoint("TOPLEFT", 1, -41); wash:SetPoint("BOTTOMRIGHT", -1, 1)
  wash:SetTexture(WHITE)
  if wash.SetGradient and CreateColor and pcall(wash.SetGradient, wash, "VERTICAL", CreateColor(0.55, 0.08, 0.35, 0.18), CreateColor(0.55, 0.08, 0.35, 0.02)) then
  else wash:SetVertexColor(0.55, 0.08, 0.35, 0.08) end
  local head = Text(f, 15, PINK[1], PINK[2], PINK[3], "OUTLINE")
  head:SetPoint("LEFT", f, "TOPLEFT", 16, -20)
  head:SetText("Drama")
  local close = Btn(f, "x", 20, 20, function() f:Hide() end)
  close:SetPoint("RIGHT", f, "TOPRIGHT", -10, -20)
  -- it slides out from behind the panel
  local slide = f:CreateAnimationGroup()
  local s0 = slide:CreateAnimation("Translation"); s0:SetOffset(-36, 0); s0:SetDuration(0); s0:SetOrder(1)
  local s1 = slide:CreateAnimation("Translation"); s1:SetOffset(36, 0); s1:SetDuration(0.22); s1:SetOrder(2)
  if s1.SetSmoothing then s1:SetSmoothing("OUT") end
  local a0 = slide:CreateAnimation("Alpha"); a0:SetFromAlpha(0); a0:SetToAlpha(1); a0:SetDuration(0.22); a0:SetOrder(2)
  f.slide = slide

  f.tabs, f.pages = {}, {}
  local function tab(key, label, x)
    local b = Btn(f, label, 98, 22, function() R:ShowDramaPage(key) end)
    b:SetPoint("TOPLEFT", x, -50)
    f.tabs[key] = b
    local pg = CreateFrame("Frame", nil, f)
    pg:SetPoint("TOPLEFT", 0, -80); pg:SetPoint("BOTTOMRIGHT", 0, 0)
    pg:Hide()
    f.pages[key] = pg
    return pg
  end
  local W = DW - 32
  local function txt(parent, size, y, r, g, b)
    local t = Text(parent, size, r or 0.88, g or 0.86, b or 0.95)
    t:SetPoint("TOPLEFT", 16, y)
    t:SetWidth(W)
    if t.SetWordWrap then t:SetWordWrap(true) end
    if t.SetSpacing then t:SetSpacing(2) end
    return t
  end

  -- Drama Queen
  local q = tab("queen", "Drama Queen", 16)
  f.status = txt(q, 10, -4)
  f.guild = Btn(q, "Cause drama in guild", W, 26, function() local d = R:DramaDB(); d.toGuild = not d.toGuild; R:Refresh() end)
  f.guild:SetPoint("TOPLEFT", 16, -34)
  Tip(f.guild, "Cause drama in guild", "Posts the drama in guild chat. Only one copy in the guild speaks at a time (Drama Queen Pro copies count too).")
  f.public = Btn(q, "Cause drama publicly", W, 26, function()
    local d = R:DramaDB(); d.public = not d.public
    if d.public and not d.toEmote and not d.toSay then d.toEmote, d.toSay = true, true end
    R:Refresh()
  end)
  f.public:SetPoint("TOPLEFT", 16, -64)
  Tip(f.public, "Cause drama publicly", "Acts it out as an emote and says it in /say, so everyone nearby sees it. /say is automatic inside instances; outside, it waits for Deliver.")
  f.emoteT = Btn(q, "Emote", 70, 20, function() local d = R:DramaDB(); d.toEmote = not d.toEmote; R:Refresh() end)
  f.emoteT:SetPoint("TOPLEFT", 40, -94)
  f.sayT = Btn(q, "/say", 70, 20, function() local d = R:DramaDB(); d.toSay = not d.toSay; R:Refresh() end)
  f.sayT:SetPoint("LEFT", f.emoteT, "RIGHT", 6, 0)
  f.onoff = Btn(q, "Turn on", 92, 26, function() R:DramaEnable(not R:DramaDB().enabled) end, "drama")
  f.onoff:SetPoint("TOPLEFT", 16, -122)
  local now = Btn(q, "Drama now", 96, 26, function() R:DramaPost(true) end, "primary")
  now:SetPoint("LEFT", f.onoff, "RIGHT", 6, 0)
  Tip(now, "Drama now", "Causes one bit of drama right now, wherever your switches point.")
  f.sayIt = Btn(q, "Say it", 108, 26, function() if R.pending then R:DeliverPending() end end, "key")
  f.sayIt:SetPoint("LEFT", now, "RIGHT", 6, 0)
  local minus = Btn(q, "- 1 min", 66, 20, function() R:DramaMinutes(R:DramaDB().minutes - 1) end)
  minus:SetPoint("TOPLEFT", 16, -154)
  local plus = Btn(q, "+ 1 min", 66, 20, function() R:DramaMinutes(R:DramaDB().minutes + 1) end)
  plus:SetPoint("LEFT", minus, "RIGHT", 6, 0)
  f.last = txt(q, 10, -182)
  f.last:SetHeight(44)
  f.last:SetJustifyV("TOP")
  local qd = Text(q, 11, PINK[1], PINK[2], PINK[3], "OUTLINE")
  qd:SetPoint("TOPLEFT", 16, -232)
  qd:SetText("Queen Detector")
  f.queens = txt(q, 9, -250)
  f.queens:SetHeight(64)
  f.queens:SetJustifyV("TOP")
  local scan = Btn(q, "Scan", 54, 20, function() R:DramaScan(); R:Print("Scanning for other Drama Queens...") end)
  scan:SetPoint("TOPLEFT", 16, -320)
  f.main = Btn(q, "Main voice", 84, 20, function() local d = R:DramaDB(); d.mainVoice = not d.mainVoice; R:Refresh() end)
  f.main:SetPoint("LEFT", scan, "RIGHT", 6, 0)
  Tip(f.main, "Main voice", "This character does the guild's drama, ahead of the other copies online.")
  f.net = Btn(q, "Network", 74, 20, function() R:DramaNetwork(not R:DramaDB().network); R:Refresh() end)
  f.net:SetPoint("LEFT", f.main, "RIGHT", 6, 0)
  Tip(f.net, "Drama Queen network", "Joins a hidden chat channel (kept out of your chat windows) to find Drama Queens outside your guild.")
  local warn = txt(q, 9, -350, 0.70, 0.64, 0.74)
  warn:SetText("Drama posts real-sounding personal drama where others can see it. Use at your own risk, and turn it off before it gets you in trouble.")

  -- Paranoid
  local pa = tab("paranoid", "Paranoid", 120)
  f.who = txt(pa, 13, -4, 1, 0.85, 0.4)
  f.act = txt(pa, 10, -26)
  f.paraBar = Bar(pa, W, 6, PINK[1], PINK[2], PINK[3])
  f.paraBar:SetPoint("TOPLEFT", 16, -46)
  f.paraStart = Btn(pa, "Start", 66, 26, function()
    local run = R.run
    if run and run.opts and run.opts.paranoid then R:TogglePlay() else R:ParanoidStart() end
  end, "drama")
  f.paraStart:SetPoint("TOPLEFT", 16, -62)
  local nx = Btn(pa, "Next", 54, 26, function() if R.run and R.run.opts and R.run.opts.paranoid then R:Skip() end end)
  nx:SetPoint("LEFT", f.paraStart, "RIGHT", 6, 0)
  local skip = Btn(pa, "Skip act", 72, 26, function() R:ParanoidSkipAct() end)
  skip:SetPoint("LEFT", nx, "RIGHT", 6, 0)
  local stop = Btn(pa, "Stop", 54, 26, function() if R.run and R.run.opts and R.run.opts.paranoid then R:Stop() end end, "stop")
  stop:SetPoint("LEFT", skip, "RIGHT", 6, 0)
  f.quiet = Btn(pa, "Inner monologue", W, 24, function() local d = R:DramaDB(); d.paranoidQuiet = not d.paranoidQuiet; R:Refresh() end)
  f.quiet:SetPoint("TOPLEFT", 16, -98)
  Tip(f.quiet, "Inner monologue", "The thoughts print only in your own chat: nobody else sees them. Takes effect the next time you press Start.")
  f.paraLine = txt(pa, 10, -132)
  f.paraLine:SetHeight(60)
  f.paraLine:SetJustifyV("TOP")
  local pnote = txt(pa, 9, -200, 0.70, 0.66, 0.80)
  pnote:SetText("Target someone and press Start: five acts of growing suspicion, from a nervous glance to light trash talk. " ..
    "It runs on the panel's own timer (never faster than one line every " .. R.MIN_GAP .. " seconds), so Pause, Scenes and Deliver work too.")

  -- Brain Rot
  local br = tab("rot", "Brain Rot", 224)
  f.rot = Btn(br, "BRAIN ROT", W, 46, function() R:BrainRot() end, "drama")
  f.rot:SetPoint("TOPLEFT", 16, -8)
  f.rot.text:SetFont(FONT, 16, "OUTLINE")
  Tip(f.rot, "Brain Rot", "Says or emotes one random line of brain rot, aimed at your target. It recharges for " .. R.ROT_GAP .. " seconds after each one.")
  f.rotModes = {}
  local modes = { { "say", "Say it" }, { "emote", "Emote it" }, { "mix", "Mix" } }
  for i, m in ipairs(modes) do
    local b = Btn(br, m[2], 96, 22, function() R:DramaDB().rotMode = m[1]; R:Refresh() end)
    b:SetPoint("TOPLEFT", 16 + (i - 1) * 104, -62)
    b.mode = m[1]
    f.rotModes[i] = b
  end
  f.rotLast = txt(br, 11, -96)
  f.rotLast:SetHeight(70)
  f.rotLast:SetJustifyV("TOP")
  local rnote = txt(br, 9, -176, 0.70, 0.66, 0.80)
  rnote:SetText(#self.DRAMA.rot .. " lines of brain rot. Your target's name goes where the line roasts someone. Say it posts in /say; Emote it acts it out with an animation.")

  f:SetScript("OnShow", function() R:RefreshDrama() end)
  f:Hide()
  self.dramaWin = f
end

function R:ShowDramaPage(key)
  local f = self.dramaWin
  if not f then return end
  self.db.dramaPage = key
  for k, pg in pairs(f.pages) do if k == key then pg:Show() else pg:Hide() end end
  for k, b in pairs(f.tabs) do b:Kind(k == key and "drama" or nil) end
  self:RefreshDrama()
end

-- the parts that tick: countdowns and the Say it button
function R:RefreshDramaTimer()
  local f = self.dramaWin
  if not (f and f:IsShown()) then return end
  local d = self:DramaDB()
  local secs = math.max(0, math.floor((self.dramaNext or 0) - GetTime()))
  local leader = self:DramaLeader()
  f.status:SetText((d.enabled and ("|cffff6bb8On|r  ·  every %d min  ·  next in %d:%02d  ·  posts %d"):format(d.minutes, math.floor(secs / 60), secs % 60, d.posted)
    or ("|cff888888Off|r  ·  every %d min  ·  posts %d"):format(d.minutes, d.posted)) ..
    (leader ~= (UnitName("player") or "") and d.toGuild and ("\n|cffffcc55" .. leader .. " is causing the guild's drama (one voice per guild)|r") or ""))
  local wait = self:RotWait()
  f.rot.text:SetText(wait > 0 and ("BRAIN ROT  " .. math.ceil(wait) .. "s") or "BRAIN ROT")
  f.rot:SetAlpha(wait > 0 and 0.6 or 1)
  local pend = self.pending and self.pending[4] == "SAY"
  f.sayIt:SetAlpha(pend and 1 or 0.4)
  f.sayIt.text:SetText(pend and "Say it!" or "Say it")
  if self.bar and self.bar.lore and self.bar.lore:IsShown() then self:RefreshLore() end
end

function R:RefreshDrama()
  local f = self.dramaWin
  if not (f and f:IsShown()) then return end
  local d = self:DramaDB()
  f.guild:Kind(d.toGuild and "drama" or nil)
  f.guild.text:SetText((d.toGuild and "[x]  " or "[  ]  ") .. "Cause drama in guild")
  f.public:Kind(d.public and "drama" or nil)
  f.public.text:SetText((d.public and "[x]  " or "[  ]  ") .. "Cause drama publicly")
  f.emoteT:Kind(d.toEmote and "on" or nil); f.emoteT:SetAlpha(d.public and 1 or 0.4)
  f.sayT:Kind(d.toSay and "on" or nil); f.sayT:SetAlpha(d.public and 1 or 0.4)
  f.onoff.text:SetText(d.enabled and "Turn off" or "Turn on")
  f.main:Kind(d.mainVoice and "on" or nil)
  f.net:Kind(d.network and "on" or nil)
  f.last:SetText("|cffff9fd0Last:|r " .. (d.last or "Nothing yet.") ..
    ((self.pending and self.pending[4] == "SAY") and ("\n|cffff9fd0Waiting to be said:|r " .. self.pending[1]) or ""))
  local total, online = self:QueenCounts()
  local list = {}
  for n, qq in pairs(self.queens) do list[#list + 1] = { n = n, q = qq } end
  table.sort(list, function(a, b) return a.q.t > b.q.t end)
  local rows = { ("%d other Drama Queen%s detected  ·  %d online now"):format(total, total == 1 and "" or "s", online) }
  for i = 1, math.min(3, #list) do
    local e = list[i]
    rows[#rows + 1] = ((GetTime() - e.q.t < 300) and "|cff7dff7d" or "|cff888888") .. e.n .. "|r  " .. e.q.where .. "  v" .. e.q.ver
  end
  if #list > 3 then rows[#rows + 1] = "... and " .. (#list - 3) .. " more" end
  f.queens:SetText(table.concat(rows, "\n"))
  -- Paranoid
  local run = self.run
  local para = run and run.opts and run.opts.paranoid
  if para then
    f.who:SetText("Watching: " .. run.name:gsub("^Paranoid: ", ""))
    local act = "Act I"
    for i = 1, math.min(run.i + 1, #run.lines) do if run.lines[i][6] then act = run.lines[i][6] end end
    f.act:SetText(act .. "  ·  " .. (self.state == "paused" and "|cffffd100paused|r" or self.state == "waiting" and "|cffff8080waiting|r" or "|cff80ff80watching|r"))
    f.paraBar:SetValue(run.i / #run.lines)
    local cur = run.lines[run.i]
    f.paraLine:SetText(cur and ("|cffc9a8ff\"|r" .. self:Render(cur[1]) .. "|cffc9a8ff\"|r") or "")
    f.paraStart.text:SetText(self.state == "paused" and "Resume" or "Pause")
  else
    local t = self:Target()
    f.who:SetText(t and ("Target: " .. t) or "|cffaaaaaaTarget someone suspicious|r")
    f.act:SetText("Five acts of growing concern")
    f.paraBar:SetValue(0)
    f.paraLine:SetText("Target a player and press Start. Your character slowly becomes convinced they are up to something.")
    f.paraStart.text:SetText("Start")
  end
  f.quiet:Kind(d.paranoidQuiet and "on" or nil)
  -- Brain Rot
  for _, b in ipairs(f.rotModes) do b:Kind(d.rotMode == b.mode and "drama" or nil) end
  f.rotLast:SetText(self.lastRot and ("|cffff9fd0Last:|r " .. self.lastRot) or "Press the button. Become the brain rot.")
  self:RefreshDramaTimer()
end

---------------------------------------------------------------------------
-- The theme bar under the header: Drama, Pirate, Love, War, Peace, Dungeon; each slides out its own panel
---------------------------------------------------------------------------
local BAR = {
  { "drama", "Drama", "drama", "drama", "Drama Queen, Paranoid and Brain Rot: drama on a timer, five acts of suspicion about your target, and brain rot." },
  { "pirate", "Pirate", "skull", "pirate", "Pirate lines in twelve categories, scenes, and a pirate accent for everything you say." },
  { "love", "Love", "heart", "love", "Flirting, compliments, courtship, longing, heartbreak and devotion." },
  { "war", "War", "swords", "war", "Battle cries, the eve of battle, the fray, taunts, victory and the aftermath." },
  { "peace", "Peace", "dove", "peace", "Peaceful greetings, stillness, wisdom, mending quarrels, blessings, rest and nature." },
  { "nsfw", "NSFW", "cocktail", "night", "18+ After Dark: drinking, go-go dancing, cheeky flirting, dares, bar brawls and the morning after. Cheeky, never explicit." },
  { "dungeon", "Dungeon", "dungeon", "blue", "One-click group chat: GG, interrupt!, need that?, brb, sorry, grats, hello, goodbye and more." },
}

function R:BuildThemeBar(p)
  local f = Section(p, 40)
  p.themebar = f
  local n = #BAR
  local w = math.floor((PW - PAD * 2 - (n - 1) * 6) / n)
  p.themeBtns = {}
  for i, b in ipairs(BAR) do
    local key = b[1]
    local btn = Btn(f, b[2], w, 28, function() R:ToggleSlideout(key) end, b[4], b[3], { iconSize = 13, size = 10 })
    btn:SetPoint("TOPLEFT", PAD + (i - 1) * (w + 6), -6)
    local count = key ~= "drama" and key ~= "dungeon" and R:ThemeCount(key)
    if key == "nsfw" then btn:SetAlpha(0.85) end
    Tip(btn, b[2], (count and (count .. " lines. ") or "") .. b[5])
    p.themeBtns[key] = btn
  end
  p.dramaBtn, p.pirateBtn = p.themeBtns.drama, p.themeBtns.pirate
end

-- one slide-out at a time
function R:HideSlideouts(except)
  if except ~= "drama" and self.dramaWin then self.dramaWin:Hide() end
  if except ~= "dungeon" and self.dungeonWin then self.dungeonWin:Hide() end
  for k, w in pairs(self.themeWins or {}) do if k ~= except then w:Hide() end end
end

function R:ToggleSlideout(key)
  if key == "drama" then self:ToggleDrama()
  elseif key == "dungeon" then self:ToggleDungeon()
  else self:ToggleTheme(key) end
end

local function SlideAnim(f)
  local slide = f:CreateAnimationGroup()
  local s0 = slide:CreateAnimation("Translation"); s0:SetOffset(-36, 0); s0:SetDuration(0); s0:SetOrder(1)
  local s1 = slide:CreateAnimation("Translation"); s1:SetOffset(36, 0); s1:SetDuration(0.22); s1:SetOrder(2)
  if s1.SetSmoothing then s1:SetSmoothing("OUT") end
  local a0 = slide:CreateAnimation("Alpha"); a0:SetFromAlpha(0); a0:SetToAlpha(1); a0:SetDuration(0.22); a0:SetOrder(2)
  f.slide = slide
end

local WASH = { nsfw = { 0.55, 0.05, 0.50 }, pirate = { 0.05, 0.30, 0.32 }, love = { 0.55, 0.10, 0.25 }, war = { 0.50, 0.10, 0.06 }, peace = { 0.20, 0.45, 0.30 }, dungeon = { 0.10, 0.20, 0.50 } }
local function Wash(f, key)
  local c = WASH[key] or WASH.pirate
  local wash = f:CreateTexture(nil, "BACKGROUND", nil, 4)
  wash:SetPoint("TOPLEFT", 1, -41); wash:SetPoint("BOTTOMRIGHT", -1, 1)
  wash:SetTexture(WHITE)
  if wash.SetGradient and CreateColor and pcall(wash.SetGradient, wash, "VERTICAL", CreateColor(c[1], c[2], c[3], 0.20), CreateColor(c[1], c[2], c[3], 0.03)) then
  else wash:SetVertexColor(c[1], c[2], c[3], 0.08) end
end

local function SlideHeader(f, title, icon)
  local ic = f:CreateTexture(nil, "ARTWORK")
  ic:SetTexture(MEDIA .. icon); ic:SetSize(22, 22); ic:SetPoint("LEFT", f, "TOPLEFT", 14, -20)
  ic:SetVertexColor(GOLD_HI[1], GOLD_HI[2], GOLD_HI[3])
  local head = Text(f, 15, GOLD_HI[1], GOLD_HI[2], GOLD_HI[3], "OUTLINE")
  head:SetPoint("LEFT", ic, "RIGHT", 8, 0)
  head:SetText(title)
  local close = Btn(f, "", 24, 24, function() f:Hide() end, "key", "close", { iconSize = 12 })
  close:SetPoint("RIGHT", f, "TOPRIGHT", -12, -20)
end

---------------------------------------------------------------------------
-- A theme's slide-out (Pirate, Love, War, Peace): a big button, Say/Emote/Mix, and a row per category
---------------------------------------------------------------------------
function R:ToggleTheme(key, show)
  local meta = self:ThemeMeta(key)
  -- the 18+ tab asks once before it opens
  if meta and meta.adult and not self.db.adultOK then
    if StaticPopupDialogs and StaticPopup_Show then
      StaticPopupDialogs.STORYCASTER_ADULT = {
        text = "After Dark has adult-themed lines: drinking, club dancing, cheeky flirting, dares and brawls. Nothing explicit.\n\nOnly open it if you are 18 or older, and keep anything you post in public within the game's chat rules.",
        button1 = "I'm 18+, open it", button2 = "Cancel", timeout = 0, whileDead = true, hideOnEscape = true, preferredIndex = 3,
        OnAccept = function() R.db.adultOK = true; R:ToggleTheme(key, true) end,
      }
      StaticPopup_Show("STORYCASTER_ADULT")
    end
    return
  end
  self.themeWins = self.themeWins or {}
  if not self.themeWins[key] then self:BuildTheme(key) end
  local f = self.themeWins[key]
  if show == true or (show == nil and not f:IsShown()) then
    self.db.showBar = true
    self:Refresh()
    self:HideSlideouts(key)
    f:Show(); f.slide:Stop(); f.slide:Play()
    self:RefreshThemes()
  else f:Hide() end
end
function R:TogglePirate(show) return self:ToggleTheme("pirate", show) end

function R:BuildTheme(key)
  local meta, data = self:ThemeMeta(key), self:ThemeData(key)
  local cats = data.cats
  local W, RH = 360, 28
  local top = meta.accent and 162 or 134
  local f = CreateFrame("Frame", meta.frame or ("StoryCaster" .. meta.title), self.bar)
  f:SetSize(W, top + #cats * RH + 56)
  f:SetPoint("TOPLEFT", self.bar, "TOPRIGHT", 6, 0)
  f:SetClampedToScreen(true)
  f:EnableMouse(true)
  Glass(f, 0.97, 40)
  Wash(f, key)
  SlideHeader(f, meta.title, meta.icon)
  SlideAnim(f)
  f.key = key
  f.big = Btn(f, meta.big, W - 32, 40, function() R:ThemeLine(key) end, meta.kind, meta.bigIcon, { size = 16, burst = 10 })
  f.big:SetPoint("TOPLEFT", 16, -50)
  f.big.label = meta.big
  f.arr = f.big
  Tip(f.big, meta.big, "One random line from any " .. meta.title:lower() .. " category, at your target. It rests " .. R.THEME_GAP .. " seconds after each one.")
  f.modes = {}
  for i, m in ipairs({ { "say", "Say it" }, { "emote", "Emote it" }, { "mix", "Mix" } }) do
    local b = Btn(f, m[2], 104, 24, function() R:ThemeDB(key).mode = m[1]; R:RefreshThemes() end)
    b:SetPoint("TOPLEFT", 16 + (i - 1) * 112, -98)
    b.mode = m[1]
    Tip(b, m[2], m[1] == "say" and "Spoken lines are said aloud in /say." or m[1] == "emote" and "Spoken lines become 'says, ...' emotes." or "A mix of both.")
    f.modes[i] = b
  end
  if meta.accent then
    f.accent = Btn(f, "Pirate accent: Off", W - 32, 24, function() R:TogglePirateAccent() end, nil, "parrot")
    f.accent:SetPoint("TOPLEFT", 16, -128)
    Tip(f.accent, "Pirate accent", "Everything you say comes out in pirate: you becomes ye, hello becomes ahoy, my becomes me, sailing becomes sailin'. Works on every script, not only these lines.")
  end
  for i, c in ipairs(cats) do
    local y = -top - (i - 1) * RH
    local t = Btn(f, c.title, W - 32 - 124, RH - 4, function() R:ThemeLine(key, c.key) end, nil, c.icon, { iconSize = 15 })
    t:SetPoint("TOPLEFT", 16, y)
    Tip(t, c.title, #c.lines .. " lines. Click for one now.")
    local one = Btn(f, "Line", 56, RH - 4, function() R:ThemeLine(key, c.key) end, "key")
    one:SetPoint("LEFT", t, "RIGHT", 4, 0)
    local sc = Btn(f, "Scene", 60, RH - 4, function() R:ThemeScene(key, c.key) end, meta.kind)
    sc:SetPoint("LEFT", one, "RIGHT", 4, 0)
    Tip(sc, "Scene", "A dozen " .. c.title:lower() .. " lines, performed on your timer.")
  end
  f.last = Text(f, 10, 0.86, 0.84, 0.95)
  f.last:SetPoint("BOTTOMLEFT", 16, 12)
  f.last:SetWidth(W - 32)
  f.last:SetHeight(36)
  f.last:SetJustifyV("TOP")
  f:SetScript("OnUpdate", function(s, el)
    s.acc = (s.acc or 0) + el
    if s.acc < 0.2 then return end
    s.acc = 0
    local w = R:ThemeWait()
    s.big.text:SetText(w > 0 and (s.big.label .. "  " .. math.ceil(w) .. "s") or s.big.label)
    s.big:SetAlpha(w > 0 and 0.6 or 1)
  end)
  f:Hide()
  self.themeWins[key] = f
end

function R:RefreshThemes()
  for key, f in pairs(self.themeWins or {}) do
    if f:IsShown() then
      local d = self:ThemeDB(key)
      local meta = self:ThemeMeta(key)
      for _, b in ipairs(f.modes) do b:Kind(d.mode == b.mode and meta.kind or nil) end
      if f.accent then
        f.accent.text:SetText("Pirate accent: " .. (d.accent and "On" or "Off"))
        f.accent:Kind(d.accent and "key" or nil)
      end
      local last = self.themeLast and self.themeLast[key]
      f.last:SetText(last and ("|cffeec060" .. last.cat .. ":|r " .. last.text) or (self:ThemeCount(key) .. " lines. " .. meta.blurb))
    end
  end
  self:RefreshDungeon()
end
function R:RefreshPirate() self:RefreshThemes() end

---------------------------------------------------------------------------
-- Dungeon: a grid of phrase buttons, eight groups, straight into your group's chat
---------------------------------------------------------------------------
function R:ToggleDungeon(show)
  if not self.dungeonWin then self:BuildDungeon() end
  local f = self.dungeonWin
  if show == true or (show == nil and not f:IsShown()) then
    self.db.showBar = true
    self:Refresh()
    self:HideSlideouts("dungeon")
    f:Show(); f.slide:Stop(); f.slide:Play()
    self:RefreshDungeon()
  else f:Hide() end
end

function R:BuildDungeon()
  local W, COLS, BH = 380, 4, 24
  local bw = math.floor((W - 32 - (COLS - 1) * 4) / COLS)
  local y = -76
  local f = CreateFrame("Frame", "StoryCasterDungeon", self.bar)
  f:SetClampedToScreen(true)
  f:EnableMouse(true)
  Glass(f, 0.97, 40)
  Wash(f, "dungeon")
  SlideHeader(f, "Dungeon", "dungeon")
  SlideAnim(f)
  f.chan = Text(f, 10, 0.80, 0.78, 0.90)
  f.chan:SetPoint("TOPLEFT", 16, -52)
  f.chan:SetWidth(W - 32)
  f.btns = {}
  for gi, g in ipairs(self.DUNGEON) do
    local lab = Text(f, 11, GOLD_HI[1], GOLD_HI[2], GOLD_HI[3])
    lab:SetPoint("TOPLEFT", 18, y)
    lab:SetText(g[1])
    y = y - 16
    for i, b in ipairs(g[2]) do
      local col, row = (i - 1) % COLS, math.floor((i - 1) / COLS)
      local btn = Btn(f, b[1], bw, BH, function() R:DungeonSay(gi, i) end, g[1] == "Combat" and "stop" or g[1] == "Thanks" and "go" or nil, nil, { size = 10, burst = 3 })
      btn:SetPoint("TOPLEFT", 16 + col * (bw + 4), y - row * (BH + 4))
      Tip(btn, b[1], "Says one of:\n" .. table.concat(b[2], "\n"))
      f.btns[#f.btns + 1] = btn
    end
    y = y - math.ceil(#g[2] / COLS) * (BH + 4) - 6
  end
  f.last = Text(f, 10, 0.86, 0.84, 0.95)
  f.last:SetPoint("TOPLEFT", 16, y - 4)
  f.last:SetWidth(W - 32)
  f:SetSize(W, -y + 34)
  f:SetPoint("TOPLEFT", self.bar, "TOPRIGHT", 6, 0)
  f:Hide()
  self.dungeonWin = f
end

function R:RefreshDungeon()
  local f = self.dungeonWin
  if not (f and f:IsShown()) then return end
  local chan = self:GroupChannel()
  local names = { INSTANCE_CHAT = "instance chat", RAID = "raid chat", PARTY = "party chat" }
  f.chan:SetText(chan and ("Speaking in |cff7fd8ff" .. names[chan] .. "|r. Hover a button to see what it can say.")
    or "|cffff7777You're not in a group.|r These buttons speak in party, raid or instance chat.")
  f.last:SetText(self.lastDungeon and ("|cffeec060Last:|r " .. self.lastDungeon) or "")
end
