-- StoryCaster: Ideas. Reads another player's RP profile (Total RP 3, or MyRolePlay / XRP through MSP) and suggests
-- openers made from it; gives random scene prompts; and finds your own RP name and title for {name} and {title}.
-- Nothing is sent anywhere: it only reads what your RP addon already knows.
local ADDON, ns = ...
local R = ns.R

local function secret(v) return v ~= nil and issecretvalue and issecretvalue(v) end

-- profile text without colour codes, links, pictures, TRP3 tags or line breaks
local function clean(s)
  if type(s) ~= "string" or secret(s) then return nil end
  s = s:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("|T.-|t", ""):gsub("|H.-|h(.-)|h", "%1"):gsub("{.-}", " "):gsub("|", "")
  s = s:gsub("[\r\n]+", " "):gsub("%s%s+", " "):gsub("^%s+", ""):gsub("%s+$", "")
  if s == "" then return nil end
  return s
end
R.CleanProfileText = clean

local function short(s, n)
  if not s then return nil end
  if #s > n then s = (s:sub(1, n):match("^(.*)%s") or s:sub(1, n)) .. "..." end
  return s
end

local function fullName(unit)
  local name, realm = UnitName(unit)
  if not name or secret(name) then return nil end
  if realm and realm ~= "" and not secret(realm) then return name .. "-" .. realm end
  local myRealm = GetNormalizedRealmName and GetNormalizedRealmName() or (GetRealmName and GetRealmName() or "")
  myRealm = (myRealm or ""):gsub("%s", "")
  return myRealm ~= "" and (name .. "-" .. myRealm) or name
end

---------------------------------------------------------------------------
-- Reading a profile
---------------------------------------------------------------------------
local function fromTRP3(unit)
  if not (TRP3_API and TRP3_API.register) then return nil end
  local ok, data = pcall(function()
    if unit == "player" then return TRP3_API.profile and TRP3_API.profile.getData and TRP3_API.profile.getData("player") end
    local id = TRP3_API.utils and TRP3_API.utils.str and TRP3_API.utils.str.getUnitID and TRP3_API.utils.str.getUnitID(unit)
    if not id then return nil end
    if TRP3_API.register.isUnitIDKnown and not TRP3_API.register.isUnitIDKnown(id) then return nil end
    if TRP3_API.register.hasProfile and not TRP3_API.register.hasProfile(id) then return nil end
    return TRP3_API.register.getUnitIDCurrentProfile and TRP3_API.register.getUnitIDCurrentProfile(id)
  end)
  if not ok or type(data) ~= "table" then return nil end
  local c = type(data.characteristics) == "table" and data.characteristics or {}
  local p = { source = "Total RP 3" }
  local function s(v) return type(v) == "string" and v or "" end
  p.name = clean(s(c.FN) .. " " .. s(c.LN))
  p.title, p.fullTitle = clean(c.TI), clean(c.FT)
  p.race, p.class, p.age = clean(c.RA), clean(c.CL), clean(c.AG)
  p.eyes, p.height, p.home, p.birthplace = clean(c.EC), clean(c.HE), clean(c.RE), clean(c.BP)
  p.misc = {}
  if type(c.MI) == "table" then
    for _, m in ipairs(c.MI) do
      if type(m) == "table" and clean(m.NA) and clean(m.VA) then p.misc[#p.misc + 1] = { clean(m.NA), clean(m.VA) } end
    end
  end
  local ch = type(data.character) == "table" and data.character or {}
  p.currently, p.ooc = clean(ch.CU), clean(ch.CO)
  local a = type(data.about) == "table" and data.about or {}
  local parts = {}
  if type(a.T1) == "table" then parts[#parts + 1] = clean(a.T1.TX) end
  if type(a.T2) == "table" then for _, t in ipairs(a.T2) do if type(t) == "table" then parts[#parts + 1] = clean(t.TX) end end end
  if type(a.T3) == "table" then
    for _, k in ipairs({ "PH", "PS", "HI" }) do if type(a.T3[k]) == "table" then parts[#parts + 1] = clean(a.T3[k].TX) end end
  end
  local text = {}
  for _, t in ipairs(parts) do if t then text[#text + 1] = t end end
  p.text = short(clean(table.concat(text, " ")), 2000)
  return p
end

local MSP_FIELDS = { "NA", "NT", "NH", "RA", "RC", "AG", "AE", "AH", "HH", "HB", "CU", "CO", "DE", "HI", "MO", "NI" }
local function fromMSP(unit)
  if not (type(msp) == "table") then return nil end
  local f
  if unit == "player" then f = type(msp.my) == "table" and msp.my
  else
    local who = fullName(unit)
    if not who then return nil end
    if msp.Request then pcall(msp.Request, msp, who, MSP_FIELDS) end
    local c = type(msp.char) == "table" and msp.char[who]
    f = c and type(c.field) == "table" and c.field
  end
  if not f then return nil end
  local p = { source = "MyRolePlay" }
  p.name, p.title, p.race, p.class, p.age = clean(f.NA), clean(f.NT), clean(f.RA), clean(f.RC), clean(f.AG)
  p.eyes, p.height, p.home, p.birthplace = clean(f.AE), clean(f.AH), clean(f.HH), clean(f.HB)
  p.currently, p.ooc = clean(f.CU), clean(f.CO)
  p.misc = {}
  if clean(f.MO) then p.misc[#p.misc + 1] = { "Motto", clean(f.MO) } end
  if clean(f.NI) then p.misc[#p.misc + 1] = { "Nickname", clean(f.NI) } end
  if clean(f.NH) then p.misc[#p.misc + 1] = { "House", clean(f.NH) } end
  local function s(v) return type(v) == "string" and v or "" end
  p.text = short(clean(s(f.DE) .. " " .. s(f.HI)), 2000)
  if not (p.name or p.title or p.text or p.currently) then return nil end
  return p
end

-- the profile of a unit ("target" by default): from Total RP 3, then MSP, then the plain game details
function R:ReadProfile(unit)
  unit = unit or "target"
  if not UnitExists(unit) or (UnitIsPlayer and not UnitIsPlayer(unit)) then return nil, "Target another player first." end
  if unit ~= "player" and UnitIsUnit and UnitIsUnit(unit, "player") then return nil, "That's you. Target another player." end
  local name = UnitName(unit)
  if not name or secret(name) then return nil, "That name can't be read right now." end
  local p = fromTRP3(unit) or fromMSP(unit)
  if not p then p = { source = "the game", misc = {} } end
  p.charName = name
  p.name = p.name or name
  local function g(v) if v and not secret(v) and v ~= "" then return v end end
  p.race = p.race or g(UnitRace and UnitRace(unit))
  p.class = p.class or g(UnitClass and UnitClass(unit))
  p.guild = g(GetGuildInfo and GetGuildInfo(unit))
  return p
end

-- your own RP name and title (Total RP 3 or MSP), for {name} and {title}
function R:RPName()
  if self.db and self.db.rpName == false then return nil end
  local p = fromTRP3("player") or fromMSP("player")
  return p and p.name, p and (p.title or p.fullTitle)
end

---------------------------------------------------------------------------
-- Suggestions made from a profile
-- [N] name, [T] title, [R] race, [C] class, [E] eyes, [H] home, [B] birthplace, [A] age, [G] guild, [M] motto.
-- A line that names something the profile doesn't have is left out.
---------------------------------------------------------------------------
local THEMES = {
  { key = "knight", words = { "knight", "paladin", "oath", "honor", "honour", "crusade", "squire", "light", "templar", "vow" }, title = "A Matter of Honor", lines = {
    "straightens at the sight of [N] and offers a respectful nod. [nod]",
    "says <mood>, \"You carry yourself like someone who has sworn an oath. [T], is it?\"",
    "says, \"Tell me, what does a vow mean to you, when no one is watching?\"",
    "rests a hand over their heart, waiting for the answer." } },
  { key = "scholar", words = { "mage", "scholar", "book", "library", "study", "arcane", "research", "tome", "magister", "kirin", "student", "learned" }, title = "A Question of Learning", lines = {
    "notices the ink on [N]'s fingers, or the look of someone who reads too late into the night.",
    "says <mood>, \"Forgive me. You look like someone who knows things. Useful things.\"",
    "says, \"I've a question that's been bothering me for weeks. Might I borrow your mind for a moment?\"",
    "pulls out a battered notebook, pen ready." } },
  { key = "sailor", words = { "sea", "ship", "sail", "captain", "pirate", "boat", "harbor", "harbour", "kul tiras", "boralus", "admiral", "deck", "crew" }, title = "Salt in the Air", lines = {
    "catches a whiff of salt and tar near [N] and grins.",
    "says <mood>, \"You've spent time on the water. I can always tell. It's in the way you stand.\"",
    "says, \"What ship? Or should I not ask?\"",
    "leans on the nearest post, as though it were a ship's rail. [chuckle]" } },
  { key = "drinker", words = { "tavern", "ale", "drink", "drunk", "brew", "inn", "bar", "wine", "whiskey", "mead", "barkeep" }, title = "A Round on Me", lines = {
    "spots [N] and raises a mug in greeting. [cheer]",
    "says <mood>, \"You look like someone who appreciates a good drink. Or a bad one. I don't judge.\"",
    "says, \"Next round's on me, if you've a story worth hearing.\"",
    "slides a mug across toward [N]." } },
  { key = "shadow", words = { "thief", "rogue", "shadow", "assassin", "spy", "secret", "hidden", "dagger", "smuggler", "agent", "mysterious", "unknown", "hooded" }, title = "Something Hidden", lines = {
    "keeps half an eye on [N], the way you watch someone who might be watching you.",
    "says <mood>, \"You've got the look of someone with secrets. Don't worry, I won't ask for all of them.\"",
    "says, \"Just one. Pick whichever you like least.\"",
    "smiles, very slightly. [chuckle]" } },
  { key = "healer", words = { "healer", "priest", "medic", "nurse", "herb", "doctor", "mend", "surgeon", "cleric", "apothecary", "physician", "remedy" }, title = "A Steady Hand", lines = {
    "winces, rubbing an old wound, and glances hopefully at [N].",
    "says <mood>, \"Someone told me you know your way around a bandage.\"",
    "says, \"Nothing serious. Probably. Though it does make a strange noise when I bend it.\"",
    "holds out the arm in question, a little sheepish. [shrug]" } },
  { key = "noble", words = { "noble", "lord", "lady", "house", "heir", "court", "baron", "duke", "count", "prince", "princess", "estate", "aristocrat" }, title = "Manners at Court", lines = {
    "notices the fine cut of [N]'s clothes and stands a little straighter.",
    "bows, perhaps a touch too deeply. [bow]",
    "says <mood>, \"[T]. An honor. I'm told one should address you properly. I'm afraid I never learned how.\"",
    "says, \"Teach me, and I'll owe you a favor.\"" } },
  { key = "soldier", words = { "soldier", "army", "veteran", "war", "guard", "sergeant", "captain", "legion", "regiment", "watch", "front", "battle", "marine" }, title = "Old Soldiers", lines = {
    "recognizes something in the way [N] scans the room: the habit of someone who's stood a watch.",
    "says <mood>, \"Where did you serve? You've got the look.\"",
    "says, \"I won't ask what you saw. Only whether the food was as bad as I remember.\"",
    "offers a brisk salute. [salute]" } },
  { key = "merchant", words = { "merchant", "trade", "gold", "shop", "coin", "business", "vendor", "goods", "caravan", "profit", "market" }, title = "A Business Proposition", lines = {
    "sizes up [N] with a merchant's eye, then puts on a friendly smile.",
    "says <mood>, \"I hear you're someone who knows the value of a coin.\"",
    "says, \"I have a proposition. It's either very clever or very stupid. I need a second opinion.\"",
    "rubs their hands together hopefully." } },
  { key = "bard", words = { "bard", "music", "song", "lute", "sing", "singer", "poet", "poetry", "dance", "perform", "stage", "actor" }, title = "A Song Request", lines = {
    "hums a few bars of something, glancing over at [N].",
    "says <mood>, \"You've got the look of a performer. Do you sing, or only make others want to?\"",
    "says, \"I'd pay a silver for a song. Two if it's about someone who deserved it.\"",
    "taps a beat on the nearest surface. [dance]" } },
  { key = "wild", words = { "hunter", "beast", "wild", "forest", "ranger", "tracker", "woods", "druid", "nature", "wolf", "animal", "hunt" }, title = "Tracks in the Mud", lines = {
    "notices the mud on [N]'s boots: real wilderness mud, not city dirt.",
    "says <mood>, \"You've been out past the roads. What's it like out there this season?\"",
    "says, \"I'm looking for someone who can read tracks. Mine keep leading me in circles.\"",
    "gestures vaguely at their own very lost-looking boots. [shrug]" } },
  { key = "dark", words = { "dark", "void", "fel", "necro", "death", "curse", "cult", "shadowy", "demon", "warlock", "blood", "forbidden" }, title = "A Chill in the Room", lines = {
    "shivers, though the room isn't cold, and glances at [N].",
    "says <mood>, \"Forgive me. You've got the air of someone who's looked into things best left closed.\"",
    "says, \"I'm not judging. I'm asking. What did you see?\"",
    "waits, very still." } },
  { key = "faith", words = { "faith", "god", "goddess", "temple", "pray", "prayer", "elune", "light", "ancestors", "spirit", "loa", "shrine", "monk" }, title = "A Question of Faith", lines = {
    "notices the way [N] carries themselves, as if listening for something only they can hear.",
    "says <mood>, \"Do you pray? I ask everyone. The answers are always interesting.\"",
    "says, \"Mine are mostly for better weather and fewer murlocs.\"",
    "smiles, and waits for theirs. [chuckle]" } },
}
R.PROFILE_THEMES = THEMES

-- the first impression, made from the details themselves
local FIRST = {
  "notices [N] and takes a moment to look them over.",
  "takes in [N]'s [E] eyes, and holds the gaze a moment longer than is polite.",
  "says <mood>, \"[N], isn't it? [T]. I've heard the name.\"",
  "says, \"Not every day I meet a [R] [C] around here.\"",
  "says, \"You're from [H], aren't you? I passed through there once.\"",
  "says, \"Born in [B]? That's a long way from here.\"",
  "says, \"I like your motto. '[M]'. Does it hold up?\"",
  "says, \"I've heard [G] mentioned. Good people?\"",
  "offers a hand. [wave]",
}

-- a friendly fallback when nothing in the profile stands out
local FRIENDLY = { title = "Small Talk", lines = {
  "drifts over toward [N], trying very hard to look casual.",
  "says <mood>, \"Lovely weather. Terrible weather. One of those.\"",
  "says, \"I'm told I should talk to more people. You were closest.\"",
  "grins, a little embarrassed. [chuckle]",
  "says, \"So. What brings a [R] like you to [Z]?\"" } }

local function fill(lines, p)
  local zone = (GetRealZoneText and GetRealZoneText()) or "these parts"
  local motto
  for _, m in ipairs(p.misc or {}) do if (m[1] or ""):lower():find("motto") then motto = m[2] end end
  local values = { N = p.name, T = p.title or p.fullTitle, R = p.race, C = p.class and p.class:lower(), E = p.eyes and p.eyes:lower(),
    H = p.home, B = p.birthplace, A = p.age, G = p.guild, M = motto and short(motto, 80), Z = zone }
  local out = {}
  for _, l in ipairs(lines) do
    local ok = true
    local t = l:gsub("%[(%u)%]", function(k)
      local v = values[k]
      if not v or v == "" then ok = false; return "" end
      return (v:gsub("%%", "%%%%"))
    end)
    if ok then out[#out + 1] = t end
  end
  return out
end

-- how well a profile fits each theme: words in its title, currently, text, class and extra fields
function R:ProfileThemes(p)
  local hay = " " .. table.concat({ p.title or "", p.fullTitle or "", p.currently or "", p.text or "", p.class or "", p.ooc and "" or "" }, " "):lower() .. " "
  for _, m in ipairs(p.misc or {}) do hay = hay .. " " .. (m[2] or ""):lower() end
  local scored = {}
  for _, th in ipairs(THEMES) do
    local n = 0
    for _, w in ipairs(th.words) do
      local _, c = hay:gsub("%f[%w]" .. w:gsub("(%W)", "%%%1"), "")
      n = n + c
    end
    if n > 0 then scored[#scored + 1] = { th, n } end
  end
  table.sort(scored, function(a, b) return a[2] > b[2] end)
  return scored
end

-- three suggestions: a first impression from the details, and the two themes that fit best (or friendly small talk)
function R:SuggestFromProfile(p)
  local out = {}
  local first = fill(FIRST, p)
  out[#out + 1] = { title = "First Impressions", text = table.concat(first, "\n") }
  local themes = self:ProfileThemes(p)
  for i = 1, math.min(2, #themes) do
    local th = themes[i][1]
    out[#out + 1] = { title = th.title, text = table.concat(fill(th.lines, p), "\n"), theme = th.key }
  end
  if #out < 3 then out[#out + 1] = { title = FRIENDLY.title, text = table.concat(fill(FRIENDLY.lines, p), "\n") } end
  if #out < 3 then
    local th = THEMES[math.random(#THEMES)]
    out[#out + 1] = { title = th.title, text = table.concat(fill(th.lines, p), "\n"), theme = th.key }
  end
  return out
end

-- a short summary of a profile for the Ideas tab
function R:ProfileSummary(p)
  local who = p.name .. (p.title and (" |cffeec060" .. p.title .. "|r") or "")
  local bits = {}
  for _, v in ipairs({ p.age and (p.age .. " years"), p.race, p.class, p.home and ("from " .. p.home) }) do if v then bits[#bits + 1] = v end end
  local s = who .. (#bits > 0 and ("  ·  " .. table.concat(bits, ", ")) or "")
  if p.currently then s = s .. "\n|cffb48cffCurrently:|r " .. short(p.currently, 110) end
  s = s .. "\n|cff888888From " .. p.source .. (p.source == "the game" and " (no Total RP 3 or MyRolePlay profile found)" or "") .. "|r"
  return s
end

---------------------------------------------------------------------------
-- Prompts: a random scene to start from, with {target} and <mood> ready
---------------------------------------------------------------------------
R.PROMPTS = {
  { "The Sealed Letter", "finds a sealed letter on the table that wasn't there a moment ago.\nturns it over. No name on it. Only a wax seal of a closed eye.\nglances around the room, then at {target}.\nsays <mood>, \"Did you see who left this?\"" },
  { "A Rival's Request", "spots {target} and stiffens, then sighs.\nsays <mood>, \"Of all the people to ask for help. Fine. I need your help.\"\nsays, \"Don't make that face. It's temporary. Like a rash.\"" },
  { "The Wrong Room", "bursts through the door, then stops dead, realizing it is entirely the wrong room.\nlooks at {target}. [gasp]\nsays <mood>, \"This is not the bathhouse.\"\nsays, \"I'm going to pretend I meant to come in here. Hello.\"" },
  { "Stolen Purse", "pats their belt, then pats it again, faster.\nsays <mood>, \"My purse. It was right here.\"\nnarrows their eyes at {target}.\nsays, \"You didn't see a small, fast child go by, did you?\"" },
  { "The Stranger's Map", "unrolls a weathered map on the table, weighing the corners with mugs.\ntaps an X in a place no one has ever mapped. [point]\nsays <mood>, \"{target}. You look like someone who can keep a secret. And swing a sword.\"" },
  { "Old Debt", "stops in front of {target}, arms folded.\nsays <mood>, \"I believe you owe me five gold and an apology. In that order.\"\nsays, \"Don't remember? Convenient. I remember everything.\"" },
  { "The Storm", "shakes rain off a cloak as thunder rolls outside.\nsays <mood>, \"Nobody's going anywhere tonight. Not in that.\"\nsits down across from {target}. [sit]\nsays, \"So. We might as well tell stories.\"" },
  { "A Fortune Told", "takes {target}'s hand and turns it palm up, studying it seriously.\nsays <mood>, \"Hmm. A long life. A short temper. And... oh. Oh dear.\"\nlets go quickly. [cower]\nsays, \"Never mind. It's probably nothing.\"" },
  { "The Duel at Dawn", "slaps a glove against the table in front of {target}.\nsays <mood>, \"You've insulted my honor, my family, and my hat.\"\nsays, \"Dawn. The old bridge. Bring a second.\"\npauses. \"Or a friend. Or snacks. I'm not picky.\"" },
  { "The Lost Child", "kneels beside a small, crying child, then looks up at {target}. [kneel]\nsays <mood>, \"She says her family is a red tent by the river. There are a hundred red tents by the river.\"\nsays, \"Help me look?\"" },
  { "The Bet", "sets a single gold coin on the table between them and {target}.\nsays <mood>, \"I bet you can't make the barkeep laugh.\"\nsays, \"Nobody has. Ever. It's practically a legend.\"" },
  { "The Ghost", "freezes as every candle in the room gutters at once.\nsays <mood>, \"Tell me you felt that.\"\nmoves a little closer to {target}. [cower]\nsays, \"I'm not scared. I'm cold. It's different.\"" },
  { "The Secret Recipe", "leans across to {target}, whispering.\nsays <mood>, \"The innkeeper's stew. I've figured out the secret ingredient.\"\nsays, \"I can't say it out loud. Lean closer. No, closer.\"" },
  { "The Wanted Poster", "pulls a wanted poster off the wall and holds it up beside {target}'s face.\nlooks from the poster to {target} and back. Twice.\nsays <mood>, \"It's a very good likeness. Bit unflattering around the nose.\"" },
  { "A Favor Owed", "slides a small wrapped package across the table to {target}.\nsays <mood>, \"Don't open it here. Don't open it at all, ideally.\"\nsays, \"Just get it to the docks by midnight. You'll know who to give it to.\"" },
  { "The Broken Wagon", "stands beside a wagon with a snapped axle, staring at it helplessly.\nsays <mood>, \"I don't suppose you know anything about wheels, {target}?\"\nsays, \"Or about very angry goats? They were in the wagon.\"" },
  { "The Masquerade", "adjusts an elaborate feathered mask and turns to {target}.\nsays <mood>, \"I know who you are. Even behind that mask.\"\nsays, \"The question is whether you know who I am.\" [bow]" },
  { "Firelight Confessions", "pokes at the campfire, sending sparks into the dark.\nsays <mood>, \"Can I tell you something, {target}? Something I've never told anyone?\"\nstares into the flames for a long moment. [sit]" },
  { "The Strange Cargo", "lowers their voice as a crate nearby twitches.\nsays <mood>, \"I was paid not to ask what's in the crate.\"\nwatches the crate twitch again.\nsays, \"I'm starting to regret that.\"" },
  { "The Recruitment Speech", "climbs onto a crate and clears their throat loudly.\nsays <mood>, \"Friends! Strangers! {target}! Hear me!\"\nsays, \"I'm forming an expedition. Danger, glory, modest pay, terrible food. Who's with me?\" [cheer]" },
  { "The Memory", "stops short, staring at {target}.\nsays <mood>, \"I know you. I'm sure I know you. Years ago, maybe.\"\nsays, \"Were you ever in Stormwind's orphanage? Or a very particular tavern brawl?\"" },
  { "The Healer's Visit", "limps up to {target}, clutching their side.\nsays <mood>, \"It's nothing. A scratch. A very large, bleeding scratch.\"\nsways a little. [cower]\nsays, \"You wouldn't happen to have a bandage?\"" },
  { "The Riddle", "taps the table three times and smiles at {target}.\nsays <mood>, \"Answer my riddle and I'll tell you what I know. Fail, and you buy the next round.\"\nsays, \"What has roots that nobody sees, and is taller than the trees?\"" },
  { "The Message in a Bottle", "fishes a bottle out of the water, a rolled note inside.\nholds it up for {target} to see.\nsays <mood>, \"Should we read it? It feels like we're meant to read it.\"" },
}

function R:RandomPrompts(n)
  local pool, out = {}, {}
  for i = 1, #self.PROMPTS do pool[i] = i end
  for i = #pool, 2, -1 do local j = math.random(i); pool[i], pool[j] = pool[j], pool[i] end
  for i = 1, math.min(n or 3, #pool) do
    local pr = self.PROMPTS[pool[i]]
    out[#out + 1] = { title = pr[1], text = pr[2], prompt = true }
  end
  return out
end

-- an idea as a script of its own (not saved to your scripts), performed now
function R:PerformIdea(idea)
  if not idea then return end
  local script = self:Convert(idea.text, "lines", false)
  if #script == 0 then self:Print("That idea has no lines.") return end
  local name = "Idea: " .. idea.title
  self.temp = self.temp or {}
  self.temp[name] = script
  self:Start(name)
end

function R:EditIdea(idea)
  if not idea then return end
  self.db.mode = "lines"
  self:ToggleWriter(true)
  self.writer.name:SetText(idea.title)
  self.writer.edit:SetText(idea.text)
  self:RefreshWriter()
end

-- the Ideas tab: read the target's profile
function R:ReadTargetIdeas()
  local p, why = self:ReadProfile("target")
  if not p then self:Print(why) return nil end
  self.ideaProfile = p
  self.ideas = self:SuggestFromProfile(p)
  self.db.ideasSeen = true
  self:Refresh()
  return p
end

function R:PromptIdeas()
  self.ideaProfile = nil
  self.ideas = self:RandomPrompts(3)
  self:Refresh()
end
