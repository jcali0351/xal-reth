-- StoryCaster: turns pasted text into a script.
-- A script line is { text, anim, wait, chan, speaker, scene }:
--   text     what follows your name (an emote) or what you say (a chat line); "" for an animation-only step
--   anim     animation token (BOW, WAVE...) or nil
--   wait     seconds to wait before this line instead of the timer (from /pause), or nil
--   chan     nil for an emote, or SAY, YELL, PARTY, RAID, GUILD, INSTANCE_CHAT
--   speaker  in a duet, the character who performs the line ([Brannoc] at the start), or nil (whoever starts it)
--   scene    a scene that begins at this line (## Act Two), or nil
-- and, by name:
--   mood     the panel mood switches to this just before the line ("/mood sad"; "none" turns it off)
--   choice   a choose-your-path stop: { { label, scene }, ... } ("?? Fight it | Run away > The Escape")
--   go       a jump: a scene title, or "END" ("/goto The Escape", "/end")
local ADDON, ns = ...
local R = ns.R

R.MAX_LEN = 255
R.MAX_WAIT = 600

-- The animated emotes: token, button label, words that trigger it when Auto animate is on
R.ANIMS = {
  { "WAVE", "Wave", { "waves" } },
  { "BOW", "Bow", { "bows" } },
  { "NOD", "Nod", { "nods" } },
  { "NO", "Shake head", { "shakes .- head" } },
  { "TALK", "Talk", { "speaks", "explains", "tells" } },
  { "POINT", "Point", { "points" } },
  { "LAUGH", "Laugh", { "laughs", "giggles" } },
  { "CHUCKLE", "Chuckle", { "chuckles" } },
  { "CHEER", "Cheer", { "cheers" } },
  { "APPLAUD", "Clap", { "claps", "applauds" } },
  { "SALUTE", "Salute", { "salutes" } },
  { "KNEEL", "Kneel", { "kneels" } },
  { "CRY", "Cry", { "cries", "weeps", "sobs" } },
  { "SHRUG", "Shrug", { "shrugs" } },
  { "DANCE", "Dance", { "dances" } },
  { "ROAR", "Roar", { "roars" } },
  { "FLEX", "Flex", { "flexes" } },
  { "GASP", "Gasp", { "gasps" } },
  { "COWER", "Cower", { "cowers", "flinches" } },
  { "THANK", "Thank", { "thanks" } },
  { "SIGH", "Sigh", { "sighs" } },
  { "BEG", "Beg", { "begs", "pleads" } },
  { "KISS", "Blow kiss", { "blows a kiss" } },
  { "SIT", "Sit", { "sits down", "takes a seat" } },
}
R.ANIM_BY_TOKEN = {}
for _, a in ipairs(R.ANIMS) do R.ANIM_BY_TOKEN[a[1]] = a end

-- chat lines a script can hold (written /s, /y, /p, /ra, /g, /i)
R.CHANNELS = { s = "SAY", say = "SAY", y = "YELL", yell = "YELL", p = "PARTY", party = "PARTY", ra = "RAID", raid = "RAID",
  g = "GUILD", guild = "GUILD", i = "INSTANCE_CHAT", instance = "INSTANCE_CHAT" }
R.CHANNEL_SLASH = { SAY = "/s", YELL = "/y", PARTY = "/p", RAID = "/ra", GUILD = "/g", INSTANCE_CHAT = "/i" }
local WAITS = { pause = true, wait = true, delay = true, sleep = true }

local function trim(s) return (s:gsub("^%s+", ""):gsub("%s+$", "")) end

-- "[bow]" anywhere in a line: the animation, removed from the text
local function takeTag(text)
  local anim
  text = text:gsub("%[(%a+)%]", function(w)
    local t = w:upper()
    if R.ANIM_BY_TOKEN[t] then anim = anim or t; return "" end
  end)
  return trim(text:gsub("%s%s+", " ")), anim
end

-- "[Brannoc] ..." at the start of a line: who performs it (a name, not an animation)
local function takeSpeaker(text)
  local name, rest = text:match("^%[([%a\128-\255][%a\128-\255%-']*)%]%s*(.*)$")
  if name and not R.ANIM_BY_TOKEN[name:upper()] then return rest, name end
  return text, nil
end
R.TakeSpeaker = takeSpeaker

-- with Auto animate on: the first trigger word in the line
function R:GuessAnim(text)
  local l = " " .. text:lower() .. " "
  local best, at
  for _, a in ipairs(self.ANIMS) do
    for _, w in ipairs(a[3]) do
      local i = l:find("%f[%a]" .. w .. "%f[%A]")
      if i and (not at or i < at) then best, at = a[1], i end
    end
  end
  return best
end

-- split a paragraph into sentences, keeping closing quotes with their sentence and never cutting inside
-- quoted speech (says, "The beast is never gone. We simply learn to walk beside it." stays one line)
local function sentences(p)
  local out, cur = {}, ""
  local i, quoted = 1, false
  while i <= #p do
    local c = p:sub(i, i)
    cur = cur .. c
    if c == '"' then quoted = not quoted end
    if c == "." or c == "!" or c == "?" then
      while i < #p and p:sub(i + 1, i + 1):match("[%.!%?\"')%]]") do
        i = i + 1
        local d = p:sub(i, i)
        cur = cur .. d
        if d == '"' then quoted = not quoted end
      end
      if not quoted and (i == #p or p:sub(i + 1, i + 1):match("%s")) then out[#out + 1] = trim(cur); cur = "" end
    end
    i = i + 1
  end
  if trim(cur) ~= "" then out[#out + 1] = trim(cur) end
  return out
end

-- cut a too-long piece at the last sentence end or space that fits
local function fit(piece, out)
  local split = 0
  while #piece > R.MAX_LEN do
    local cut = piece:sub(1, R.MAX_LEN - 4)
    local at = cut:match("^.*()[%.!%?,;]%s") or cut:match("^.*()%s") or #cut
    out[#out + 1] = trim(piece:sub(1, at))
    piece = trim(piece:sub(at + 1))
    split = split + 1
  end
  if piece ~= "" then out[#out + 1] = piece end
  return split
end

-- mode: "lines" (one per line typed), "sentences" (one per sentence), "fill" (pack sentences up to the limit)
-- Returns the script, how many long pieces were split, and how many lines were skipped.
function R:Convert(raw, mode, autoAnim)
  local me = (UnitName("player") or ""):lower()
  local script, split, skipped = {}, 0, 0
  local pieces = {}
  -- a pause written in the middle of a line gets a line of its own
  raw = (raw or ""):gsub("%s+(/[Pp][Aa][Uu][Ss][Ee]%s+[%d%.]+)%s*", "\n%1\n"):gsub("%s+(/[Ww][Aa][Ii][Tt]%s+[%d%.]+)%s*", "\n%1\n")
  for line in (raw .. "\n"):gmatch("([^\r\n]*)\r?\n") do
    local l = trim(line:gsub("|", ""))
    l = l:gsub("^%d+[%.%)]%s+", ""):gsub("^[%-%*]%s+", "")
    local scene = l:match("^##+%s*(.-)%s*$")
    -- read before the | characters are stripped: they separate the options
    local choice = not scene and trim(line):match("^%?%?%s*(.-)%s*$")
    local speaker, handled
    if choice then
      -- ?? Fight it | Run away > The Escape   (each option jumps to the scene named after > , or to its own name)
      local opts = {}
      for part in (choice .. "|"):gmatch("([^|]*)|") do
        local label, target = part:match("^%s*(.-)%s*%-?>%s*(.-)%s*$")
        label = trim(label or part)
        if label ~= "" then opts[#opts + 1] = { label, (target and target ~= "") and target or label } end
      end
      if #opts > 0 then pieces[#pieces + 1] = { choice = opts } else skipped = skipped + 1 end
      l, handled = "", true
    elseif not scene then
      l, speaker = takeSpeaker(l)
      if me ~= "" and l:lower():sub(1, #me + 1) == me .. " " then l = l:sub(#me + 2) end
    end
    local onlyName = me ~= "" and l:lower() == me
    if onlyName then l = "" end
    l = l:gsub("^/[Ee][Mm][Oo][Tt][Ee]%s+", ""):gsub("^/[Ee]%s+", ""):gsub("^/[Mm][Ee]%s+", "")
    local cmd, arg = l:match("^/(%a+)%s*(.-)%s*$")
    if scene then
      if scene ~= "" then pieces[#pieces + 1] = { scene = scene } end
    elseif cmd then
      local c = cmd:lower()
      if WAITS[c] then
        local n = tonumber(arg:match("[%d%.]+") or "")
        if n then pieces[#pieces + 1] = { wait = math.max(1, math.min(self.MAX_WAIT, n)) } else skipped = skipped + 1 end
      elseif c == "mood" then
        local m = arg:lower()
        local found = (m == "none" or m == "off") and "none" or (self.MoodList and self:MoodList(m) and self:MoodList(m)[1])
        if found then pieces[#pieces + 1] = { mood = found } else skipped = skipped + 1 end
      elseif c == "goto" and arg ~= "" then
        pieces[#pieces + 1] = { go = arg }
      elseif c == "end" then
        pieces[#pieces + 1] = { go = "END" }
      elseif self.ANIM_BY_TOKEN[c:upper()] then
        pieces[#pieces + 1] = { anim = c:upper(), speaker = speaker }
      elseif self.CHANNELS[c] and arg ~= "" then
        pieces[#pieces + 1] = { chat = arg, chan = self.CHANNELS[c], speaker = speaker }
      else
        skipped = skipped + 1
      end
    elseif l == "" then
      if line:match("%S") and not onlyName and not handled then skipped = skipped + 1 end
    elseif mode == "lines" or speaker then
      pieces[#pieces + 1] = { text = l, speaker = speaker }
    else
      for _, s in ipairs(sentences(l)) do pieces[#pieces + 1] = { text = s } end
      pieces[#pieces + 1] = false -- a paragraph break: "fill" never packs across it
    end
  end
  local wait, scene, mood
  local function add(t, anim, chan, speaker)
    local l = { t, anim, wait, chan, speaker, scene }
    l.mood = mood
    script[#script + 1] = l
    wait, scene, mood = nil, nil, nil
    return l
  end
  local function push(text, chan, speaker)
    local t, anim = takeTag(text)
    if not anim and autoAnim and t ~= "" and not chan then anim = self:GuessAnim(t) end
    if t == "" and not anim then return end
    local parts = {}
    split = split + fit(t, parts)
    if #parts == 0 then add("", anim, nil, speaker) end
    for i, p in ipairs(parts) do add(p, i == 1 and anim or nil, chan, speaker) end
  end
  local function command(p)
    if p.wait then wait = (wait or 0) + p.wait
    elseif p.scene then scene = p.scene
    elseif p.mood then mood = p.mood
    elseif p.choice then add("").choice = p.choice
    elseif p.go then add("").go = p.go
    elseif p.anim then add("", p.anim, nil, p.speaker)
    elseif p.chat then push(p.chat, p.chan, p.speaker) end
  end
  if mode == "fill" then
    local buf = ""
    for _, p in ipairs(pieces) do
      if p == false or (p and not p.text) or (p and p.speaker) then
        if buf ~= "" then push(buf); buf = "" end
        if p then if p.text then push(p.text, nil, p.speaker) else command(p) end end
      elseif buf == "" then buf = p.text
      elseif #buf + 1 + #(takeTag(p.text)) <= self.MAX_LEN and not p.text:find("%[%a+%]") then buf = buf .. " " .. p.text
      else push(buf); buf = p.text end
    end
    if buf ~= "" then push(buf) end
  else
    for _, p in ipairs(pieces) do
      if p then if p.text then push(p.text, nil, p.speaker) else command(p) end end
    end
  end
  return script, split, skipped
end

-- back to editable text, one line per script line (it converts back to the same script in "lines" mode)
function R:LineToText(l)
  if l.choice then
    local parts = {}
    for _, o in ipairs(l.choice) do parts[#parts + 1] = o[1] == o[2] and o[1] or (o[1] .. " > " .. o[2]) end
    return "?? " .. table.concat(parts, " | ")
  end
  if l.go then return l.go == "END" and "/end" or ("/goto " .. l.go) end
  local s = ""
  if l[5] then s = "[" .. l[5] .. "] " end
  if l[4] then s = s .. (self.CHANNEL_SLASH[l[4]] or "/s") .. " " end
  if l[2] then s = s .. "[" .. l[2]:lower() .. "] " end
  return s .. (l[1] or "")
end

function R:ScriptToText(script)
  local out = {}
  for _, l in ipairs(script or {}) do
    if l[6] then out[#out + 1] = "## " .. l[6] end
    if l[3] then out[#out + 1] = "/pause " .. l[3] end
    if l.mood then out[#out + 1] = "/mood " .. l.mood:lower() end
    out[#out + 1] = self:LineToText(l)
  end
  return table.concat(out, "\n")
end

-- Scripts saved by older versions: any line holding "/something" is rebuilt
function R:Repair(script)
  for _, l in ipairs(script) do
    if (l[1] or ""):find("^%s*/%a") or (l[1] or ""):find("%s/[Pp][Aa][Uu][Ss][Ee]%s+%d") then
      local fixed = self:Convert(self:ScriptToText(script), "lines", false)
      fixed.opts = script.opts
      return fixed, true
    end
  end
  return script, false
end

-- the line where a scene starts, by its title (any case, extra spaces ignored), or nil
function R:SceneIndex(script, title)
  local want = trim((title or ""):lower()):gsub("%s+", " ")
  for i, l in ipairs(script or {}) do
    if l[6] and trim(l[6]:lower()):gsub("%s+", " ") == want then return i end
  end
end

-- the scenes in a script: { { index, title }, ... }
function R:Scenes(script)
  local out = {}
  for i, l in ipairs(script or {}) do if l[6] then out[#out + 1] = { i, l[6] } end end
  return out
end

-- everyone named as a speaker, other than you
function R:CastOf(script)
  local me, seen, out = (UnitName("player") or ""):lower(), {}, {}
  for _, l in ipairs(script or {}) do
    local s = l[5]
    if s and s:lower() ~= me and not seen[s:lower()] then seen[s:lower()] = true; out[#out + 1] = s end
  end
  return out
end
