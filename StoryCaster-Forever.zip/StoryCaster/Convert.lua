-- StoryCaster: turns pasted text into a script of /emote lines.
-- Each script line is { text, anim } where text follows your name in chat and anim is an animation token
-- (BOW, WAVE...) or nil. A line can be animation only ("[bow]" on its own).
local ADDON, ns = ...
local R = ns.R

R.MAX_LEN = 255

-- The animated emotes: token, button label, words that trigger it when Auto animate is on
R.ANIMS = {
  { "WAVE", "Wave", { "waves" } },
  { "BOW", "Bow", { "bows" } },
  { "NOD", "Nod", { "nods" } },
  { "NO", "Shake head", { "shakes .- head" } },
  { "TALK", "Talk", { "speaks", "explains", "tells" } },
  { "POINT", "Point", { "points" } },
  { "LAUGH", "Laugh", { "laughs", "giggles" } },
  { "CHUCKLE", "Chuckle", { "chuckles" } },
  { "CHEER", "Cheer", { "cheers" } },
  { "APPLAUD", "Clap", { "claps", "applauds" } },
  { "SALUTE", "Salute", { "salutes" } },
  { "KNEEL", "Kneel", { "kneels" } },
  { "CRY", "Cry", { "cries", "weeps", "sobs" } },
  { "SHRUG", "Shrug", { "shrugs" } },
  { "DANCE", "Dance", { "dances" } },
  { "ROAR", "Roar", { "roars" } },
  { "FLEX", "Flex", { "flexes" } },
  { "GASP", "Gasp", { "gasps" } },
  { "COWER", "Cower", { "cowers", "flinches" } },
  { "THANK", "Thank", { "thanks" } },
  { "SIGH", "Sigh", { "sighs" } },
  { "BEG", "Beg", { "begs", "pleads" } },
  { "KISS", "Blow kiss", { "blows a kiss" } },
  { "SIT", "Sit", { "sits down", "takes a seat" } },
}
R.ANIM_BY_TOKEN = {}
for _, a in ipairs(R.ANIMS) do R.ANIM_BY_TOKEN[a[1]] = a end

local function trim(s) return (s:gsub("^%s+", ""):gsub("%s+$", "")) end

-- "[bow]" or "[BOW]" anywhere in a line: the animation, removed from the text
local function takeTag(text)
  local anim
  text = text:gsub("%[(%a+)%]", function(w)
    local t = w:upper()
    if R.ANIM_BY_TOKEN[t] then anim = anim or t; return "" end
  end)
  return trim(text:gsub("%s%s+", " ")), anim
end

-- with Auto animate on: the first trigger word in the line
function R:GuessAnim(text)
  local l = " " .. text:lower() .. " "
  local best, at
  for _, a in ipairs(self.ANIMS) do
    for _, w in ipairs(a[3]) do
      local i = l:find("%f[%a]" .. w .. "%f[%A]")
      if i and (not at or i < at) then best, at = a[1], i end
    end
  end
  return best
end

-- split a paragraph into sentences, keeping closing quotes with their sentence
local function sentences(p)
  local out, cur = {}, ""
  local i = 1
  while i <= #p do
    local c = p:sub(i, i)
    cur = cur .. c
    if c == "." or c == "!" or c == "?" then
      -- swallow repeated marks and closing quotes/brackets
      while i < #p and p:sub(i + 1, i + 1):match("[%.!%?\"')%]]") do i = i + 1; cur = cur .. p:sub(i, i) end
      if i == #p or p:sub(i + 1, i + 1):match("%s") then out[#out + 1] = trim(cur); cur = "" end
    end
    i = i + 1
  end
  if trim(cur) ~= "" then out[#out + 1] = trim(cur) end
  return out
end

-- cut a too-long piece at the last sentence end or space that fits
local function fit(piece, out)
  local split = 0
  while #piece > R.MAX_LEN do
    local cut = piece:sub(1, R.MAX_LEN - 4)
    local at = cut:match("^.*()[%.!%?,;]%s") or cut:match("^.*()%s") or #cut
    out[#out + 1] = trim(piece:sub(1, at))
    piece = trim(piece:sub(at + 1))
    split = split + 1
  end
  if piece ~= "" then out[#out + 1] = piece end
  return split
end

-- Script commands, the way macro scripts are written. A line that starts with one is never posted as words:
--   /pause 4, /wait 4, /delay 4   wait that many seconds before the next emote (instead of the timer)
--   /bow, /wave, /kneel ...        play that animation
--   /s text, /say text             becomes an emote: says, "text"   (addons cannot /say on a timer)
--   /y text, /yell text            becomes an emote: yells, "text"
--   any other /command             skipped
local WAITS = { pause = true, wait = true, delay = true, sleep = true }
local SAYS = { s = "says", say = "says", y = "yells", yell = "yells" }
R.MAX_WAIT = 600

-- mode: "lines" (one emote per line you typed), "sentences" (one per sentence), "fill" (pack sentences up to the limit)
-- Returns the script ({ {text, anim, wait}, ... }), how many long pieces were split, and how many lines were skipped.
-- wait (optional) = seconds to wait before that line instead of the timer.
function R:Convert(raw, mode, autoAnim)
  local me = (UnitName("player") or ""):lower()
  local script, split, skipped = {}, 0, 0
  local pieces = {}
  -- a pause written in the middle of a line ("...sounds. /pause 4 Then...") gets a line of its own
  raw = (raw or ""):gsub("%s+(/[Pp][Aa][Uu][Ss][Ee]%s+[%d%.]+)%s*", "\n%1\n"):gsub("%s+(/[Ww][Aa][Ii][Tt]%s+[%d%.]+)%s*", "\n%1\n")
  for line in (raw .. "\n"):gmatch("([^\r\n]*)\r?\n") do
    local l = trim(line:gsub("|", ""))
    l = l:gsub("^%d+[%.%)]%s+", ""):gsub("^[%-%*]%s+", "")
    if me ~= "" and l:lower():sub(1, #me + 1) == me .. " " then l = l:sub(#me + 2) end
    local onlyName = me ~= "" and l:lower() == me -- just your name, left over from a copied chat line
    if onlyName then l = "" end
    l = l:gsub("^/[Ee][Mm][Oo][Tt][Ee]%s+", ""):gsub("^/[Ee]%s+", ""):gsub("^/[Mm][Ee]%s+", "")
    local cmd, arg = l:match("^/(%a+)%s*(.-)%s*$")
    if cmd then
      local c = cmd:lower()
      if WAITS[c] then
        local n = tonumber(arg:match("[%d%.]+") or "")
        if n then pieces[#pieces + 1] = { wait = math.max(1, math.min(self.MAX_WAIT, n)) } else skipped = skipped + 1 end
      elseif self.ANIM_BY_TOKEN[c:upper()] then
        pieces[#pieces + 1] = { anim = c:upper() }
      elseif SAYS[c] and arg ~= "" then
        pieces[#pieces + 1] = SAYS[c] .. ', "' .. arg:gsub('^"', ""):gsub('"$', "") .. '"'
      else
        skipped = skipped + 1
      end
    elseif l == "" then
      if line:match("%S") and not onlyName then skipped = skipped + 1 end
    elseif mode == "lines" then
      pieces[#pieces + 1] = l
    else
      -- tags stay with the sentence they are in
      for _, s in ipairs(sentences(l)) do pieces[#pieces + 1] = s end
      pieces[#pieces + 1] = false -- a paragraph break: "fill" never packs across it
    end
  end
  local wait
  local function add(t, anim)
    script[#script + 1] = { t, anim, wait }
    wait = nil
  end
  local function push(text)
    local t, anim = takeTag(text)
    if not anim and autoAnim and t ~= "" then anim = self:GuessAnim(t) end
    if t == "" and not anim then return end
    local parts = {}
    split = split + fit(t, parts)
    if #parts == 0 then add("", anim) end
    for i, p in ipairs(parts) do add(p, i == 1 and anim or nil) end
  end
  local function command(p)
    if p.wait then wait = (wait or 0) + p.wait else add("", p.anim) end
  end
  if mode == "fill" then
    local buf = ""
    for _, p in ipairs(pieces) do
      if type(p) == "table" then
        if buf ~= "" then push(buf); buf = "" end
        command(p)
      elseif p == false then
        if buf ~= "" then push(buf); buf = "" end
      elseif buf == "" then buf = p
      elseif #buf + 1 + #(takeTag(p)) <= self.MAX_LEN and not p:find("%[%a+%]") then buf = buf .. " " .. p
      else push(buf); buf = p end
    end
    if buf ~= "" then push(buf) end
  else
    for _, p in ipairs(pieces) do
      if type(p) == "table" then command(p) elseif p then push(p) end
    end
  end
  -- a pause at the very end has nothing to wait for
  return script, split, skipped
end

-- back to editable text (pauses as /pause lines, tags as [token] at the start)
function R:ScriptToText(script)
  local out = {}
  for _, l in ipairs(script or {}) do
    if l[3] then out[#out + 1] = "/pause " .. l[3] end
    out[#out + 1] = (l[2] and ("[" .. l[2]:lower() .. "] ") or "") .. (l[1] or "")
  end
  return table.concat(out, "\n")
end

-- Scripts saved before /pause was understood: any line posted as "/something" is rebuilt
function R:Repair(script)
  for _, l in ipairs(script) do
    if (l[1] or ""):find("^%s*/%a") or (l[1] or ""):find("%s/[Pp][Aa][Uu][Ss][Ee]%s+%d") then
      return (self:Convert(self:ScriptToText(script), "lines", false)), true
    end
  end
  return script, false
end
