-- Xal'Reth RP - the 100 Rites of Xal'Reth, in 10 parent categories.
-- Each entry: { key, motif }. The key is a set in ns.Sets or a Book section.
-- The motif names the picture on that rite's icon (Media\rNNN.tga).
local ADDON, ns = ...

ns.RiteCategories = {
  { key = "gathering", title = "Rites of Gathering", icon = "cat01", rites = {
    { "opening", "altar" }, { "closing", "coil" }, { "callresponse", "bell" }, { "ritual", "stone" },
    { "heatlamps", "lamp" }, { "rollcall", "scroll" }, { "traveler", "clawprint" }, { "opendoor", "key" },
    { "vespers", "moon" }, { "dawn", "sun" },
  } },
  { key = "prayers", title = "Prayers and Devotions", icon = "cat02", rites = {
    { "prayers", "head" }, { "praise", "hands" }, { "blessings", "star" }, { "begging", "heart" },
    { "raidprayer", "shield" }, { "lootprayer", "chalice" }, { "lagprayer", "candle" }, { "grace", "bowl" },
    { "mercies", "feather" }, { "nightwatch", "eye" },
  } },
  { key = "hymns", title = "Chants and Hymns", icon = "cat03", rites = {
    { "chants", "crystal" }, { "songs", "note" }, { "lamphymn", "lamp" }, { "drinkingsong", "chalice" },
    { "cadence", "swords" }, { "hatchlullaby", "egg" }, { "hisschoir", "bell" }, { "rexballad", "crown" },
    { "colddirge", "moon" }, { "endlessround", "coil" },
  } },
  { key = "scale", title = "Rites of the Scale", icon = "cat04", rites = {
    { "molt", "flame" }, { "vigil", "sun" }, { "tail", "coil" }, { "polishing", "crystal" },
    { "coldblood", "hourglass" }, { "sunning", "stone" }, { "tongueflick", "eye" }, { "stillness", "head" },
    { "burdens", "hands" }, { "thirdeyelid", "mask" },
  } },
  { key = "passage", title = "Rites of Passage", icon = "cat05", rites = {
    { "initiation", "egg" }, { "wedding", "rings" }, { "hatchday", "star" }, { "ascension", "crown" },
    { "naming", "scroll" }, { "maxmolt", "flame" }, { "farewell", "feather" }, { "prodigal", "key" },
    { "anniversary", "chalice" }, { "funeral", "candle" },
  } },
  { key = "battle", title = "Rites of Battle", icon = "cat06", rites = {
    { "warcries", "swords" }, { "lament", "skull" }, { "tankblessing", "shield" }, { "healeranoint", "heart" },
    { "victory", "star" }, { "keyrite", "key" }, { "taunt", "mask" }, { "rally", "flame" },
    { "lootcouncil", "chalice" }, { "trance", "eye" },
  } },
  { key = "offering", title = "Sacrifice and Offering", icon = "cat07", rites = {
    { "sacrifice", "dagger" }, { "feast", "bowl" }, { "goldoffering", "crystal" }, { "firstkill", "skull" },
    { "greyitems", "flame" }, { "tithe", "key" }, { "lampoffering", "lamp" }, { "officersacrifice", "swords" },
    { "cricketoffering", "hands" }, { "plushsacrifice", "altar" },
  } },
  { key = "divination", title = "Prophecy and Divination", icon = "cat08", rites = {
    { "oracle", "orb" }, { "prophecy", "moon" }, { "shedreading", "scroll" }, { "cricketaugury", "bowl" },
    { "coildream", "eye" }, { "starreading", "star" }, { "bones", "skull" }, { "coilmirror", "crystal" },
    { "lootomen", "hourglass" }, { "patchprophecy", "feather" },
  } },
  { key = "lore", title = "Lore and Sermons", icon = "cat09", rites = {
    { "sermon", "head" }, { "origin", "stone" }, { "decrees", "scroll" }, { "xalrathiel", "crown" },
    { "firstlamp", "lamp" }, { "impatientmammal", "mask" }, { "mountsermon", "star" }, { "greatwipe", "skull" },
    { "sevenscales", "shield" }, { "basementtale", "key" },
  } },
  { key = "fellowship", title = "Mischief and Fellowship", icon = "cat10", rites = {
    { "confession", "mask" }, { "exorcism", "flame" }, { "ambient", "lamp" }, { "hideseek", "clawprint" },
    { "stillnesstrial", "hourglass" }, { "roast", "chalice" }, { "teaparty", "bowl" }, { "mammalcontest", "feather" },
    { "interrogation", "orb" }, { "midnightbask", "moon" },
  } },
}
