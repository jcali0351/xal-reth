-- Xal'Reth RP - new rites: Gathering, Prayers, Hymns
local ADDON, ns = ...
local S = ns.Sets

-- Rites of Gathering ----------------------------------------------------
S.heatlamps = { title = "Lighting of the Heat Lamps", fallback = "the nearest cultist", lines = {
  "carries a long brass taper into the hall. \"It is time. Let the heat lamps be lit.\"",
  "lights the first lamp. A warm amber glow spills across the floor. \"For patience.\"",
  "lights the second lamp. \"For stillness.\" The air begins to shimmer.",
  "lights the third lamp. \"For the Coil, which binds us.\"",
  "lights the fourth lamp and holds a hand beneath it, eyes closed, savoring the warmth.",
  "hands the taper to {target}. \"Light the last one. Carefully. These are rented.\"",
  "watches the final lamp flare to life and exhales slowly. \"The hall is warm. Xal'Reth approves.\"",
  "announces, \"Basking may now commence. Shoes off. Scales... metaphorically out.\"",
} }

S.rollcall = { title = "Roll Call of the Coil", fallback = "the faithful", lines = {
  "unrolls a list so long it bounces across the floor. \"Roll call! Answer when your name is hissed.\"",
  "reads, \"The tanks?\" and waits for a grunt of acknowledgment.",
  "reads, \"The healers?\" and nods. \"Present, and already judging everyone. Good.\"",
  "reads, \"The damage dealers?\" A chorus answers. \"Yes, yes, we hear you. You are very loud.\"",
  "reads, \"{target}?\" and peers over the list until they answer.",
  "reads, \"MaximumRex?\" then pauses. \"Present in spirit. And probably in the guild bank.\"",
  "reads, \"Anyone here who is secretly a mammal?\" Silence. \"Excellent. Same as always.\"",
  "rolls the list back up. \"All present, or close enough. The Coil is complete.\"",
} }

S.traveler = { title = "Welcome of the Weary Traveler", fallback = "the traveler", lines = {
  "spots {target} approaching and raises a hand. \"Halt, traveler. You look cold.\"",
  "circles {target} slowly, sniffing the air. \"Long road. Cold rain. Poor snacks.\"",
  "drapes a warm woolen shawl over {target}'s shoulders. \"Here. It was heated on a sacred stone.\"",
  "offers {target} a cup of warm water. \"Drink. It is the drink of the faithful. It is mostly just water.\"",
  "points to the warmest seat by the heat lamp. \"Sit. Bask. Ask no questions about the décor.\"",
  "asks, \"Where do you travel from, and do you have any interest in joining a perfectly normal organization?\"",
  "slides a small pamphlet into {target}'s hand. On the cover: a spiral, and the words 'Have You Considered Basking?'",
  "bows. \"Rest as long as you like, traveler. Xal'Reth watches over all who are cold.\"",
} }

S.opendoor = { title = "Rite of the Open Door", fallback = "the newcomer", lines = {
  "unlocks the great door of the hall with an iron key shaped like a coiled serpent.",
  "swings the door wide. Warm air rolls out into the night.",
  "calls into the darkness, \"Any who seek warmth, enter! Any who seek loot, also enter!\"",
  "places a lantern on the threshold so that wanderers may find the way.",
  "lays a mat at the door. Woven into it: 'WIPE YOUR CLAWS'.",
  "greets {target} at the door with a deep bow. \"Come in, come in. Mind the crickets.\"",
  "intones, \"The door of the Coil is never locked to the cold. Only to the obnoxious.\"",
  "leaves the door just slightly ajar, as Xal'Reth intended. \"Draft-free, but welcoming.\"",
} }

S.vespers = { title = "Evening Vespers", fallback = "the faithful", lines = {
  "rings a soft bell as the sun touches the horizon. \"Vespers. The warm hours end.\"",
  "turns to face the last light of the day and holds out both palms to catch it.",
  "whispers, \"Thank you, sun, for your warmth. We will see you tomorrow. Probably.\"",
  "lights a single candle as the shadows lengthen across the floor.",
  "leads a slow, low hum that rises and falls like breathing.",
  "recites, \"The day was long. The stones were warm. The loot was... adequate.\"",
  "dims the heat lamps to the night setting with ceremonial care.",
  "bows to {target} and the gathered faithful. \"Rest well. Coil tight. Dream warm.\"",
} }

S.dawn = { title = "The Dawn Greeting", fallback = "the faithful", lines = {
  "climbs to the highest point nearby and waits, perfectly still, for the sun.",
  "watches the first light break over the horizon and lets out a long, contented sigh.",
  "spreads their arms wide to soak in the first rays of morning.",
  "calls out, \"Good morning, Xal'Reth! Good morning, sun! Good morning, rocks!\"",
  "turns to {target}. \"Do not speak to me for twenty minutes. I am charging.\"",
  "closes their eyes and basks. A faint, satisfied rumble comes from somewhere deep inside.",
  "rolls their shoulders and stretches, slow and luxurious, as warmth returns to every limb.",
  "descends at last, glowing faintly. \"The dawn is greeted. Now, breakfast. Crickets, scrambled.\"",
} }

-- Prayers and Devotions -------------------------------------------------
S.raidprayer = { title = "Prayer for the Raid", fallback = "our raid leader", lines = {
  "gathers the raid in a circle and bows their head. \"Let us pray before we pull.\"",
  "prays, \"Xal'Reth, guide the hands of the tank, that they may face the boss AWAY from us.\"",
  "prays, \"Guide the hands of the healers, that their mana be deep and their patience deeper.\"",
  "prays, \"Guide the feet of the damage dealers, that they may step out of things. Any things. All things.\"",
  "prays, \"Grant clarity to {target}, who must explain the tactics a fourth time.\"",
  "prays, \"Let no one be AFK when the pull timer ends. Let no one's cat walk across the keyboard.\"",
  "prays, \"And if we wipe, Xal'Reth, let it be funny enough to talk about later.\"",
  "lifts their head. \"Amen. Hail Xal'Reth. Somebody please buff me.\"",
} }

S.lootprayer = { title = "Prayer for Loot", fallback = "the needy one", lines = {
  "kneels before a closed chest and clasps their hands. \"Xal'Reth, hear my humble greed.\"",
  "prays, \"Let the trinket drop. Not for me. For the raid. But also for me.\"",
  "prays, \"Let the tier piece be for my class. Let it be for my slot. Let me not already have it.\"",
  "prays, \"Grant {target} the item they have chased for eleven weeks. They are starting to scare us.\"",
  "prays, \"Bless the loot roll with a high number, and if not high, then at least higher than the hunter's.\"",
  "touches the chest lightly. \"I promise to use it wisely. I will not vendor it. Probably.\"",
  "rises. \"Whatever drops, we accept it as the will of the Coil. Unless it is cloth. Again.\"",
} }

S.lagprayer = { title = "Prayer for the Sick and Lagging", fallback = "the afflicted", lines = {
  "lights a candle for those who suffer. \"Let us pray for the lagging.\"",
  "prays, \"For those whose ping climbs above three hundred, Xal'Reth, have mercy.\"",
  "prays, \"For those who disconnect on the last boss, Xal'Reth, bring them home.\"",
  "prays, \"For those whose framerate falls to single digits in the capital city, grant them strength.\"",
  "lays a gentle hand on {target}. \"And for this one, whose internet is held together by hope.\"",
  "prays, \"For those with a cold in the real world: warm tea, soft blankets, and a heat lamp.\"",
  "prays, \"For the router, which needs to be turned off and on again. Guide its blinking lights.\"",
  "snuffs the candle. \"May all of them recover, reconnect, and remember to update their drivers.\"",
} }

S.grace = { title = "Grace Before the Feast", fallback = "the cook", lines = {
  "taps a cup with a spoon until the table falls quiet. \"Before we eat, we give thanks.\"",
  "folds their hands over the table. \"Thank you, Xal'Reth, for the crickets.\"",
  "continues, \"Thank you for the bread, for those who are not ready for crickets.\"",
  "continues, \"Thank you for {target}, who cooked this, and who only set one small thing on fire.\"",
  "continues, \"Thank you for the warm water, the warm stones, and the warm company.\"",
  "adds, \"And bless whoever brought the fish feast, which we will all pretend to share fairly.\"",
  "raises a cup. \"May this food warm our blood and fuel our DPS. Hail Xal'Reth.\"",
  "picks up a fork. \"Dig in. Leave some crickets for the officers.\"",
} }

S.mercies = { title = "Litany of Small Mercies", fallback = "the faithful", lines = {
  "sits quietly and begins a gentle litany of thanks for the little things.",
  "says, \"For short queues, we give thanks.\"",
  "says, \"For a tank who marks the pull, we give thanks.\"",
  "says, \"For a mailbox right outside the dungeon, we give thanks.\"",
  "says, \"For {target}, who always has a spare repair bot, we give thanks.\"",
  "says, \"For the first sunny day after a week of rain, we give great thanks.\"",
  "says, \"For a flight path that does not go the long way round, we give thanks.\"",
  "says, \"For guildmates who say good morning, every morning, we give the greatest thanks of all.\"",
  "smiles. \"Small mercies are still mercies. Hail Xal'Reth.\"",
} }

S.nightwatch = { title = "Prayer of the Night Watch", fallback = "the sleeping faithful", lines = {
  "takes up a lantern and stands at the edge of the camp. \"I keep the night watch.\"",
  "prays softly, \"Xal'Reth, watch over the faithful while they sleep coiled and cold.\"",
  "walks the perimeter slowly, lantern swaying, eyes scanning the dark.",
  "pauses beside {target}, sleeping, and adjusts the blanket so {target} stays warm.",
  "whispers, \"Let no cold wind find them. Let no mammal disturb them. Let no one snore. Too late.\"",
  "stares into the darkness for a long time, unblinking. Something out there stares back, then leaves.",
  "prays, \"And when the dawn comes, let them wake warm and well rested and on time for raid.\"",
  "settles beside the fire with the lantern. \"The watch is kept. Xal'Reth keeps it with me.\"",
} }

-- Chants and Hymns ------------------------------------------------------
S.lamphymn = { title = "Hymn of the Heat Lamp", fallback = "the choir", lines = {
  "raises a hand to begin the Hymn of the Heat Lamp, swaying gently.",
  "sings, \"O lamp of gold, O lamp of grace, you shine upon my scaly face.\"",
  "sings, \"When winter bites and rain falls cold, you keep me warm, O lamp of gold.\"",
  "sings, \"Three hundred watts of holy light, you burn for us both day and night.\"",
  "sings the refrain, \"Glow, glow, never go! Glow, glow, never go!\"",
  "sings, \"And when the power bill comes due, Xal'Reth, we'll pay it. Probably. Through you.\"",
  "holds the final note, arms raised toward the nearest light source.",
  "bows. \"The Hymn of the Heat Lamp. Please do not touch the lamp. It is very hot.\"",
} }

S.drinkingsong = { title = "Drinking Song of the Coil", fallback = "the thirsty", lines = {
  "slams a mug on the table. \"A song! A drinking song! Warm water for everyone!\"",
  "sings, \"Oh pour me a cup of the warm and the wet, the finest tap water a lizard can get!\"",
  "sings, \"We drink to the stones and we drink to the sun, we drink to the raid that was finally won!\"",
  "sings, \"Hey ho, the Coil goes round, the Coil goes round and round!\"",
  "clinks mugs with {target} so hard that warm water sloshes everywhere.",
  "sings, \"So here's to Xal'Reth, the longest of all, he'd come to the tavern but can't fit through the hall!\"",
  "sings the chorus again, louder and more off-key. \"HEY HO, THE COIL GOES ROUND!\"",
  "drains the mug and wipes their mouth. \"Ahh. Room temperature. Perfect.\"",
} }

S.cadence = { title = "Marching Cadence", fallback = "the column", lines = {
  "forms the faithful into a column and begins to march in place. \"Cadence! Repeat after me!\"",
  "calls, \"I don't know but I've been told!\" (Repeat!)",
  "calls, \"Lizard blood is mighty cold!\" (Repeat!)",
  "calls, \"Mammals sweat and mammals cry!\" (Repeat!)",
  "calls, \"We just bask and wonder why!\" (Repeat!)",
  "calls, \"Sound off!\" (Xal!) \"Sound off!\" (Reth!) \"Bring it on down!\" (XAL RETH!)",
  "glares at {target}. \"You! You're out of step! Left claw, right claw!\"",
  "calls, \"Up the hill and through the gate, raid starts now, so don't be late!\" (Repeat!)",
  "halts the column with a stomp. \"Faithful, HALT! At ease. Bask if you need to.\"",
} }

S.hatchlullaby = { title = "Lullaby for Hatchlings", fallback = "the little one", lines = {
  "cradles a small speckled stone egg in their arms and begins to hum.",
  "sings softly, \"Hush, little hatchling, don't you cry, the heat lamp's on and the stones are dry.\"",
  "sings, \"And if that lamp should flicker out, Xal'Reth will warm you, never doubt.\"",
  "sings, \"Hush, little hatchling, curl up small, you'll be the longest one of all.\"",
  "rocks the egg slowly, side to side, eyes half closed.",
  "tucks a corner of their cloak around the egg as if around {target}.",
  "sings, \"Sleep in the warm and wake in the sun, your scaly life has just begun.\"",
  "whispers, \"Goodnight, little one,\" and sets the egg gently beside the heat lamp.",
} }

S.hisschoir = { title = "The Hissing Choir", fallback = "the soloist", lines = {
  "taps a baton on a stone. \"Choir! Positions! Today we perform 'Sssymphony in Sss Minor'.\"",
  "conducts the sopranos: a high, thin hiss rises like steam from a kettle.",
  "conducts the baritones: a low, rumbling hiss joins in beneath it.",
  "gestures sharply. Both sections hiss in perfect harmony. Several cats nearby leave.",
  "points the baton at {target}. \"Solo! Give me your best hiss! From the diaphragm!\"",
  "nods along, eyes closed in rapture. \"Yes. YES. Xal'Reth weeps.\"",
  "brings the choir to a dramatic crescendo, then cuts it off with a single snap of the baton.",
  "bows deeply to the silence that follows. \"Thank you. We are available for weddings.\"",
} }

S.rexballad = { title = "Ballad of MaximumRex", fallback = "the bard", lines = {
  "strums a battered lute. \"A ballad, for our leader. The Ballad of MaximumRex.\"",
  "sings, \"There once was a lizard of very great size, with a crown on his head and gold in his eyes.\"",
  "sings, \"He founded a guild in the cold and the rain, and swore that no cultist would shiver again.\"",
  "sings, \"Oh Rex, Maximum Rex! Long may he reign! Long may he bask! Long may he reign!\"",
  "sings, \"He fought off the mammals, he hid all our tails, he balanced the guild bank with scales upon scales.\"",
  "sings, \"And when the raid wiped and the healers despaired, he said 'one more pull', and nobody cared.\"",
  "nods to {target} to join the last chorus. \"Oh Rex, Maximum Rex! Long may he reign!\"",
  "strums a final chord. \"Tips accepted in gold or crickets.\"",
} }

S.colddirge = { title = "Dirge of the Cold Rain", fallback = "the mourners", lines = {
  "stands in the rain, shivering, and begins a slow and miserable dirge.",
  "sings, \"Oh the rain, the cold, cold rain, it falls upon my scales again.\"",
  "sings, \"No sun today, no warm today, the clouds have stolen it away.\"",
  "huddles closer to {target} for warmth, still singing, utterly dejected.",
  "sings, \"My blood runs slow, my thoughts run slower, my mood could not get any lower.\"",
  "sings, \"But Xal'Reth says the clouds will part, so keep a heat lamp in your heart.\"",
  "looks up hopefully. The rain continues. \"...Any day now.\"",
  "trudges indoors, still dripping. \"The dirge is complete. I am going to sit on the stove.\"",
} }

S.endlessround = { title = "Round of the Endless Coil", fallback = "the next singer", lines = {
  "explains, \"This is a round. I start, then each of you joins. It never ends. That is the point.\"",
  "sings, \"Round and round the Coil goes, where it ends, nobody knows.\"",
  "points at {target} to start the second part. \"Round and round the Coil goes...\"",
  "sings over the top, \"Longer, longer, ever longer, every loop a little stronger.\"",
  "sings, \"Round and round the Coil goes,\" as three different parts now overlap in chaos.",
  "conducts wildly. Nobody is sure where the round started anymore.",
  "sings, \"Where it ends, nobody knows,\" and realizes that this is now literally true.",
  "stops abruptly. The round continues without them. \"It has a life of its own now. Hail Xal'Reth.\"",
} }
