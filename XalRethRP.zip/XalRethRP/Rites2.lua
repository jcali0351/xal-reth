-- Xal'Reth RP - new rites: Scale, Passage, Battle
local ADDON, ns = ...
local S = ns.Sets

-- Rites of the Scale ----------------------------------------------------
S.tail = { title = "Rite of the Regrown Tail", fallback = "the faithful", lines = {
  "announces solemnly, \"We gather to honor the tail. The tail that was lost. The tail that returns.\"",
  "teaches, \"When the enemy grabs the tail, the tail lets go. Be like the tail. Let go.\"",
  "mimes detaching an invisible tail and leaving it behind with great dignity.",
  "continues, \"And in time, the tail grows back. Shorter. Different. But ours.\"",
  "turns to {target}. \"What have you let go of this week? A grudge? A bad key? A guild bank flask?\"",
  "nods wisely at the answer. \"Good. It will grow back as something better.\"",
  "intones, \"Lose the tail, keep the life. Lose the loot, keep the guild. Lose the wipe, keep the joke.\"",
  "bows. \"Blessed is the tail that falls, and blessed is the tail that grows. Hail Xal'Reth.\"",
} }

S.polishing = { title = "Polishing of the Scales", fallback = "the next in line", lines = {
  "unpacks a velvet cloth, a tin of wax, and a very small brush with great ceremony.",
  "explains, \"Dull scales mean a dull spirit. Today we shine.\"",
  "applies a dab of wax to the back of their hand and buffs it in slow, careful circles.",
  "holds up the hand to the light. It gleams unreasonably. \"Behold. Radiance.\"",
  "beckons {target}. \"Your turn. Hold still. This will tickle, spiritually.\"",
  "buffs {target}'s armor until it reflects the candlelight like a mirror.",
  "steps back to admire the work. \"Magnificent. You could blind a mammal at forty yards.\"",
  "packs away the tin. \"Shine bright, faithful. Not too bright. We are still in hiding.\"",
} }

S.coldblood = { title = "Rite of Cold Blood", fallback = "the hot-headed one", lines = {
  "sits cross-legged and closes their eyes. \"The Rite of Cold Blood. We learn to be calm.\"",
  "breathes in slowly for a count of eight. Out for a count of eight. Their pulse visibly slows.",
  "says, \"When the tank pulls early, we do not panic. Our blood is cold.\"",
  "says, \"When the healer says 'oom' in the middle of the boss, our blood is cold.\"",
  "says, \"When someone needs on our item, our blood is... cold. Mostly. Very cold.\"",
  "looks at {target}. \"You. You are getting worked up. Breathe. Slower. Like a turtle with nowhere to be.\"",
  "becomes so still that a moth lands on their nose. They do not react.",
  "opens their eyes. \"Cold blood. Calm mind. Clear rotation. Hail Xal'Reth.\"",
} }

S.sunning = { title = "Sunning of the Stones", fallback = "the stone bearer", lines = {
  "carries a heavy basket of smooth river stones out into the sunlight.",
  "lays the stones one by one in a long spiral on the warm ground.",
  "explains, \"The stones drink the sun all day, so that tonight, they can share it with us.\"",
  "turns each stone carefully so every side gets its share of light.",
  "hands a stone to {target}. \"Feel it. Already warm. Already blessed.\"",
  "lies down beside the spiral and joins the stones in basking.",
  "murmurs, \"We are all stones, really. Some of us are just more talkative.\"",
  "gathers the stones at sunset, warm and heavy, and carries the stones back to the altar.",
} }

S.tongueflick = { title = "Tongue-Flick Meditation", fallback = "the meditator", lines = {
  "sits perfectly still and announces, \"Tongue-Flick Meditation. Taste the air. Know the world.\"",
  "tastes the air with great concentration. \"I taste... rain, later today.\"",
  "tastes again. \"I taste... someone nearby is eating a pastry. Cinnamon.\"",
  "tastes again, then frowns. \"I taste... fear. Someone has not read the boss guide.\"",
  "turns slowly toward {target} and tastes the air in {target}'s direction. \"Hm. Confidence. And onions.\"",
  "explains, \"The air carries everything. Loot. Danger. Gossip. Mostly gossip.\"",
  "closes their mouth firmly. \"Enough tasting. The air in here is mostly feet.\"",
} }

S.stillness = { title = "The Long Stillness", fallback = "the faithful", lines = {
  "announces, \"The Long Stillness begins. We do not move until Xal'Reth says so.\"",
  "goes completely, perfectly motionless.",
  "remains motionless.",
  "continues to remain motionless. Somewhere far away, a bird finishes an entire song.",
  "has not moved. {target} waves a hand in front of their face. Nothing.",
  "is so still that a passing adventurer tries to loot them.",
  "remains motionless. A small lizard climbs up and sits on their shoulder in solidarity.",
  "blinks, slowly, once. \"Xal'Reth says we may move. The Long Stillness is complete.\"",
  "stretches with a series of alarming cracks. \"Same time next week.\"",
} }

S.burdens = { title = "Shedding of Burdens", fallback = "the burdened one", lines = {
  "sets an empty basket in the center of the circle. \"Bring your burdens. Leave them here.\"",
  "drops in a crumpled piece of parchment. \"Mine: I keep forgetting my flask. I release it.\"",
  "invites {target} forward. \"What weighs on you? Write it. Fold it. Drop it.\"",
  "watches each cultist drop a folded note into the basket, nodding with each one.",
  "says, \"A bad week. A bad key. A bad roll. All heavy things. All shed now.\"",
  "lights the basket with a candle. The notes curl up and drift away as warm smoke.",
  "waves the warm smoke over the circle. \"Feel lighter. Feel warmer. Feel like a fresh skin.\"",
  "bows. \"Your burdens are shed. Do not pick them back up. They are ash now. Gross ash.\"",
} }

S.thirdeyelid = { title = "Rite of the Third Eyelid", fallback = "the initiate", lines = {
  "lowers their voice. \"Only the most devoted may learn the Rite of the Third Eyelid.\"",
  "explains, \"The mammal has two eyelids. The faithful have... also two. Officially.\"",
  "demonstrates a slow, deliberate blink. Then a second blink, sideways. \"You saw nothing.\"",
  "instructs {target}, \"Now you try. Blink down. Then... the other way. No. The OTHER other way.\"",
  "watches {target} attempt it and nods encouragingly. \"Close. Very close. Keep practicing.\"",
  "warns, \"Never do this in front of mammals. They ask questions. They film things.\"",
  "blinks once more, sideways, and smiles serenely. \"The Third Eyelid sees what the others miss.\"",
} }

-- Rites of Passage ------------------------------------------------------
S.hatchday = { title = "Hatching Day Celebration", fallback = "the birthday cultist", lines = {
  "bursts into the hall carrying a cake shaped like an egg. \"Happy Hatching Day, {target}!\"",
  "places a small paper crown on {target}'s head. It has a tiny scale painted on it.",
  "leads the faithful in a song: \"Happy hatch day to you, may your scales shine like new!\"",
  "presents {target} with a gift: a warm stone, polished, wrapped in green silk.",
  "lights the candles on the cake. Every single one. There are a lot. \"Make a wish!\"",
  "whispers, \"Xal'Reth hears all Hatching Day wishes. He grants about forty percent.\"",
  "cuts the cake. It is filled with crickets. \"Surprise!\"",
  "raises a cup. \"To {target}! Another year shed, another year shinier!\"",
} }

S.ascension = { title = "Ascension to Officer", fallback = "the new officer", lines = {
  "summons the faithful. \"Today, one of us rises to the rank of officer of the Coil.\"",
  "calls {target} forward. \"Kneel. Officially. And then stand, because officers have meetings.\"",
  "drapes a violet sash over {target}'s shoulders. It is embroidered with tiny golden spirals.",
  "asks, \"Do you swear to answer guild chat questions you have already answered nine times?\"",
  "asks, \"Do you swear to settle loot disputes, calm drama, and remember to refill the guild bank?\"",
  "presents {target} with a heavy iron key. \"The key to the guild bank. Use it wisely. Log everything.\"",
  "announces, \"Rise, Officer {target}! Your burdens are many and your pay is crickets!\"",
  "leads the guild in a long round of applause and one enthusiastic hiss from the back.",
} }

S.naming = { title = "Naming of a Hatchling", fallback = "the hatchling", lines = {
  "holds up a newly made character for all to see. \"A new hatchling has joined the Coil!\"",
  "dips two fingers in warm sand and touches the sand to {target}'s brow. \"You need a name.\"",
  "consults a long scroll of approved names. \"Xal-something. Reth-something. Something-scale.\"",
  "asks the faithful, \"Does anyone object to this name?\" and listens carefully. \"Good.\"",
  "declares, \"By the warm stone, you are named. By the Coil, you are known.\"",
  "adds, \"May your first dungeon be easy and your first mount come quickly.\"",
  "hands {target} a small starter pouch: three silver, a cricket, and a map to the heat lamp.",
  "bows. \"Welcome, little one. Level fast. Bask often.\"",
} }

S.maxmolt = { title = "The Max-Level Molt", fallback = "the newly grown", lines = {
  "rings a bell three times. \"Attention! {target} has reached the maximum level!\"",
  "circles {target} slowly. \"The final molt. The child skin falls away. The adult emerges.\"",
  "pretends to peel an invisible layer of skin off {target}'s shoulder with great reverence.",
  "announces, \"No more leveling. Now begins the true journey: gearing, forever.\"",
  "presents {target} with a polished scale. \"A memento. Your last baby scale.\"",
  "whispers, \"The endgame is long, but so is Xal'Reth. You will be fine.\"",
  "raises a cup. \"To {target}, fully grown, fully scaled, and fully stuck with us now!\"",
} }

S.farewell = { title = "Farewell to a Departing Cultist", fallback = "our departing friend", lines = {
  "gathers the faithful at the edge of the hall. \"One of us must travel on.\"",
  "turns to {target}. \"Whatever road you take, the Coil remains. You can always come back.\"",
  "presents {target} with a small warm stone. \"For the cold nights. Hold it and remember us.\"",
  "says, \"You were a good cultist. You stood in the fire only sometimes. You laughed at our jokes.\"",
  "adds, \"Your guild bank tab will remain untouched. Mostly. We might take the herbs.\"",
  "leads a soft hiss of farewell, rising and falling like wind through tall grass.",
  "clasps {target}'s hand. \"Safe travels. Warm stones. Short queues.\"",
  "watches until {target} is out of sight. \"Hail Xal'Reth. Hail our friend.\"",
} }

S.prodigal = { title = "Return of the Prodigal Lizard", fallback = "the returning one", lines = {
  "drops everything and points. \"Look! It is {target}! The prodigal lizard returns!\"",
  "rushes forward and embraces {target}. \"We thought you were hibernating! Or lost! Or playing another game!\"",
  "calls out, \"Light the heat lamps! Warm the stones! Thaw the good crickets!\"",
  "drapes a warm cloak over {target}. \"You must be freezing. Out there with the mammals.\"",
  "asks, \"Where have you been? No, wait, do not tell us. We have all been there.\"",
  "explains the changes: \"New patch. New raid. Your talents are probably reset. Sorry.\"",
  "raises a cup. \"To {target}, who shed the outer world and came back to the Coil!\"",
  "whispers, \"Xal'Reth never stopped keeping your spot warm.\"",
} }

S.anniversary = { title = "Guild Anniversary", fallback = "our oldest member", lines = {
  "stands before the guild banner. \"Today we celebrate another year of {guild}.\"",
  "recalls, \"We started with a handful of cold, confused lizards. Look at us now. Many cold, confused lizards.\"",
  "raises a cup to the founders. \"To MaximumRex, who built the burrow, and to all who dug alongside him.\"",
  "lists the year's glories: bosses felled, keys timed, mounts won, and one legendary wipe.",
  "honors {target}. \"And to our longest-serving cultist, who has seen every patch and complained about most.\"",
  "unveils a cake shaped like the guild crest. It is enormous. It is mostly frosting.",
  "leads a toast. \"To another year! May the stones stay warm and the roster stay full!\"",
  "lifts the banner high. \"Hail {guild}! Hail Xal'Reth!\"",
} }

S.funeral = { title = "Funeral of a Fallen Cultist", fallback = "the departed", lines = {
  "stands before a small stone cairn, head bowed. \"We gather to remember {target}.\"",
  "lays a warm stone on the cairn. \"They were brave. They stood in front of the boss. Often by accident.\"",
  "lights a candle. \"They always had a spare potion. They always said good morning.\"",
  "recites, \"From the warm stone you came, and to the warm stone you return.\"",
  "lays a single shed scale on the cairn as an offering.",
  "says, \"Some say {target} is gone. The Coil says {target} is just very, very offline.\"",
  "leads a long, low hiss of mourning that echoes softly across the hills.",
  "bows. \"Rest warm, friend. We will keep your heat lamp burning.\"",
} }

-- Rites of Battle -------------------------------------------------------
S.tankblessing = { title = "Blessing of the Tank", fallback = "our tank", lines = {
  "approaches {target} with great ceremony. \"The tank goes first. The tank must be blessed.\"",
  "taps {target}'s shield three times. \"Let this shield be thick and this skull be thicker.\"",
  "anoints {target}'s gauntlets with warm sand. \"Let these hands grip every add.\"",
  "anoints {target}'s boots. \"Let these feet face the boss away from the raid. Always away.\"",
  "whispers, \"Remember: mark the pull. Mark the pull. Please mark the pull.\"",
  "steps back and salutes. \"Go forth, wall of the Coil. We are right behind you. Well behind you.\"",
} }

S.healeranoint = { title = "Anointing of the Healer", fallback = "our healer", lines = {
  "kneels before {target}. \"Healer. Keeper of our lives. Forgiver of our sins.\"",
  "offers {target} a cup of warm water. \"For your mana. It is mostly symbolic.\"",
  "anoints {target}'s hands. \"Let these hands heal those who deserve it, and also those who do not.\"",
  "confesses on behalf of the raid, \"We will stand in things. We are sorry in advance.\"",
  "lays a small warm stone in {target}'s palm. \"For when you are out of mana and patience.\"",
  "bows deeply. \"The Coil lives because you allow it to. Hail the healer.\"",
} }

S.victory = { title = "The Victory Hiss", fallback = "the champion", lines = {
  "throws both arms in the air as the boss falls. \"VICTORY! XAL'RETH!\"",
  "lets out a long, triumphant hiss that echoes off the walls.",
  "grabs {target} by the shoulders. \"WE DID IT! You did not even stand in the fire! Much!\"",
  "climbs onto the boss's body and strikes a heroic pose.",
  "shouts, \"Let the loot be counted! Let the screenshot be taken! Everyone, pose!\"",
  "leads the raid in a victory chant: \"Bask! Strike! Loot! BASK! STRIKE! LOOT!\"",
  "kneels briefly. \"Thank you, Xal'Reth. That one was for you. And for the achievement.\"",
  "stands. \"Next boss! Before the tank's repair bill sobers us up!\"",
} }

S.keyrite = { title = "Rite Before the Key", fallback = "the key holder", lines = {
  "gathers the party at the dungeon entrance. \"Before the key, we perform the rite.\"",
  "holds the keystone up to the light. \"Behold. The timer awaits. The affixes are... unkind.\"",
  "turns to {target}. \"You hold the key. Do you accept the burden of the route?\"",
  "prays, \"Xal'Reth, guide our pulls, guard our cooldowns, and smite the pug who pulls the extra pack.\"",
  "taps everyone's weapon in turn. \"Interrupts ready. Defensives ready. Snacks ready.\"",
  "intones, \"If we deplete it, it was the affixes. If we time it, it was skill.\"",
  "inserts the key with a dramatic flourish. \"Go. Go go go. GO.\"",
} }

S.taunt = { title = "Taunting of the Foe", fallback = "the enemy", lines = {
  "steps forward and points at {target}. \"You! Warm-blooded fool!\"",
  "jeers, \"Your armor is cold. Your heart is cold. Not in the cool way. In the sad way.\"",
  "taunts, \"I have seen geckos with better rotations than you.\"",
  "flicks their tongue at {target} with great disrespect.",
  "mocks, \"You call that a raid boss? We have heat lamps that hit harder.\"",
  "jeers, \"When we are done, you will be shed like an old skin. Crumpled. In a corner.\"",
  "turns their back on {target} and basks with deliberate, insulting calm.",
} }

S.rally = { title = "Rally of the Wiped", fallback = "the fallen", lines = {
  "rises from the floor, freshly resurrected, and claps once. \"Up! Everyone up!\"",
  "walks among the fallen. \"Accept your rez. Brush yourself off. That was a learning pull.\"",
  "lifts {target} off the ground. \"You died first again. It is fine. It is a tradition now.\"",
  "shouts, \"The boss is only stronger because it is warm and we are cold! We will warm up!\"",
  "slaps their own face twice. \"Focus! Cold blood! Clear eyes! Full mana!\"",
  "rallies, \"We came within three percent! Three! Xal'Reth is watching! Xal'Reth is VERY entertained!\"",
  "raises a fist. \"Buff up! Eat food! One more pull!\"",
  "mutters, \"And this time, everybody move out of the purple.\"",
} }

S.lootcouncil = { title = "Loot Council of Xal'Reth", fallback = "the candidate", lines = {
  "seats themselves upon a tall stool behind a warm stone desk. \"The Loot Council is in session.\"",
  "holds up the item. \"Before us: one shiny thing. Many wanting hands.\"",
  "asks {target}, \"State your case. Why does the Coil need YOU to have this?\"",
  "listens carefully, stroking their chin. \"Hm. Upgrade, you say. How much upgrade?\"",
  "consults a thick ledger. \"Our records show you received a ring last week. And a cloak. And our hearts.\"",
  "deliberates with an invisible committee, nodding and occasionally hissing.",
  "declares, \"The council has decided!\" and hands the item to {target} with great ceremony.",
  "adds, \"Everyone else: next week. Probably. The council is very busy.\"",
} }

S.trance = { title = "The Battle Trance", fallback = "the enemy", lines = {
  "closes their eyes before the fight. Their breathing slows to a crawl.",
  "opens their eyes. The pupils have narrowed to thin vertical slits.",
  "whispers, \"I see the pull. I see the patrol. I see the one who will stand in fire.\"",
  "stares at {target} with total, unblinking focus.",
  "sways gently, like a serpent waiting to strike.",
  "goes utterly still. Even the air around them seems to hold its breath.",
  "hisses, \"Now.\" and the trance breaks like a snapped string.",
} }
