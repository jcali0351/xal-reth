-- The Book of Xal'Reth - scripture, part one
-- Every line is an /emote; the game puts your name in front of it.
-- Tokens: {target} = your target (or a fallback), {guild} = your guild name.
local ADDON, ns = ...
ns.Sections = ns.Sections or {}
local S = ns.Sections

-- 1 ---------------------------------------------------------------------
S[#S + 1] = {
  key = "opening", title = "The Gathering of the Faithful", icon = "altar",
  desc = "Opens any meeting of the cult. Perform it before anything else.",
  lines = {
    "strikes the ground three times with a staff. \"The faithful gather. Let the warm stones be laid.\"",
    "unrolls a black silk cloth embroidered with a single golden spiral: the sigil of the Coil.",
    "sets seven smooth river stones upon the cloth, warm to the touch though no fire has been lit.",
    "lights a candle at each corner of the cloth. The flames lean gently toward the center.",
    "calls out, \"Come, all who are cold of blood and warm of heart. Xal'Reth is listening.\"",
    "draws a slow spiral in the dirt around the gathering with the end of a staff.",
    "sprinkles warm sand across the circle. Where it lands, the ground hums faintly.",
    "intones, \"Let no mammal cross this line uninvited. Let no heat lamp go unattended.\"",
    "raises both hands. \"Who comes before the Coil?\" and waits for the faithful to answer.",
    "bows to each of the gathered in turn, slowly, with unblinking eyes.",
    "whispers, \"The circle is drawn. The stones are warm. The Gathering of the Faithful has begun.\"",
    "turns to {target}. \"You. You look cold. Stand nearer to the stones.\"",
    "declares, \"Let the record show that {guild} has assembled, and that nobody here is a lizard.\"",
    "folds their hands and waits in perfect, reptilian stillness for the faithful to settle.",
    "opens the Book of Xal'Reth to the first page. The binding creaks like an old branch in the sun.",
    "reads aloud: \"In the beginning, there was the Warm Stone. And upon it, something basked.\"",
    "closes the book halfway and nods. \"We may begin.\"",
  },
}

-- 2 ---------------------------------------------------------------------
S[#S + 1] = {
  key = "prayers", title = "Prayers of Xal'Reth", icon = "head",
  desc = "The daily prayers. Spoken with eyes closed and body temperature lowered.",
  lines = {
    "kneels and begins the Morning Prayer: \"Xal'Reth, Coiled One, Warden of the Warm Stones, hear me.\"",
    "continues, \"Grant me the patience of the sunning rock and the reflexes of the striking tail.\"",
    "prays, \"Keep my scales hidden from the eyes of mammals, and my loot rolls high.\"",
    "bows lower. \"Forgive me, Xal'Reth, for I stood in fire. Twice. It was very warm.\"",
    "prays, \"Bless the tank, who goes before us. Bless the healer, who forgives us. Bless the rest of us, who pull aggro.\"",
    "whispers the Noon Prayer: \"While the sun is high, let me bask. While the boss is low, let me strike.\"",
    "prays, \"Xal'Reth, who shed the old world like a skin, help me shed my bad habits. Starting next week.\"",
    "folds their hands. \"Let my enemies be slow and cold. Let my friends be warm and well geared.\"",
    "prays, \"Watch over the guild bank, Xal'Reth. Someone keeps taking the good flasks.\"",
    "recites the Evening Prayer: \"The sun departs, but the stones remember its warmth. So shall I remember yours.\"",
    "prays, \"Guard my heat lamp through the night, and let no one unplug it to charge their phone.\"",
    "murmurs, \"In the warm we trust. In the cold we wait. In the Coil we are one.\"",
    "presses their forehead to the ground. \"I am small, Xal'Reth. You are long. Very long. Possibly endless.\"",
    "prays for {target}: \"Xal'Reth, warm this one. They look like they forgot their cloak.\"",
    "recites the Prayer of the Shedding: \"What I was, I leave behind. What I am, I offer you.\"",
    "prays, \"Grant us a timed key, Xal'Reth, and if not a timed key, then at least a funny wipe.\"",
    "prays, \"Bless the officers, who carry the weight of the guild. Bless the guild master, who carries the officers.\"",
    "whispers the Midnight Prayer: \"In the darkest hour, the faithful sleep coiled, warm, and unbothered.\"",
    "rises slowly. \"Hear our prayers, Xal'Reth. Or do not. You are under no obligation. That is what makes you great.\"",
    "ends the prayers with three soft taps to the chest. \"Hail Xal'Reth.\"",
  },
}

-- 3 ---------------------------------------------------------------------
S[#S + 1] = {
  key = "chants", title = "The Weird Chants", icon = "eye",
  desc = "Chants of uncertain origin. Do not perform near livestock.",
  lines = {
    "begins to chant in a low monotone: \"Sssss-ah. Sssss-reth. Sssss-ah. Sssss-reth.\"",
    "rocks slowly side to side, chanting, \"Warm stone, warm stone, flat and warm and warm and flat.\"",
    "chants, \"XAL. XAL. RETH. Xal Xal Reth. XAL RETH XAL.\" in a rhythm that makes no musical sense.",
    "flicks their tongue out twice, rapidly, then denies having done so.",
    "chants the Chant of the Long Tail: \"Longer, longer, ever longer, coiling round the world.\"",
    "hums at a pitch so low that nearby pebbles begin to vibrate.",
    "chants, \"One scale, two scale, red scale, blue scale, Xal'Reth scale, YOU scale.\" and points at {target}.",
    "whispers the forbidden Chant of the Basement, then immediately says, \"Forget that one.\"",
    "chants, \"Bask. Bask. Bask. Bask.\" for exactly the length of time it takes everyone to get uncomfortable.",
    "spins in a slow circle chanting, \"The coil turns, the coil turns, it never stops, the coil turns.\"",
    "chants backwards. It sounds like \"hteR'laX liaH\". The candles flicker in confusion.",
    "begins the Clicking Chant, clicking their tongue in a pattern known only to the Inner Circle and some geckos.",
    "chants, \"Hot rock good. Cold rock bad. Wet rock worst. Hail the hot rock.\"",
    "lowers to a crouch and chants, \"Mammals sleep, mammals sleep, little warm-blooded mammals sleep.\"",
    "chants, \"Where is the heat lamp? Where is the heat lamp? THERE is the heat lamp.\" and points at nothing.",
    "chants the Chant of Infinite Patience by saying nothing at all for a very long time.",
    "breaks into an aggressive whisper: \"Xal'Reth. Xal'Reth. Xal'Reth.\" each one quieter than the last.",
    "chants, \"We are normal. We are human. We have the right number of eyelids.\"",
    "rattles a small gourd full of what are definitely just beans, chanting the name of Xal'Reth with each shake.",
    "ends the chant abruptly, mid-word, and stares into the distance as if nothing happened.",
  },
}

-- 4 ---------------------------------------------------------------------
S[#S + 1] = {
  key = "begging", title = "The Begging Litany", icon = "hands",
  desc = "For when prayer is not enough and dignity is no longer required.",
  lines = {
    "drops to both knees. \"Xal'Reth. Mighty Xal'Reth. I need a favor.\"",
    "clasps their hands together. \"Please. Just one mount. Just one. I have run that dungeon four hundred times.\"",
    "begs, \"Xal'Reth, I will bask every day. Twice a day. I will even bask on Mondays.\"",
    "crawls forward a little. \"Please let the healer stay for one more key. Please. I will be good.\"",
    "begs, \"O Coiled One, let the auction house price drop. Just a little. Just for me.\"",
    "presses their face to the dirt. \"I am but a humble worm. A worm with excellent transmog, but a worm.\"",
    "pleads, \"Xal'Reth, I know I said I would not ask again. I am asking again.\"",
    "holds up a single cricket. \"I brought a snack. It is yours. Please accept it and grant my wish.\"",
    "begs, \"Make the raid leader say 'one more pull' and actually mean ONE more pull.\"",
    "wails softly, \"Why does the Great Vault hate me, Xal'Reth? What did I do to the Great Vault?\"",
    "begs on behalf of {target}: \"Help this one, Xal'Reth. They are trying their best. Their best is not great.\"",
    "rolls onto their back like a submissive lizard. \"See? Belly up. Total surrender. Now please.\"",
    "begs, \"Let my lag be low and my framerate be high, and let no disconnect find me on the last boss.\"",
    "whispers, \"Xal'Reth, if you grant this, I promise to stop calling you 'big lizard' in guild chat.\"",
    "begs, \"Please let the tank have read the guide. Please let the tank have read ANY guide.\"",
    "sobs dramatically into their sleeve. \"I just want the legendary, Xal'Reth. Everyone else has the legendary.\"",
    "offers up a handful of gold coins. \"Take it. Take it all. Except enough for repairs.\"",
    "begs, \"Grant me a quiet queue, a kind group, and a loot roll of one hundred.\"",
    "looks up hopefully, waits, then sighs. \"No answer. That means maybe.\"",
    "rises with as much dignity as can be recovered. \"Thank you for listening, Xal'Reth. I will check back in an hour.\"",
  },
}

-- 5 ---------------------------------------------------------------------
S[#S + 1] = {
  key = "songs", title = "Songs of Xal'Reth", icon = "note",
  desc = "Hymns of the cult. Sing loudly. Sing badly. Xal'Reth does not judge pitch.",
  lines = {
    "clears their throat and begins the First Hymn, 'The Warm Stone Waits':",
    "sings, \"Oh the warm stone waits, oh the warm stone waits, through the cold and the rain the warm stone waits.\"",
    "sings, \"And upon it lies the Coiled One wise, with a thousand scales and two slow eyes.\"",
    "sings the refrain, \"Hail, hail, Xal'Reth, hail! Long of body, long of tail!\"",
    "starts the Second Hymn, 'Ballad of the Great Molt', swaying gently:",
    "sings, \"I was small and I was dull, my skin it fit me tight. So I prayed to old Xal'Reth and shed it in the night.\"",
    "sings, \"Now I'm shiny, now I'm new, I'm scaly through and through. But don't you tell the mammals, or they'll want to shed it too.\"",
    "sings the chorus with great feeling: \"Molt, molt, molt it off! Molt, molt, molt!\"",
    "begins the Third Hymn, 'Lullaby of the Coil', in a hushed, gentle voice:",
    "sings softly, \"Sleep, little cultist, curl up tight, the heat lamp's on and the stones are bright.\"",
    "sings, \"Xal'Reth is watching, long and wise, with patient heart and slitted eyes.\"",
    "sings, \"Dream of basking, dream of sun, dream of loot when the raid is done.\"",
    "launches into the Fourth Hymn, 'March of the Draco Reptilian Elite', stomping in time:",
    "sings, \"We march at dawn, we march at noon, we march beneath the basking moon!\"",
    "sings, \"We are elite, we are discreet, we definitely do not have tails and claws for feet!\"",
    "sings, \"So raise your banner, raise it high, the Draco Reptilian Elite will never die!\"",
    "sings the closing hymn, 'Hail to the Heat Lamp', arms raised:",
    "sings, \"Hail to the lamp that warms the soul, hail to the stone, hail to the coil!\"",
    "sings the final note far longer than anyone expected. It goes on. It keeps going. It finally stops.",
    "bows deeply. \"The Songs of Xal'Reth are sung. Applause is permitted. Hissing is preferred.\"",
  },
}

-- 6 ---------------------------------------------------------------------
S[#S + 1] = {
  key = "xalrathiel", title = "Invocations of Xalrathiel", icon = "crown",
  desc = "The invocations of the High Priestess Xalrathiel, voice of the Coil.",
  lines = {
    "spreads her arms wide. \"I am Xalrathiel, High Priestess of the Coil, and I call upon Xal'Reth.\"",
    "raises a staff crowned with a violet stone. Shadow gathers around it like smoke around a candle.",
    "intones, \"By the first scale and the last, by the warm stone and the long dark, I invoke you.\"",
    "says, \"Xalrathiel speaks, and the Coil listens. The Coil speaks, and Xalrathiel obeys.\"",
    "lets her eyes roll back. When she speaks again, her voice is low and doubled.",
    "speaks in two voices at once: \"THE HIGH PRIESTESS HAS CALLED. WHAT DO THE FAITHFUL DESIRE?\"",
    "invokes, \"Xal'Reth, lend me the patience of a thousand winters and the bite of a single strike.\"",
    "turns her gaze upon {target}. \"The Coil has noticed you. Do not be alarmed. Be slightly alarmed.\"",
    "invokes, \"Let the shadows bend toward the faithful and away from the unworthy.\"",
    "draws a spiral of violet light in the air. It hangs there, slowly turning, then sinks into the ground.",
    "declares, \"I have walked the warm halls beneath the world. I have seen the Great Heat Lamp. It is very bright.\"",
    "invokes the Rite of Shadow and Scale: \"Darkness to hide us. Warmth to keep us. Scales to remain politely unmentioned.\"",
    "places a hand on the earth. \"Xal'Reth, your High Priestess kneels. Let the faithful rise.\"",
    "speaks softly, \"I was chosen not because I was strong, but because I was willing to sit very still for a very long time.\"",
    "invokes, \"Let every cultist here be warmed, guided, and, where necessary, carried through the dungeon.\"",
    "lifts her staff high. The violet stone blazes. \"XAL'RETH! Hear the voice of Xalrathiel!\"",
    "lowers her staff slowly as the light fades. \"He has heard. He is pleased. He is going back to sleep now.\"",
    "bows her head. \"So speaks Xalrathiel, High Priestess of the Coil. So be it. Hail Xal'Reth.\"",
  },
}

-- 7 ---------------------------------------------------------------------
S[#S + 1] = {
  key = "sacrifice", fallback = "the chosen one", title = "The Sacrifice of a Guildmate", icon = "dagger",
  desc = "Target a willing guildmate first. No guildmates are harmed. Mostly.",
  lines = {
    "points a long finger at {target}. \"You have been chosen. Do not run. It makes the ritual awkward.\"",
    "beckons {target} toward the altar with a slow, unsettling smile.",
    "announces, \"Faithful! Xal'Reth hungers! And {target} has volunteered! Nobody else volunteered, so {target} has volunteered.\"",
    "drapes a garland of dried leaves and warm pebbles around {target}'s neck.",
    "gently but firmly guides {target} to lie upon the warm stones.",
    "produces a ceremonial dagger. It is made of wood. It is painted gold. It is very ceremonial.",
    "raises the dagger high. \"O Xal'Reth! Accept this offering! It has decent gear and a cheerful attitude!\"",
    "pauses, dagger raised, and leans down to {target}. \"Any last words? Keep it short, the candles are burning.\"",
    "reads from a scroll: \"Do you, {target}, offer your loyalty, your gold, and your next three loot rolls to Xal'Reth?\"",
    "nods solemnly. \"Xal'Reth accepts your loot rolls. That is the real sacrifice.\"",
    "brings the wooden dagger down with great drama. It taps {target} gently on the shoulder. Boop.",
    "throws their head back and shouts, \"IT IS DONE! The offering is accepted!\"",
    "listens carefully to the silence, then announces, \"Xal'Reth says {target} was delicious. Spiritually.\"",
    "helps {target} up off the stones and brushes away the sand. \"Congratulations. You are now Sacred.\"",
    "presents {target} with a small clay medallion stamped with the Coil. \"Your certificate of sacrifice.\"",
    "announces, \"Let it be written that {target} was sacrificed to Xal'Reth, and was fine, and stayed for raid.\"",
    "leads the faithful in polite applause for {target}.",
    "says, \"Next week we sacrifice someone else. Do not all volunteer at once.\"",
  },
}
