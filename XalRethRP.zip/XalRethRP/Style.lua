-- Xal'Reth RP - look and feel: Warcraft stone backgrounds with a purple
-- overlay, purple buttons, the golden razzle-dazzle, the synth pad, and
-- Xal'Reth's dragon morph.
local ADDON, ns = ...
local R = ns.R
local MEDIA = "Interface\\AddOns\\" .. ADDON .. "\\Media\\"

---------------------------------------------------------------------------
-- Backgrounds: the game's own stone texture, tinted and washed in purple,
-- inside our gold frame.
---------------------------------------------------------------------------
local STONE = "Interface\\FrameGeneral\\UI-Background-Rock"

function R:DressFrame(f, frameTex, w, h, cw, ch)
  local mask = f:CreateMaskTexture()
  mask:SetTexture(self:Tex("mask_round"), "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
  mask:SetPoint("TOPLEFT", 3, -3)
  mask:SetPoint("BOTTOMRIGHT", -3, 3)
  local function layer(sub)
    local t = f:CreateTexture(nil, "BACKGROUND", nil, sub)
    t:SetPoint("TOPLEFT", 3, -3)
    t:SetPoint("BOTTOMRIGHT", -3, 3)
    t:AddMaskTexture(mask)
    return t
  end
  local base = layer(-8)
  base:SetColorTexture(0.07, 0.02, 0.11, 0.97)
  local stone = layer(-7)
  stone:SetTexture(STONE, "REPEAT", "REPEAT")
  stone:SetHorizTile(true)
  stone:SetVertTile(true)
  stone:SetVertexColor(0.75, 0.62, 1.0)
  stone:SetAlpha(0.85)
  local overlay = layer(-6)
  overlay:SetTexture(self:Tex("purple_overlay"))
  overlay:SetAlpha(0.8)
  local border = f:CreateTexture(nil, "BORDER", nil, 0)
  border:SetAllPoints()
  border:SetTexture(self:Tex(frameTex))
  border:SetTexCoord(0, w / cw, 0, h / ch)
end

---------------------------------------------------------------------------
-- Purple buttons, each a different shade
---------------------------------------------------------------------------
local SHADES = { { 0.78, 0.62, 1.0 }, { 0.62, 0.45, 0.98 }, { 0.88, 0.74, 1.0 }, { 0.55, 0.38, 0.88 },
  { 0.72, 0.55, 0.96 }, { 0.92, 0.82, 1.0 }, { 0.6, 0.44, 0.84 }, { 0.82, 0.6, 0.98 } }
local shadeN = 0

function R:PurpleButton(parent, w, h)
  shadeN = shadeN % #SHADES + 1
  local c = SHADES[shadeN]
  local b = CreateFrame("Button", nil, parent)
  b:SetSize(w or 100, h or 22)
  b:SetNormalTexture(self:Tex("pbtn"))
  b:GetNormalTexture():SetVertexColor(c[1], c[2], c[3])
  b:SetPushedTexture(self:Tex("pbtn_down"))
  b:GetPushedTexture():SetVertexColor(c[1], c[2], c[3])
  b:SetHighlightTexture(self:Tex("pbtn_hl"), "ADD")
  local fs = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  fs:SetPoint("LEFT", 5, 1)          -- 5px padding on every side of the label
  fs:SetPoint("RIGHT", -5, 1)
  fs:SetJustifyH("CENTER")
  fs:SetWordWrap(false)
  fs:SetShadowOffset(1, -1)
  fs:SetShadowColor(0.12, 0, 0.22, 1)
  b:SetFontString(fs)
  b:SetPushedTextOffset(1, -1)
  -- grow the button if a label would not fit with its padding
  local setText = b.SetText
  b.SetText = function(self, text)
    setText(self, text)
    local need = (fs.GetUnboundedStringWidth and fs:GetUnboundedStringWidth() or fs:GetStringWidth()) + 10
    if need > self:GetWidth() then self:SetWidth(need) end
    if self:GetHeight() < fs:GetStringHeight() + 10 then self:SetHeight(fs:GetStringHeight() + 10) end
  end
  return b
end

---------------------------------------------------------------------------
-- Razzle-dazzle: on every emote Xal'Reth erupts in gold
---------------------------------------------------------------------------
local function fade(ag, peak, inT, holdT, outT, startDelay)
  local a = ag:CreateAnimation("Alpha")
  a:SetFromAlpha(0); a:SetToAlpha(peak); a:SetDuration(inT); a:SetOrder(1)
  if startDelay then a:SetStartDelay(startDelay) end
  local b = ag:CreateAnimation("Alpha")
  b:SetFromAlpha(peak); b:SetToAlpha(0); b:SetDuration(outT); b:SetOrder(2)
  if holdT and holdT > 0 then b:SetStartDelay(holdT) end
end

local function scale(ag, from, to, dur, startDelay)
  local s = ag:CreateAnimation("Scale")
  if s.SetScaleFrom then s:SetScaleFrom(from, from); s:SetScaleTo(to, to)
  else s:SetScale(to / from, to / from) end
  s:SetDuration(dur); s:SetOrder(1)
  if startDelay then s:SetStartDelay(startDelay) end
  return s
end

function R:BuildDazzle(p)
  local d = CreateFrame("Frame", nil, p)
  d:SetSize(1, 1)
  d:SetPoint("CENTER", p.logo, "CENTER")
  d:SetFrameLevel(p:GetFrameLevel() + 8)
  local function tex(name, size)
    local t = d:CreateTexture(nil, "OVERLAY")
    t:SetTexture(self:Tex(name))
    t:SetSize(size, size)
    t:SetPoint("CENTER")
    t:SetBlendMode("ADD")
    t:SetAlpha(0)
    return t
  end
  local groups = {}
  local function group(t) local ag = t:CreateAnimationGroup(); groups[#groups + 1] = ag; return ag end

  -- wide golden halo
  local halo = tex("gold_glow", 240)
  local ag = group(halo); fade(ag, 1, 0.2, 0.5, 1.8); scale(ag, 0.7, 1.3, 2.5)
  -- second halo, brighter core
  local core = tex("gold_glow", 130)
  ag = group(core); fade(ag, 1, 0.12, 0.3, 1.2)
  -- golden rays, turning as they fade
  local rays = tex("gold_rays", 320)
  ag = group(rays); fade(ag, 1, 0.25, 0.4, 2.0); scale(ag, 0.55, 1.2, 2.65)
  local rot = ag:CreateAnimation("Rotation"); rot:SetDegrees(-80); rot:SetDuration(2.65); rot:SetOrder(1)
  -- two shockwave rings
  for k = 0, 1 do
    local ring = tex("gold_ring", 110)
    ag = group(ring); fade(ag, 1, 0.08, 0, 0.95, k * 0.35); scale(ag, 0.5, 2.8, 1.05, k * 0.35)
  end
  -- a double flash on Xal'Reth himself
  local flash = tex("gold_glow", 110)
  ag = group(flash)
  local f1 = ag:CreateAnimation("Alpha"); f1:SetFromAlpha(0); f1:SetToAlpha(1); f1:SetDuration(0.1); f1:SetOrder(1)
  local f2 = ag:CreateAnimation("Alpha"); f2:SetFromAlpha(1); f2:SetToAlpha(0.25); f2:SetDuration(0.25); f2:SetOrder(2)
  local f3 = ag:CreateAnimation("Alpha"); f3:SetFromAlpha(0.25); f3:SetToAlpha(0.9); f3:SetDuration(0.15); f3:SetOrder(3)
  local f4 = ag:CreateAnimation("Alpha"); f4:SetFromAlpha(0.9); f4:SetToAlpha(0); f4:SetDuration(0.9); f4:SetOrder(4)
  -- sparkles bursting outward
  d.sparks = {}
  for i = 1, 26 do
    local size = 14 + (i % 5) * 5
    local sp = tex("sparkle", size)
    local sg = group(sp)
    local delay = (i % 9) * 0.05
    local tr = sg:CreateAnimation("Translation")
    tr:SetDuration(1.2 + (i % 4) * 0.2); tr:SetOrder(1); tr:SetStartDelay(delay)
    if tr.SetSmoothing then tr:SetSmoothing("OUT") end
    fade(sg, 1, 0.1, 0.5, 0.8, delay)
    scale(sg, 0.4, 1.3, 1.2, delay)
    local sr = sg:CreateAnimation("Rotation"); sr:SetDegrees(180); sr:SetDuration(1.4); sr:SetOrder(1); sr:SetStartDelay(delay)
    d.sparks[i] = tr
  end
  d.groups = groups
  p.dazzle = d
end

function R:Dazzle()
  local p = self.bar
  if not (p and p:IsShown() and p.dazzle) then return end
  for _, tr in ipairs(p.dazzle.sparks) do
    local a = math.random() * 2 * math.pi
    local r = 60 + math.random() * 90
    tr:SetOffset(math.cos(a) * r, math.sin(a) * r)
  end
  for _, ag in ipairs(p.dazzle.groups) do ag:Stop(); ag:Play() end
  if self.db.sound then
    local now = GetTime()
    if not self.lastPad or now - self.lastPad > 3 then
      self.lastPad = now
      pcall(PlaySoundFile, MEDIA .. "pad.ogg", "Master")
    end
  end
end

---------------------------------------------------------------------------
-- The dragon morph: every 15 seconds Xal'Reth slowly takes his dragon form,
-- holds it, and returns. Frames cross-fade so the change is smooth.
---------------------------------------------------------------------------
local LOGO_FRAMES, PORTRAIT_FRAMES = 12, 8
local CYCLE, MORPH, HOLD = 15, 2.8, 5.0

local function framePath(kind, i) return MEDIA .. "morph\\" .. kind .. ("%02d"):format(i) end

-- progress 0 = Xal'Reth, 1 = dragon, for time t within the cycle
local function morphProgress(t)
  if t < MORPH then return t / MORPH end
  if t < MORPH + HOLD then return 1 end
  if t < MORPH * 2 + HOLD then return 1 - (t - MORPH - HOLD) / MORPH end
  return 0
end

local function applyMorph(base, top, kind, count, prog)
  local pos = prog * (count - 1)
  local i = math.floor(pos)
  if i >= count - 1 then i = count - 2 end
  local frac = pos - i
  if base.morphIndex ~= i then
    base:SetTexture(framePath(kind, i))
    top:SetTexture(framePath(kind, i + 1))
    base.morphIndex = i
  end
  top:SetAlpha(frac)
end

function R:AttachMorph(baseTex, kind, count)
  local parent = baseTex:GetParent()
  local layer, sub = baseTex:GetDrawLayer()
  local top = parent:CreateTexture(nil, layer, nil, math.min(7, (sub or 0) + 1))
  top:SetAllPoints(baseTex)
  top:SetAlpha(0)
  -- preload every frame so the first transformation is smooth
  for i = 0, count - 1 do
    local pre = parent:CreateTexture(nil, "BACKGROUND")
    pre:SetTexture(framePath(kind, i)); pre:SetSize(1, 1); pre:SetAlpha(0)
  end
  self.morphs = self.morphs or {}
  table.insert(self.morphs, { base = baseTex, top = top, kind = kind, count = count })
  if not self.morphDriver then
    local drv = CreateFrame("Frame")
    drv.t = 0
    drv:SetScript("OnUpdate", function(f, el)
      if not R.db.morph then
        for _, m in ipairs(R.morphs) do applyMorph(m.base, m.top, m.kind, m.count, 0) end
        return
      end
      f.t = (f.t + el) % CYCLE
      local prog = morphProgress(f.t)
      for _, m in ipairs(R.morphs) do
        if m.base:IsVisible() then applyMorph(m.base, m.top, m.kind, m.count, prog) end
      end
    end)
    self.morphDriver = drv
  end
end

R.LOGO_FRAMES, R.PORTRAIT_FRAMES = LOGO_FRAMES, PORTRAIT_FRAMES
