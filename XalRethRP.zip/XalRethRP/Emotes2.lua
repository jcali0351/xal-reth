-- Xal'Reth RP - new rites (v2.0)
-- Tokens: {target} = your target (or the set's stand-in), {guild} = your guild name
local ADDON, ns = ...
local S = ns.Sets
ns.NewOrder = { "decrees", "prophecy", "origin", "warcries", "wedding", "confession", "callresponse", "ambient" }

S.decrees = {
  title = "Decrees of MaximumRex", icon = "scroll", shuffle = false, fallback = "the faithful",
  lines = {
    "unrolls a long scroll sealed with green wax and the imprint of a very large claw.",
    "clears their throat. \"Hear ye! A decree from MaximumRex, Supreme Leader of the Coil, Warden of the Guild Bank!\"",
    "reads, \"By order of MaximumRex: all cultists shall bask for no less than one hour daily. Rain is not an excuse.\"",
    "reads, \"By order of MaximumRex: the word 'lizard' is banned in guild chat. Use 'scale-adjacent human'.\"",
    "reads, \"By order of MaximumRex: whoever keeps taking the good flasks from the bank will be fed to the heat lamp.\"",
    "reads, \"By order of MaximumRex: raid starts on time. 'On time' means on time. Not 'on time-ish'.\"",
    "reads, \"By order of MaximumRex: the basement is closed for renovations. There is no basement.\"",
    "reads, \"By order of MaximumRex: all new Initiates shall be greeted warmly. Literally. Bring a heat lamp.\"",
    "reads, \"By order of MaximumRex: crickets in the guild hall must be kept in their jars. All of them. Count them.\"",
    "reads, \"By order of MaximumRex: {target} is hereby commended for loyal service and slightly above average DPS.\"",
    "reads, \"By order of MaximumRex: shedding in public is permitted only on Fridays and only behind the inn.\"",
    "reads, \"By order of MaximumRex: anyone who pulls the boss early shall carry the Cone of Shame until next reset.\"",
    "reads, \"By order of MaximumRex: Xal'Reth is to be praised before every pull, and blamed after every wipe.\"",
    "reads, \"By order of MaximumRex: the High Priestess speaks with the full authority of the Coil. Mostly about snacks.\"",
    "rolls the scroll back up with great care. \"So it is decreed. So it shall be. Long live MaximumRex.\"",
    "bows toward the guild hall. \"Hail MaximumRex! Hail Xal'Reth! Dismissed.\"",
  },
}

S.prophecy = {
  title = "The Prophecy of the Great Molt", icon = "moon", shuffle = false, fallback = "the chosen one",
  lines = {
    "stares upward, eyes wide and unblinking. \"I have seen it. I have seen the Great Molt.\"",
    "speaks in a slow, distant voice. \"When the twin moons align and the heat lamps flicker as one...\"",
    "continues, \"...the old skin of the world shall split from horizon to horizon.\"",
    "raises a trembling hand. \"And from the cracks shall rise warmth. So much warmth. Uncomfortable amounts of warmth.\"",
    "whispers, \"The mammals shall reach for their blankets, and find them already shed.\"",
    "intones, \"The sun shall pause in the sky, so that the faithful may bask a little longer.\"",
    "declares, \"And the Coiled One shall wake, and stretch, and it shall take three days. He is very long.\"",
    "turns slowly toward {target}. \"And one shall stand before the Coil, and they shall look a lot like you.\"",
    "trembles. \"The chosen one shall carry the Last Warm Stone to the altar, and not drop it. Please do not drop it.\"",
    "whispers, \"Then the faithful of {guild} shall cast off their disguises, and nobody will be surprised.\"",
    "shouts, \"THE MOLT IS COMING! Pack light! Wear something loose! Hydrate!\"",
    "staggers, the vision fading from their eyes. \"I... where am I? Did I say anything weird?\"",
    "consults a small notebook. \"According to my math, the Great Molt is next Tuesday. Or in four thousand years.\"",
    "closes the notebook. \"Either way, bring snacks. The prophecy is clear on snacks.\"",
  },
}

S.origin = {
  title = "The Tale of Xal'Reth's Awakening", icon = "stone", shuffle = false, fallback = "a young listener",
  lines = {
    "sits upon a warm stone and gestures for the faithful to gather close. \"Let me tell you how it began.\"",
    "begins, \"Long ago, before the first heat lamp, the world was cold, and all creatures shivered.\"",
    "continues, \"Deep beneath the earth there lay a single stone, warmer than all the others. Nobody knew why.\"",
    "lowers their voice. \"Upon that stone, curled in a perfect spiral, slept Xal'Reth. He had been napping for an age.\"",
    "says, \"One day a small lizard, lost and cold, wandered into the deep and found the warm stone.\"",
    "smiles. \"The lizard did not ask permission. The lizard simply climbed on top and basked. Very bold.\"",
    "says, \"And Xal'Reth opened one great golden eye, and looked at the tiny lizard sitting on his warm stone.\"",
    "pauses dramatically. \"Everyone expected him to be angry. Instead he said: 'Finally. Company.'\"",
    "continues, \"From that day the lizard was the first of the faithful, and the warm stone was the first altar.\"",
    "says, \"More came: lizards, serpents, a confused turtle, and later some very suspicious humans.\"",
    "explains, \"Xal'Reth taught them three things: be patient, stay warm, and never tell the mammals.\"",
    "nods to {target}. \"That is why we bask. That is why we wait. That is why we are so very good at standing still.\"",
    "says, \"And one day, the faithful built a guild, and called it {guild}, and the rest is history.\"",
    "spreads their hands. \"Xal'Reth sleeps still, coiled beneath us. When you feel warm ground, that is him.\"",
    "stands and dusts off their robes. \"That is the tale. Now go to bed. Or to raid. Whichever is warmer.\"",
  },
}

S.warcries = {
  title = "Battle Prayers", icon = "swords", shuffle = true, fallback = "our tank",
  lines = {
    "raises a fist. \"For Xal'Reth! For the Coil! For the loot!\"",
    "whispers a quick prayer: \"Xal'Reth, let the tank have read the tactics.\"",
    "hisses loudly and bares their teeth at the enemy. It is surprisingly intimidating.",
    "shouts, \"Cold blood, steady hands! We strike when it is warm!\"",
    "slaps {target} on the back. \"Go on. Xal'Reth believes in you. The rest of us are hedging.\"",
    "draws the sign of the Coil in the air. \"Let this pull be blessed, and short.\"",
    "bellows, \"DRACO REPTILIAN ELITE! SCALES OUT!\" then quickly adds, \"Metaphorically!\"",
    "murmurs, \"May our cooldowns line up and our feet stay out of the fire.\"",
    "chants, \"Bask, strike, loot. Bask, strike, loot.\" growing louder each time.",
    "cracks their neck in three places. Two of them sounded reptilian.",
    "shouts, \"Remember the Lament for the Wiped! We will not need it tonight!\"",
    "points dramatically at the enemy. \"You stand between us and our warm stones. Big mistake.\"",
    "kisses a small clay idol of Xal'Reth and tucks it into their armor for luck.",
    "roars, \"XAL'RETH HUNGERS!\" and then, more quietly, \"for victory. He hungers for victory.\"",
    "lowers into a crouch, tail-less but somehow wagging. \"Ready when you are, {target}.\"",
    "nods solemnly to the group. \"If I fall, avenge me. If I stand in fire, do not tell anyone.\"",
  },
}

S.wedding = {
  title = "The Binding of the Coil", icon = "rings", shuffle = false, fallback = "the beloved",
  lines = {
    "steps before the altar and spreads their arms. \"Faithful! We gather to bind two souls in the warmth of the Coil.\"",
    "lays a ribbon of green silk across the warm stones in a slow spiral.",
    "says, \"Xal'Reth teaches that two cold creatures, basking together, stay warm through any winter.\"",
    "turns to {target}. \"Do you come to the Coil freely, with a warm heart and a reasonably full bank?\"",
    "asks, \"Do you promise to share your basking stone, your heat lamp, and your last health potion?\"",
    "asks, \"Do you promise to stand beside your beloved in every raid, and behind them when there is fire?\"",
    "asks, \"Do you promise never to sell their mount collection, no matter how many gold it would fetch?\"",
    "says, \"Then let the rings be brought forth: two coils of gold, each with no beginning and no end.\"",
    "holds up the rings to the light. They glint violet for just a moment.",
    "wraps the green silk ribbon gently around the joined hands of the couple.",
    "intones, \"By the first scale and the last, by the warm stone and the long dark, you are bound.\"",
    "declares, \"May you shed together, bask together, and never argue about the thermostat.\"",
    "raises both hands. \"By the power vested in me by Xal'Reth and the officers of {guild}, I pronounce you Coiled!\"",
    "throws a handful of warm sand into the air like confetti. It gets everywhere.",
    "leads the faithful in long, joyful hissing applause.",
    "announces, \"To the feast! There are crickets! There are so many crickets!\"",
  },
}

S.confession = {
  title = "The Rite of Confession", icon = "mask", shuffle = false, fallback = "the penitent",
  lines = {
    "sits behind a small screen of woven reeds. \"Approach, penitent. Xal'Reth listens. I also listen. I will tell no one.\"",
    "beckons {target} closer. \"Speak your sins, and be warmed.\"",
    "listens carefully, then gasps. \"You rolled Need on WHAT? For your OFF-SPEC?\"",
    "nods slowly. \"Standing in fire, three times. Yes. Xal'Reth has seen worse. Xal'Reth has done worse.\"",
    "leans in. \"And you took the last flask from the guild bank and did not replace it? That is a serious one.\"",
    "sighs deeply. \"You called Xal'Reth 'the big iguana' in guild chat. He heard. He always hears.\"",
    "whispers, \"You left the heat lamp on overnight? Bold. Dangerous. Spiritually admirable.\"",
    "covers their face. \"You went AFK in the middle of a key and blamed your cat. Do you even have a cat?\"",
    "says, \"For your penance: bask for one hour, compliment the healer, and replace that flask.\"",
    "adds, \"Also you must say 'Hail Xal'Reth' in guild chat with total sincerity. Total.\"",
    "places a warm stone in {target}'s hand. \"Hold this. Feel the warmth. You are forgiven. Mostly.\"",
    "makes the sign of the Coil. \"Go, and sin no more. Or sin less. Or at least sin in a different dungeon.\"",
    "turns to the waiting line of cultists. \"Next! And please, we only have time for small sins today.\"",
  },
}

S.callresponse = {
  title = "Call and Response", icon = "bell", shuffle = false, fallback = "the faithful",
  lines = {
    "rings a small bronze bell three times. \"Faithful! When I call, you answer! Ready?\"",
    "calls out, \"Who are we?\" (Answer: The Draco Reptilian Elite!)",
    "calls, \"What are we?\" (Answer: Totally normal humans!)",
    "calls, \"What do we love?\" (Answer: Warm stones!)",
    "calls, \"What do we fear?\" (Answer: Cold rain and bad tanks!)",
    "calls, \"Who watches over us?\" (Answer: Xal'Reth!)",
    "calls, \"How long is Xal'Reth?\" (Answer: VERY long!)",
    "calls, \"What do we never discuss?\" (Answer: The basement!)",
    "calls, \"What do we do when the sun comes out?\" (Answer: BASK!)",
    "points at {target}. \"You! Louder! What do we do when the sun comes out?\"",
    "calls, \"And what do we say to the mammals?\" (Answer: Nothing! Act natural!)",
    "calls, \"Who leads the Coil?\" (Answer: MaximumRex!)",
    "calls, \"And what do we always say?\" (Answer: HAIL XAL'RETH!)",
    "rings the bell once more and beams with pride. \"Beautiful. Xal'Reth heard that one. Possibly the neighbors too.\"",
  },
}

S.ambient = {
  title = "Idle Cultist (ambient)", icon = "lamp", shuffle = true, fallback = "a passerby",
  lines = {
    "finds a patch of sunlight and stands in it, eyes half closed, perfectly content.",
    "polishes a small warm stone with the corner of their sleeve.",
    "hums the Basking Psalm quietly to themselves.",
    "glances suspiciously at a passing mammal, then relaxes.",
    "flicks a speck of something off their arm. It looked a little bit like a scale.",
    "adjusts their robes and checks the time. It is basking o'clock. It is always basking o'clock.",
    "nibbles a cricket from a small paper bag, very discreetly.",
    "murmurs a short prayer to Xal'Reth under their breath.",
    "stands very, very still. A passerby wonders if they are a statue.",
    "traces a tiny spiral in the dust with the toe of their boot.",
    "stretches slowly, starting at the neck and ending somewhere unexpectedly far down.",
    "nods knowingly to {target}, as if they share a secret. They do not. Or do they.",
    "reads a small black book with a golden spiral on the cover, turning pages very slowly.",
    "sniffs the air. \"Rain later. Cold rain. Terrible.\"",
    "warms their hands over a candle that does not appear to be lit.",
    "blinks slowly. Then once more, sideways. Probably a trick of the light.",
    "whispers, \"Hail Xal'Reth,\" to absolutely no one, then goes back to waiting.",
    "taps their chest three times, the old salute, out of pure habit.",
    "tilts their head toward the sun and sighs with deep satisfaction.",
    "counts the crickets in their pocket. Recounts them. One is missing. Narrows their eyes.",
    "writes something in a tiny notebook labeled 'MAMMALS: SUSPICIOUS'.",
    "leans against a warm wall and soaks up the heat like a sponge.",
    "smooths their hair back. It stays perfectly in place. Unnaturally in place.",
    "smiles serenely at nothing at all. Xal'Reth is near. Xal'Reth is always near.",
  },
}
