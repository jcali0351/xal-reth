-- The Book of Xal'Reth - scripture, part two
local ADDON, ns = ...
ns.Sections = ns.Sections or {}
local S = ns.Sections

-- 8 ---------------------------------------------------------------------
S[#S + 1] = {
  key = "blessings", title = "Xal'Reth Bless You All", icon = "sun",
  desc = "Blessings for the faithful. Spread them generously; they are free.",
  lines = {
    "spreads both arms over the crowd. \"Xal'Reth bless you all!\"",
    "blesses the tanks: \"May your cooldowns be ready and your healers be awake.\"",
    "blesses the healers: \"May your mana never run dry and your party never stand in the bad.\"",
    "blesses the damage dealers: \"May your crits be many and your deaths be few.\"",
    "blesses the crafters: \"May your materials be cheap and your customers be patient.\"",
    "blesses the collectors: \"May every mount drop on the first try, and every pet be yours.\"",
    "blesses the roleplayers: \"May your stories be grand, your emotes be long, and your typos be few.\"",
    "blesses the casuals: \"May you log in whenever you like and be greeted warmly every time.\"",
    "blesses the officers: \"May your patience be infinite and your guild drama be zero.\"",
    "places a warm hand on {target}'s head. \"Xal'Reth bless you specifically. You look like you need it.\"",
    "blesses the guild bank: \"May it be full, may it be organized, may someone finally sort the herbs.\"",
    "blesses the newcomers: \"Welcome to the Coil. Your blessings are retroactive.\"",
    "blesses the ones who are not here: \"Wherever you are tonight, may your stones be warm.\"",
    "blesses the very air: \"Let it be warm. Let it be dry. Let it smell faintly of hot rocks.\"",
    "blesses the loot: \"May it be fair, may it be plentiful, may it go to the one who needs it and not the one who rolled need on everything.\"",
    "blesses the heat lamps of {guild}: \"Burn bright, burn long, burn without tripping the breaker.\"",
    "sprinkles warm sand over everyone within reach. \"Blessed. Blessed. You are blessed. You too.\"",
    "raises both hands one final time. \"Xal'Reth bless you all, every scale of you. Go forth and bask.\"",
  },
}

-- 9 ---------------------------------------------------------------------
S[#S + 1] = {
  key = "initiation", fallback = "the Initiate", title = "Initiation of the New Scaled", icon = "egg",
  desc = "Target the new member. Welcomes them into the Coil.",
  lines = {
    "calls out, \"Bring forth the Initiate!\" and gestures toward {target}.",
    "circles {target} slowly, inspecting every inch. \"Hmm. Warm-blooded. We can work with that.\"",
    "asks, \"Initiate {target}, do you seek the warmth of the Coil?\" and waits for an answer.",
    "asks, \"Do you swear to bask when the sun is out, and to never speak of the basement?\"",
    "asks, \"Do you swear to show up for raid, mostly on time, with flasks?\"",
    "asks, \"Do you accept that we are ordinary humans and that nothing about this is suspicious?\"",
    "nods slowly. \"The Initiate has sworn. Bring the Egg of Becoming.\"",
    "presents a large, speckled stone egg and places it gently in {target}'s hands.",
    "says, \"Hold it close. Keep it warm. That is the whole lesson. Most people fail it.\"",
    "anoints {target}'s brow with warm sand. \"By the first scale, you are seen.\"",
    "anoints {target}'s hands. \"By the long tail, you are bound.\"",
    "anoints {target}'s feet. \"By the warm stone, you are home.\"",
    "takes back the stone egg and inspects it. \"Still warm. Excellent. You pass.\"",
    "raises {target}'s hand into the air. \"Faithful! Welcome our newest member of the Coil!\"",
    "leads a chorus of hissing applause for {target}.",
    "whispers to {target}, \"Your scales will arrive in four to six business days. Do not open the package in public.\"",
    "bows to {target}. \"Welcome to {guild}. Xal'Reth is glad you are here. So are we.\"",
  },
}

-- 10 --------------------------------------------------------------------
S[#S + 1] = {
  key = "feast", title = "The Feast of Crickets", icon = "bowl",
  desc = "A celebration after a good raid night. Bring snacks. Bring more snacks.",
  lines = {
    "rings a small bronze bell. \"The Feast of Crickets begins! Everyone, to the table!\"",
    "unveils a large covered bowl with great ceremony. Inside: crickets. Hundreds. Seasoned.",
    "raises a cricket like a fine glass of wine. \"To Xal'Reth, who provides!\"",
    "eats the cricket with eyes closed and an expression of deep spiritual satisfaction.",
    "passes the bowl to {target}. \"Take two. They are small. Take three, actually.\"",
    "announces, \"For those who are not yet ready for crickets, there is bread. Bread is fine. Bread is acceptable.\"",
    "pours warm water into small clay cups and passes the cups around. \"Warm water. The drink of the faithful.\"",
    "stands and gives a toast: \"To tonight's raid! We wiped many times, but we wiped together!\"",
    "gives a second toast: \"To our tanks, who took every hit, and to our healers, who forgave every mistake!\"",
    "gives a third toast: \"To the loot that dropped, and to the loot that did not. We will meet again.\"",
    "leans back, contented. \"Ah. This is the warmest I have been all week.\"",
    "tells a long story about a heroic battle. It is mostly true. The dragon gets bigger every time.",
    "sneaks a few extra crickets into a pocket for later. No one is fooled.",
    "slowly sinks into a food coma, eyes half closed, basking in the candlelight.",
    "rouses themselves. \"The Feast is complete. Xal'Reth is fed. We are fed. Everything is fed.\"",
  },
}

-- 11 --------------------------------------------------------------------
S[#S + 1] = {
  key = "lament", fallback = "the fallen", title = "Lament for the Wiped", icon = "candle",
  desc = "Perform after a raid wipe. Mourn, then rez, then try again.",
  lines = {
    "kneels amid the fallen and lights a single candle. \"We gather to mourn the wipe.\"",
    "bows their head. \"They stood in the fire. They stood in it together. That is a kind of courage.\"",
    "places a warm stone beside each fallen cultist. \"Rest, warm and briefly dead.\"",
    "intones, \"The boss was at four percent. Four. Xal'Reth weeps. Xal'Reth weeps four percent.\"",
    "reads the names of the fallen from a scroll. The scroll is the whole raid roster.",
    "lays a gentle hand on {target}'s corpse. \"You died first. Xal'Reth forgives you. The raid leader might not.\"",
    "sings a slow, mournful dirge: \"Release spirit, release spirit, the long walk back begins.\"",
    "whispers, \"In death, we learn. In death, we read the tactics we should have read before.\"",
    "intones, \"Let the repair bills be light. Let the run back be short. Let no one blame the healer.\"",
    "rises. \"Mourning is over. The Coil does not stay down. The Coil always comes back.\"",
    "raises their arms. \"Faithful, accept your resurrections! We pull again in two minutes!\"",
  },
}

-- 12 --------------------------------------------------------------------
S[#S + 1] = {
  key = "exorcism", fallback = "the afflicted", title = "Exorcism of the Mammal Within", icon = "flame",
  desc = "For a cultist showing worrying signs of warm-bloodedness. Target them.",
  lines = {
    "points at {target}. \"This one has been seen sweating. Shivering. Drinking COLD water. The mammal is strong in them.\"",
    "draws a circle of salt around {target}. \"Do not step out of the circle. The mammal will try to make you.\"",
    "holds a small heat lamp close to {target}'s face. \"Be warmed, and be cleansed!\"",
    "intones, \"Mammal within! I command you! Stop wanting blankets!\"",
    "waves a bundle of smoking herbs around {target}. It smells like a campfire and old socks.",
    "commands, \"Mammal! What is your name?\" and leans in to listen to {target}'s answer.",
    "flicks warm sand at {target}. \"Begone, fur! Begone, sweat! Begone, opinions about room temperature!\"",
    "shouts, \"By the power of Xal'Reth! By the warmth of the stones! By the length of the Coil!\"",
    "grabs {target} by the shoulders. \"Fight it! You are cold of blood! You are patient! You can sit still!\"",
    "staggers back as if struck by an invisible force. \"It is fighting back! It wants a hot chocolate!\"",
    "places both palms on {target}'s forehead and hisses, long and loud.",
    "steps back, panting. \"It is gone. The mammal is gone. You may leave the circle.\"",
    "inspects {target} carefully. \"Blink for me. Slowly. Good. Very good. Very reptilian.\"",
    "announces, \"{target} has been cleansed! Their blood runs cold once more! Hail Xal'Reth!\"",
  },
}

-- 13 --------------------------------------------------------------------
S[#S + 1] = {
  key = "oracle", fallback = "the seeker", title = "The Oracle of the Warm Stones", icon = "orb",
  desc = "Fortunes read from the stones. Target someone to read their fate.",
  lines = {
    "scatters seven warm stones across the silk and studies the pattern intently.",
    "peers at the stones for {target}. \"I see... loot. I see a great deal of loot. None of it is yours.\"",
    "reads the stones. \"A long queue approaches. Bring snacks.\"",
    "gasps. \"The stones form the shape of a mount! A rare mount! Oh. No. That is just a rock shaped like a rock.\"",
    "reads the stones. \"Someone in this guild will forget their flask tonight. The stones will not say who. It is {target}.\"",
    "turns over the largest stone. \"Xal'Reth foresees a timed key. He does not specify which year.\"",
    "reads the stones for {target}. \"You will find love. Or a really good transmog. The stones are blurry.\"",
    "rubs the stones together. They spark violet. \"The omens are favorable. Pull the boss.\"",
    "frowns at the stones. \"The stones say 'reroll'. The stones are joking. Probably.\"",
    "gathers the stones back into the pouch. \"The future is warm. The future is scaly. That is all the stones will say.\"",
  },
}

-- 14 --------------------------------------------------------------------
S[#S + 1] = {
  key = "closing", title = "The Closing Benediction", icon = "coil",
  desc = "Ends any gathering. Perform it last.",
  lines = {
    "closes the Book of Xal'Reth slowly. \"The gathering draws to its end.\"",
    "snuffs the first candle with bare fingers. \"For the stones, which kept us warm.\"",
    "snuffs the second candle. \"For the Coil, which kept us together.\"",
    "snuffs the third candle. \"For the faithful, who kept showing up.\"",
    "snuffs the fourth candle. \"And for Xal'Reth, who kept watch, and mostly napped.\"",
    "gathers the seven stones into a leather pouch, still warm, and ties it with black cord.",
    "folds the silk cloth with great care and tucks it away.",
    "erases the spiral in the dirt with the side of a boot. No trace remains.",
    "raises a hand over the faithful. \"Go now in warmth. Go now in patience. Go now in normal human clothing.\"",
    "says, \"Remember: you were never here, this was never a cult, and the basement does not exist.\"",
    "bows deeply to {target} and to all who gathered. \"Until the stones are warm again.\"",
    "taps their chest three times. \"Hail Xal'Reth. The gathering is closed.\"",
  },
}
