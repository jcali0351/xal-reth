-- Xal'Reth RP - Rite Engine: shared building blocks
-- Placeholders filled by the engine:
--   {epithet} a title of Xal'Reth      {place} where the aspect's rite happens
--   {object}  the order's sacred object  {aspect} the aspect word (frost, ember...)
--   {condition} the aspect's weather/mood  {noun} the rite's title noun
-- and, at emote time: {target} {guild}
local ADDON, ns = ...
ns.Gen = ns.Gen or {}
local G = ns.Gen

G.forms = { "Rite", "Litany", "Vigil", "Hymn", "Oath", "Benediction", "Procession", "Communion", "Ordeal", "Mystery" }

G.epithets = {
  "the Coiled One", "the Warden of the Warm Stones", "the Long Sleeper", "the Keeper of the Heat Lamp",
  "the Unblinking", "the First Basker", "the Patient Coil", "the Golden Eye", "the Endless Tail",
  "the Lord of Slow Things", "the Sun-Drinker", "the Scale Beneath the World", "the Great Molt",
  "the Quiet Fang", "the Breath of Warm Stone", "the Sleeper in the Deep", "the Shedder of Ages",
  "the Coil That Binds", "the Watcher Below", "the Warmth in the Dark", "the Ancient Iguana",
  "the Hissing Dawn", "the Unhurried", "the Keeper of Small Crickets", "the Long and Wise",
  "the Serpent of Seven Stones", "the Eye That Opens Slowly", "the Heart of the Hearth",
  "the Mother-and-Father of All Lizards", "the Very Large and Very Calm",
}

G.openings = {
  "steps into the circle {place} and raises a hand for silence. \"The {form} begins.\"",
  "lays a black silk cloth {place} and sets the {object} upon it.",
  "strikes the ground three times with a staff. \"Gather, faithful. We perform the {form} of the {noun}.\"",
  "lights a ring of candles {place}. The flames lean inward, toward the {object}.",
  "unrolls a strip of scaled leather marked with spirals and kneels upon it.",
  "calls out, \"Come, all who are cold of blood! The {form} of the {noun} begins {place}!\"",
  "draws a slow spiral in the dust {place}, then steps into its center.",
  "places the {object} at the heart of the gathering and bows to it once.",
  "rings a small bronze bell, once for each of the faithful present.",
  "wraps a violet stole around their shoulders and turns to face the faithful.",
  "sets down seven warm stones in a spiral {place}. \"Let it begin.\"",
  "lifts the {object} high so all can see it. \"Behold, and be warmed.\"",
  "opens the Book of Xal'Reth to a page marked with a shed scale.",
  "sprinkles warm sand in a circle {place}. \"Within this line, all are welcome. Except mammals.\"",
  "lowers their hood and speaks softly. \"We begin {place}, {condition}.\"",
  "taps their chest three times, the old salute. \"Faithful. Attend.\"",
  "kneels {place} and presses both palms flat to the ground, listening.",
  "lights a stick of incense that smells of hot rocks and moss. \"The {form} begins.\"",
  "hangs a small brass lantern on a post {place}. Its light is the color of old gold.",
  "arranges the faithful in a spiral, smallest to tallest, then steps into the middle.",
}

G.invocations = {
  "raises both arms. \"Hear us, {voc}! We call you {condition}!\"",
  "intones, \"By the first scale and the last, by the {aspect} and the stone, we invoke {epithet}.\"",
  "whispers, \"{voc}, coil close. Your faithful are cold and the {aspect} is near.\"",
  "chants the old names: \"Coiled One. Long Sleeper. Warden. Hear us.\"",
  "calls, \"Xal'Reth! Xal'Reth! Xal'Reth!\" each time a little quieter, until the last is barely breath.",
  "intones, \"From the warm halls beneath the world, we call {epithet}.\"",
  "spreads their hands over the {object}. \"Let {epithet} look upon this, and be pleased.\"",
  "bows low. \"{voc}, we ask only warmth, patience, and maybe some loot.\"",
  "declares, \"Let the {aspect} bear witness. Let the stones bear witness. Let {target} bear witness.\"",
  "murmurs, \"Open one golden eye, {voc}. Just one. We will not ask for two.\"",
  "invokes, \"Wake, {voc}, but slowly, as is your way.\"",
  "intones, \"We are small, {voc}, and you are long. Very long. Hear us anyway.\"",
  "calls into the {aspect}, \"{voc}! Your faithful have gathered! Mostly on time!\"",
  "lifts their face. \"Xal'Reth, {epithet}, we come {condition}, as the scriptures foretold.\"",
  "speaks in a low, doubled voice: \"THE COIL LISTENS. CONTINUE.\"",
  "sings a single long note, and somewhere far below, something seems to stir.",
  "intones, \"Warm the stone. Warm the blood. Warm the heart. {voc}, hear us.\"",
  "traces the sign of the Coil in the air. It glows faintly violet, then fades.",
  "whispers, \"{voc}, you who basked before the first sunrise, bless this {noun}.\"",
  "kneels. \"Hail, {voc}. Hail the Coil. Hail the {aspect}.\"",
}

G.chants = {
  "Cold of blood, warm of stone, Xal'Reth guards us, scale and bone.",
  "Coil and coil and coil again, warm the lizards, warm the men.",
  "Bask, wait, strike. Bask, wait, strike.",
  "Long the tail and slow the eye, Xal'Reth sees the {aspect} pass by.",
  "Hot rock good, cold rock bad, warmest rock the best we've had.",
  "Sss-ah, sss-reth, sss-ah, sss-reth.",
  "Shed the old, wear the new, Xal'Reth makes it all come true.",
  "In the {aspect} we wait, in the warmth we rise.",
  "One scale, two scale, gold scale, true scale.",
  "Turn the coil, turn the coil, hidden deep beneath the soil.",
  "Patience is the first scale. Stillness is the second.",
  "We are normal, we are human, we have the right amount of eyelids.",
  "Slow is holy, still is wise, warm the stone and close the eyes.",
  "By the {noun} and by the stone, never cold and never alone.",
  "Hiss for the morning, hiss for the night, hiss for the heat lamp burning bright.",
  "The coil turns, the coil turns, the heat lamp never burns.",
  "Xal. Xal. Reth. Xal Xal Reth.",
  "What is shed is offered. What remains is renewed.",
  "Bask in the {aspect}, bask in the light, the Coil holds us through the night.",
  "Warm stone, warm stone, flat and warm and warm and flat.",
}

G.chantLines = {
  "leads the faithful in the chant: \"{chant}\"",
  "begins a low chant, and the faithful take it up: \"{chant}\"",
  "sways slowly, chanting, \"{chant}\"",
  "chants three times, each louder than the last: \"{chant}\"",
  "hums the melody, then sings the words: \"{chant}\"",
  "claps a slow rhythm and chants, \"{chant}\"",
}

G.offerings = {
  "lays a single cricket upon the {object}. \"Accept this, {voc}.\"",
  "places a handful of gold coins beside the {object}. They are immediately warm to the touch.",
  "offers a shed scale, holding it up to the light before setting it down.",
  "pours a cup of warm water over the stones. It hisses and steams.",
  "lays a sprig of dried herbs upon the {object}. It smells faintly of summer.",
  "offers a polished river stone, warm from a day in the sun.",
  "sets down a small clay idol of a very calm iguana as an offering.",
  "burns a grey, useless item from their bags as a humble sacrifice.",
  "places a slice of honey cake beside the {object}. \"For you, {voc}. And for me, after.\"",
  "offers a lock of hair, a loose thread, and one very small cricket.",
  "lays a folded note upon the {object}. On it, a wish. Nobody else may read it.",
  "offers a brand-new candle, lighting it from the old one.",
  "places a flask from the guild bank on the altar. \"It will be returned. Probably.\"",
  "offers a single violet gem, which pulses once and goes dim.",
  "lays a warm woolen scarf upon the {object}. \"So that you are never cold, {voc}.\"",
  "hands {target} an offering bowl. \"Give what you can. Give a little more than that.\"",
  "offers the first loot of the day, still shiny, with only mild reluctance.",
  "pours a pinch of warm sand into the bowl and whispers a name into it.",
  "sets down a tiny heat lamp, no bigger than a thimble. It glows faithfully.",
  "offers a spoonful of {aspect}-touched water, carefully, as if it were precious.",
}

G.omens = {
  "watches the candle flames bend toward {target}. \"An omen. You will be lucky this week.\"",
  "studies the pattern of the warm sand. \"The {aspect} favors us. Pull the boss.\"",
  "listens to the hiss of the stones. \"They say: patience. They always say patience.\"",
  "sees a lizard cross the circle from left to right. \"A good sign. A very good sign.\"",
  "frowns at the smoke. \"The smoke spells 'reroll'. The smoke is joking. Probably.\"",
  "watches the {object} glow violet for a moment. \"Xal'Reth has noticed us.\"",
  "reads the stones. \"Someone here will forget their flask tonight. It is {target}.\"",
  "sees the {aspect} shift and nods slowly. \"Change is coming. Bring snacks.\"",
  "watches a cricket leap onto the altar. \"The cricket has spoken. It said 'yes'.\"",
  "turns the largest stone over. \"Warm on both sides. A blessing doubled.\"",
  "squints at the candlelight. \"I see loot. A great deal of loot. None of it is cloth.\"",
  "feels the ground grow warm beneath their palms. \"He stirs. He approves.\"",
  "watches a single scale drift down from nowhere. \"A gift. Keep it, {target}.\"",
  "hears three soft knocks from below the floor. \"There is no basement. Ignore that.\"",
  "watches the flame gutter, then rise tall. \"Trouble, then triumph. As always.\"",
}

G.beats = {
  "pauses to adjust their robes, then continues with great dignity.",
  "glances suspiciously at a passing mammal, then relaxes.",
  "whispers to {target}, \"You are doing great. Stop fidgeting.\"",
  "basks briefly in the candlelight, eyes half closed, before remembering where they are.",
  "blinks slowly. Then once more, sideways. Probably a trick of the light.",
  "nibbles a cricket from a small paper bag, very discreetly.",
  "hushes a giggling cultist at the back with a single look.",
  "stands perfectly still for an uncomfortably long moment.",
  "flicks a speck of something off their sleeve. It looked a little like a scale.",
  "consults a small notebook labeled 'RITUALS (DO NOT LOSE)'.",
  "mutters, \"This part always takes longer than it should,\" and keeps going.",
  "nods to {target} as if they share a secret. They do not. Or do they.",
  "warms their hands over the candles for a moment before continuing.",
  "sneezes. The faithful pretend it was part of the rite.",
  "smiles serenely. Xal'Reth is near. Xal'Reth is always near.",
}

G.closings = {
  "snuffs the candles one by one with bare fingers. \"The {form} is complete. Hail Xal'Reth.\"",
  "bows to the four directions. \"Go in warmth, faithful.\"",
  "gathers the stones back into a pouch, still warm. \"Until the stones are warm again.\"",
  "folds the silk cloth and tucks the {object} away. \"It is done.\"",
  "taps their chest three times. \"Hail Xal'Reth. The {form} of the {noun} is closed.\"",
  "raises a hand over the faithful. \"Go now in warmth, in patience, and in normal human clothing.\"",
  "erases the spiral in the dust with the side of a boot. No trace remains.",
  "declares, \"The Coil is unbroken. {epithet} is pleased. Dismissed.\"",
  "bows deeply to {target}. \"Thank you for bearing witness.\"",
  "closes the Book of Xal'Reth with a soft thump. \"So it was, so it is, so it shall be.\"",
  "whispers, \"Remember: you were never here, and the basement does not exist.\"",
  "lifts the {object} one last time. \"Xal'Reth has heard. Xal'Reth is going back to sleep now.\"",
  "dims the lantern. \"The {aspect} remains. So do we. Hail Xal'Reth.\"",
  "leads one final, soft hiss. \"The {form} is ended. Snacks are by the door.\"",
  "kneels, touches the ground, and rises. \"Coil tight. Bask often. Hail Xal'Reth.\"",
}
