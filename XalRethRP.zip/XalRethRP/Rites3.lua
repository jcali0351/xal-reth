-- Xal'Reth RP - new rites: Offering, Divination, Lore, Fellowship
local ADDON, ns = ...
local S = ns.Sets

-- Sacrifice and Offering ------------------------------------------------
S.goldoffering = { title = "Offering of Gold", fallback = "the generous one", lines = {
  "sets a brass bowl upon the altar. \"Xal'Reth asks for little. Today he asks for gold.\"",
  "drops in a handful of coins. They clink and glitter in the candlelight.",
  "nods to {target}. \"Give what you can. Give what you won't miss. Give a bit more than that.\"",
  "watches the bowl fill and murmurs approval with each coin.",
  "explains, \"This gold will buy flasks, food, and heat lamp oil for the whole guild.\"",
  "adds, \"Also one very nice chair for the High Priestess. For spiritual reasons.\"",
  "lifts the bowl to the sky. \"Xal'Reth, accept this tribute from the faithful!\"",
  "carries the bowl to the guild bank with great solemnity. \"Logged. Witnessed. Blessed.\"",
} }

S.firstkill = { title = "Offering of the First Kill", fallback = "the first to strike", lines = {
  "kneels beside the first fallen enemy of the day. \"The first kill belongs to Xal'Reth.\"",
  "lays a hand on the defeated foe. \"You fought well. Not well enough. Thank you for the experience points.\"",
  "plucks a single feather, scale, or bolt of cloth from the body as a token.",
  "places the token on a small travel altar. \"For you, Coiled One. The day's first glory.\"",
  "turns to {target}. \"You struck the first blow. The honor is yours.\"",
  "draws the sign of the Coil in the dust. \"May the rest of the hunt be swift.\"",
  "rises. \"The offering is made. Now we kill everything else for ourselves.\"",
} }

S.greyitems = { title = "Burning of the Grey Items", fallback = "the hoarder", lines = {
  "drags a bulging sack before the fire. \"Today we cleanse our bags. Today we burn the grey.\"",
  "pulls out a broken tooth. \"Junk. Worth two copper. Gone.\" Tosses it into the flames.",
  "pulls out a tattered hide. \"Junk.\" Into the fire. \"Junk.\" Into the fire.",
  "turns to {target}. \"Empty your bags. I know you are carrying forty-two pieces of torn cloth.\"",
  "watches the fire crackle with the useless loot of a hundred adventures.",
  "holds up one grey item and hesitates. \"This one... has sentimental value.\" Burns it anyway.",
  "declares, \"Our bags are light! Our spirits are lighter! Our gold is unchanged!\"",
  "warms their hands over the fire. \"The grey items finally served a purpose.\"",
} }

S.tithe = { title = "Tithe to the Guild Bank", fallback = "the depositor", lines = {
  "stands before the guild bank vault holding a ledger. \"The weekly tithe is due.\"",
  "reads from the ledger, \"Flasks: low. Food: low. Enchanting materials: suspiciously low.\"",
  "beckons {target}. \"Approach the vault and give unto the Coil.\"",
  "watches {target} deposit herbs, cloth, and one questionable fish.",
  "writes in the ledger with a long quill. \"Recorded. You have earned Xal'Reth's favor. And a gold star.\"",
  "announces, \"Remember: the guild bank provides for all, but only if all provide.\"",
  "locks the vault with great ceremony. \"The tithe is complete. Do not take the good flasks.\"",
} }

S.lampoffering = { title = "Offering of the Heat Lamp", fallback = "the lamp keeper", lines = {
  "carries a brand-new heat lamp to the altar, still in its packaging.",
  "unwraps it slowly, reverently, and holds it up for all to see. \"Behold. Three hundred watts.\"",
  "places the lamp on the altar and plugs it in. It glows. Everyone sighs with relief.",
  "explains, \"The old lamp served us faithfully for nine years. It is now retired to a nice shelf.\"",
  "asks {target} to say a few words of thanks to the new lamp.",
  "prays, \"May this lamp burn long, warm deep, and never trip the breaker during raid.\"",
  "basks in the new light with eyes closed. \"Oh yes. Oh, that is good. Xal'Reth is pleased.\"",
} }

S.officersacrifice = { title = "Mock Sacrifice of an Officer", fallback = "the officer", lines = {
  "announces, \"Today, Xal'Reth demands a sacrifice of great rank. An officer!\"",
  "points dramatically at {target}. \"YOU. You are an officer. You have been chosen.\"",
  "leads {target} to the altar while the guild cheers far too enthusiastically.",
  "reads the charges: \"Leaving people in queue. Forgetting the raid invites. Saying 'one more pull' twice.\"",
  "raises the wooden dagger high. \"For the faithful who waited in the cold!\"",
  "taps {target} gently on the head. Boop. \"It is done.\"",
  "announces, \"The officer has been sacrificed! They are now reborn as a slightly better officer!\"",
  "helps {target} up. \"No hard feelings. You still have bank access. For now.\"",
} }

S.cricketoffering = { title = "Offering of Crickets", fallback = "the faithful", lines = {
  "opens a small wicker cage. Dozens of crickets chirp inside.",
  "holds the cage up to the sky. \"Xal'Reth, accept these crickets, plump and lively.\"",
  "explains, \"We do not eat these ones. These are the sacred crickets. They get a nice garden.\"",
  "sets the cage on the altar and opens the little door.",
  "watches the crickets hop out into the grass, one by one, free and chirping.",
  "turns to {target}. \"Do not eat them. I know what you are thinking. Do not.\"",
  "listens to the chirping. \"Hear that? That is the sound of Xal'Reth being pleased.\"",
} }

S.plushsacrifice = { title = "Sacrifice of the Mammal Plush", fallback = "the assistant", lines = {
  "produces a stuffed toy bear from a sack. \"Behold! A mammal! A soft, fluffy, warm-blooded mammal!\"",
  "places the bear on the altar. It stares upward with button eyes.",
  "addresses the bear: \"You represent all mammals. Their sweat. Their blankets. Their opinions.\"",
  "hands {target} the wooden dagger. \"You may do the honors.\"",
  "watches {target} tap the plush bear with the dagger. The bear does not react. It is a bear.",
  "declares, \"The mammal is vanquished! Symbolically!\"",
  "hugs the bear afterward. \"Its name is Mr. Fluffington. He comes back every week. He is a good sport.\"",
} }

-- Prophecy and Divination -----------------------------------------------
S.shedreading = { title = "Reading of the Shed Skin", fallback = "the seeker", lines = {
  "unfolds a delicate shed skin across the altar, smoothing out every crinkle.",
  "traces the patterns with a fingertip. \"The skin remembers. The skin foretells.\"",
  "reads for {target}: \"This ridge here. It means... a long journey. Or a long queue.\"",
  "peers closer. \"These spots... a mount. A rare one. No. Wait. That is a stain.\"",
  "holds the skin up to the candlelight. Faint patterns glow violet through it.",
  "declares, \"The skin speaks of change. A new patch. New talents. New complaints.\"",
  "folds the skin carefully. \"The reading is done. The future is scaly, as always.\"",
} }

S.cricketaugury = { title = "Augury of the Crickets", fallback = "the questioner", lines = {
  "releases three crickets onto a board marked with runes. \"The crickets will decide.\"",
  "asks the crickets, \"Will {target} get their loot this week?\"",
  "watches the first cricket hop onto the rune for 'maybe'.",
  "watches the second cricket hop onto 'no', then off it, then back onto it.",
  "watches the third cricket hop off the board entirely and escape.",
  "interprets solemnly, \"The crickets say: it is complicated. Also, we need more crickets.\"",
  "gathers the remaining crickets gently. \"The augury is complete. Xal'Reth thanks the crickets.\"",
} }

S.coildream = { title = "Dream of the Coiled One", fallback = "the dreamer", lines = {
  "lies down on the warm stones and closes their eyes. \"I go to dream with Xal'Reth.\"",
  "breathes slower and slower until they seem not to breathe at all.",
  "murmurs in their sleep, \"...so long... the coil goes down forever... it is so warm here...\"",
  "twitches. \"...he is watching... he has one eye open... he is very relaxed about it...\"",
  "whispers, \"...he says... {target}... should stop pulling extra packs...\"",
  "smiles in their sleep. \"...he says we are doing fine... he says bring more crickets...\"",
  "wakes with a start and sits up. \"I have returned! Xal'Reth sends his regards. And a snack list.\"",
} }

S.starreading = { title = "Reading of the Stars", fallback = "the seeker", lines = {
  "lies back on the grass beneath the night sky. \"The stars hold the map of the Coil.\"",
  "points upward. \"See there? That constellation. The Great Iguana.\"",
  "traces a line of stars. \"And that one. The Heat Lamp. It is very bright this season.\"",
  "points at a faint red star. \"That is Mammalus. Bad omen. Avoid queuing when it rises.\"",
  "reads for {target}: \"Your star is in the house of loot. Expect a good week. Or a long one.\"",
  "watches a shooting star streak across the sky. \"Quick, wish for a mount!\"",
  "sits up. \"The stars have spoken. Mostly about lizards.\"",
} }

S.bones = { title = "Casting of the Bones", fallback = "the one who asks", lines = {
  "shakes a small leather pouch, its contents clacking softly. \"Ask your question.\"",
  "listens to {target}'s question, then nods gravely.",
  "casts the bones across a square of black cloth. They scatter and settle.",
  "studies the pattern. \"The long bone points north. Toward the auction house. Interesting.\"",
  "taps a small skull-shaped bone. \"This means danger. Or a dungeon. Same thing.\"",
  "frowns at two crossed bones. \"These say 'reroll'. They always say 'reroll'. These bones are cynical.\"",
  "gathers the bones back into the pouch. \"The answer is yes. Probably. Do not quote me.\"",
} }

S.coilmirror = { title = "Mirror of the Coil", fallback = "the gazer", lines = {
  "unveils an oval mirror framed in coiled bronze. \"The Mirror of the Coil shows your true self.\"",
  "gazes into it first. Their reflection, for just a moment, has scales. They cough and look away.",
  "invites {target} to look into the mirror.",
  "watches {target}'s reflection carefully. \"Hm. I see... a mighty warrior. And a little bit of lizard.\"",
  "explains, \"Everyone has a bit of lizard in them. Some of us just have more.\"",
  "breathes on the mirror and wipes it with a sleeve. \"Fingerprints. Disrespectful.\"",
  "covers the mirror again with a velvet cloth. \"The mirror rests. It does not like to be stared at.\"",
} }

S.lootomen = { title = "Omen of the Loot Roll", fallback = "the hopeful roller", lines = {
  "turns over an hourglass filled with violet sand. \"Before the roll, we read the omen.\"",
  "watches the sand fall, muttering numbers under their breath.",
  "says, \"If the sand runs fast, roll high. If it runs slow... roll anyway. Hope is free.\"",
  "turns to {target}. \"Close your eyes. Think of the item. Think of it very hard.\"",
  "flicks the hourglass. A single grain sticks. \"Interesting. Very interesting. That means... something.\"",
  "declares, \"The omen is favorable! Probably! Roll now, before Xal'Reth changes his mind!\"",
} }

S.patchprophecy = { title = "Prophecy of the Next Patch", fallback = "the theorycrafter", lines = {
  "climbs onto a crate and holds a quill aloft. \"I have seen the next patch!\"",
  "prophesies, \"Our class will be nerfed. Then buffed. Then nerfed again. As it always is.\"",
  "prophesies, \"A new raid shall rise. Its final boss shall have three phases. The third will be unfair.\"",
  "prophesies, \"The mount everyone wants shall drop at one percent. It shall drop for {target}. Eventually.\"",
  "prophesies, \"The forums shall burn. The forums always burn. Xal'Reth reads none of it.\"",
  "lowers the quill. \"And through it all, the Coil shall endure. Because we bask through everything.\"",
} }

-- Lore and Sermons ------------------------------------------------------
S.firstlamp = { title = "Tale of the First Heat Lamp", fallback = "the listener", lines = {
  "settles by the fire. \"Have I told you the tale of the First Heat Lamp?\"",
  "begins, \"Long ago, the faithful only had the sun. And when the sun left, they grew cold and slow.\"",
  "continues, \"One clever cultist, named Gleamscale, stole a little sun and trapped it in a glass bulb.\"",
  "explains, \"It burned their fingers. It burned their eyebrows. But it glowed. Oh, how it glowed.\"",
  "smiles. \"That night, for the first time, the faithful basked in the dark.\"",
  "leans toward {target}. \"Xal'Reth himself woke up, looked at it, and said: 'Nice.'\"",
  "concludes, \"Every heat lamp since is a child of that first one. Treat them with respect.\"",
} }

S.impatientmammal = { title = "Parable of the Impatient Mammal", fallback = "the young one", lines = {
  "folds their hands. \"Hear now the Parable of the Impatient Mammal.\"",
  "tells, \"A mammal and a lizard both wanted to cross a cold river.\"",
  "continues, \"The mammal leapt in at once, splashing and shivering, and was swept away. Its fur got very soggy.\"",
  "continues, \"The lizard waited on a warm rock until noon, when the river was shallow and the stones were warm.\"",
  "continues, \"Then the lizard walked across, dry and warm, and found the mammal sulking on the far bank.\"",
  "turns to {target}. \"What is the lesson?\"",
  "answers before anyone else can. \"Wait for noon. Never pull before the tank is ready. Same thing.\"",
} }

S.mountsermon = { title = "Sermon on the Mount", fallback = "the farmer", lines = {
  "stands atop a large rock. \"Today, a sermon. On the mount. About the mount.\"",
  "preaches, \"Blessed are the farmers, for they shall run the same dungeon three hundred times.\"",
  "preaches, \"Blessed are the unlucky, for their mount shall drop for someone who just started.\"",
  "preaches, \"Blessed are the patient, for they shall get it eventually, and then never ride it.\"",
  "points at {target}. \"Blessed is this one, who has farmed the same boss every week since the last expansion.\"",
  "preaches, \"And blessed are those who link their mount in guild chat, for they shall be envied.\"",
  "steps down from the rock. \"Go now and farm. Xal'Reth farms with you. Spiritually.\"",
} }

S.greatwipe = { title = "Chronicle of the Great Wipe", fallback = "the survivor", lines = {
  "opens an old, battered book. \"I read from the Chronicle of the Great Wipe.\"",
  "reads, \"It was a night like any other. The raid was confident. Too confident.\"",
  "reads, \"The boss was at one percent. ONE. The healers had nothing left. The tank had less.\"",
  "reads, \"And then... someone stepped in the fire. To this day, nobody admits who.\"",
  "glances at {target}. \"Some say it was you. Some say it was destiny. It was probably you.\"",
  "reads, \"Forty minutes of walking back. The silence in voice chat was deafening.\"",
  "reads, \"But the next week, they returned, and they won, and they never stepped in fire again.\"",
  "closes the book. \"The moral: Watch your feet. Also: never give up.\"",
} }

S.sevenscales = { title = "The Seven Scales of Virtue", fallback = "the student", lines = {
  "holds up seven small polished scales. \"The Seven Scales of Virtue. Learn them.\"",
  "lifts the first scale. \"Patience. The lizard waits for the sun.\"",
  "lifts the second. \"Stillness. The lizard does not fidget.\" Glares at {target}.",
  "lifts the third. \"Warmth. The lizard shares its basking stone.\"",
  "lifts the fourth. \"Discretion. The lizard does not tell the mammals.\"",
  "lifts the fifth. \"Courage. The lizard faces the boss. After the tank.\"",
  "lifts the sixth. \"Generosity. The lizard fills the guild bank.\"",
  "lifts the seventh. \"Humor. The lizard laughs at the wipe. Especially the funny ones.\"",
  "lays the seven scales in a spiral. \"Live by these, and you will never be cold.\"",
} }

S.basementtale = { title = "The Tale of the Basement", fallback = "the curious one", lines = {
  "lowers their voice and leans in close. \"You want to know about the basement.\"",
  "glances over both shoulders. \"There is no basement. Let us be clear. There is no basement.\"",
  "continues anyway, \"But IF there were a basement, it would be very warm.\"",
  "whispers, \"And IF there were a basement, it might contain... a very large heat lamp.\"",
  "adds, \"And IF {target} ever found the door to the basement, they should knock three times. Not that there is one.\"",
  "whispers, \"And some say, if you listen at the floor at midnight, you can hear something very long, breathing.\"",
  "straightens up, smiling brightly. \"Anyway. There is no basement. Who wants crickets?\"",
} }

-- Mischief and Fellowship -----------------------------------------------
S.hideseek = { title = "Hide and Seek: Reptile Rules", fallback = "the seeker", lines = {
  "claps their hands. \"Hide and seek! Reptile rules! You may only hide by standing perfectly still.\"",
  "explains, \"No running. No crouching behind things. Just stillness. Blend in. Be a rock.\"",
  "points to {target}. \"You are the seeker. Count to thirty. Slowly. Like a tortoise.\"",
  "freezes in the middle of the open floor, arms half raised, utterly motionless.",
  "does not move as {target} walks right past. Not a blink. Not a twitch.",
  "remains a statue. A passerby hangs a coat on their outstretched arm.",
  "finally sneezes and is found. \"Unfair. Dust. The dust betrayed me.\"",
} }

S.stillnesstrial = { title = "Trial of Stillness", fallback = "the challenger", lines = {
  "announces, \"The Trial of Stillness! Last one to move wins a warm stone!\"",
  "takes a starting pose and goes completely rigid. \"Begin!\"",
  "remains frozen while the competitors around them twitch and wobble.",
  "does not react when {target} tries to make them laugh with a silly face.",
  "remains frozen as a fly lands on their nose and wanders around for a while.",
  "remains frozen. Somewhere, a guildmate falls over. They are disqualified.",
  "is still frozen. It has been a long time. Some have gone to get snacks.",
  "finally blinks. \"I concede. I had an itch. The itch won.\" Hands {target} the warm stone.",
} }

S.roast = { title = "Roast of a Guildmate", fallback = "the guest of honor", lines = {
  "taps a cup. \"Welcome to the Roast of {target}! Warmest roast in the Coil!\"",
  "begins, \"{target} is so cold-blooded, they need a heat lamp to warm up for a heat lamp.\"",
  "continues, \"{target} has stood in so much fire, the fire filed a complaint.\"",
  "continues, \"{target} spends more time in the guild bank than the gold does.\"",
  "continues, \"I asked {target} for the tactics. They said 'stand behind the tank'. In a puzzle fight.\"",
  "softens. \"But truly. {target} is warm-hearted, loyal, and always shows up. Even when late.\"",
  "raises a cup. \"To {target}! Roasted, toasted, and loved by the Coil!\"",
} }

S.teaparty = { title = "Tea Party of the Coil", fallback = "the guest", lines = {
  "lays out a lace cloth, tiny cups, and a teapot shaped like a coiled serpent.",
  "pours tea for {target} with exaggerated elegance, pinky raised.",
  "offers a plate. \"Biscuit? Or cricket? The crickets have been dipped in honey.\"",
  "sips tea and comments, \"Lovely weather. Warm. Dry. Excellent basking conditions.\"",
  "gossips, \"Did you hear? Someone in the guild rolled need on a cloth item. As a warrior.\"",
  "gasps theatrically at their own gossip and fans themselves with a napkin.",
  "raises the teacup. \"To the Coil. To civility. To being terribly, terribly normal.\"",
} }

S.mammalcontest = { title = "Mammal Impersonation Contest", fallback = "the contestant", lines = {
  "announces, \"The annual Mammal Impersonation Contest! Show us your most convincing mammal!\"",
  "demonstrates first: shivers dramatically, complains about the cold, and asks for a blanket.",
  "adds a yawn with the mouth wide open. \"See? Very mammal. Very warm-blooded.\"",
  "invites {target} to perform. \"Go on. Be fluffy. Be sweaty. Be loud.\"",
  "takes notes as {target} performs. \"The fidgeting is excellent. The fur is unconvincing.\"",
  "whispers to the judges, \"Honestly, that one is a little too good. Keep an eye on them.\"",
  "declares a winner and hands over a prize: a tiny knitted sweater.",
} }

S.interrogation = { title = "Interrogation of a Suspected Mammal", fallback = "the suspect", lines = {
  "pulls up a chair in front of {target} and shines a heat lamp in {target}'s face. \"Sit.\"",
  "asks, \"Where were you on the night the guild bank flasks went missing?\"",
  "leans closer. \"How do you feel about the cold? Be honest. We will know.\"",
  "asks, \"Have you ever, at any point, owned a blanket? More than one?\"",
  "taps the table. \"Blink for me. Slowly. ...Hm. Two eyelids. Suspicious. Or normal. Unclear.\"",
  "asks, \"Final question. Warm stone or soft pillow? Choose carefully.\"",
  "leans back, satisfied. \"Verdict: lizard. Probably. You may go. Do not leave town.\"",
} }

S.midnightbask = { title = "The Midnight Bask Party", fallback = "the party animal", lines = {
  "flips every heat lamp to maximum at the stroke of midnight. \"Let the Midnight Bask begin!\"",
  "lies across three warm stones with an expression of total bliss.",
  "puts on a pair of tiny sunglasses. \"It is dark. I do not care. The vibe is sunny.\"",
  "passes {target} a cup of warm water with a tiny umbrella in it.",
  "starts a slow, lazy dance that is mostly just shifting from one warm spot to another.",
  "declares, \"No raiding! No keys! No dailies! Only basking!\"",
  "dozes off mid-sentence, warm and utterly content.",
  "wakes up hours later, still on the stones. \"Best party ever. Same time next week.\"",
} }
