XAL'RETH RP  v4.1  -  THE BOOK OF XAL'RETH   (WoW Retail / Midnight 12.1)
=========================================================================
Performs the rites of Xal'Reth as /emotes, one line at a time, on a timer.

  The 100 Canon Rites     hand-written, 10 categories, 1,000 emotes
  The Grand Book          10,000 numbered rites in 200 categories
                          (10 Orders x 20 Aspects, 50 rites each), built by
                          the Rite Engine from hand-written pieces. Rite #4817
                          is the same rite on every computer, so the guild can
                          agree on "tonight we perform #4817".
  Your Own and Uploads    paste in your own emotes and save them as rites

INSTALL
  Delete your old XalRethRP folder, then move this "XalRethRP" folder into
    World of Warcraft\_retail_\Interface\AddOns\
  Fully restart WoW (new art only loads on a full restart, not /reload).
  Your settings and custom lines carry over.

THE PANEL  (/xrp shows it; drag it anywhere; X hides it)
  Xal'Reth sits in the rotating sigil with the current rite's icon as a badge.
  Every emote, he erupts in gold: a halo, turning light rays, shockwave rings,
  a burst of sparkles and a golden border flare, with a soft synth pad
  (speaker button or /xrp sound to turn the pad off).
  Every 15 seconds he slowly transforms into his dragon form, holds it, and
  returns (/xrp morph to turn it off). The Book's portrait transforms too.
  Backgrounds use the game's own stone texture washed in purple.
  Play/Pause, Next, Stop     run the rite
  Rites (four squares)       open the Book of Xal'Reth
  Timer slider               5 to 60 seconds between emotes
  Dice                       random timing: every gap is a random 5-35 seconds
  Loop / Test / Shuffle      click to toggle
  [ Upload ]                 open the Upload window
  [ Random ]                 choose a random rite from the Grand Book
                             (shift-click to begin it at once)

THE BOOK  (Rites button, or /xrp book)
  Books:    The 100 Canon Rites, the ten Orders of the Grand Book, Your Own
  Aspects:  each Order has 20 (Dawnlit, Frostbound, Ember-Kissed, Moonsworn...)
  Rites:    left-click to choose, right-click to begin at once
  Search:   type a number (4817), a canon number (c12) or words, press Enter
  Every rite has its own icon: Grand Book icons are built from the Order's
  colors, the Aspect's rim and gem, and the rite's own symbol.

UPLOAD  ([ Upload ] on the panel, or /xrp upload)
  1. Type a name for your rite.
  2. Paste your emotes, one per line (Ctrl+V).
  3. Save as Rite (or Save and Begin). It appears under Your Own and Uploads.
  Cleaned up for you: "/e" and "/emote", numbering like "1." or "-", and your
  character's name at the start of a line. Lines too long for chat are split.
  Use {target} anywhere to insert your target's name.
  To edit or remove one later: type its name, then Load or Delete.

COMMANDS (/xrp help)
  /xrp start ritual | start 4817 | start c12 | start <upload name>
  /xrp pause  resume  next  stop     /xrp book     /xrp upload
  /xrp random      /xrp random start      /xrp search <words>
  /xrp interval 20   /xrp dice   /xrp dice 10 20
  /xrp loop  shuffle  test  sound  morph   /xrp preview <rite>
  /xrp add <text>  list  del <n>   /xrp pronouns auto|she|he|they
  /xrp reset (re-center the panel)

Rites pause automatically in combat and boss chat lockdown, then continue on
the same line. With no target, each rite uses a fitting stand-in name.

THE GRAND BOOK: ORDERS AND ASPECTS
  Orders (I-X): Gathering, Devotion, Hymnody, the Scale, Passage, Battle,
    Offering, Divination, Lore, Fellowship
  Aspects: Dawnlit, Dusk-Hallowed, Rain-Soaked, Frostbound, Ember-Kissed,
    Moonsworn, Stormcalled, Ash-Marked, Blossoming, Tide-Drawn, Hearthbound,
    Shadow-Veiled, Gilded, Bone-Carved, Silk-Woven, Smoke-Wreathed,
    Crystal-Lit, Thunder-Struck, Mist-Shrouded, Star-Crowned
  Numbering: each Order holds 1,000 rites (Order I = #1-1000 ... Order X =
    #9001-10000); each Aspect within it holds 50.

THE 100 CANON RITES  (start them by name, or by number with c1-c100) OF XAL'RETH   (WoW Retail / Midnight 12.1)
===============================================================================
Performs the rites of Xal'Reth as /emotes, one line at a time, on a timer.
100 rites in 10 categories, 1,000 emotes, every rite with its own icon.

INSTALL
  Delete your old XalRethRP folder, then move this "XalRethRP" folder into
    World of Warcraft\_retail_\Interface\AddOns\
  Fully restart WoW (new art only loads on a full restart, not /reload).
  Your settings and custom lines carry over.

THE PANEL  (/xrp shows it; drag it anywhere; X hides it)
  Xal'Reth himself sits in the rotating sigil, with the current rite's icon
  as a badge. Every time an emote posts, the panel glows: the border flares,
  light rays burst behind Xal'Reth and he flashes violet.
  Play/Pause, Next, Stop     run the rite
  Rites (four squares)       open the Book of 100 Rites (pick a category,
                             left-click a rite to choose, right-click to begin)
  Timer slider               5 to 60 seconds between emotes (mouse wheel works)
  Dice                       random timing: every gap is a random 5-35 seconds
  Loop / Test / Shuffle      click to toggle

COMMANDS (/xrp help)
  /xrp start <rite>  pause  resume  next  stop
  /xrp interval 20   /xrp dice   /xrp dice 10 20 (custom random range)
  /xrp loop  shuffle  test   /xrp sets   /xrp preview <rite>
  /xrp add <text>  list  del <n>   (write emotes without your name)
  /xrp pronouns auto|she|he|they   /xrp reset (re-center the panel)
  Extra sets under "Your Own": custom, book (the Book of Xal'Reth, 230 lines),
  all (all 100 rites in order, 1,000 lines).

Rites pause automatically in combat and boss chat lockdown, then continue on
the same line. Rites marked with {target} use your target's name; with no
target, each rite uses a fitting stand-in.

THE 100 RITES
I. Rites of Gathering
  #1   The Gathering of the Faithful            /xrp start opening
  #2   The Closing Benediction                  /xrp start closing
  #3   Call and Response                        /xrp start callresponse
  #4   The Rite of the Warm Stones              /xrp start ritual
  #5   Lighting of the Heat Lamps               /xrp start heatlamps
  #6   Roll Call of the Coil                    /xrp start rollcall
  #7   Welcome of the Weary Traveler            /xrp start traveler
  #8   Rite of the Open Door                    /xrp start opendoor
  #9   Evening Vespers                          /xrp start vespers
  #10  The Dawn Greeting                        /xrp start dawn

II. Prayers and Devotions
  #11  Prayers of Xal'Reth                      /xrp start prayers
  #12  Hymns of Praise                          /xrp start praise
  #13  Xal'Reth Bless You All                   /xrp start blessings
  #14  The Begging Litany                       /xrp start begging
  #15  Prayer for the Raid                      /xrp start raidprayer
  #16  Prayer for Loot                          /xrp start lootprayer
  #17  Prayer for the Sick and Lagging          /xrp start lagprayer
  #18  Grace Before the Feast                   /xrp start grace
  #19  Litany of Small Mercies                  /xrp start mercies
  #20  Prayer of the Night Watch                /xrp start nightwatch

III. Chants and Hymns
  #21  The Weird Chants                         /xrp start chants
  #22  Songs of Xal'Reth                        /xrp start songs
  #23  Hymn of the Heat Lamp                    /xrp start lamphymn
  #24  Drinking Song of the Coil                /xrp start drinkingsong
  #25  Marching Cadence                         /xrp start cadence
  #26  Lullaby for Hatchlings                   /xrp start hatchlullaby
  #27  The Hissing Choir                        /xrp start hisschoir
  #28  Ballad of MaximumRex                     /xrp start rexballad
  #29  Dirge of the Cold Rain                   /xrp start colddirge
  #30  Round of the Endless Coil                /xrp start endlessround

IV. Rites of the Scale
  #31  The Rite of Molting                      /xrp start molt
  #32  The Basking Vigil                        /xrp start vigil
  #33  Rite of the Regrown Tail                 /xrp start tail
  #34  Polishing of the Scales                  /xrp start polishing
  #35  Rite of Cold Blood                       /xrp start coldblood
  #36  Sunning of the Stones                    /xrp start sunning
  #37  Tongue-Flick Meditation                  /xrp start tongueflick
  #38  The Long Stillness                       /xrp start stillness
  #39  Shedding of Burdens                      /xrp start burdens
  #40  Rite of the Third Eyelid                 /xrp start thirdeyelid

V. Rites of Passage
  #41  Initiation of the New Scaled             /xrp start initiation
  #42  The Binding of the Coil                  /xrp start wedding
  #43  Hatching Day Celebration                 /xrp start hatchday
  #44  Ascension to Officer                     /xrp start ascension
  #45  Naming of a Hatchling                    /xrp start naming
  #46  The Max-Level Molt                       /xrp start maxmolt
  #47  Farewell to a Departing Cultist          /xrp start farewell
  #48  Return of the Prodigal Lizard            /xrp start prodigal
  #49  Guild Anniversary                        /xrp start anniversary
  #50  Funeral of a Fallen Cultist              /xrp start funeral

VI. Rites of Battle
  #51  Battle Prayers                           /xrp start warcries
  #52  Lament for the Wiped                     /xrp start lament
  #53  Blessing of the Tank                     /xrp start tankblessing
  #54  Anointing of the Healer                  /xrp start healeranoint
  #55  The Victory Hiss                         /xrp start victory
  #56  Rite Before the Key                      /xrp start keyrite
  #57  Taunting of the Foe                      /xrp start taunt
  #58  Rally of the Wiped                       /xrp start rally
  #59  Loot Council of Xal'Reth                 /xrp start lootcouncil
  #60  The Battle Trance                        /xrp start trance

VII. Sacrifice and Offering
  #61  The Sacrifice of a Guildmate             /xrp start sacrifice
  #62  The Feast of Crickets                    /xrp start feast
  #63  Offering of Gold                         /xrp start goldoffering
  #64  Offering of the First Kill               /xrp start firstkill
  #65  Burning of the Grey Items                /xrp start greyitems
  #66  Tithe to the Guild Bank                  /xrp start tithe
  #67  Offering of the Heat Lamp                /xrp start lampoffering
  #68  Mock Sacrifice of an Officer             /xrp start officersacrifice
  #69  Offering of Crickets                     /xrp start cricketoffering
  #70  Sacrifice of the Mammal Plush            /xrp start plushsacrifice

VIII. Prophecy and Divination
  #71  The Oracle of the Warm Stones            /xrp start oracle
  #72  The Prophecy of the Great Molt           /xrp start prophecy
  #73  Reading of the Shed Skin                 /xrp start shedreading
  #74  Augury of the Crickets                   /xrp start cricketaugury
  #75  Dream of the Coiled One                  /xrp start coildream
  #76  Reading of the Stars                     /xrp start starreading
  #77  Casting of the Bones                     /xrp start bones
  #78  Mirror of the Coil                       /xrp start coilmirror
  #79  Omen of the Loot Roll                    /xrp start lootomen
  #80  Prophecy of the Next Patch               /xrp start patchprophecy

IX. Lore and Sermons
  #81  Sermon of the Coiled One                 /xrp start sermon
  #82  The Tale of Xal'Reth's Awakening         /xrp start origin
  #83  Decrees of MaximumRex                    /xrp start decrees
  #84  Invocations of Xalrathiel                /xrp start xalrathiel
  #85  Tale of the First Heat Lamp              /xrp start firstlamp
  #86  Parable of the Impatient Mammal          /xrp start impatientmammal
  #87  Sermon on the Mount                      /xrp start mountsermon
  #88  Chronicle of the Great Wipe              /xrp start greatwipe
  #89  The Seven Scales of Virtue               /xrp start sevenscales
  #90  The Tale of the Basement                 /xrp start basementtale

X. Mischief and Fellowship
  #91  The Rite of Confession                   /xrp start confession
  #92  Exorcism of the Mammal Within            /xrp start exorcism
  #93  Idle Cultist (ambient)                   /xrp start ambient
  #94  Hide and Seek: Reptile Rules             /xrp start hideseek
  #95  Trial of Stillness                       /xrp start stillnesstrial
  #96  Roast of a Guildmate                     /xrp start roast
  #97  Tea Party of the Coil                    /xrp start teaparty
  #98  Mammal Impersonation Contest             /xrp start mammalcontest
  #99  Interrogation of a Suspected Mammal      /xrp start interrogation
  #100 The Midnight Bask Party                  /xrp start midnightbask
