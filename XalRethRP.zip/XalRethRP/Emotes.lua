-- Xal'Reth RP - emote lists
-- Each line is posted as /emote, so the game puts your name in front:
--   "Rethyss kneels before the altar..."
-- Tokens: {target} = your target's name (or "the altar" with no target)
--         {guild}  = your guild's name
local ADDON, ns = ...

ns.Sets = {}
ns.SetOrder = { "praise", "ritual", "molt", "vigil", "sermon" }

ns.Sets.praise = {
  title = "Hymns of Praise",
  shuffle = true,
  lines = {
    "raises both hands toward the sky and intones, \"Hail Xal'Reth, Coiled One, Warden of the Warm Stones.\"",
    "bows deeply, whispering praise to Xal'Reth in a language that is mostly hissing.",
    "presses a palm to the ground, feeling for the slow heartbeat of Xal'Reth beneath the earth.",
    "chants softly, \"Cold of blood, warm of stone, Xal'Reth guards us, scale and bone.\"",
    "traces the sigil of the Coil in the air with one finger. It glows faintly, then fades.",
    "closes their eyes and basks, as Xal'Reth teaches, in the nearest available light.",
    "murmurs, \"Blessed be the scales that hide us. Blessed be the mammals who suspect nothing.\"",
    "lifts a small clay idol of a very calm iguana and kisses its forehead reverently.",
    "declares to no one in particular, \"Xal'Reth sees all. Xal'Reth judges none. Xal'Reth naps often.\"",
    "taps their chest three times in the old salute of the Inner Circle.",
    "kneels and lays a single cricket upon the ground as an offering to Xal'Reth.",
    "sings a low, droning hymn. Nearby insects go very quiet.",
    "turns slowly in a full circle, blessing each direction in the name of the Coil.",
    "whispers, \"In the warmth we wait. In the shade we plan. In Xal'Reth we trust.\"",
    "anoints their brow with warm sand from a small velvet pouch.",
    "gazes at the sun with deep gratitude, then blinks with both sets of eyelids. Just the one set. Normal.",
    "recites the Third Litany: \"The tail grows back. The faith grows stronger.\"",
    "holds out an open palm, as if offering warmth to an unseen god.",
    "intones, \"Praise be to Xal'Reth, who shed the old world and wore the new one better.\"",
    "rests a hand over their heart, and their pulse slows to an unreasonably calm rhythm.",
    "bows to {target} and says, \"May the warm stones find you, and the cold rain miss you.\"",
    "carefully arranges three smooth stones in a triangle, the sacred shape of the Coil.",
    "hums the Basking Psalm, swaying gently like a lizard on a sunny branch.",
    "lowers their voice: \"The Great Molt is coming. Pack light. Wear something loose.\"",
    "raises a cup of warm water in a toast: \"To Xal'Reth, first among the scaled!\"",
    "spreads their arms wide and proclaims, \"We are the Draco Reptilian Elite, and we are absolutely ordinary humans.\"",
    "kneels, bows until their forehead touches the earth, and remains perfectly still for an uncomfortable length of time.",
    "whispers a prayer for every cultist who ever stood in fire and lived.",
    "lights a stick of incense that smells faintly of hot rocks and moss.",
    "makes the sign of the Coil over {target}: a slow spiral, inward, then out.",
  },
}

ns.Sets.ritual = {
  title = "The Rite of the Warm Stones",
  shuffle = false,
  lines = {
    "steps forward and strikes the ground three times with their staff. The Rite of the Warm Stones begins.",
    "unrolls a strip of black silk and lays it before {target} as an altar cloth.",
    "places seven warm river stones in a spiral upon the silk, from largest to smallest.",
    "lights a ring of small candles around the stones. The flames lean inward, toward the spiral.",
    "calls out, \"Gather, faithful! The stones are warm. The Coiled One listens.\"",
    "raises both arms, and the shadows around them seem to lengthen and coil.",
    "intones the First Invocation: \"From the deep warm places, we call you, Xal'Reth.\"",
    "draws a slow spiral in the dirt around the altar with the end of their staff.",
    "sprinkles warm sand over the stones. It hisses softly as it lands.",
    "intones the Second Invocation: \"From the long patience of the sun-baked rock, we call you, Xal'Reth.\"",
    "produces a long, shed serpent skin from their robes and drapes it across the stones with great care.",
    "chants low and steady. The candle flames shrink, then swell, keeping time with the words.",
    "intones the Third Invocation: \"From the hidden halls beneath the world of mammals, we call you, Xal'Reth.\"",
    "goes perfectly still. Their pupils narrow to thin, vertical slits. Probably a trick of the light.",
    "whispers, \"It stirs.\" The air grows noticeably, unseasonably warm.",
    "lifts the largest stone above their head. It pulses with a faint violet glow.",
    "speaks in a voice not entirely their own: \"WE SEE YOU, FAITHFUL. YOU MAY CONTINUE.\"",
    "staggers back a step, breathing hard, then steadies themselves against their staff.",
    "places the glowing stone back at the heart of the spiral. The others begin to glow in turn.",
    "calls to {target}, \"Step forward, and receive the warmth of the Coil.\"",
    "touches two fingers to the stone, then to {target}'s brow, leaving a small warm mark.",
    "declares, \"The Coil is unbroken. The scales are hidden. Xal'Reth is pleased.\"",
    "snuffs the candles one by one with bare fingers, never flinching.",
    "gathers the stones back into a leather pouch, still warm, and seals it with a knot of black cord.",
    "bows to the four directions, then to the gathered faithful. \"The Rite is complete. Hail Xal'Reth.\"",
    "folds the black silk neatly and tucks it away, as if nothing unusual happened here. Nothing did.",
  },
}

ns.Sets.molt = {
  title = "The Rite of Molting",
  shuffle = false,
  lines = {
    "kneels in a circle of salt and announces, \"I begin the Rite of Molting. Do not look directly at me.\"",
    "rolls their shoulders slowly, as if something underneath the skin is trying to find a new shape.",
    "scratches their arm. A thin, papery flake drifts to the ground, politely ignored by all.",
    "breathes deeply, and the air around them shimmers with heat.",
    "whispers, \"The old self is too small. The old self must go.\"",
    "arches their back with a long, unsettling creak. Several onlookers quietly leave.",
    "peels a long, translucent strip of something from their forearm and holds it up to the light, satisfied.",
    "intones, \"What is shed is offered. What remains is renewed.\"",
    "places the shed skin in a small bronze bowl and sets it alight. It smells of cinnamon and regret.",
    "rises slowly, looking somehow taller, shinier, and very, very well moisturized.",
    "announces, \"The Molt is complete. I am reborn. Please do not ask about the bowl.\"",
  },
}

ns.Sets.vigil = {
  title = "The Basking Vigil",
  shuffle = false,
  lines = {
    "finds the warmest stone in the area and claims it for the Basking Vigil.",
    "lies flat upon the stone, arms out, face toward the light.",
    "goes completely motionless. This is the sacred stillness of Xal'Reth.",
    "remains motionless.",
    "absorbs warmth with profound spiritual focus.",
    "is still motionless. A small bird lands on them, then thinks better of it.",
    "turns slightly to warm the other side, as the scriptures command.",
    "whispers, without moving their lips, \"The vigil endures.\"",
    "continues to bask with alarming dedication.",
    "slowly opens one eye, then closes it again. Not yet.",
    "sits up at last, glowing faintly with stored warmth. \"The Vigil is kept. Xal'Reth is honored.\"",
  },
}

ns.Sets.sermon = {
  title = "Sermon of the Coiled One",
  shuffle = false,
  lines = {
    "climbs onto the nearest crate and clears their throat. \"Faithful of Xal'Reth, hear me.\"",
    "spreads their hands. \"They call us strange. They call us cold. They are half right.\"",
    "continues, \"The mammals rush. The mammals panic. The mammals stand in fire.\"",
    "lowers their voice. \"But we, the scaled, we WAIT. We bask. We strike only when it is warm.\"",
    "points to the sky. \"Every sunrise is a gift from Xal'Reth. Every sunset is a reminder to find a heat lamp.\"",
    "taps their temple. \"Patience is the first scale. Silence is the second. Snacks are the third.\"",
    "raises a fist. \"Some say the cult is a joke. To the doubters I say: that is exactly what we want you to think.\"",
    "gestures toward {target}. \"Look at this one. Calm. Unblinking. Clearly one of us.\"",
    "leans in. \"Remember the Three Laws. Never discuss the Molt. Never reveal the Burrow. Never leave the heat lamp on unattended.\"",
    "raises both arms. \"Go now, and be ordinary. Be human. Be so very, very human.\"",
    "steps down from the crate. \"Hail Xal'Reth. Sermon concluded. There will be crickets afterward.\"",
  },
}
