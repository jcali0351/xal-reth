-- Xal'Reth RP - Upload window: paste your own emote strings and save them
-- as a named rite (it appears under "Your Own and Uploads").
local ADDON, ns = ...
local R = ns.R

local MAX_LEN = 255
local UW, UH = 470, 430

-- Turn pasted text into clean emote lines.
-- Accepts "/e text", "/emote text", "/me text", and lines that start with
-- your character's name (the game adds your name, so it is removed).
function R:CleanUpload(text)
  local lines, split, skipped = {}, 0, 0
  local me = (UnitName("player") or ""):lower()
  for raw in ((text or "") .. "\n"):gmatch("([^\r\n]*)\r?\n") do
    local l = raw:gsub("|", ""):gsub("^%s+", ""):gsub("%s+$", "")
    l = l:gsub("^/[Ee][Mm][Oo][Tt][Ee]%s+", ""):gsub("^/[Ee]%s+", ""):gsub("^/[Mm][Ee]%s+", "")
    l = l:gsub("^%d+[%.%)]%s+", "")                       -- "1. " or "1) " numbering
    l = l:gsub("^[%-%*]%s+", "")                           -- bullet points
    if me ~= "" and l:lower():sub(1, #me + 1) == me .. " " then l = l:sub(#me + 2) end
    if l == "" then
      if raw:match("%S") then skipped = skipped + 1 end
    else
      while #l > MAX_LEN do                                -- split very long lines
        local cut = l:sub(1, MAX_LEN - 4)
        local at = cut:match("^.*()[%.!%?]%s") or cut:match("^.*()%s") or #cut
        lines[#lines + 1] = l:sub(1, at):gsub("%s+$", "")
        l = l:sub(at + 1):gsub("^%s+", "")
        split = split + 1
      end
      if l ~= "" then lines[#lines + 1] = l end
    end
  end
  return lines, split, skipped
end

function R:UploadNames()
  return self.db.uploadOrder
end

function R:SaveUpload(name, lines)
  name = (name or ""):gsub("|", ""):gsub("^%s+", ""):gsub("%s+$", ""):gsub(":", "")
  if name == "" then return false, "Give your rite a name first." end
  if #name > 48 then return false, "That name is too long (48 characters max)." end
  if #lines == 0 then return false, "Paste at least one emote line." end
  local isNew = self.db.uploads[name] == nil
  self.db.uploads[name] = lines
  if isNew then table.insert(self.db.uploadOrder, name) end
  return true, (isNew and "Saved new rite" or "Updated rite") .. " '" .. name .. "' with " .. #lines .. " emotes."
end

function R:DeleteUpload(name)
  if not self.db.uploads[name] then return false end
  if self.run and self.run.name == "u:" .. name then self:Stop(true) end
  self.db.uploads[name] = nil
  for i, n in ipairs(self.db.uploadOrder) do if n == name then table.remove(self.db.uploadOrder, i) break end end
  if self.db.lastSet == "u:" .. name then self.db.lastSet = "ritual" end
  return true
end

function R:ToggleUpload()
  if not self.upload then self:BuildUpload() end
  if self.upload:IsShown() then self.upload:Hide() else self.upload:Show(); self:RefreshUpload() end
end

function R:BuildUpload()
  local f = CreateFrame("Frame", "XalRethRPUpload", UIParent)
  f:SetSize(UW, UH)
  f:SetPoint("CENTER", 0, 40)
  f:SetFrameStrata("DIALOG")
  f:SetToplevel(true)
  f:SetClampedToScreen(true)
  f:EnableMouse(true)
  f:SetMovable(true)
  f:RegisterForDrag("LeftButton")
  f:SetScript("OnDragStart", f.StartMoving)
  f:SetScript("OnDragStop", f.StopMovingOrSizing)
  tinsert(UISpecialFrames, "XalRethRPUpload")
  self:DressFrame(f, "frame_upload", UW, UH, 512, 512)

  local logo = f:CreateTexture(nil, "ARTWORK")
  logo:SetTexture(self:Tex("logo"))
  logo:SetSize(46, 46)
  logo:SetPoint("TOPLEFT", 16, -12)
  local head = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
  head:SetPoint("TOPLEFT", logo, "TOPRIGHT", 8, -4)
  head:SetText("|cffe8be5cUpload Emotes|r")
  local help = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  help:SetPoint("TOPLEFT", head, "BOTTOMLEFT", 0, -3)
  help:SetWidth(UW - 100)
  help:SetJustifyH("LEFT")
  help:SetText("Paste one emote per line (Ctrl+V). Leave out your name: the game adds it. " ..
    "/e, numbering and your name at the start are removed for you. Use {target} for your target's name.")

  -- rite name
  local nl = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
  nl:SetPoint("TOPLEFT", 20, -74)
  nl:SetText("Rite name")
  local name = CreateFrame("EditBox", nil, f, "InputBoxTemplate")
  name:SetSize(250, 20)
  name:SetTextInsets(5, 5, 0, 0)
  name:SetPoint("LEFT", nl, "RIGHT", 12, 0)
  name:SetAutoFocus(false)
  name:SetMaxLetters(48)
  name:SetScript("OnEscapePressed", function(b) b:ClearFocus() end)
  name:SetScript("OnEnterPressed", function(b) b:ClearFocus() end)
  name:SetScript("OnTabPressed", function() f.edit:SetFocus() end)
  f.name = name

  -- big paste box
  local box = CreateFrame("Frame", nil, f, "BackdropTemplate")
  box:SetPoint("TOPLEFT", 16, -98)
  box:SetPoint("BOTTOMRIGHT", -16, 98)
  box:SetBackdrop({ bgFile = "Interface\\Tooltips\\UI-Tooltip-Background", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    tile = true, tileSize = 16, edgeSize = 12, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
  box:SetBackdropColor(0.03, 0.01, 0.06, 0.92)
  box:SetBackdropBorderColor(0.66, 0.5, 0.18, 1)
  local scroll = CreateFrame("ScrollFrame", "XalRethRPUploadScroll", box, "UIPanelScrollFrameTemplate")
  scroll:SetPoint("TOPLEFT", 8, -8)
  scroll:SetPoint("BOTTOMRIGHT", -28, 8)
  local edit = CreateFrame("EditBox", nil, scroll)
  edit:SetMultiLine(true)
  edit:SetAutoFocus(false)
  edit:SetFontObject(ChatFontNormal)
  edit:SetWidth(UW - 72)
  edit:SetMaxLetters(0)
  edit:SetTextInsets(5, 5, 5, 5)
  edit:SetScript("OnEscapePressed", function(b) b:ClearFocus() end)
  edit:SetScript("OnTextChanged", function(b, user)
    if ScrollingEdit_OnTextChanged then ScrollingEdit_OnTextChanged(b, scroll) end
    R:RefreshUpload()
  end)
  if ScrollingEdit_OnCursorChanged then edit:SetScript("OnCursorChanged", ScrollingEdit_OnCursorChanged) end
  if ScrollingEdit_OnUpdate then edit:SetScript("OnUpdate", function(b, el) ScrollingEdit_OnUpdate(b, el, scroll) end) end
  scroll:SetScrollChild(edit)
  box:EnableMouse(true)
  box:SetScript("OnMouseDown", function() edit:SetFocus() end)
  f.edit = edit

  -- status line
  f.status = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  f.status:SetPoint("BOTTOMLEFT", 20, 74)
  f.status:SetWidth(UW - 40)
  f.status:SetJustifyH("LEFT")

  local function button(text, w, x, y, fn, tip)
    local b = R:PurpleButton(f, w, 22)
    b:SetPoint("BOTTOMLEFT", x, y)
    b:SetText(text)
    b:SetScript("OnClick", fn)
    if tip then
      b:SetScript("OnEnter", function(btn) GameTooltip:SetOwner(btn, "ANCHOR_TOP"); GameTooltip:SetText(tip, 1, 1, 1, 1, true); GameTooltip:Show() end)
      b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    end
    return b
  end
  button("Save as Rite", 104, 16, 46, function()
    local lines = R:CleanUpload(f.edit:GetText())
    local ok, msg = R:SaveUpload(f.name:GetText(), lines)
    R:Print(msg)
    if ok then
      R.db.lastSet = "u:" .. f.name:GetText():gsub("|", ""):gsub("^%s+", ""):gsub("%s+$", ""):gsub(":", "")
      R:UpdateBar()
      if R.picker and R.picker:IsShown() then R:RefreshPicker() end
    end
    R:RefreshUpload()
  end, "Save these lines as a rite with this name. Saving with an existing name replaces it.")
  button("Save and Begin", 112, 124, 46, function()
    local lines = R:CleanUpload(f.edit:GetText())
    local ok, msg = R:SaveUpload(f.name:GetText(), lines)
    R:Print(msg)
    if ok then
      f:Hide()
      R:Start("u:" .. f.name:GetText():gsub("|", ""):gsub("^%s+", ""):gsub("%s+$", ""):gsub(":", ""))
    end
  end, "Save, then start performing it right away.")
  button("Add to Your Emotes", 136, 240, 46, function()
    local lines = R:CleanUpload(f.edit:GetText())
    for _, l in ipairs(lines) do table.insert(R.db.custom, l) end
    R:Print("Added " .. #lines .. " emotes to Your Own Emotes (" .. #R.db.custom .. " total).")
    R:UpdateBar()
  end, "Add these lines to your general custom list instead of a separate rite.")
  button("Clear", 70, UW - 86, 46, function() f.edit:SetText(""); f.name:SetText("") end)

  -- load / delete saved uploads
  f.savedLabel = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
  f.savedLabel:SetPoint("BOTTOMLEFT", 20, 24)
  button("Load", 64, 300, 18, function()
    local n = f.name:GetText():gsub("^%s+", ""):gsub("%s+$", "")
    local lines = R.db.uploads[n]
    if not lines then R:Print("No saved rite named '" .. n .. "'. Saved: " .. (#R.db.uploadOrder > 0 and table.concat(R.db.uploadOrder, ", ") or "none")) return end
    f.edit:SetText(table.concat(lines, "\n"))
    R:Print("Loaded '" .. n .. "' for editing.")
  end, "Type the name of a saved rite, then Load it here to edit.")
  button("Delete", 64, 368, 18, function()
    local n = f.name:GetText():gsub("^%s+", ""):gsub("%s+$", "")
    if R:DeleteUpload(n) then R:Print("Deleted '" .. n .. "'."); R:UpdateBar()
      if R.picker and R.picker:IsShown() then R:RefreshPicker() end
    else R:Print("No saved rite named '" .. n .. "'.") end
    R:RefreshUpload()
  end, "Type the name of a saved rite, then Delete it.")
  local close = self:RoundButton(f, "btn_close", 18, UW - 40, -14, function() f:Hide() end, "Close")
  close:SetFrameLevel(f:GetFrameLevel() + 5)
  f:Hide()
  self.upload = f
end

function R:RefreshUpload()
  local f = self.upload
  if not f then return end
  local lines, split, skipped = self:CleanUpload(f.edit:GetText())
  local msg = ("|cff55ff55%d emotes ready|r"):format(#lines)
  if split > 0 then msg = msg .. ("  |cffffcc00%d long line(s) split to fit the chat limit|r"):format(split) end
  if skipped > 0 then msg = msg .. ("  |cff999999%d empty line(s) skipped|r"):format(skipped) end
  if #lines > 0 then msg = msg .. "\n|cff8a6fb0First:|r " .. UnitName("player") .. " " .. self:Render(lines[1]) end
  f.status:SetText(msg)
  local n = #self.db.uploadOrder
  f.savedLabel:SetText(n == 0 and "|cff999999No saved uploads yet.|r" or ("Saved uploads: |cffffffff" .. n .. "|r"))
end
