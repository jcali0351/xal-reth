-- Xal'Reth RP - the Book picker: Canon rites, the Grand Book of 10,000,
-- your own uploads, search and a random rite. Also the layered icon widget.
local ADDON, ns = ...
local R = ns.R
local E = ns.Engine
local G = ns.Gen

---------------------------------------------------------------------------
-- Layered icon: a canon/custom icon is one texture; a Grand Book icon is
-- built from layers (order background + motif + aspect rim + aspect gem)
---------------------------------------------------------------------------
function R:MakeIcon(parent, size)
  local f = CreateFrame("Frame", nil, parent)
  f:SetSize(size, size)
  f.bg = f:CreateTexture(nil, "ARTWORK", nil, 0)
  f.bg:SetAllPoints()
  f.motif = f:CreateTexture(nil, "ARTWORK", nil, 1)
  f.motif:SetPoint("TOPLEFT", size * 0.11, -size * 0.11)
  f.motif:SetPoint("BOTTOMRIGHT", -size * 0.11, size * 0.11)
  f.rim = f:CreateTexture(nil, "ARTWORK", nil, 2)
  f.rim:SetAllPoints()
  f.gem = f:CreateTexture(nil, "ARTWORK", nil, 3)
  f.gem:SetSize(size * 0.34, size * 0.34)
  f.gem:SetPoint("CENTER", f, "BOTTOMRIGHT", -size * 0.16, size * 0.16)
  f.gem:SetTexture(R:Tex("gem"))
  function f:SetSet(set)
    local spec = set and set.iconSpec
    if spec then
      self.bg:SetTexture(R:Tex(spec.bg))
      if spec.motif then
        self.motif:SetTexture(R:Tex(spec.motif))
        if spec.mirror then self.motif:SetTexCoord(1, 0, 0, 1) else self.motif:SetTexCoord(0, 1, 0, 1) end
        self.motif:Show()
      else
        self.motif:Hide()
      end
      self.rim:SetTexture(R:Tex(spec.rim)); self.rim:Show()
      self.gem:SetVertexColor(spec.gem[1], spec.gem[2], spec.gem[3]); self.gem:Show()
    else
      self.bg:SetTexture(R:Icon(set))
      self.motif:Hide(); self.rim:Hide(); self.gem:Hide()
    end
  end
  return f
end

-- Icon spec for a whole Grand Book category (no motif, just its colors)
local function categorySpec(o, a)
  return { bg = ("bg%02d"):format(o), rim = ("rim%d"):format(((a - 1) % 4) + 1), gem = G.aspects[a].color }
end

---------------------------------------------------------------------------
-- Scrolling list (mouse wheel + arrow buttons), reused three times
---------------------------------------------------------------------------
local function makeList(parent, x, y, w, rowH, visible, makeRow, fillRow)
  local L = { items = {}, offset = 0, rows = {}, visible = visible }
  local holder = CreateFrame("Frame", nil, parent)
  holder:SetPoint("TOPLEFT", x, y)
  holder:SetSize(w, rowH * visible)
  holder:EnableMouseWheel(true)
  L.holder = holder
  for i = 1, visible do
    local row = makeRow(holder, w, rowH)
    row:SetPoint("TOPLEFT", 0, -(i - 1) * rowH)
    L.rows[i] = row
  end
  local function arrow(tex, dy, anchor, delta)
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(18, 18)
    b:SetPoint(anchor, holder, anchor == "TOPRIGHT" and "TOPRIGHT" or "BOTTOMRIGHT", 20, dy)
    b:SetNormalTexture(tex .. "-Up")
    b:SetPushedTexture(tex .. "-Down")
    b:SetHighlightTexture("Interface\\Buttons\\UI-Common-MouseHilight", "ADD")
    b:SetScript("OnClick", function() L:Scroll(delta) end)
    return b
  end
  L.up = arrow("Interface\\Buttons\\UI-ScrollBar-ScrollUpButton", 0, "TOPRIGHT", -3)
  L.down = arrow("Interface\\Buttons\\UI-ScrollBar-ScrollDownButton", 0, "BOTTOMRIGHT", 3)
  holder:SetScript("OnMouseWheel", function(_, d) L:Scroll(-d * (IsShiftKeyDown() and 10 or 2)) end)
  function L:SetItems(items, keepOffset)
    self.items = items
    if not keepOffset then self.offset = 0 end
    self:Refresh()
  end
  function L:Scroll(d)
    local maxOff = math.max(0, #self.items - self.visible)
    self.offset = math.max(0, math.min(maxOff, self.offset + d))
    self:Refresh()
  end
  function L:ScrollTo(index)
    local maxOff = math.max(0, #self.items - self.visible)
    self.offset = math.max(0, math.min(maxOff, index - math.floor(self.visible / 2)))
    self:Refresh()
  end
  function L:Refresh()
    for i, row in ipairs(self.rows) do
      local item = self.items[self.offset + i]
      if item then fillRow(row, item); row:Show() else row:Hide() end
    end
    local more = #self.items > self.visible
    if more then self.up:Show(); self.down:Show() else self.up:Hide(); self.down:Hide() end
    self.up:SetEnabled(self.offset > 0)
    self.down:SetEnabled(self.offset < #self.items - self.visible)
  end
  return L
end

local function baseRow(parent, w, h, iconSize)
  local b = CreateFrame("Button", nil, parent)
  b:SetSize(w, h - 1)
  b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
  b.sel = b:CreateTexture(nil, "BACKGROUND")
  b.sel:SetAllPoints()
  b.sel:SetColorTexture(0.54, 0.17, 0.89, 0.40)
  b.sel:Hide()
  local hl = b:CreateTexture(nil, "HIGHLIGHT")
  hl:SetAllPoints()
  hl:SetColorTexture(1, 1, 1, 0.1)
  b.icon = R:MakeIcon(b, iconSize)
  b.icon:SetPoint("LEFT", 5, 0)
  b.text = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  b.text:SetPoint("LEFT", b.icon, "RIGHT", 5, 0)
  b.text:SetPoint("RIGHT", -5, 0)
  b.text:SetJustifyH("LEFT")
  b.text:SetWordWrap(false)
  return b
end

---------------------------------------------------------------------------
-- Picker
---------------------------------------------------------------------------
local KW, KH = 790, 430

-- Book list: canon, ten Orders of the Grand Book, your own
function R:Books()
  local books = { { kind = "canon", title = "The 100 Canon Rites", icon = "logo_small" } }
  for o, order in ipairs(G.orders) do
    books[#books + 1] = { kind = "order", o = o, title = "Order of " .. order.name, icon = ("cat%02d"):format(o) }
  end
  books[#books + 1] = { kind = "own", title = "Your Own and Uploads", icon = "coil" }
  return books
end

function R:LocateKey(key)
  -- returns book index, category index (within book), rite index (within category)
  local n = key and tonumber(key:match("^g(%d+)$"))
  if n then
    local o, a, i = E.Locate(n)
    return o + 1, a, i + 1
  end
  local s = ns.RiteByKey[key]
  if s and s.cat then
    for idx, r in ipairs(s.cat.rites) do if r[1] == key then return 1, s.cat.num, idx end end
  end
  return 12, 1, 1
end

function R:CategoriesOf(book)
  local out = {}
  if book.kind == "canon" then
    for ci, cat in ipairs(ns.RiteCategories) do
      out[#out + 1] = { title = self.Categories[ci].title, icon = { file = cat.icon }, canonCat = ci }
    end
  elseif book.kind == "order" then
    for a = 1, E.NUM_ASPECTS do
      local first = E.FirstRite(book.o, a)
      out[#out + 1] = { title = E.CategoryTitle(book.o, a), short = G.aspects[a].adj, icon = { spec = categorySpec(book.o, a) },
        o = book.o, a = a, range = ("#%d-%d"):format(first, first + E.PER_CAT - 1) }
    end
  else
    out[1] = { title = "Your Own", icon = { file = "coil" }, own = true }
  end
  return out
end

function R:RitesOf(cat)
  local keys = {}
  if cat.canonCat then
    for _, r in ipairs(ns.RiteCategories[cat.canonCat].rites) do
      if ns.RiteByKey[r[1]] then keys[#keys + 1] = r[1] end
    end
  elseif cat.o then
    local first = E.FirstRite(cat.o, cat.a)
    for n = first, first + E.PER_CAT - 1 do keys[#keys + 1] = "g" .. n end
  else
    keys[1] = "custom"
    for _, name in ipairs(self.db.uploadOrder) do keys[#keys + 1] = "u:" .. name end
    keys[#keys + 1] = "book"
    keys[#keys + 1] = "all"
  end
  return keys
end

function R:TogglePicker()
  if not self.picker then self:BuildPicker() end
  if self.picker:IsShown() then self.picker:Hide() return end
  self:ShowInPicker((self.run and self.run.name) or self.db.lastSet)
  self.picker:Show()
end

function R:ShowInPicker(key)
  local b, c, r = self:LocateKey(key)
  self.pick = { book = b, cat = c, search = nil }
  local p = self.picker
  if p.searchBox then p.searchBox:SetText("") end
  self:RefreshPicker()
  p.bookList:ScrollTo(b)
  p.catList:ScrollTo(c)
  p.riteList:ScrollTo(r)
end

local function iconFill(widget, icon)
  if icon.spec then widget:SetSet({ iconSpec = icon.spec })
  else widget:SetSet({ icon = icon.file }) end
end

function R:BuildPicker()
  local p = CreateFrame("Frame", "XalRethRPPicker", self.bar)
  p:SetSize(KW, KH)
  p:SetPoint("TOP", self.bar, "BOTTOM", 0, 4)
  p:SetFrameStrata("DIALOG")
  p:SetClampedToScreen(true)
  p:EnableMouse(true)
  p:SetMovable(true)
  p:RegisterForDrag("LeftButton")
  p:SetScript("OnDragStart", p.StartMoving)
  p:SetScript("OnDragStop", p.StopMovingOrSizing)
  tinsert(UISpecialFrames, "XalRethRPPicker")
  self:DressFrame(p, "frame_book", KW, KH, 1024, 512)

  local head = p:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
  head:SetPoint("TOP", 0, -14)
  head:SetText("|cffe8be5cThe Book of Xal'Reth|r  |cffb58cff10,100 rites|r")

  -- portrait of Xal'Reth
  local portrait = p:CreateTexture(nil, "ARTWORK")
  portrait:SetTexture(self:Tex("portrait"))
  portrait:SetSize(120, 240)
  portrait:SetPoint("TOPLEFT", 16, -44)
  self:AttachMorph(portrait, "p", self.PORTRAIT_FRAMES)
  local cap = p:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
  cap:SetPoint("TOP", portrait, "BOTTOM", 0, -4)
  cap:SetWidth(120)
  cap:SetText("|cffb58cffXal'Reth,\nthe Coiled One|r")

  -- search, random, upload
  local sb = CreateFrame("EditBox", nil, p, "InputBoxTemplate")
  sb:SetSize(170, 20)
  sb:SetTextInsets(5, 5, 0, 0)
  sb:SetPoint("TOPLEFT", 24, -340)
  sb:SetAutoFocus(false)
  sb:SetScript("OnEnterPressed", function(box) box:ClearFocus(); R:Search(box:GetText()) end)
  sb:SetScript("OnEscapePressed", function(box) box:ClearFocus() end)
  p.searchBox = sb
  local sl = p:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  sl:SetPoint("BOTTOMLEFT", sb, "TOPLEFT", -4, 2)
  sl:SetText("Search: a number (4817) or words")

  local function button(text, w, x, y, fn, tip)
    local b = R:PurpleButton(p, w, 22)
    b:SetPoint("TOPLEFT", x, y)
    b:SetText(text)
    b:SetScript("OnClick", fn)
    if tip then
      b:SetScript("OnEnter", function(btn) GameTooltip:SetOwner(btn, "ANCHOR_TOP"); GameTooltip:SetText(tip, 1, 1, 1, 1, true); GameTooltip:Show() end)
      b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    end
    return b
  end
  button("Random Rite", 84, 14, -368, function()
    if IsShiftKeyDown() then R:StartRandom() else R:PickRandom() end
  end, "Choose a random rite from the Grand Book. Shift-click to begin it at once.")
  button("Upload", 84, 102, -368, function() R:ToggleUpload() end, "Paste your own emotes and save them as a rite.")

  -- column titles
  local function colTitle(text, x)
    local t = p:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    t:SetPoint("TOPLEFT", x, -46)
    t:SetText("|cffb58cff" .. text .. "|r")
    return t
  end
  colTitle("Books", 154)
  p.catHeader = colTitle("Categories", 314)
  p.riteHeader = colTitle("Rites", 494)

  -- books
  p.bookList = makeList(p, 150, -66, 152, 26, 12,
    function(parent, w, h) return baseRow(parent, w, h, 22) end,
    function(row, item)
      row.item = item
      row.icon:SetSet({ icon = item.icon })
      row.text:SetText(item.title)
      if R.pick and R.pick.book == item.index and not R.pick.search then row.sel:Show() else row.sel:Hide() end
      row:SetScript("OnClick", function()
        R.pick = { book = item.index, cat = 1 }
        R:RefreshPicker()
      end)
    end)

  -- categories
  p.catList = makeList(p, 310, -66, 152, 26, 12,
    function(parent, w, h) return baseRow(parent, w, h, 22) end,
    function(row, item)
      iconFill(row.icon, item.icon)
      row.text:SetText((item.short or item.title) .. (item.range and (" |cff888888" .. item.range .. "|r") or ""))
      if R.pick and R.pick.cat == item.index and not R.pick.search then row.sel:Show() else row.sel:Hide() end
      row:SetScript("OnClick", function()
        R.pick.cat = item.index; R.pick.search = nil
        R:RefreshPicker()
      end)
    end)

  -- rites
  p.riteList = makeList(p, 490, -66, 268, 26, 13,
    function(parent, w, h)
      local row = baseRow(parent, w, h, 24)
      row:SetScript("OnEnter", function(btn)
        if not btn.key then return end
        local s = R:GetSet(btn.key)
        if not s then return end
        GameTooltip:SetOwner(btn, "ANCHOR_RIGHT")
        GameTooltip:SetText(R:Title(s), 1, 0.82, 0)
        if s.grand then
          local o, a = E.Locate(s.num)
          GameTooltip:AddLine(E.CategoryTitle(o, a), 0.7, 0.55, 1)
        end
        GameTooltip:AddLine(#s.lines .. " emotes", 0.8, 0.7, 1)
        if s.lines[1] then GameTooltip:AddLine(UnitName("player") .. " " .. R:Render(s.lines[1], s), 0.9, 0.9, 0.9, true) end
        GameTooltip:AddLine("Left-click: choose.  Right-click: begin now.", 0.5, 0.5, 0.5)
        GameTooltip:Show()
      end)
      row:SetScript("OnLeave", function() GameTooltip:Hide() end)
      row:SetScript("OnClick", function(btn, mouse)
        if not btn.key then return end
        if mouse == "RightButton" then p:Hide(); R:Start(btn.key)
        elseif R.run then R:Print("A rite is in progress. Stop it first, or right-click a rite to switch now.")
        else R.db.lastSet = btn.key; R:UpdateBar(); R:RefreshPicker() end
      end)
      return row
    end,
    function(row, key)
      local s = R:GetSet(key)
      row.key = key
      if s then
        row.icon:SetSet(s)
        row.text:SetText(R:Title(s) .. " |cff888888(" .. #s.lines .. ")|r")
      end
      local current = (R.run and R.run.name) or R.db.lastSet
      if key == current then row.sel:Show() else row.sel:Hide() end
    end)

  p.status = p:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  p.status:SetPoint("BOTTOMRIGHT", -22, 14)

  local close = self:RoundButton(p, "btn_close", 18, KW - 40, -14, function() p:Hide() end, "Close")
  close:SetFrameLevel(p:GetFrameLevel() + 5)
  p:Hide()
  self.picker = p
end

function R:RefreshPicker()
  local p = self.picker
  if not p then return end
  self.pick = self.pick or { book = 1, cat = 1 }
  local books = self:Books()
  for i, b in ipairs(books) do b.index = i end
  p.bookList:SetItems(books, true)

  if self.pick.search then
    p.catList:SetItems({}, true)
    p.catHeader:SetText("|cffb58cffCategories|r")
    p.riteHeader:SetText(("|cffb58cffSearch: %s|r"):format(self.pick.searchText))
    p.riteList:SetItems(self.pick.search, true)
    p.status:SetText(#self.pick.search == 0 and "No rites found." or (#self.pick.search .. " found"))
    return
  end

  local book = books[self.pick.book] or books[1]
  local cats = self:CategoriesOf(book)
  for i, c in ipairs(cats) do c.index = i end
  p.catHeader:SetText("|cffb58cff" .. (book.kind == "order" and "Aspects" or "Categories") .. "|r")
  p.catHeader:SetWidth(150)
  p.catList:SetItems(cats, true)
  local cat = cats[self.pick.cat] or cats[1]
  local keys = self:RitesOf(cat)
  p.riteHeader:SetText("|cffb58cffRites|r")
  p.riteList:SetItems(keys, true)
  p.status:SetText(("%s  |  %d rites  |  scroll for more"):format(cat.title, #keys))
end

function R:Search(text)
  text = (text or ""):gsub("^%s+", ""):gsub("%s+$", "")
  if text == "" then self.pick.search = nil; self:RefreshPicker() return end
  local results = {}
  local canonNum = tonumber(text:lower():match("^c(%d+)$"))
  if canonNum and ns.RiteList[canonNum] then results[1] = ns.RiteList[canonNum].key end
  local q = text:lower()
  if not canonNum then
    for _, s in ipairs(ns.RiteList) do
      if s.title:lower():find(q, 1, true) then results[#results + 1] = s.key end
    end
    for _, name in ipairs(self.db.uploadOrder) do
      if name:lower():find(q, 1, true) then results[#results + 1] = "u:" .. name end
    end
    for _, n in ipairs(E.Search(text, 60)) do results[#results + 1] = "g" .. n end
  end
  self.pick.search, self.pick.searchText = results, text
  self:RefreshPicker()
  self.picker.riteList:ScrollTo(1)
end

function R:PickRandom()
  local key = "g" .. math.random(E.COUNT)
  if self.run then self:Print("Stop the current rite first, or shift-click Random Rite to switch now.") return key end
  self.db.lastSet = key
  self:UpdateBar()
  if self.picker and self.picker:IsShown() then self:ShowInPicker(key) end
  local s = self:GetSet(key)
  self:Print("The dice of Xal'Reth chose |cffffd100" .. self:Title(s) .. "|r.")
  return key
end

function R:StartRandom()
  local key = "g" .. math.random(E.COUNT)
  if self.picker then self.picker:Hide() end
  self:Start(key)
end
