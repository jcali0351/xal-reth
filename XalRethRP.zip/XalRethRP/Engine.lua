-- Xal'Reth RP - the Rite Engine
-- Builds the Grand Book: 10,000 numbered rites in 200 categories
-- (10 Orders x 20 Aspects x 50 rites). Rite #n is always the same rite,
-- on every computer, so the guild can say "tonight we perform #4817".
local ADDON, ns = ...
local G = ns.Gen
local E = {}
ns.Engine = E

E.COUNT, E.PER_CAT = 10000, 50
E.NUM_ORDERS, E.NUM_ASPECTS = #G.orders, #G.aspects   -- 10, 20

E.MOTIFS = { "head", "coil", "eye", "altar", "hands", "note", "crown", "dagger", "sun", "egg", "bowl",
  "candle", "flame", "orb", "scroll", "moon", "stone", "swords", "rings", "mask", "bell", "lamp",
  "clawprint", "star", "heart", "shield", "chalice", "feather", "crystal", "hourglass", "skull", "key" }

local floor = math.floor

-- Park-Miller generator: exact in double precision, same everywhere.
local function newRng(seed)
  local s = seed % 2147483647
  if s <= 0 then s = s + 2147483646 end
  for _ = 1, 3 do s = (s * 16807) % 2147483647 end
  return function(n)
    s = (s * 16807) % 2147483647
    return (s % n) + 1
  end
end

-- n (1..10000) -> order (1..10), aspect (1..20), index within category (0..49)
function E.Locate(n)
  local c = floor((n - 1) / E.PER_CAT)
  return floor(c / E.NUM_ASPECTS) + 1, (c % E.NUM_ASPECTS) + 1, (n - 1) % E.PER_CAT
end

function E.CategoryNumber(o, a) return (o - 1) * E.NUM_ASPECTS + a end   -- 1..200
function E.FirstRite(o, a) return (E.CategoryNumber(o, a) - 1) * E.PER_CAT + 1 end

function E.CategoryTitle(o, a)
  local order, aspect = G.orders[o], G.aspects[a]
  return aspect.adj .. " Rites of " .. order.name
end

-- Titles are built from the index digits, so every title is unique.
function E.TitleParts(n)
  local o, a, i = E.Locate(n)
  local order, aspect = G.orders[o], G.aspects[a]
  local form = G.forms[(i % 10) + 1]
  local noun = order.nouns[((floor(i / 10) * 2 + a) % 10) + 1]
  return form, aspect.adj, noun
end

function E.Title(n)
  local form, adj, noun = E.TitleParts(n)
  return form .. " of the " .. adj .. " " .. noun
end

local function fill(text, vars)
  return (text:gsub("{(%w+)}", function(k)
    local v = vars[k]
    if v == nil then return "{" .. k .. "}" end
    return v
  end))
end

-- pick k distinct entries from list using rng
local function pickDistinct(list, k, rng)
  local idx, out = {}, {}
  for i = 1, #list do idx[i] = i end
  for j = 1, math.min(k, #list) do
    local r = rng(#idx)
    out[j] = list[idx[r]]
    table.remove(idx, r)
  end
  return out
end

local cache, cacheOrder = {}, {}

function E.Rite(n)
  n = floor(tonumber(n) or 0)
  if n < 1 or n > E.COUNT then return nil end
  if cache[n] then return cache[n] end

  local o, a, i = E.Locate(n)
  local order, aspect = G.orders[o], G.aspects[a]
  local rng = newRng(n * 7919 + 104729)
  local form, adj, noun = E.TitleParts(n)
  local epithet = G.epithets[rng(#G.epithets)]
  local vars = {
    epithet = epithet, voc = (epithet:gsub("^the ", "")),
    place = aspect.place, condition = aspect.condition,
    object = order.object, aspect = aspect.name:lower(),
    form = form, noun = noun,
  }

  local lines = {}
  local function add(t) lines[#lines + 1] = fill(t, vars) end

  add(G.openings[rng(#G.openings)])
  add(G.invocations[rng(#G.invocations)])

  -- the body: three to four order actions with one or two aspect moments woven in
  local body = pickDistinct(order.actions, 3 + (rng(2) - 1), rng)
  local aspectLines = pickDistinct(aspect.lines, rng(2), rng)
  for _, al in ipairs(aspectLines) do
    table.insert(body, rng(#body + 1), al)
  end
  for _, b in ipairs(body) do add(b) end

  local chant = fill(G.chants[rng(#G.chants)], vars)
  add((G.chantLines[rng(#G.chantLines)]:gsub("{chant}", function() return chant end)))

  if rng(2) == 1 then add(G.offerings[rng(#G.offerings)]) else add(G.omens[rng(#G.omens)]) end
  if rng(3) == 1 then add(G.beats[rng(#G.beats)]) end
  add(G.closings[rng(#G.closings)])

  local set = {
    key = "g" .. n, num = n, grand = true,
    title = form .. " of the " .. adj .. " " .. noun,
    lines = lines, fallback = "the faithful", shuffle = false,
    order = o, aspect = a,
    iconSpec = {
      bg = ("bg%02d"):format(o),
      rim = ("rim%d"):format(((a - 1) % 4) + 1),
      motif = "m_" .. E.MOTIFS[(i % #E.MOTIFS) + 1],
      mirror = i >= #E.MOTIFS,
      gem = aspect.color,
    },
  }

  -- keep a small cache so browsing stays fast without holding 10,000 rites
  cache[n] = set
  cacheOrder[#cacheOrder + 1] = n
  if #cacheOrder > 400 then cache[table.remove(cacheOrder, 1)] = nil end
  return set
end

-- Search titles and numbers. Returns up to `limit` rite numbers.
function E.Search(query, limit)
  limit = limit or 40
  local out = {}
  local q = (query or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")
  if q == "" then return out end
  local num = tonumber((q:gsub("^#", "")))
  if num then
    if num >= 1 and num <= E.COUNT then out[1] = num end
    return out
  end
  for n = 1, E.COUNT do
    local o, a = E.Locate(n)
    if E.Title(n):lower():find(q, 1, true) or E.CategoryTitle(o, a):lower():find(q, 1, true) then
      out[#out + 1] = n
      if #out >= limit then break end
    end
  end
  return out
end
