-- Xal'Reth RP v2.0 - posts Xal'Reth rites as /emotes on a timer.
-- /xrp opens the panel. Pick a rite, press play. Slider sets the timer,
-- the dice makes every gap a random 5-35 seconds.
local ADDON, ns = ...
local R = {}
ns.R = R
_G.XalRethRP = R

R.version = "4.1.1"
local MAX_LEN = 255
local MEDIA = "Interface\\AddOns\\" .. ADDON .. "\\Media\\"
local ICONS = { custom = "coil", all = "logo_small", book = "emblem" }

local DEFAULTS = {
  interval = 15,
  dice = false, diceMin = 5, diceMax = 35,
  loop = false,
  shuffle = true,
  pauseInCombat = true,
  showBar = true,
  testMode = false,
  pronouns = "auto",
  lastSet = "ritual",
  uploads = {}, uploadOrder = {},
  sound = true, morph = true,
  barPoint = nil,
  custom = {},
}

local function copyDefaults(src, dst)
  if type(dst) ~= "table" then dst = {} end
  for k, v in pairs(src) do
    if type(v) == "table" then dst[k] = copyDefaults(v, dst[k])
    elseif dst[k] == nil then dst[k] = v end
  end
  return dst
end

function R:Print(msg)
  DEFAULT_CHAT_FRAME:AddMessage("|cff8a2be2[Xal'Reth RP]|r " .. tostring(msg))
end

---------------------------------------------------------------------------
-- Sets
---------------------------------------------------------------------------
-- The 100 Rites: numbered in order through ns.RiteCategories (Registry.lua)
ns.RiteList, ns.RiteByKey = {}, {}
local function bookSection(name)
  for _, s in ipairs(ns.Sections or {}) do if s.key == name then return s end end
end
do
  local n = 0
  for ci, cat in ipairs(ns.RiteCategories) do
    cat.num = ci
    for _, r in ipairs(cat.rites) do
      local key = r[1]
      local s = ns.Sets[key] or bookSection(key)
      if s then
        n = n + 1
        s.key, s.num, s.cat, s.icon = key, n, cat, ("r%03d"):format(n)
        s.shuffle = s.shuffle or false
        ns.RiteList[n] = s
        ns.RiteByKey[key] = s
      end
    end
  end
end

local ROMAN = { "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X" }
R.Categories = {}
for ci, cat in ipairs(ns.RiteCategories) do
  R.Categories[ci] = { title = ROMAN[ci] .. ". " .. cat.title, icon = cat.icon, keys = function()
    local k = {}
    for _, r in ipairs(cat.rites) do if ns.RiteByKey[r[1]] then k[#k + 1] = r[1] end end
    return k
  end }
end
R.Categories[#R.Categories + 1] = { title = "Your Own", icon = "logo_small", keys = function()
  local k = { "custom" }
  for _, n in ipairs(R.db and R.db.uploadOrder or {}) do k[#k + 1] = "u:" .. n end
  k[#k + 1] = "book"; k[#k + 1] = "all"
  return k
end }

-- Combined sets keep each line's own stand-in by storing {line, fallback}
local function addLines(out, lines, fallback)
  for _, l in ipairs(lines) do out[#out + 1] = fallback and { l, fallback } or l end
end

function R:GetSet(name)
  if not name then return nil end
  if name == "custom" then
    return { key = "custom", title = "Your Own Emotes", shuffle = true, lines = self.db.custom, icon = ICONS.custom }
  end
  if name == "book" then
    local lines = {}
    for _, s in ipairs(ns.Sections or {}) do addLines(lines, s.lines, s.fallback) end
    return { key = "book", title = "The Whole Book of Xal'Reth", shuffle = false, lines = lines, icon = ICONS.book }
  end
  if name == "all" then
    local lines = {}
    for _, s in ipairs(ns.RiteList) do addLines(lines, s.lines, s.fallback) end
    addLines(lines, self.db.custom)
    return { key = "all", title = "All 100 Rites, in Order", shuffle = false, lines = lines, icon = ICONS.all }
  end
  local g = name:match("^g(%d+)$")
  if g then return ns.Engine.Rite(tonumber(g)) end
  local up = name:match("^u:(.+)$")
  if up then
    local lines = self.db.uploads[up]
    if not lines then return nil end
    return { key = name, title = up, lines = lines, shuffle = false, icon = "logo_small", upload = true }
  end
  return ns.RiteByKey[name]
end

-- "#12 Prayers of Xal'Reth"
function R:Title(set)
  if not set then return "?" end
  if set.grand then return "#" .. set.num .. "  " .. set.title end
  if set.num then return "Canon " .. set.num .. "  " .. set.title end
  return set.title
end

function R:CategoryIndexOf(key)
  local s = ns.RiteByKey[key]
  if s and s.cat then return s.cat.num end
  return #self.Categories
end

function R:SetNames()
  local names = {}
  for _, cat in ipairs(self.Categories) do
    for _, k in ipairs(cat.keys()) do names[#names + 1] = k end
  end
  return names
end

function R:Icon(set) return MEDIA .. ((set and set.icon) or "coil") end
function R:Tex(name) return MEDIA .. name end

local function shuffled(list)
  local out = {}
  for i, v in ipairs(list) do out[i] = v end
  for i = #out, 2, -1 do
    local j = math.random(i)
    out[i], out[j] = out[j], out[i]
  end
  return out
end

---------------------------------------------------------------------------
-- Text
---------------------------------------------------------------------------
function R:Pronoun()
  local p = self.db.pronouns
  if p == "auto" then
    local sex = UnitSex and UnitSex("player")
    return sex == 3 and "she" or sex == 2 and "he" or "they"
  end
  return p
end

-- Swap they/their/them for the performer, only outside "quoted speech".
local function swapPronouns(text, p)
  if p == "they" then return text end
  local poss, obj, refl = (p == "she") and "her" or "his", (p == "she") and "her" or "him", (p == "she") and "herself" or "himself"
  local out, inQuote = {}, false
  for chunk, q in text:gmatch('([^"]*)("?)') do
    if not inQuote then
      chunk = chunk:gsub("%f[%a]themselves%f[%A]", refl):gsub("%f[%a]their%f[%A]", poss):gsub("%f[%a]them%f[%A]", obj)
    end
    out[#out + 1] = chunk .. q
    if q == '"' then inQuote = not inQuote end
  end
  return table.concat(out)
end
R.swapPronouns = swapPronouns

function R:Render(line, set)
  local fallback = (set and set.fallback) or "the altar"
  if type(line) == "table" then line, fallback = line[1], line[2] end
  local target = UnitExists("target") and UnitName("target") or nil
  if target and issecretvalue and issecretvalue(target) then target = nil end
  if target and UnitIsUnit and UnitIsUnit("target", "player") then target = nil end
  local guild = IsInGuild() and GetGuildInfo("player") or "the cult"
  local text = line:gsub("{target}", target or fallback):gsub("{guild}", guild or "the cult")
  text = text:gsub("|", "")
  text = swapPronouns(text, self:Pronoun())
  if #text > MAX_LEN then
    local cut = text:sub(1, MAX_LEN - 3)
    text = (cut:match("^(.*)%s") or cut) .. "..."
  end
  return text
end

---------------------------------------------------------------------------
-- Player
---------------------------------------------------------------------------
-- state: nil (idle) | "running" | "paused" | "waiting" (held for combat/lockdown)

function R:CanEmote()
  if C_ChatInfo and C_ChatInfo.InChatMessagingLockdown and C_ChatInfo.InChatMessagingLockdown() then
    return false, "boss encounter chat lockdown"
  end
  if self.db.pauseInCombat and InCombatLockdown() then return false, "combat" end
  return true
end

local function send(text)
  if C_ChatInfo and C_ChatInfo.SendChatMessage then
    C_ChatInfo.SendChatMessage(text, "EMOTE")
  else
    SendChatMessage(text, "EMOTE")
  end
end

function R:NextDelay()
  if self.db.dice then
    local lo, hi = self.db.diceMin, math.max(self.db.diceMin, self.db.diceMax)
    return math.random(lo, hi)
  end
  return self.db.interval
end

function R:ArmTimer(delay)
  self:CancelTimer()
  self.nextDur = delay
  self.nextAt = GetTime() + delay
  self.timer = C_Timer.NewTimer(delay, function() self.timer = nil; self:PostNext() end)
end

-- The slider or dice changed while we're waiting: apply it to the current gap.
function R:Reschedule()
  if self.state ~= "running" or not self.nextAt then return end
  if self.db.dice then
    self:ArmTimer(self:NextDelay())
  else
    local elapsed = self.nextDur - (self.nextAt - GetTime())
    self.nextDur = self.db.interval
    local remain = math.max(1, self.db.interval - elapsed)
    self:CancelTimer()
    self.nextAt = GetTime() + remain
    self.timer = C_Timer.NewTimer(remain, function() self.timer = nil; self:PostNext() end)
  end
end

function R:Start(setName)
  if not setName or setName == "" then setName = self.db.lastSet or "ritual"
  elseif not setName:find("^u:") then setName = setName:lower() end
  local set = self:GetSet(setName)
  if not set then
    self:Print("No rite named '" .. setName .. "'. /xrp sets lists them all.")
    return
  end
  if #set.lines == 0 then
    self:Print("That set is empty. Add lines with /xrp add <text>.")
    return
  end
  self:Stop(true)
  self.db.lastSet = setName
  local lines = (set.shuffle and self.db.shuffle) and shuffled(set.lines) or set.lines
  self.run = { name = setName, title = set.title, lines = lines, i = 0, set = set }
  self.state = "running"
  self:Print(("Beginning |cffffd100%s|r: %d emotes, %s."):format(set.title, #lines,
    self.db.dice and ("random gaps of " .. self.db.diceMin .. "-" .. self.db.diceMax .. "s") or ("one every " .. self.db.interval .. "s")))
  self:PostNext()
end

function R:PostNext()
  local run = self.run
  if not run then return end
  self:CancelTimer()

  local ok, why = self:CanEmote()
  if not ok then
    if self.state ~= "waiting" then self:Print("Holding emotes during " .. why .. ".") end
    self.state = "waiting"
    self.nextAt = nil
    self.timer = C_Timer.NewTimer(3, function() self.timer = nil; self:PostNext() end)
    self:UpdateBar()
    return
  end
  if self.state == "waiting" then self.state = "running"; self:Print("Resuming.") end

  run.i = run.i + 1
  if run.i > #run.lines then
    if self.db.loop then
      local set = self:GetSet(run.name)
      run.lines = (set.shuffle and self.db.shuffle) and shuffled(set.lines) or set.lines
      run.i = 1
    else
      self:Finish()
      return
    end
  end

  local text = self:Render(run.lines[run.i], run.set)
  if self.db.testMode then
    self:Print(("|cffaaaaaa(test %d/%d)|r |cffff8040%s %s|r"):format(run.i, #run.lines, UnitName("player"), text))
  else
    local okSend, err = pcall(send, text)
    if not okSend then self:Print("Emote failed: " .. tostring(err)) end
  end
  self:Pulse()

  if run.i >= #run.lines and not self.db.loop then
    self.nextAt, self.nextDur = nil, nil
    self.timer = C_Timer.NewTimer(1, function() self.timer = nil; self:Finish() end)
  else
    self:ArmTimer(self:NextDelay())
  end
  self:UpdateBar()
end

function R:Finish()
  if not self.run then return end
  self:Print(("|cffffd100%s|r complete. Hail Xal'Reth."):format(self.run.title))
  if PlaySound and SOUNDKIT and SOUNDKIT.UI_QUEST_ROLLING_FORWARD_01 then pcall(PlaySound, SOUNDKIT.UI_QUEST_ROLLING_FORWARD_01) end
  self:Stop(true)
end

function R:CancelTimer()
  if self.timer then self.timer:Cancel(); self.timer = nil end
end

function R:Pause()
  if self.state ~= "running" and self.state ~= "waiting" then return end
  self:CancelTimer()
  self.state, self.nextAt = "paused", nil
  self:UpdateBar()
end

function R:Resume()
  if self.state ~= "paused" then return end
  self.state = "running"
  self:ArmTimer(self:NextDelay())
  self:UpdateBar()
end

function R:Stop(silent)
  self:CancelTimer()
  local was = self.run
  self.run, self.state, self.nextAt, self.nextDur = nil, nil, nil, nil
  if was and not silent then self:Print("Stopped.") end
  self:UpdateBar()
end

function R:Skip()
  if not self.run then return end
  if self.state == "paused" then self.state = "running" end
  self:PostNext()
end

function R:TogglePlay()
  if self.state == "paused" then self:Resume()
  elseif self.state then self:Pause()
  else self:Start(self.db.lastSet) end
end

function R:SetDice(on)
  self.db.dice = on and true or false
  self:Reschedule()
  self:UpdateBar()
end

function R:SetInterval(v)
  v = math.max(5, math.min(60, math.floor(v + 0.5)))
  if v == self.db.interval then return end
  self.db.interval = v
  if not self.db.dice then self:Reschedule() end
  self:UpdateBar()
end

---------------------------------------------------------------------------
-- Panel
---------------------------------------------------------------------------
local PW, PH = 440, 196

local function tooltip(widget, title, text)
  widget:SetScript("OnEnter", function(w)
    GameTooltip:SetOwner(w, "ANCHOR_TOP")
    GameTooltip:SetText(title, 1, 0.82, 0)
    if text then GameTooltip:AddLine(text, 0.9, 0.9, 0.9, true) end
    GameTooltip:Show()
  end)
  widget:SetScript("OnLeave", function() GameTooltip:Hide() end)
end

function R:RoundButton(parent, tex, size, x, y, fn, tipTitle, tipText)
  local b = CreateFrame("Button", nil, parent)
  b:SetSize(size, size)
  b:SetPoint("TOPLEFT", x, y)
  b:SetNormalTexture(self:Tex(tex))
  local hl = b:CreateTexture(nil, "HIGHLIGHT")
  hl:SetTexture(self:Tex("glow"))
  hl:SetBlendMode("ADD")
  hl:SetPoint("CENTER")
  hl:SetSize(size * 1.5, size * 1.5)
  b:SetScript("OnMouseDown", function(btn) btn:GetNormalTexture():SetVertexColor(0.75, 0.75, 0.75) end)
  b:SetScript("OnMouseUp", function(btn) btn:GetNormalTexture():SetVertexColor(1, 1, 1) end)
  b:SetScript("OnClick", fn)
  if tipTitle then tooltip(b, tipTitle, tipText) end
  return b
end

-- Footer text buttons: 5px of padding around the label, sized to fit it
local function textButton(parent, x, y, fn)
  local b = CreateFrame("Button", nil, parent)
  b:SetSize(90, 20)
  b:SetPoint("TOPLEFT", x - 5, y + 3)
  b.text = b:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
  b.text:SetPoint("LEFT", 5, 0)
  local hl = b:CreateTexture(nil, "HIGHLIGHT")
  hl:SetAllPoints()
  hl:SetColorTexture(0.6, 0.4, 1, 0.18)
  function b:SetLabel(text)
    self.text:SetText(text)
    self:SetWidth(self.text:GetStringWidth() + 10)
  end
  b:SetScript("OnClick", fn)
  return b
end

function R:BuildBar()
  local p = CreateFrame("Frame", "XalRethRPPanel", UIParent)
  p:SetSize(PW, PH)
  if self.db.barPoint then
    local pt = self.db.barPoint
    p:SetPoint(pt[1], UIParent, pt[2], pt[3], pt[4])
  else
    p:SetPoint("TOP", 0, -110)
  end
  p:SetFrameStrata("MEDIUM")
  p:SetClampedToScreen(true)
  p:SetMovable(true)
  p:EnableMouse(true)
  p:RegisterForDrag("LeftButton")
  p:SetScript("OnDragStart", p.StartMoving)
  p:SetScript("OnDragStop", function(f)
    f:StopMovingOrSizing()
    local p1, _, p2, x, y = f:GetPoint()
    R.db.barPoint = { p1, p2, x, y }
  end)

  self:DressFrame(p, "frame_panel", PW, PH, 512, 256)

  -- Xal'Reth logo inside a rotating sigil, with the rite's icon as a badge
  local LX, LY = 56, -56
  p.rays = p:CreateTexture(nil, "BORDER")
  p.rays:SetTexture(self:Tex("rays"))
  p.rays:SetBlendMode("ADD")
  p.rays:SetSize(150, 150)
  p.rays:SetPoint("CENTER", p, "TOPLEFT", LX, LY)
  p.rays:SetAlpha(0)

  p.sigil = p:CreateTexture(nil, "ARTWORK", nil, 1)
  p.sigil:SetTexture(self:Tex("sigil"))
  p.sigil:SetSize(104, 104)
  p.sigil:SetPoint("CENTER", p, "TOPLEFT", LX, LY)
  p.sigil:SetAlpha(0.9)
  local spin = p.sigil:CreateAnimationGroup()
  spin:SetLooping("REPEAT")
  local rot = spin:CreateAnimation("Rotation")
  rot:SetDegrees(-360); rot:SetDuration(18)
  p.spin = spin

  p.logo = p:CreateTexture(nil, "ARTWORK", nil, 2)
  p.logo:SetTexture(self:Tex("logo"))
  p.logo:SetSize(80, 80)
  p.logo:SetPoint("CENTER", p, "TOPLEFT", LX, LY)

  p.logoGlow = p:CreateTexture(nil, "ARTWORK", nil, 3)
  p.logoGlow:SetTexture(self:Tex("glow"))
  p.logoGlow:SetBlendMode("ADD")
  p.logoGlow:SetSize(110, 110)
  p.logoGlow:SetPoint("CENTER", p.logo, "CENTER")
  p.logoGlow:SetAlpha(0)

  p.icon = self:MakeIcon(p, 34)
  p.icon:SetPoint("CENTER", p.logo, "BOTTOMLEFT", 4, 6)
  p.icon:SetFrameLevel(p:GetFrameLevel() + 3)

  -- edge glow over the whole panel (shown on every emote)
  p.edge = p:CreateTexture(nil, "OVERLAY", nil, 7)
  p.edge:SetTexture(self:Tex("panel_glow_gold"))
  p.edge:SetTexCoord(0, PW / 512, 0, PH / 256)
  p.edge:SetBlendMode("ADD")
  p.edge:SetPoint("TOPLEFT", -6, 6)
  p.edge:SetPoint("BOTTOMRIGHT", 6, -6)
  p.edge:SetAlpha(0)

  -- one flash = fade in fast, fade out slowly
  local function flash(tex, peak, fadeIn, fadeOut, scaleFrom)
    local ag = tex:CreateAnimationGroup()
    local a1 = ag:CreateAnimation("Alpha")
    a1:SetFromAlpha(0); a1:SetToAlpha(peak); a1:SetDuration(fadeIn); a1:SetOrder(1)
    local a2 = ag:CreateAnimation("Alpha")
    a2:SetFromAlpha(peak); a2:SetToAlpha(0); a2:SetDuration(fadeOut); a2:SetOrder(2)
    if scaleFrom then
      local sc = ag:CreateAnimation("Scale")
      if sc.SetScaleFrom then sc:SetScaleFrom(scaleFrom, scaleFrom); sc:SetScaleTo(1.15, 1.15)
      else sc:SetScale(1.15 / scaleFrom, 1.15 / scaleFrom) end
      sc:SetDuration(fadeIn + fadeOut); sc:SetOrder(1)
    end
    return ag
  end
  p.flashes = {
    flash(p.edge, 1, 0.12, 1.4),
    flash(p.rays, 1, 0.15, 1.6, 0.7),
    flash(p.logoGlow, 0.9, 0.1, 1.0),
  }

  -- titles
  p.title = p:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
  p.title:SetPoint("TOPLEFT", 104, -20)
  p.title:SetWidth(300)
  p.title:SetJustifyH("LEFT")
  p.title:SetWordWrap(false)
  p.sub = p:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  p.sub:SetPoint("TOPLEFT", 104, -42)
  p.sub:SetWidth(300)
  p.sub:SetJustifyH("LEFT")

  -- bars
  local function bar(texName, x, y, w, h)
    local bbg = p:CreateTexture(nil, "ARTWORK")
    bbg:SetTexture(self:Tex("bar_bg"))
    bbg:SetPoint("TOPLEFT", x, y)
    bbg:SetSize(w, h)
    local sb = CreateFrame("StatusBar", nil, p)
    sb:SetPoint("TOPLEFT", x + 1, y - 1)
    sb:SetSize(w - 2, h - 2)
    sb:SetStatusBarTexture(self:Tex(texName))
    sb:SetMinMaxValues(0, 1)
    sb:SetValue(0)
    return sb
  end
  p.progress = bar("bar_gold", 104, -58, 316, 8)

  p.preview = p:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  p.preview:SetPoint("TOPLEFT", 104, -72)
  p.preview:SetWidth(316)
  p.preview:SetHeight(30)
  p.preview:SetJustifyH("LEFT")
  p.preview:SetJustifyV("TOP")
  p.preview:SetTextColor(0.82, 0.76, 0.9)

  p.countdown = bar("bar_violet", 16, -110, 408, 7)

  -- controls
  local y = -124
  p.play = self:RoundButton(p, "btn_play", 34, 16, y, function() R:TogglePlay() end, "Play / Pause", "Start the chosen rite, or pause it.")
  self:RoundButton(p, "btn_next", 34, 54, y, function() R:Skip() end, "Next", "Emote the next line right now.")
  self:RoundButton(p, "btn_stop", 34, 92, y, function() R:Stop() end, "Stop", "End the rite.")
  self:RoundButton(p, "btn_sets", 34, 130, y, function() R:TogglePicker() end, "Rites", "Choose which rite to perform. Right-click a rite to start it at once.")

  -- timer slider
  p.sliderLabel = p:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
  p.sliderLabel:SetPoint("TOPLEFT", 180, y - 1)
  local sl = CreateFrame("Slider", nil, p)
  sl:SetOrientation("HORIZONTAL")
  sl:SetSize(150, 16)
  sl:SetPoint("TOPLEFT", 178, y - 16)
  sl:SetMinMaxValues(5, 60)
  sl:SetValueStep(1)
  sl:SetObeyStepOnDrag(true)
  local track = sl:CreateTexture(nil, "BACKGROUND")
  track:SetTexture(self:Tex("slider_track"))
  track:SetAllPoints()
  sl:SetThumbTexture(self:Tex("slider_thumb"))
  sl:GetThumbTexture():SetSize(22, 22)
  sl:EnableMouseWheel(true)
  sl:SetScript("OnMouseWheel", function(s, delta) s:SetValue(s:GetValue() + delta) end)
  sl:SetScript("OnValueChanged", function(_, v)
    if R.building then return end
    R:SetInterval(v)
  end)
  tooltip(sl, "Timer", "Seconds between emotes (5-60). Scroll the mouse wheel for fine steps.")
  p.slider = sl
  local lo = p:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  lo:SetPoint("TOPLEFT", sl, "BOTTOMLEFT", 0, -1); lo:SetText("5s")
  local hi = p:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  hi:SetPoint("TOPRIGHT", sl, "BOTTOMRIGHT", 0, -1); hi:SetText("60s")

  -- dice
  p.dice = self:RoundButton(p, "btn_dice", 38, 344, y - 2, function()
    R:SetDice(not R.db.dice)
    p.diceSpin:Stop(); p.diceSpin:Play()
    if PlaySound and SOUNDKIT and SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON then pcall(PlaySound, SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON) end
  end, "Dice of Xal'Reth", "Toggle random timing: every gap becomes a random 5-35 seconds.")
  local dspin = p.dice:GetNormalTexture():CreateAnimationGroup()
  local drot = dspin:CreateAnimation("Rotation")
  drot:SetDegrees(-360); drot:SetDuration(0.45)
  p.diceSpin = dspin
  p.diceLabel = p:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
  p.diceLabel:SetPoint("LEFT", p.dice, "RIGHT", 4, 0)
  p.diceLabel:SetWidth(46)
  p.diceLabel:SetJustifyH("LEFT")

  -- footer toggles
  p.loopBtn = textButton(p, 18, -170, function() R.db.loop = not R.db.loop; R:UpdateBar() end)
  p.testBtn = textButton(p, 92, -170, function() R.db.testMode = not R.db.testMode; R:UpdateBar() end)
  p.shufBtn = textButton(p, 166, -170, function() R.db.shuffle = not R.db.shuffle; R:UpdateBar() end)
  p.upBtn = textButton(p, 268, -170, function() R:ToggleUpload() end)
  p.upBtn:SetLabel("|cffe8be5c[ Upload ]|r")
  p.rndBtn = textButton(p, 344, -170, function()
    if IsShiftKeyDown() then R:StartRandom() else R:PickRandom() end
  end)
  p.rndBtn:SetLabel("|cffe8be5c[ Random ]|r")
  tooltip(p.upBtn, "Upload", "Paste your own emote strings and save them as a rite.")
  tooltip(p.rndBtn, "Random Rite", "Choose a random rite from the Grand Book of 10,000. Shift-click to begin it at once.")
  tooltip(p.loopBtn, "Loop", "Start the rite over when it ends.")
  tooltip(p.testBtn, "Test mode", "Emotes print only to you.")
  tooltip(p.shufBtn, "Shuffle", "Random order for Hymns of Praise, Battle Prayers, Idle Cultist and your own lines.")

  -- close
  local close = self:RoundButton(p, "btn_close", 18, PW - 46, -12, function()
    R.db.showBar = false; R:UpdateBar()
    R:Print("Panel hidden. /xrp to show it again.")
  end, "Hide panel", "/xrp brings it back. A running rite keeps going.")
  close:SetFrameLevel(p:GetFrameLevel() + 5)
  p.soundBtn = self:RoundButton(p, "btn_sound", 18, PW - 70, -12, function()
    R.db.sound = not R.db.sound
    R:UpdateBar()
    if R.db.sound then R.lastPad = nil; R:Dazzle() end
  end, "Synth pad", "Play a soft synthesizer pad when Xal'Reth glows. Click to turn on or off.")
  p.soundBtn:SetFrameLevel(p:GetFrameLevel() + 5)
  self:BuildDazzle(p)
  self:AttachMorph(p.logo, "l", self.LOGO_FRAMES)

  p:SetScript("OnUpdate", function(f, el)
    f.acc = (f.acc or 0) + el
    if f.acc < 0.1 then return end
    f.acc = 0
    R:UpdateCountdown()
  end)

  self.building = true
  sl:SetValue(self.db.interval)
  self.building = false
  self.bar = p
end

-- Every emote makes the panel glow: border flare, light rays behind the
-- logo, and Xal'Reth erupts in golden razzle-dazzle with a synth pad.
function R:Pulse()
  local p = self.bar
  if not (p and p:IsShown()) then return end
  for _, ag in ipairs(p.flashes) do ag:Stop(); ag:Play() end
  self:Dazzle()
end

function R:UpdateCountdown()
  local p = self.bar
  if not p then return end
  if self.state == "running" and self.nextAt and self.nextDur and self.run then
    local remain = math.max(0, self.nextAt - GetTime())
    p.countdown:SetValue(remain / self.nextDur)
    p.sub:SetText(("%d / %d   |cffc8a2ffnext in %ds|r"):format(self.run.i, #self.run.lines, math.ceil(remain)))
  end
end

local function onOff(label, v) return label .. ": " .. (v and "|cff55ff55on|r" or "|cff999999off|r") end

function R:UpdateBar()
  if not self.db then return end
  if not self.db.showBar then if self.bar then self.bar:Hide() end return end
  if not self.bar then self:BuildBar() end
  local p = self.bar
  p:Show()

  local run = self.run
  local set = run and run.set or self:GetSet(self.db.lastSet) or self:GetSet("ritual")
  p.icon:SetSet(set)
  p.title:SetText("|cffe8be5c" .. self:Title(set) .. "|r")

  if run then
    p.progress:SetValue(run.i / #run.lines)
    local nextLine = run.lines[run.i + 1]
    if self.state == "paused" then
      p.sub:SetText(("%d / %d   |cffffaa00paused|r"):format(run.i, #run.lines))
    elseif self.state == "waiting" then
      p.sub:SetText(("%d / %d   |cffff5555holding for combat|r"):format(run.i, #run.lines))
    end
    p.preview:SetText(nextLine and ("|cff8a6fb0Next:|r " .. UnitName("player") .. " " .. self:Render(nextLine, run.set)) or "|cff8a6fb0Final line spoken.|r")
    p.play:SetNormalTexture(self:Tex(self.state == "paused" and "btn_play" or "btn_pause"))
    if self.state == "running" then p.spin:Play() else p.spin:Pause() end
    if self.state ~= "running" then p.countdown:SetValue(0) end
  else
    p.progress:SetValue(0)
    p.countdown:SetValue(0)
    p.sub:SetText(("%d emotes   |cff999999ready|r"):format(set and #set.lines or 0))
    local first = set and set.lines[1]
    p.preview:SetText(first and ("|cff8a6fb0First:|r " .. UnitName("player") .. " " .. self:Render(first, set)) or "|cff8a6fb0Empty. Add lines with /xrp add.|r")
    p.play:SetNormalTexture(self:Tex("btn_play"))
    p.spin:Pause()
  end

  -- timer controls
  local dice = self.db.dice
  p.sliderLabel:SetText(dice and ("|cff777777Timer: " .. self.db.interval .. "s|r") or ("Timer: |cffffffff" .. self.db.interval .. "s|r"))
  p.slider:SetAlpha(dice and 0.4 or 1)
  p.dice:GetNormalTexture():SetDesaturated(not dice)
  p.dice:SetAlpha(dice and 1 or 0.7)
  p.diceLabel:SetText(dice and ("|cff55ff55" .. self.db.diceMin .. "-" .. self.db.diceMax .. "s|r") or "|cff999999random|r")

  p.soundBtn:GetNormalTexture():SetDesaturated(not self.db.sound)
  p.soundBtn:SetAlpha(self.db.sound and 1 or 0.55)
  p.loopBtn:SetLabel(onOff("Loop", self.db.loop))
  p.testBtn:SetLabel(onOff("Test", self.db.testMode))
  p.shufBtn:SetLabel(onOff("Shuffle", self.db.shuffle))
  if self.picker and self.picker:IsShown() then self:RefreshPicker() end
end

---------------------------------------------------------------------------
-- Rite picker
---------------------------------------------------------------------------
---------------------------------------------------------------------------
-- Slash commands
---------------------------------------------------------------------------
local HELP = {
  "|cff8a2be2Xal'Reth RP|r v%s  -  /xrp <command>",
  "  (nothing)  show the panel",
  "  start [rite]  begin: a name (ritual), a Grand Book number (4817) or canon (c12)",
  "  pause | resume | next | stop   |   book  open the Book   |   random [start]",
  "  upload  paste your own emotes   |   search <words>",
  "  sets  list all rites   |  preview <rite>  read a rite to yourself",
  "  interval <5-60>  timer between emotes",
  "  dice  toggle random timing   |  dice <min> <max>  change the random range",
  "  loop | shuffle | test | sound | morph  toggles",
  "  add <text>  add your own emote (no name; the game adds it)   |  list  |  del <n>",
  "  pronouns auto|she|he|they   |   reset  move the panel back to the middle",
}

function R:Slash(input)
  local cmd, rest = (input or ""):match("^%s*(%S*)%s*(.-)%s*$")
  cmd = cmd:lower()
  if cmd == "" or cmd == "show" or cmd == "bar" then
    self.db.showBar = true; self:UpdateBar()
  elseif cmd == "help" then
    for i, l in ipairs(HELP) do self:Print(i == 1 and l:format(self.version) or l) end
  elseif cmd == "start" then
    local n = tonumber((rest:gsub("^#", "")))
    local c = tonumber(rest:lower():match("^c(%d+)$"))
    if n then self:Start("g" .. n)
    elseif c and ns.RiteList[c] then self:Start(ns.RiteList[c].key)
    elseif rest ~= "" and not self:GetSet(rest:lower()) and self.db.uploads[rest] then self:Start("u:" .. rest)
    else self:Start(rest ~= "" and rest or self.db.lastSet) end
  elseif cmd == "random" then
    if rest == "start" or rest == "go" then self:StartRandom() else self:PickRandom() end
  elseif cmd == "upload" or cmd == "import" then
    self:ToggleUpload()
  elseif cmd == "book" or cmd == "rites" then
    self.db.showBar = true; self:UpdateBar(); self:TogglePicker()
  elseif cmd == "search" then
    local found = 0
    for _, s in ipairs(ns.RiteList) do
      if s.title:lower():find(rest:lower(), 1, true) then self:Print("  " .. self:Title(s)); found = found + 1 end
    end
    for _, n in ipairs(ns.Engine.Search(rest, 15)) do self:Print("  " .. self:Title(ns.Engine.Rite(n))); found = found + 1 end
    if found == 0 then self:Print("No rites found.") end
  elseif cmd == "pause" then self:Pause()
  elseif cmd == "resume" then self:Resume()
  elseif cmd == "next" or cmd == "skip" then self:Skip()
  elseif cmd == "stop" then self:Stop()
  elseif cmd == "sets" then
    for _, cat in ipairs(self.Categories) do
      self:Print("|cffb58cff" .. cat.title .. "|r")
      for _, k in ipairs(cat.keys()) do
        local s = self:GetSet(k)
        self:Print(("  |cffffd100%s|r  %s (%d)"):format(k, self:Title(s), #s.lines))
      end
    end
  elseif cmd == "preview" then
    local s = self:GetSet(rest:lower())
    if not s then self:Print("Usage: /xrp preview <rite>") return end
    for i, l in ipairs(s.lines) do self:Print(i .. ". " .. self:Render(l, s)) end
  elseif cmd == "interval" then
    local n = tonumber(rest)
    if n and n >= 5 and n <= 60 then
      self:SetInterval(n)
      if self.bar then self.building = true; self.bar.slider:SetValue(self.db.interval); self.building = false end
      self:Print("Timer: " .. self.db.interval .. "s")
    else self:Print("Usage: /xrp interval <5-60>") end
  elseif cmd == "dice" then
    local lo, hi = rest:match("^(%d+)%s+(%d+)$")
    lo, hi = tonumber(lo), tonumber(hi)
    if lo and hi and lo >= 3 and hi <= 300 and lo <= hi then
      self.db.diceMin, self.db.diceMax = lo, hi
      self:Print(("Dice range: %d-%d seconds."):format(lo, hi))
      self:SetDice(true)
    else
      self:SetDice(not self.db.dice)
      self:Print("Random timing " .. (self.db.dice and ("ON (" .. self.db.diceMin .. "-" .. self.db.diceMax .. "s)") or "OFF"))
    end
  elseif cmd == "sound" then
    self.db.sound = not self.db.sound; self:Print("Synth pad " .. (self.db.sound and "ON" or "OFF")); self:UpdateBar()
  elseif cmd == "morph" then
    self.db.morph = not self.db.morph; self:Print("Dragon morph " .. (self.db.morph and "ON" or "OFF"))
  elseif cmd == "loop" then
    self.db.loop = not self.db.loop; self:Print("Loop " .. (self.db.loop and "ON" or "OFF")); self:UpdateBar()
  elseif cmd == "shuffle" then
    self.db.shuffle = not self.db.shuffle; self:Print("Shuffle " .. (self.db.shuffle and "ON" or "OFF")); self:UpdateBar()
  elseif cmd == "test" then
    self.db.testMode = not self.db.testMode
    self:Print("Test mode " .. (self.db.testMode and "ON (emotes print only to you)" or "OFF")); self:UpdateBar()
  elseif cmd == "add" then
    if rest == "" then self:Print("Usage: /xrp add kneels and whispers to Xal'Reth.") return end
    rest = rest:gsub("|", "")
    if #rest > MAX_LEN then self:Print("Too long (" .. #rest .. " characters, max " .. MAX_LEN .. ").") return end
    table.insert(self.db.custom, rest)
    self:Print("Added custom emote #" .. #self.db.custom .. ".")
    self:UpdateBar()
  elseif cmd == "list" then
    if #self.db.custom == 0 then self:Print("No custom emotes yet. /xrp add <text>") end
    for i, l in ipairs(self.db.custom) do self:Print(i .. ". " .. l) end
  elseif cmd == "del" then
    local n = tonumber(rest)
    if n and self.db.custom[n] then
      if self.run and self.run.name == "custom" then self:Print("Stop the custom rite first.") return end
      self:Print("Removed: " .. table.remove(self.db.custom, n))
      self:UpdateBar()
    else self:Print("Usage: /xrp del <number>  (see /xrp list)") end
  elseif cmd == "pronouns" then
    if rest == "auto" or rest == "she" or rest == "he" or rest == "they" then
      self.db.pronouns = rest
      self:Print("Pronouns: " .. rest .. (rest == "auto" and (" (" .. self:Pronoun() .. ")") or ""))
      self:UpdateBar()
    else self:Print("Usage: /xrp pronouns auto|she|he|they") end
  elseif cmd == "reset" then
    self.db.barPoint = nil
    if self.bar then self.bar:ClearAllPoints(); self.bar:SetPoint("TOP", 0, -110) end
    self.db.showBar = true; self:UpdateBar()
  elseif cmd == "hide" then
    self.db.showBar = false; self:UpdateBar()
  else
    self:Print("Unknown command. /xrp help")
  end
end

SLASH_XALRETHRP1 = "/xrp"
SLASH_XALRETHRP2 = "/xalrethrp"
SlashCmdList.XALRETHRP = function(msg) R:Slash(msg) end

function XalRethRP_OnAddonCompartmentClick()
  R.db.showBar = not R.db.showBar
  R:UpdateBar()
end

---------------------------------------------------------------------------
-- Events
---------------------------------------------------------------------------
local f = CreateFrame("Frame")
f:RegisterEvent("ADDON_LOADED")
f:RegisterEvent("PLAYER_LOGIN")
f:RegisterEvent("PLAYER_TARGET_CHANGED")
f:SetScript("OnEvent", function(_, event, arg1)
  if event == "ADDON_LOADED" and arg1 == ADDON then
    XalRethRPDB = copyDefaults(DEFAULTS, XalRethRPDB)
    R.db = XalRethRPDB
    if R.db.interval > 60 then R.db.interval = 60 end
    if not R:GetSet(R.db.lastSet) then R.db.lastSet = "ritual" end
  elseif event == "PLAYER_LOGIN" then
    R:UpdateBar()
    R:Print("v" .. R.version .. " loaded. /xrp shows the panel, /xrp help lists commands.")
  elseif event == "PLAYER_TARGET_CHANGED" then
    -- refresh the preview so {target} shows the new name
    if R.bar and R.bar:IsShown() then R:UpdateBar() end
  end
end)
