-- Xal'Reth RP - Rite Engine: the twenty Aspects
-- Every Order is performed under every Aspect: 10 x 20 = 200 categories.
local ADDON, ns = ...
ns.Gen = ns.Gen or {}
local G = ns.Gen

G.aspects = {
  { name = "Dawn", adj = "Dawnlit", place = "on a hilltop at first light", condition = "as the sun first rises", color = { 1.0, 0.75, 0.35 }, lines = {
    "turns to face the rising sun and spreads their arms to catch the first rays.",
    "whispers, \"Good morning, Xal'Reth. Good morning, sun. Good morning, rocks.\"",
    "warns {target}, \"Do not speak to me for twenty minutes. I am charging.\"",
    "watches the sky turn gold and lets out a long, contented sigh.",
  } },
  { name = "Dusk", adj = "Dusk-Hallowed", place = "as the shadows lengthen", condition = "as the day's last warmth fades", color = { 0.95, 0.45, 0.35 }, lines = {
    "thanks the setting sun: \"We will see you tomorrow. Probably.\"",
    "dims the heat lamps to the night setting with ceremonial care.",
    "lights a single candle as the last light slips behind the hills.",
    "recites, \"The day was long. The stones were warm. The loot was adequate.\"",
  } },
  { name = "Rain", adj = "Rain-Soaked", place = "beneath a dripping canopy", condition = "while cold rain falls", color = { 0.45, 0.65, 0.95 }, lines = {
    "shivers in the rain, utterly dejected. \"Why. Why rain. Why today.\"",
    "huddles under a cloak with {target} for warmth.",
    "sings a miserable dirge: \"Oh the rain, the cold, cold rain, it falls upon my scales again.\"",
    "looks up hopefully. The rain continues. \"Any day now.\"",
  } },
  { name = "Frost", adj = "Frostbound", place = "on a frozen riverbank", condition = "while frost creeps over the stones", color = { 0.7, 0.9, 1.0 }, lines = {
    "breathes on their hands. Their breath is a small, sad cloud.",
    "moves very, very slowly. \"Cold. Too cold. Must... conserve... everything.\"",
    "presses a warm stone to {target}'s cheek. \"Hold this. Do not let it go.\"",
    "scrapes frost from the altar with a sleeve. \"Even here, Xal'Reth hears.\"",
  } },
  { name = "Ember", adj = "Ember-Kissed", place = "beside a crackling bonfire", condition = "as the embers glow", color = { 1.0, 0.45, 0.15 }, lines = {
    "holds both palms toward the fire and sighs with deep satisfaction.",
    "feeds a single dry branch into the flames. Sparks spiral upward like a coil.",
    "edges closer and closer to the fire until {target} pulls them back.",
    "stares into the embers. \"Every flame is a tiny sun. Every sun is a tiny Xal'Reth.\"",
  } },
  { name = "Moon", adj = "Moonsworn", place = "beneath a pale full moon", condition = "under the cold light of the moon", color = { 0.85, 0.85, 1.0 }, lines = {
    "gazes at the moon. \"The moon is just a basking rock. A very far away basking rock.\"",
    "bathes in the silver light, though it offers no warmth at all.",
    "whispers, \"The moon remembers the sun's warmth. So must we.\"",
    "points up. \"Somewhere up there, a lizard is basking. We believe this.\"",
  } },
  { name = "Storm", adj = "Stormcalled", place = "on a windswept cliff", condition = "as thunder rolls overhead", color = { 0.6, 0.55, 1.0 }, lines = {
    "flinches at a crack of thunder, then pretends it was a spiritual gesture.",
    "shouts into the wind, \"WE ARE NOT AFRAID! WE ARE A LITTLE CHILLY!\"",
    "holds the altar cloth down with both hands as the gale tries to steal it.",
    "counts the seconds between flash and thunder. \"Close. Xal'Reth is close.\"",
  } },
  { name = "Ash", adj = "Ash-Marked", place = "amid grey drifts of ash", condition = "while ash falls like snow", color = { 0.65, 0.6, 0.6 }, lines = {
    "draws a spiral on their own brow in warm ash.",
    "marks {target}'s forehead with ash. \"What burns, warms. What warms, remains.\"",
    "lets the falling ash settle on their outstretched palms without brushing it away.",
    "whispers, \"From fire, ash. From ash, warm ground. From warm ground, us.\"",
  } },
  { name = "Bloom", adj = "Blossoming", place = "in a meadow of warm flowers", condition = "as the flowers open to the sun", color = { 1.0, 0.6, 0.85 }, lines = {
    "weaves a crown of yellow flowers and sets it on {target}'s head.",
    "lies down in the sunny grass among the blossoms. \"This is allowed. This is holy.\"",
    "watches a bee visit every flower in turn. \"Patient. Methodical. Almost reptilian.\"",
    "scatters petals across the altar stones.",
  } },
  { name = "Tide", adj = "Tide-Drawn", place = "on a sun-warmed beach", condition = "as the tide draws out", color = { 0.3, 0.85, 0.85 }, lines = {
    "walks the waterline, sandals in hand, letting the warm sand cradle each step.",
    "finds a smooth, sun-hot stone in the shallows and lifts it reverently.",
    "watches the waves retreat. \"The sea breathes slowly, like Xal'Reth.\"",
    "buries {target}'s feet in warm sand. \"Stay. Bask. Become one with the beach.\"",
  } },
  { name = "Hearth", adj = "Hearthbound", place = "beside the guild hall's great hearth", condition = "while the hearth fire crackles", color = { 1.0, 0.62, 0.3 }, lines = {
    "pulls the best chair nearer to the hearth and claims it without shame.",
    "toasts bread on a long fork over the fire and hands a slice to {target}.",
    "says, \"Home is wherever the stones are warm and the guildmates are kind.\"",
    "tucks their feet under them and sighs. \"This is the good part of the night.\"",
  } },
  { name = "Shadow", adj = "Shadow-Veiled", place = "in the deep shadows of the crypt", condition = "where no sunlight reaches", color = { 0.6, 0.3, 0.9 }, lines = {
    "steps into the darkness and seems to vanish, leaving only two faint, gleaming eyes.",
    "whispers, \"In the dark, the faithful wait. We are very good at waiting.\"",
    "speaks from the shadows behind {target}. They jump. \"Sorry. Habit.\"",
    "draws violet light from the darkness and shapes it into a slowly turning coil.",
  } },
  { name = "Gold", adj = "Gilded", place = "in the guild vault among the coffers", condition = "as candlelight glints on gold", color = { 1.0, 0.85, 0.3 }, lines = {
    "runs their fingers through a chest of coins. \"Warm. Gold is always warm.\"",
    "polishes a single gold coin until it shines like a small sun.",
    "consults the ledger with great seriousness. \"Flasks: low. Morale: high.\"",
    "presses a gold coin into {target}'s palm. \"For repairs. Spend it wisely.\"",
  } },
  { name = "Bone", adj = "Bone-Carved", place = "in an ancient ossuary", condition = "among the bones of old cultists", color = { 0.95, 0.92, 0.8 }, lines = {
    "bows to a row of old skulls. \"Founders. Veterans. One guy who stood in fire a lot.\"",
    "rattles a string of small bones like a wind chime.",
    "whispers to the bones, \"You bask in a different way now. We remember you.\"",
    "taps a carved bone flute and plays three hollow notes.",
  } },
  { name = "Silk", adj = "Silk-Woven", place = "in a tent of violet silk", condition = "as silk banners ripple softly", color = { 0.9, 0.55, 1.0 }, lines = {
    "drapes a length of violet silk across the altar in a perfect spiral.",
    "wraps silk around {target}'s wrist. \"So the Coil remembers you.\"",
    "lets the silk banners brush across their face, eyes closed.",
    "knots a silk cord seven times, whispering a name with each knot.",
  } },
  { name = "Smoke", adj = "Smoke-Wreathed", place = "in a hall thick with incense", condition = "as incense smoke curls upward", color = { 0.7, 0.65, 0.8 }, lines = {
    "waves the incense smoke into a slow coil with a feather fan.",
    "reads shapes in the smoke. \"A tail. A crown. A cricket. Lunch, perhaps.\"",
    "blows a perfect smoke ring at {target}. It drifts and fades.",
    "coughs once, discreetly. \"The smoke is very holy. And very thick.\"",
  } },
  { name = "Crystal", adj = "Crystal-Lit", place = "in a cavern of violet crystals", condition = "as the crystals hum", color = { 0.75, 0.5, 1.0 }, lines = {
    "taps a tall crystal. It rings with a pure, sweet note.",
    "holds a shard up to the candle. Violet light dances across the walls.",
    "places a small crystal in {target}'s hand. \"It is warm. It should not be warm. It is.\"",
    "hums in harmony with the crystals until the whole cavern sings.",
  } },
  { name = "Thunder", adj = "Thunder-Struck", place = "beneath a sky split by lightning", condition = "as lightning cracks the sky", color = { 0.95, 0.95, 0.5 }, lines = {
    "raises the staff high just as lightning flashes. \"I did that. Probably.\"",
    "feels the static lift their hair. \"Xal'Reth is very awake tonight.\"",
    "stomps in time with the rolling thunder.",
    "grabs {target}'s arm at a sudden crack of thunder. \"That was not fear. That was devotion.\"",
  } },
  { name = "Mist", adj = "Mist-Shrouded", place = "in a valley thick with mist", condition = "as mist rolls over the ground", color = { 0.75, 0.85, 0.85 }, lines = {
    "walks slowly into the mist until only their outline remains.",
    "calls from somewhere in the fog, \"Follow the sound of my hissing.\"",
    "draws a spiral in the damp air. The mist curls to follow their finger.",
    "loses track of {target} in the fog, then finds {target} by smell. \"Onions. Yes. There you are.\"",
  } },
  { name = "Starlight", adj = "Star-Crowned", place = "under a sky full of stars", condition = "as the stars wheel overhead", color = { 0.55, 0.7, 1.0 }, lines = {
    "lies back on the warm stones and names the constellations: \"The Great Iguana. The Heat Lamp. The Cricket.\"",
    "points out a shooting star. \"Wish for a mount, quickly!\"",
    "whispers, \"Every star is a sun. Every sun is a basking stone for someone.\"",
    "traces a coil among the stars with one finger for {target} to follow.",
  } },
}
