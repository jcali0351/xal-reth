-- The Litany of Begging
-- Performs the 10,000-line Litany of Begging as /emotes, one line at a time.
-- Start anywhere, perform a single line, jump by Title, search, and use your
-- target's name as the Notional Asker.

local ADDON = ...
local L = LitanyOfBegging_Lines or {}
local T = LitanyOfBegging_Titles or {}
local TOTAL = #L
local MAX_LEN = 255
local FALLBACK = "the Notional Asker"

local P = { state = nil, timer = nil }   -- state: nil | "running" | "paused" | "waiting"
LitanyOfBegging = P

local defaults = { pos = 1, interval = 12, stopAtTitle = false, useTarget = true, pauseInCombat = true, point = nil }

local function msg(text)
  DEFAULT_CHAT_FRAME:AddMessage("|cffb98cffLitany of Begging:|r " .. text)
end

---------------------------------------------------------------------------
-- Lookups
---------------------------------------------------------------------------
local function titleIndexFor(n)
  local lo, hi = 1, #T
  while lo < hi do
    local mid = math.floor((lo + hi + 1) / 2)
    if T[mid].start <= n then lo = mid else hi = mid - 1 end
  end
  return lo
end

local function titleFor(n) return T[titleIndexFor(n)] end

local function titleEnd(idx)
  if T[idx + 1] then return T[idx + 1].start - 1 end
  return TOTAL
end

local function findTitle(b, t)
  for i, ti in ipairs(T) do
    if ti.book == b and ti.title == t then return i end
  end
end

---------------------------------------------------------------------------
-- Rendering
---------------------------------------------------------------------------
local function targetName()
  if not P.db.useTarget then return nil end
  if not UnitExists("target") then return nil end
  local name = UnitName("target")
  if name and issecretvalue and issecretvalue(name) then return nil end
  if UnitIsUnit and UnitIsUnit("target", "player") then return nil end
  return name
end

function P:Render(n)
  local line = L[n]
  if not line then return nil end
  local text = line:gsub("{target}", targetName() or FALLBACK)
  text = text:gsub("|", "")
  if #text > MAX_LEN then
    local cut = text:sub(1, MAX_LEN - 3)
    text = (cut:match("^(.*)%s") or cut) .. "..."
  end
  return text
end

---------------------------------------------------------------------------
-- Sending
---------------------------------------------------------------------------
function P:CanEmote()
  if C_ChatInfo and C_ChatInfo.InChatMessagingLockdown and C_ChatInfo.InChatMessagingLockdown() then
    return false, "encounter chat lockdown"
  end
  if self.db.pauseInCombat and InCombatLockdown() then return false, "combat" end
  return true
end

local function send(text)
  if C_ChatInfo and C_ChatInfo.SendChatMessage then
    C_ChatInfo.SendChatMessage(text, "EMOTE")
  else
    SendChatMessage(text, "EMOTE")
  end
end

-- Perform one line right now (does not change the running state).
function P:PerformLine(n)
  n = tonumber(n)
  if not n or n < 1 or n > TOTAL then msg("There is no line " .. tostring(n) .. ". The Litany has " .. TOTAL .. " lines.") return false end
  local ok, why = self:CanEmote()
  if not ok then msg("Cannot emote right now (" .. why .. "). The Coil is patient.") return false end
  send(self:Render(n))
  return true
end

---------------------------------------------------------------------------
-- Player
---------------------------------------------------------------------------
function P:CancelTimer()
  if self.timer then self.timer:Cancel(); self.timer = nil end
end

function P:Arm(delay)
  self:CancelTimer()
  self.timer = C_Timer.NewTimer(delay, function() self.timer = nil; self:Step() end)
end

function P:SetPos(n)
  n = math.max(1, math.min(TOTAL, math.floor(tonumber(n) or 1)))
  self.db.pos = n
  self:Refresh()
end

function P:Step()
  if self.state ~= "running" and self.state ~= "waiting" then return end
  local ok = self:CanEmote()
  if not ok then
    self.state = "waiting"; self:Refresh()
    self:Arm(2)
    return
  end
  self.state = "running"
  local n = self.db.pos
  send(self:Render(n))
  local idx = titleIndexFor(n)
  if n >= TOTAL then
    self:Stop(); msg("The Litany is complete. All 10,000 lines. Glory to Xal'Reth. Please rest.")
    self.db.pos = 1; self:Refresh()
    return
  end
  if self.db.stopAtTitle and n == titleEnd(idx) then
    self.db.pos = n + 1
    self:Stop(); msg("Title " .. T[idx].book .. "." .. T[idx].title .. " concluded. Stopping, as instructed.")
    return
  end
  self.db.pos = n + 1
  self:Refresh()
  self:Arm(self.db.interval)
end

function P:Play(from)
  if from then self:SetPos(from) end
  self.state = "running"
  self:Refresh()
  self:Step()
end

function P:Pause()
  if self.state == "running" or self.state == "waiting" then
    self:CancelTimer(); self.state = "paused"; self:Refresh()
  end
end

function P:Resume()
  if self.state == "paused" then self.state = "running"; self:Refresh(); self:Arm(1) end
end

function P:Toggle()
  if self.state == "running" or self.state == "waiting" then self:Pause()
  elseif self.state == "paused" then self:Resume()
  else self:Play() end
end

function P:Stop()
  self:CancelTimer(); self.state = nil; self:Refresh()
end

function P:Next() self:SetPos(self.db.pos + 1) end
function P:Prev() self:SetPos(self.db.pos - 1) end

function P:NextTitle()
  local i = titleIndexFor(self.db.pos)
  if T[i + 1] then self:SetPos(T[i + 1].start) end
end

function P:PrevTitle()
  local i = titleIndexFor(self.db.pos)
  if self.db.pos > T[i].start then self:SetPos(T[i].start)
  elseif T[i - 1] then self:SetPos(T[i - 1].start) end
end

function P:Search(words)
  words = (words or ""):lower()
  if words == "" then msg("Usage: /litany search <words>") return end
  local found = 0
  for n = 1, TOTAL do
    if L[n]:lower():find(words, 1, true) then
      found = found + 1
      if found <= 10 then msg("|cffe0c4ff" .. n .. "|r " .. L[n]:sub(1, 90) .. "...") end
    end
  end
  if found == 0 then msg("No lines contain \"" .. words .. "\".")
  elseif found > 10 then msg(found .. " lines match. Showing the first 10. Use /litany goto <line>.") end
end

---------------------------------------------------------------------------
-- Panel
---------------------------------------------------------------------------
local F

local function button(parent, text, w, onClick)
  local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
  b:SetSize(w, 24); b:SetText(text); b:SetScript("OnClick", onClick)
  return b
end

function P:BuildPanel()
  if F then return end
  F = CreateFrame("Frame", "LitanyOfBeggingFrame", UIParent, "BackdropTemplate")
  F:SetSize(460, 330)
  F:SetFrameStrata("MEDIUM")
  F:SetMovable(true); F:EnableMouse(true); F:RegisterForDrag("LeftButton"); F:SetClampedToScreen(true)
  F:SetScript("OnDragStart", F.StartMoving)
  F:SetScript("OnDragStop", function(s)
    s:StopMovingOrSizing()
    local p, _, rp, x, y = s:GetPoint(); P.db.point = { p, rp, x, y }
  end)
  F:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 14,
    insets = { left = 3, right = 3, top = 3, bottom = 3 } })
  F:SetBackdropColor(0.05, 0.03, 0.09, 0.95)
  F:SetBackdropBorderColor(0.6, 0.4, 1, 1)
  if P.db.point then F:SetPoint(P.db.point[1], UIParent, P.db.point[2], P.db.point[3], P.db.point[4]) else F:SetPoint("CENTER") end
  tinsert(UISpecialFrames, "LitanyOfBeggingFrame")

  local close = CreateFrame("Button", nil, F, "UIPanelCloseButton")
  close:SetPoint("TOPRIGHT", -2, -2)

  local title = F:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
  title:SetPoint("TOP", 0, -12); title:SetText("|cffc9a2ffThe Litany of Begging|r")

  F.where = F:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  F.where:SetPoint("TOPLEFT", 16, -38); F.where:SetPoint("TOPRIGHT", -16, -38); F.where:SetJustifyH("LEFT")

  F.count = F:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  F.count:SetPoint("TOPLEFT", 16, -56)

  F.status = F:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
  F.status:SetPoint("TOPRIGHT", -16, -58)

  local box = CreateFrame("Frame", nil, F, "BackdropTemplate")
  box:SetPoint("TOPLEFT", 14, -76); box:SetPoint("TOPRIGHT", -14, -76); box:SetHeight(96)
  box:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 })
  box:SetBackdropColor(0, 0, 0, 0.45); box:SetBackdropBorderColor(0.45, 0.3, 0.75, 0.8)
  F.text = box:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
  F.text:SetPoint("TOPLEFT", 8, -8); F.text:SetPoint("BOTTOMRIGHT", -8, 8)
  F.text:SetJustifyH("LEFT"); F.text:SetJustifyV("TOP"); F.text:SetWordWrap(true)

  local row1 = -182
  local b1 = button(F, "<< Title", 70, function() P:PrevTitle() end); b1:SetPoint("TOPLEFT", 14, row1)
  local b2 = button(F, "< Line", 64, function() P:Prev() end); b2:SetPoint("LEFT", b1, "RIGHT", 4, 0)
  F.play = button(F, "Play", 70, function() P:Toggle() end); F.play:SetPoint("LEFT", b2, "RIGHT", 4, 0)
  local b4 = button(F, "Stop", 56, function() P:Stop() end); b4:SetPoint("LEFT", F.play, "RIGHT", 4, 0)
  local b5 = button(F, "Line >", 64, function() P:Next() end); b5:SetPoint("LEFT", b4, "RIGHT", 4, 0)
  local b6 = button(F, "Title >>", 70, function() P:NextTitle() end); b6:SetPoint("LEFT", b5, "RIGHT", 4, 0)

  local row2 = -214
  local once = button(F, "Perform This Line Only", 170, function() P:PerformLine(P.db.pos) end)
  once:SetPoint("TOPLEFT", 14, row2)

  local lbl = F:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
  lbl:SetPoint("LEFT", once, "RIGHT", 14, 0); lbl:SetText("Go to line")
  F.jump = CreateFrame("EditBox", nil, F, "InputBoxTemplate")
  F.jump:SetSize(64, 20); F.jump:SetPoint("LEFT", lbl, "RIGHT", 10, 0); F.jump:SetAutoFocus(false); F.jump:SetNumeric(true)
  F.jump:SetMaxLetters(5)
  F.jump:SetScript("OnEnterPressed", function(s) P:SetPos(s:GetNumber()); s:ClearFocus() end)
  local go = button(F, "Go", 40, function() P:SetPos(F.jump:GetNumber()); F.jump:ClearFocus() end)
  go:SetPoint("LEFT", F.jump, "RIGHT", 6, 0)

  local s = CreateFrame("Slider", nil, F, "OptionsSliderTemplate")
  s:SetPoint("TOPLEFT", 20, -258); s:SetWidth(200); s:SetMinMaxValues(3, 60); s:SetValueStep(1); s:SetObeyStepOnDrag(true)
  s:SetValue(P.db.interval)
  if s.Low then s.Low:SetText("3s") end
  if s.High then s.High:SetText("60s") end
  F.sliderText = s.Text
  s:SetScript("OnValueChanged", function(_, v)
    P.db.interval = math.floor(v + 0.5)
    if F.sliderText then F.sliderText:SetText("Seconds between lines: " .. P.db.interval) end
  end)
  if F.sliderText then F.sliderText:SetText("Seconds between lines: " .. P.db.interval) end

  local function check(label, key, x, y)
    local c = CreateFrame("CheckButton", nil, F, "UICheckButtonTemplate")
    c:SetSize(24, 24); c:SetPoint("TOPLEFT", x, y); c:SetChecked(P.db[key])
    local t = c:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); t:SetPoint("LEFT", c, "RIGHT", 2, 0); t:SetText(label)
    c:SetScript("OnClick", function(self) P.db[key] = self:GetChecked() and true or false; P:Refresh() end)
    return c
  end
  check("Stop at end of Title", "stopAtTitle", 250, -246)
  check("Use my target as Notional Asker", "useTarget", 250, -270)
  check("Pause in combat", "pauseInCombat", 250, -294)

  local foot = F:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  foot:SetPoint("BOTTOMLEFT", 16, 12); foot:SetText("/litany help  ·  Glory to Xal'Reth")

  F:Hide()
end

function P:Refresh()
  if not F or not F:IsShown() then return end
  local n = self.db.pos
  local ti = titleFor(n)
  F.where:SetText(ti and ("Book " .. ti.name) or "")
  F.count:SetText(string.format("Line |cffe0c4ff%d|r of %d", n, TOTAL))
  local st = self.state == "running" and "|cff9be15dPerforming|r" or self.state == "paused" and "|cffe8d44dPaused|r"
    or self.state == "waiting" and "|cffff8080Waiting (combat or lockdown)|r" or "|cffaaaaaaIdle|r"
  F.status:SetText(st)
  local name = UnitName("player") or "You"
  F.text:SetText("|cffb98cff" .. name .. "|r " .. (self:Render(n) or ""))
  F.play:SetText((self.state == "running" or self.state == "waiting") and "Pause" or (self.state == "paused" and "Resume" or "Play"))
end

function P:TogglePanel()
  self:BuildPanel()
  if F:IsShown() then F:Hide() else F:Show(); self:Refresh() end
end

---------------------------------------------------------------------------
-- Slash commands
---------------------------------------------------------------------------
local HELP = {
  "/litany  - show or hide the panel",
  "/litany play [line]  - perform from the current line (or from [line])",
  "/litany pause | resume | stop",
  "/litany next | prev  - move one line",
  "/litany goto <line>  - set the current line (1 to 10000)",
  "/litany line <line>  - perform just that one line now",
  "/litany title <book>.<title>  - jump to a Title, e.g. /litany title 14.3",
  "/litany interval <seconds>  - 3 to 60",
  "/litany search <words>  - find lines",
  "/litany random  - perform one random line",
  "/litany where  - show your place in the Litany",
}

SLASH_LITANYOFBEGGING1 = "/litany"
SLASH_LITANYOFBEGGING2 = "/lob"
SlashCmdList.LITANYOFBEGGING = function(input)
  local cmd, rest = (input or ""):match("^%s*(%S*)%s*(.-)%s*$")
  cmd = (cmd or ""):lower()
  if cmd == "" then P:TogglePanel()
  elseif cmd == "help" then for _, h in ipairs(HELP) do msg(h) end
  elseif cmd == "play" or cmd == "start" then P:Play(tonumber(rest))
  elseif cmd == "pause" then P:Pause()
  elseif cmd == "resume" then P:Resume()
  elseif cmd == "stop" then P:Stop()
  elseif cmd == "next" then P:Next(); msg("Line " .. P.db.pos)
  elseif cmd == "prev" then P:Prev(); msg("Line " .. P.db.pos)
  elseif cmd == "goto" then P:SetPos(rest); msg("Line " .. P.db.pos .. " of " .. TOTAL .. ".")
  elseif cmd == "line" then P:PerformLine(rest)
  elseif cmd == "title" then
    local b, t = rest:match("^(%d+)%.(%d+)$")
    local i = b and findTitle(tonumber(b), tonumber(t))
    if i then P:SetPos(T[i].start); msg("Title " .. T[i].name .. " begins at line " .. T[i].start .. ".")
    else msg("Usage: /litany title <book>.<title>, books 1-20, titles 1-10.") end
  elseif cmd == "interval" then
    local v = tonumber(rest)
    if v then P.db.interval = math.max(3, math.min(60, math.floor(v))); msg("Interval set to " .. P.db.interval .. " seconds.") end
  elseif cmd == "search" then P:Search(rest)
  elseif cmd == "random" then P:PerformLine(math.random(1, TOTAL))
  elseif cmd == "where" then
    local ti = titleFor(P.db.pos); msg("Line " .. P.db.pos .. " of " .. TOTAL .. ", in " .. (ti and ti.name or "?") .. ".")
  else msg("Unknown command. Type /litany help.") end
end

function LitanyOfBegging_OnAddonCompartmentClick() P:TogglePanel() end

---------------------------------------------------------------------------
-- Events
---------------------------------------------------------------------------
local ev = CreateFrame("Frame")
ev:RegisterEvent("ADDON_LOADED")
ev:RegisterEvent("PLAYER_TARGET_CHANGED")
ev:SetScript("OnEvent", function(_, event, arg1)
  if event == "ADDON_LOADED" and arg1 == ADDON then
    LitanyOfBeggingDB = LitanyOfBeggingDB or {}
    for k, v in pairs(defaults) do if LitanyOfBeggingDB[k] == nil then LitanyOfBeggingDB[k] = v end end
    P.db = LitanyOfBeggingDB
    if P.db.pos < 1 or P.db.pos > TOTAL then P.db.pos = 1 end
    msg("Loaded " .. TOTAL .. " lines. Type /litany to begin. We are sorry in advance.")
  elseif event == "PLAYER_TARGET_CHANGED" and P.db then
    P:Refresh()
  end
end)
