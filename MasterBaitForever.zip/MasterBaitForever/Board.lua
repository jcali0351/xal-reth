-- Master Bait Forever: the leaderboard network.
-- Every copy joins a hidden chat channel that carries only addon messages, says hello, and shares
-- three numbers: all-time catches, this week's catches and its most valuable catch. Anyone your game
-- can reach on that channel (your realm and its connected realms) shows up on the board.
local MBP = MasterBaitForever
local S = MBP.S
local UI = MBP.UI
local C = UI.C
local Text, Grad, Border, SetBorderColor = UI.Text, UI.Grad, UI.Border, UI.SetBorderColor

local PREFIX = "MBFOREVER"
local NETCHAN = "MasterBaitForeverNet"
local ONLINE = 150            -- seconds since last word before someone counts as offline
local HEARTBEAT = 60          -- seconds between hellos
local KEEP_DAYS = 30          -- forget anglers not seen for this long

local lastSend, lastReply, joined = 0, 0, false

-- Who am I ---------------------------------------------------------------------------------
local myRealm
local function Realm()
	if not myRealm or myRealm == "" then
		myRealm = (GetNormalizedRealmName and GetNormalizedRealmName()) or ""
		if myRealm == "" then myRealm = (GetRealmName and GetRealmName() or ""):gsub("[%s%-]", "") end
	end
	return myRealm
end

local function Full(name)
	if not name or name == "" then return nil end
	if name:find("-", 1, true) then return name end
	local r = Realm()
	return r ~= "" and (name .. "-" .. r) or name
end

local function Me() return Full(UnitName("player")) or "?" end

-- Network ----------------------------------------------------------------------------------
local function ChannelId()
	local id = GetChannelName(NETCHAN)
	if type(id) == "number" and id > 0 then return id end
end

local function HideChannel()
	for i = 1, (NUM_CHAT_WINDOWS or 10) do
		local cf = _G["ChatFrame" .. i]
		if cf then
			if ChatFrame_RemoveChannel then pcall(ChatFrame_RemoveChannel, cf, NETCHAN)
			elseif ChatFrameUtil and ChatFrameUtil.RemoveChannel then pcall(ChatFrameUtil.RemoveChannel, cf, NETCHAN) end
		end
	end
end

local function Send(text)
	if InCombatLockdown() then return false end
	local sent = false
	local id = ChannelId()
	if id then sent = pcall(C_ChatInfo.SendAddonMessage, PREFIX, text, "CHANNEL", id) or sent end
	if IsInGuild() then sent = pcall(C_ChatInfo.SendAddonMessage, PREFIX, text, "GUILD") or sent end
	return sent
end

local function Clamp(n, max) n = tonumber(n) or 0; if n < 0 then return 0 end; if n > max then return max end; return math.floor(n) end

local function MyLine()
	local db = MBP.db
	local best = MBP.ItemID(db.records.bestLink) or 0
	return string.format("S:1:%d:%d:%d:%d:%d:%d:%s", db.totals.catches, db.week.id, db.week.catches,
		best, math.floor(db.records.bestValue or 0), S.active and 1 or 0, MBP.VERSION)
end

-- force: send now (session start/stop). Otherwise a catch sends at most every 20 seconds.
function MBP.Announce(force)
	local db = MBP.db
	if not db or not db.network then return end
	if not force and GetTime() - lastSend < 20 then return end
	if Send(MyLine()) then lastSend = GetTime() end
end

local function Request() if MBP.db.network then Send("R:1") end end

local function Join()
	local db = MBP.db
	if not db.network then return end
	if not ChannelId() then pcall(JoinTemporaryChannel, NETCHAN) end
	HideChannel()
	C_Timer.After(3, function()
		HideChannel()
		joined = ChannelId() ~= nil
		if joined then MBP.Announce(true); C_Timer.After(1, Request) end
		if MBP.Refresh then MBP.Refresh() end
		if MBP.RefreshBoard then MBP.RefreshBoard() end
	end)
end

local function Leave()
	if ChannelId() then pcall(LeaveChannelByName, NETCHAN) end
	joined = false
end

function MBP.SetNetwork(on)
	if on then Join() else Leave() end
	if MBP.Refresh then MBP.Refresh() end
	if MBP.RefreshBoard then MBP.RefreshBoard() end
end

local function OnMessage(prefix, msg, channel, sender)
	if prefix ~= PREFIX or type(msg) ~= "string" then return end
	local db = MBP.db
	if not db or not db.network then return end
	sender = Full(sender)
	if not sender or sender == Me() then return end
	if msg:sub(1, 2) == "R:" then
		-- someone new arrived: answer once, after a short random wait so everyone doesn't shout at once
		if GetTime() - lastReply > 15 then
			lastReply = GetTime()
			C_Timer.After(1 + math.random() * 6, function()
				if GetTime() - lastSend > 10 then MBP.Announce(true) end
			end)
		end
		return
	end
	local c, wid, w, b, bv, f, ver = msg:match("^S:1:(%d+):(%d+):(%d+):(%d+):(%d+):(%d):?([%w%.]*)")
	if not c then return end
	local isNew = db.board[sender] == nil
	db.board[sender] = {
		c = Clamp(c, 1e8), wid = Clamp(wid, 1e7), w = Clamp(w, 1e7), b = Clamp(b, 1e8),
		bv = Clamp(bv, 1e12), f = f == "1", v = ver, seen = time(),
	}
	if isNew and GetTime() - lastSend > 10 and GetTime() - lastReply > 15 then
		-- a stranger said hello: make sure they know about us too
		lastReply = GetTime()
		C_Timer.After(1 + math.random() * 4, function() MBP.Announce(true) end)
	end
	if MBP.RefreshBoard then MBP.RefreshBoard() end
end

-- Board data -------------------------------------------------------------------------------
function MBP.OnlineCount()
	local db, now, n = MBP.db, time(), 1
	for _, e in pairs(db.board) do if now - (e.seen or 0) <= ONLINE then n = n + 1 end end
	return n, joined
end

-- mode: "fish" (all-time catches), "best" (most valuable catch) or "week"
function MBP.BoardRows(mode, onlineOnly)
	local db, now, wid, me = MBP.db, time(), MBP.WeekId(), Me()
	local rows = {}
	local function add(full, e, isMe)
		local online = isMe or (now - (e.seen or 0) <= ONLINE)
		if onlineOnly and not online then return end
		local week = (e.wid == wid) and e.w or 0
		local score = mode == "best" and (e.bv or 0) or mode == "week" and week or (e.c or 0)
		if score <= 0 and not isMe then return end
		local name, realm = full:match("^([^%-]+)%-?(.*)$")
		rows[#rows + 1] = { full = full, name = name or full, realm = realm or "", c = e.c or 0, w = week, b = e.b or 0,
			bv = e.bv or 0, online = online, fishing = e.f and online, seen = e.seen, me = isMe, score = score }
	end
	add(me, {
		c = db.totals.catches, wid = db.week.id, w = db.week.catches, b = MBP.ItemID(db.records.bestLink) or 0,
		bv = db.records.bestValue or 0, f = S.active, seen = now,
	}, true)
	for full, e in pairs(db.board) do if full ~= me then add(full, e, false) end end
	table.sort(rows, function(a, b)
		if a.score ~= b.score then return a.score > b.score end
		if a.c ~= b.c then return a.c > b.c end
		return a.full < b.full
	end)
	for i, r in ipairs(rows) do r.rank = i end
	return rows
end

local function Ago(t)
	local s = time() - (t or 0)
	if s < ONLINE then return "online now" end
	if s < 3600 then return math.floor(s / 60) .. " min ago" end
	if s < 86400 then return math.floor(s / 3600) .. " h ago" end
	return math.floor(s / 86400) .. " d ago"
end

-- The window --------------------------------------------------------------------------------
local board, rows = nil, {}
local ROWS, ROW_H = 12, 26
local offset = 0
local MEDAL = { { 1.0, 0.82, 0.29 }, { 0.80, 0.85, 0.92 }, { 0.85, 0.55, 0.30 } }

local function FishTooltip(self)
	local r = self:GetParent().row
	if not r or r.b == 0 then return end
	GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
	pcall(GameTooltip.SetItemByID, GameTooltip, r.b)
	GameTooltip:AddLine(" ")
	GameTooltip:AddDoubleLine(r.me and "Your best catch" or (r.name .. "'s best catch"), MBP.Coins(r.bv), 0.55, 0.68, 0.78, 1, 1, 1)
	local unit, src = MBP.Price(r.b)
	if unit > 0 then GameTooltip:AddDoubleLine("Auction price today", MBP.Coins(unit), 0.55, 0.68, 0.78, 1, 1, 1) end
	GameTooltip:Show()
end

local function RowTooltip(self)
	local r = self.row
	if not r then return end
	GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
	GameTooltip:AddLine(r.name .. (r.realm ~= "" and ("|cff6f8597-" .. r.realm .. "|r") or ""), 1, 0.82, 0.29)
	GameTooltip:AddDoubleLine("Fish caught", BreakUpLargeNumbers(r.c), 0.55, 0.68, 0.78, 1, 1, 1)
	GameTooltip:AddDoubleLine("This week", BreakUpLargeNumbers(r.w), 0.55, 0.68, 0.78, 1, 1, 1)
	if r.b > 0 then
		local name = (C_Item and C_Item.GetItemNameByID and C_Item.GetItemNameByID(r.b)) or ("item " .. r.b)
		GameTooltip:AddDoubleLine("Most valuable catch", name, 0.55, 0.68, 0.78, 1, 1, 1)
		GameTooltip:AddDoubleLine(" ", MBP.Coins(r.bv), 0.55, 0.68, 0.78, 1, 1, 1)
	end
	GameTooltip:AddLine(r.me and "That's you." or (r.fishing and "Fishing right now" or Ago(r.seen)),
		r.fishing and 0.31 or 0.55, r.fishing and 0.85 or 0.62, r.fishing and 1 or 0.70)
	GameTooltip:Show()
end

local function MakeRow(parent, i)
	local W = parent:GetWidth() - 24
	local f = CreateFrame("Button", nil, parent)
	f:SetSize(W, ROW_H - 2)
	f:SetPoint("TOPLEFT", 12, -112 - (i - 1) * ROW_H)
	f.bg = f:CreateTexture(nil, "BACKGROUND")
	f.bg:SetAllPoints()
	f.bg:SetColorTexture(1, 1, 1, i % 2 == 0 and 0.03 or 0)
	f.hl = f:CreateTexture(nil, "BACKGROUND", nil, 1)
	f.hl:SetAllPoints()
	f.hl:SetColorTexture(0.31, 0.85, 1, 0.08)
	f.hl:Hide()
	f.mine = f:CreateTexture(nil, "BACKGROUND", nil, 2)
	f.mine:SetAllPoints()
	Grad(f.mine, "HORIZONTAL", C.gold, C.gold, 0.16, 0.02)
	f.medal = f:CreateTexture(nil, "ARTWORK")
	f.medal:SetSize(20, 20)
	f.medal:SetPoint("LEFT", 4, 0)
	f.medal:SetTexture(UI.WHITE)
	if f.CreateMaskTexture then
		local m = f:CreateMaskTexture()
		m:SetAllPoints(f.medal)
		m:SetTexture("Interface\\CharacterFrame\\TempPortraitAlphaMask", "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
		f.medal:AddMaskTexture(m)
	end
	f.rank = Text(f, 10, C.text, UI.HEAD_FONT)
	f.rank:SetPoint("CENTER", f.medal, "CENTER", 0, 0)
	f.rank:SetJustifyH("CENTER")
	f.dot = f:CreateTexture(nil, "ARTWORK")
	f.dot:SetSize(6, 6)
	f.dot:SetPoint("LEFT", 32, 0)
	f.dot:SetTexture(UI.WHITE)
	f.name = Text(f, 11, C.text, UI.HEAD_FONT)
	f.name:SetPoint("LEFT", 44, 0)
	f.name:SetWidth(130)
	f.count = Text(f, 11, { 1, 1, 1 }, UI.HEAD_FONT)
	f.count:SetPoint("RIGHT", -112, 0)
	f.count:SetJustifyH("RIGHT")
	f.fish = CreateFrame("Button", nil, f)
	f.fish:SetSize(20, 20)
	f.fish:SetPoint("RIGHT", -82, 0)
	f.fish.icon = f.fish:CreateTexture(nil, "ARTWORK")
	f.fish.icon:SetAllPoints()
	f.fish.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
	Border(f.fish, C.line, 1)
	f.fish:SetScript("OnEnter", FishTooltip)
	f.fish:SetScript("OnLeave", GameTooltip_Hide)
	f.value = Text(f, 10, C.gold, UI.HEAD_FONT)
	f.value:SetPoint("LEFT", f.fish, "RIGHT", 6, 0)
	f.value:SetWidth(70)
	f.pop = f:CreateAnimationGroup()
	UI.AlphaAnim(f.pop, 0, 1, 0.25, 1)
	UI.MoveAnim(f.pop, 12, 0, 0, 1)
	UI.MoveAnim(f.pop, -12, 0, 0.25, 2, "OUT")
	f:SetScript("OnEnter", function(self) self.hl:Show(); RowTooltip(self) end)
	f:SetScript("OnLeave", function(self) self.hl:Hide(); GameTooltip:Hide() end)
	return f
end

local function FillRow(f, r, mode)
	f.row = r
	if not r then f:Hide(); return end
	f:Show()
	local m = MEDAL[r.rank]
	if m then f.medal:SetVertexColor(m[1], m[2], m[3], 1); f.rank:SetTextColor(0.1, 0.07, 0.02)
	else f.medal:SetVertexColor(1, 1, 1, 0.06); f.rank:SetTextColor(C.muted[1], C.muted[2], C.muted[3]) end
	f.rank:SetText(r.rank)
	if r.fishing then f.dot:SetVertexColor(C.aqua[1], C.aqua[2], C.aqua[3], 1)
	elseif r.online then f.dot:SetVertexColor(C.green[1], C.green[2], C.green[3], 1)
	else f.dot:SetVertexColor(0.35, 0.40, 0.45, 1) end
	f.name:SetText(r.name .. (r.me and " |cffffd24a(you)|r" or ""))
	if r.online then f.name:SetTextColor(C.text[1], C.text[2], C.text[3]) else f.name:SetTextColor(0.6, 0.66, 0.72) end
	f.mine:SetShown(r.me)
	f.count:SetText(BreakUpLargeNumbers(mode == "week" and r.w or r.c))
	if mode == "best" then f.count:SetTextColor(C.muted[1], C.muted[2], C.muted[3]) else f.count:SetTextColor(1, 1, 1) end
	if r.b > 0 then
		f.fish:Show()
		f.fish.icon:SetTexture(MBP.ItemIcon(r.b) or "Interface\\Icons\\INV_Misc_Fish_02")
		local quality = C_Item and C_Item.GetItemQualityByID and C_Item.GetItemQualityByID(r.b)
		local qr, qg, qb = UI.QualityColor(quality or 1)
		SetBorderColor(f.fish, qr, qg, qb, 1)
		f.value:SetText(MBP.ShortGold(r.bv))
		f.value:SetTextColor(UI.TierColor(r.bv))
	else
		f.fish:Hide()
		f.value:SetText("")
	end
end

local function Tab(parent, label, key)
	local b = CreateFrame("Button", nil, parent)
	b:SetSize(82, 22)
	b.text = Text(b, 10, C.muted, UI.HEAD_FONT)
	b.text:SetPoint("CENTER")
	b.text:SetText(label)
	b.under = b:CreateTexture(nil, "ARTWORK")
	b.under:SetPoint("BOTTOMLEFT", 8, 0)
	b.under:SetPoint("BOTTOMRIGHT", -8, 0)
	b.under:SetHeight(2)
	b.under:SetColorTexture(C.aqua[1], C.aqua[2], C.aqua[3], 1)
	b.key = key
	b:SetScript("OnClick", function()
		MBP.db.boardMode = key
		offset = 0
		MBP.RefreshBoard(true)
	end)
	return b
end

local function Build()
	local W, H = 400, 112 + ROWS * ROW_H + 58
	board = CreateFrame("Frame", "MasterBaitForeverBoard", UIParent)
	board:SetSize(W, H)
	board:SetPoint("CENTER", -120, 40)
	board:SetFrameStrata("HIGH")
	board:SetClampedToScreen(true)
	board:EnableMouse(true)
	board:SetMovable(true)
	board:RegisterForDrag("LeftButton")
	board:SetScript("OnDragStart", board.StartMoving)
	board:SetScript("OnDragStop", board.StopMovingOrSizing)
	tinsert(UISpecialFrames, "MasterBaitForeverBoard")

	local shadow = board:CreateTexture(nil, "BACKGROUND", nil, -8)
	shadow:SetPoint("TOPLEFT", -8, 8)
	shadow:SetPoint("BOTTOMRIGHT", 8, -8)
	shadow:SetColorTexture(0, 0, 0, 0.45)
	local body = board:CreateTexture(nil, "BACKGROUND", nil, -6)
	body:SetAllPoints()
	Grad(body, "VERTICAL", C.panelBot, C.panelTop, 0.97, 0.97)
	Border(board, C.line, 0.9)
	local rule = board:CreateTexture(nil, "ARTWORK")
	rule:SetPoint("TOPLEFT", 1, -1)
	rule:SetPoint("TOPRIGHT", -1, -1)
	rule:SetHeight(2)
	Grad(rule, "HORIZONTAL", C.goldDeep, C.gold, 1, 1)

	local trophy = board:CreateTexture(nil, "ARTWORK")
	trophy:SetSize(30, 30)
	trophy:SetPoint("TOPLEFT", 14, -12)
	trophy:SetTexture("Interface\\Icons\\INV_Misc_Fish_31")
	trophy:SetTexCoord(0.08, 0.92, 0.08, 0.92)
	local title = Text(board, 16, C.gold, UI.HEAD_FONT, "OUTLINE")
	title:SetPoint("TOPLEFT", trophy, "TOPRIGHT", 10, -1)
	title:SetText("Leaderboard")
	board.sub = Text(board, 10, C.muted)
	board.sub:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -3)
	board.sub:SetWidth(W - 90)

	local close = CreateFrame("Button", nil, board)
	close:SetSize(20, 20)
	close:SetPoint("TOPRIGHT", -8, -8)
	close.t = Text(close, 13, C.muted, UI.HEAD_FONT)
	close.t:SetPoint("CENTER")
	close.t:SetText("X")
	close:SetScript("OnEnter", function(self) self.t:SetTextColor(1, 1, 1) end)
	close:SetScript("OnLeave", function(self) self.t:SetTextColor(C.muted[1], C.muted[2], C.muted[3]) end)
	close:SetScript("OnClick", function() board:Hide() end)

	board.tabs = { Tab(board, "MOST FISH", "fish"), Tab(board, "BEST CATCH", "best"), Tab(board, "THIS WEEK", "week") }
	for i, t in ipairs(board.tabs) do t:SetPoint("TOPLEFT", 14 + (i - 1) * 84, -54) end

	local only = CreateFrame("CheckButton", nil, board, "UICheckButtonTemplate")
	only:SetSize(20, 20)
	only:SetPoint("TOPRIGHT", -70, -55)
	only.label = Text(board, 9, C.muted, UI.HEAD_FONT)
	only.label:SetPoint("LEFT", only, "RIGHT", 2, 0)
	only.label:SetText("ONLINE ONLY")
	only:SetScript("OnClick", function(self) MBP.db.boardOnline = self:GetChecked() and true or false; offset = 0; MBP.RefreshBoard(true) end)
	board.only = only

	local hdr = function(txt, point, x, justify)
		local fs = Text(board, 8, C.muted, UI.HEAD_FONT)
		fs:SetPoint(point, board, "TOP" .. point, x, -96)
		fs:SetJustifyH(justify or "LEFT")
		fs:SetText(txt)
		return fs
	end
	hdr("#", "LEFT", 22)
	hdr("ANGLER", "LEFT", 56)
	board.colCount = hdr("FISH", "RIGHT", -124, "RIGHT")
	hdr("BEST CATCH", "RIGHT", -40, "RIGHT")

	for i = 1, ROWS do rows[i] = MakeRow(board, i) end
	board.empty = Text(board, 11, C.muted)
	board.empty:SetPoint("TOP", 0, -150)
	board.empty:SetJustifyH("CENTER")
	board.empty:SetWidth(W - 40)
	if board.empty.SetWordWrap then board.empty:SetWordWrap(true) end

	board.you = Text(board, 11, C.text, UI.HEAD_FONT)
	board.you:SetPoint("BOTTOMLEFT", 16, 30)
	board.note = Text(board, 9, { 0.42, 0.52, 0.60 })
	board.note:SetPoint("BOTTOMLEFT", 16, 14)
	board.note:SetWidth(W - 32)
	board.note:SetText("Shows players on your realm and connected realms. Scroll to see more.")
	local ping = UI.Button(board, "Refresh", 70, false, function()
		Request(); MBP.Announce(true); MBP.RefreshBoard(true)
	end)
	ping:SetPoint("BOTTOMRIGHT", -12, 24)

	board:EnableMouseWheel(true)
	board:SetScript("OnMouseWheel", function(_, delta)
		offset = math.max(0, offset - delta * 3)
		MBP.RefreshBoard(true)
	end)

	board.open = board:CreateAnimationGroup()
	UI.ScaleAnim(board.open, 0.92, 1, 0.22, 1, "OUT")
	UI.AlphaAnim(board.open, 0, 1, 0.18, 1)
	board:SetScript("OnUpdate", function(self, el)
		self.t = (self.t or 0) + el
		if self.t > 5 then self.t = 0; MBP.RefreshBoard() end
	end)
	board:Hide()
end

local lastFirst = {}
function MBP.RefreshBoard(animate)
	if MBP.Refresh then MBP.Refresh() end
	if not board or not board:IsShown() then return end
	local db = MBP.db
	local mode = db.boardMode or "fish"
	for _, t in ipairs(board.tabs) do
		local on = t.key == mode
		t.under:SetShown(on)
		local c = on and C.aqua or C.muted
		t.text:SetTextColor(c[1], c[2], c[3])
	end
	board.only:SetChecked(db.boardOnline and true or false)
	board.colCount:SetText(mode == "week" and "THIS WEEK" or "FISH")

	local list = MBP.BoardRows(mode, db.boardOnline)
	offset = math.max(0, math.min(offset, #list - ROWS))
	local mine
	for _, r in ipairs(list) do if r.me then mine = r end end
	for i = 1, ROWS do
		local r = list[i + offset]
		local before = rows[i].row and rows[i].row.full
		FillRow(rows[i], r, mode)
		if r and (animate or before ~= r.full) then
			rows[i].pop:Stop()
			C_Timer.After((i - 1) * 0.025, function() rows[i].pop:Play() end)
		end
	end
	local n, connected = MBP.OnlineCount()
	local total = 0
	for _ in pairs(db.board) do total = total + 1 end
	if not db.network then
		board.sub:SetText("|cffff5c5cNetwork off.|r Type /mbf network on to compete.")
	elseif not connected then
		board.sub:SetText("Connecting to other anglers...")
	else
		board.sub:SetText(string.format("|cff5cff8c%d online|r  ·  %d angler%s seen", n, total + 1, total == 0 and "" or "s"))
	end
	board.empty:SetShown(#list <= 1 and connected)
	board.empty:SetText(#list <= 1 and "Nobody else here yet. Other Master Bait Forever anglers appear as soon as they log in or catch a fish." or "")
	if mine then
		local label = mode == "best" and "by best catch" or mode == "week" and "this week" or "by fish caught"
		board.you:SetText(string.format("You are |cffffd24a#%d|r of %d %s", mine.rank, #list, label))
	else
		board.you:SetText("")
	end
end

function MBP.ToggleBoard()
	if not board then Build() end
	if board:IsShown() then board:Hide(); return end
	board:Show()
	board.open:Stop(); board.open:Play()
	Request()
	MBP.RefreshBoard(true)
end

-- Startup -------------------------------------------------------------------------------------
local ev = CreateFrame("Frame")
ev:RegisterEvent("PLAYER_LOGIN")
ev:RegisterEvent("CHAT_MSG_ADDON")
ev:RegisterEvent("CHANNEL_UI_UPDATE")
ev:SetScript("OnEvent", function(_, e, ...)
	if e == "PLAYER_LOGIN" then
		pcall(C_ChatInfo.RegisterAddonMessagePrefix, PREFIX)
		local db = MBP.db
		if not db then return end
		db.boardMode = db.boardMode or "fish"
		local cutoff = time() - KEEP_DAYS * 86400
		for k, v in pairs(db.board) do if (v.seen or 0) < cutoff then db.board[k] = nil end end
		C_Timer.After(8, Join)
		C_Timer.NewTicker(HEARTBEAT, function()
			if not MBP.db.network then return end
			if not ChannelId() then Join(); return end
			joined = true
			if GetTime() - lastSend >= HEARTBEAT - 5 then MBP.Announce(true) end
			if MBP.Refresh then MBP.Refresh() end
		end)
	elseif e == "CHAT_MSG_ADDON" then
		OnMessage(...)
	elseif e == "CHANNEL_UI_UPDATE" then
		if MBP.db and MBP.db.network then HideChannel(); joined = ChannelId() ~= nil end
	end
end)
