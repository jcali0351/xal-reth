-- Paranoid RP 1.0.0
-- Target someone. Become concerned about them. Then very concerned. Then say so.

local ADDON = "ParanoidRP"
local P = {}
_G.ParanoidRP = P

local MAX_LEN = 255
local FALLBACK_NAME = "that one"
local FALLBACK_GUILD = "Guildless Wanderers"

local DEFAULTS = {
  interval = 12, dice = false, diceMin = 8, diceMax = 20,
  monologue = false, animations = true, pauseInCombat = true,
  point = { "CENTER", nil, "CENTER", 260, 80 }, shown = true,
}

local function msg(t) DEFAULT_CHAT_FRAME:AddMessage("|cffb98cffParanoid RP:|r " .. t) end
local function secret(v) return v ~= nil and issecretvalue and issecretvalue(v) end

---------------------------------------------------------------------------
-- The suspect
---------------------------------------------------------------------------
-- Captured once when the performance starts, so it keeps going if you change target.
function P:CaptureSuspect()
  if not UnitExists("target") or UnitIsUnit("target", "player") then return nil end
  local name = UnitName("target")
  if not name or secret(name) then return nil end
  local class = UnitClass("target")
  local race = UnitRace("target")
  local guild = GetGuildInfo("target")
  if secret(class) or not class then class = UnitCreatureType and UnitCreatureType("target") or "suspect" end
  if secret(class) or not class then class = "suspect" end
  if secret(race) or not race then race = "mysterious" end
  if secret(guild) or not guild or guild == "" then guild = FALLBACK_GUILD end
  local zone = GetZoneText() or "here"
  if secret(zone) then zone = "here" end
  return { name = name, class = class, race = race, guild = guild, zone = zone }
end

local function fill(text, s)
  s = s or {}
  local function safe(v, d) v = tostring(v or d):gsub("%%", "%%%%"); return v end
  text = text:gsub("{t}", safe(s.name, FALLBACK_NAME))
             :gsub("{class}", safe(s.class, "suspect"):lower())
             :gsub("{race}", safe(s.race, "mysterious"))
             :gsub("{guild}", safe(s.guild, FALLBACK_GUILD))
             :gsub("{zone}", safe(s.zone, "here"))
             :gsub("|", "")
  if #text > MAX_LEN then
    local cut = text:sub(1, MAX_LEN - 3)
    text = (cut:match("^(.*)%s") or cut) .. "..."
  end
  return text
end

---------------------------------------------------------------------------
-- Speaking
---------------------------------------------------------------------------
function P:CanSpeak()
  if self.db.monologue then return true end
  if C_ChatInfo and C_ChatInfo.InChatMessagingLockdown and C_ChatInfo.InChatMessagingLockdown() then
    return false, "encounter chat lockdown"
  end
  if self.db.pauseInCombat and InCombatLockdown() then return false, "combat" end
  return true
end

local function sendEmote(text)
  if C_ChatInfo and C_ChatInfo.SendChatMessage then C_ChatInfo.SendChatMessage(text, "EMOTE")
  else SendChatMessage(text, "EMOTE") end
end

function P:Animate(token)
  if not token or not self.db.animations or self.db.monologue then return end
  -- Play the animation at the current target if it is still the suspect, otherwise on its own.
  local onTarget = self.suspect and UnitExists("target") and not secret(UnitName("target"))
                   and UnitName("target") == self.suspect.name
  pcall(DoEmote, token, onTarget and "target" or "none")
end

function P:Say(entry)
  local text = fill(entry[1], self.suspect)
  self.lastText = text
  if self.db.monologue then
    local me = UnitName("player") or "You"
    DEFAULT_CHAT_FRAME:AddMessage("|cffc9a8ff(thinks) " .. me .. " " .. text .. "|r")
  else
    sendEmote(text)
    if entry[2] then C_Timer.After(0.4, function() self:Animate(entry[2]) end) end
  end
end

---------------------------------------------------------------------------
-- The performance
---------------------------------------------------------------------------
local function actCount() return #ParanoidRP_Acts end
local function linesIn(a) return a and ParanoidRP_Acts[a] and #ParanoidRP_Acts[a].lines or 0 end

function P:TotalLines()
  local n = 0
  for a = 1, actCount() do n = n + linesIn(a) end
  return n + #ParanoidRP_Finale
end

function P:Position()
  local done = 0
  for a = 1, (self.act or 1) - 1 do done = done + linesIn(a) end
  if self.act and self.act > actCount() then done = done + (self.line or 1) - 1
  else done = done + (self.line or 1) - 1 end
  return done, self:TotalLines()
end

function P:Cancel() if self.timer then self.timer:Cancel(); self.timer = nil end end

function P:Delay()
  if self.db.dice then
    return math.random(self.db.diceMin, math.max(self.db.diceMin, self.db.diceMax))
  end
  return self.db.interval
end

function P:Arm(sec)
  self:Cancel()
  self.nextAt = GetTime() + sec
  self.timer = C_Timer.NewTimer(sec, function() self.timer = nil; self:Tick() end)
end

function P:Start(act)
  local s = self:CaptureSuspect()
  if not s then msg("Target someone first. You cannot be paranoid about nobody. Well, you can, but not with this addon.") return end
  self.suspect = s
  self.act = math.max(1, math.min(actCount(), tonumber(act) or 1))
  self.line = 1
  self.state = "running"
  msg("Now watching |cffffd100" .. s.name .. "|r. " .. ParanoidRP_Acts[self.act].name .. ".")
  self:Tick()
end

function P:Stop(quiet)
  self:Cancel()
  self.state = "idle"
  if not quiet and self.suspect then msg("Stopped watching " .. self.suspect.name .. ". For now.") end
  self:Refresh()
end

function P:Pause()
  if self.state == "running" or self.state == "waiting" then
    self:Cancel(); self.state = "paused"; msg("Paused. Still watching, though.")
  elseif self.state == "paused" then
    self.state = "running"; msg("Resumed."); self:Tick()
  end
  self:Refresh()
end

function P:Advance()
  self.line = self.line + 1
  if self.act <= actCount() then
    if self.line > linesIn(self.act) then
      self.act = self.act + 1
      self.line = 1
      if self.act <= actCount() then msg(ParanoidRP_Acts[self.act].name .. ".") end
    end
  elseif self.line > #ParanoidRP_Finale then
    return false
  end
  return true
end

function P:Current()
  if self.act <= actCount() then return ParanoidRP_Acts[self.act].lines[self.line] end
  return ParanoidRP_Finale[self.line]
end

function P:Tick()
  if self.state ~= "running" and self.state ~= "waiting" then return end
  local ok = self:CanSpeak()
  if not ok then self.state = "waiting"; self:Refresh(); self:Arm(2) return end
  self.state = "running"
  local entry = self:Current()
  if entry then self:Say(entry) end
  if not self:Advance() then
    self.state = "idle"; self:Cancel()
    msg("The performance is over. " .. (self.suspect and self.suspect.name or "They") .. " has been thoroughly suspected.")
    self:Refresh()
    return
  end
  self:Arm(self:Delay())
  self:Refresh()
end

function P:Next()
  if self.state == "idle" or not self.suspect then self:Start() return end
  local ok, why = self:CanSpeak()
  if not ok then msg("Cannot speak right now (" .. why .. ").") return end
  local entry = self:Current()
  if entry then self:Say(entry) end
  if not self:Advance() then self:Stop(true); msg("That was the last thought.") return end
  if self.state == "running" then self:Arm(self:Delay()) end
  self:Refresh()
end

function P:SkipAct()
  if self.state == "idle" then msg("Not watching anyone yet.") return end
  if self.act > actCount() then msg("Already at the finale.") return end
  self.act, self.line = self.act + 1, 1
  msg(self.act <= actCount() and (ParanoidRP_Acts[self.act].name .. ".") or "The finale.")
  self:Refresh()
end

---------------------------------------------------------------------------
-- Panel
---------------------------------------------------------------------------
local function button(parent, label, w, x, y, fn)
  local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
  b:SetSize(w, 22); b:SetPoint("TOPLEFT", x, y); b:SetText(label); b:SetScript("OnClick", fn)
  return b
end

local function check(parent, label, key, x, y)
  local c = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
  c:SetSize(24, 24); c:SetPoint("TOPLEFT", x, y)
  local t = c.Text or c.text
  if not t then t = c:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); t:SetPoint("LEFT", c, "RIGHT", 2, 0) end
  t:SetText(label); t:SetFontObject("GameFontHighlightSmall")
  c:SetChecked(P.db[key])
  c:SetScript("OnShow", function(self) self:SetChecked(P.db[key]) end)
  c:SetScript("OnClick", function(self) P.db[key] = self:GetChecked() and true or false; P:Refresh() end)
  return c
end

function P:BuildPanel()
  local f = CreateFrame("Frame", "ParanoidRPPanel", UIParent, "BasicFrameTemplateWithInset")
  f:SetSize(340, 296)
  f:SetMovable(true); f:EnableMouse(true); f:RegisterForDrag("LeftButton"); f:SetClampedToScreen(true)
  f:SetScript("OnDragStart", f.StartMoving)
  f:SetScript("OnDragStop", function(s)
    s:StopMovingOrSizing()
    local p, _, rp, x, y = s:GetPoint(); P.db.point = { p, nil, rp, x, y }
  end)
  f:SetScript("OnHide", function() P.db.shown = false end)
  local pt = self.db.point
  f:SetPoint(pt[1], UIParent, pt[3], pt[4], pt[5])
  local title = f.TitleText or f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
  if not f.TitleText then title:SetPoint("TOP", 0, -6) end
  title:SetText("Paranoid |cffb98cffRP|r")

  local eye = f:CreateTexture(nil, "ARTWORK")
  eye:SetSize(40, 40); eye:SetPoint("TOPLEFT", 14, -34); eye:SetTexture("Interface\\Icons\\INV_Misc_Eye_01")
  self.eye = eye

  local who = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
  who:SetPoint("TOPLEFT", 62, -36); who:SetPoint("RIGHT", -14, 0); who:SetJustifyH("LEFT")
  self.whoText = who
  local act = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  act:SetPoint("TOPLEFT", 62, -58); act:SetPoint("RIGHT", -14, 0); act:SetJustifyH("LEFT")
  self.actText = act

  local bar = CreateFrame("StatusBar", nil, f)
  bar:SetPoint("TOPLEFT", 14, -84); bar:SetPoint("TOPRIGHT", -14, -84); bar:SetHeight(12)
  bar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
  bar:SetStatusBarColor(0.72, 0.55, 1.0)
  local bg = bar:CreateTexture(nil, "BACKGROUND"); bg:SetAllPoints(); bg:SetColorTexture(0.1, 0.06, 0.16, 0.9)
  local bt = bar:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); bt:SetPoint("CENTER")
  self.bar, self.barText = bar, bt

  local line = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  line:SetPoint("TOPLEFT", 16, -104); line:SetPoint("TOPRIGHT", -16, -104); line:SetHeight(56)
  line:SetJustifyH("LEFT"); line:SetJustifyV("TOP"); line:SetWordWrap(true)
  self.lineText = line

  self.startBtn = button(f, "Start", 72, 14, -166, function()
    if P.state == "idle" or not P.state then P:Start() else P:Pause() end
  end)
  button(f, "Next", 64, 90, -166, function() P:Next() end)
  button(f, "Skip Act", 80, 158, -166, function() P:SkipAct() end)
  button(f, "Stop", 72, 242, -166, function() P:Stop() end)

  local iv = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  iv:SetPoint("TOPLEFT", 16, -200); self.intervalText = iv
  button(f, "-", 24, 200, -195, function() P.db.interval = math.max(5, P.db.interval - 1); P:Refresh() end)
  button(f, "+", 24, 228, -195, function() P.db.interval = math.min(60, P.db.interval + 1); P:Refresh() end)
  check(f, "Dice", "dice", 258, -194)

  check(f, "Inner monologue only (no one else sees it)", "monologue", 12, -222)
  check(f, "Play emote animations", "animations", 12, -244)
  check(f, "Pause in combat", "pauseInCombat", 12, -266)

  f:SetScript("OnUpdate", function(s, el)
    s.acc = (s.acc or 0) + el
    if s.acc > 0.25 then s.acc = 0; P:RefreshTimer() end
  end)
  self.panel = f
end

function P:RefreshTimer()
  if not self.panel or not self.panel:IsShown() then return end
  local d = self.db.dice and ("Dice: " .. self.db.diceMin .. "-" .. self.db.diceMax .. "s") or ("Every " .. self.db.interval .. " seconds")
  if self.state == "running" and self.nextAt then
    d = d .. string.format("   |cffb98cffnext in %ds|r", math.max(0, math.ceil(self.nextAt - GetTime())))
  end
  self.intervalText:SetText(d)
end

function P:Refresh()
  if not self.panel then return end
  local s = self.suspect
  local state = self.state or "idle"
  if s and state ~= "idle" then
    self.whoText:SetText("Watching: |cffffd100" .. s.name .. "|r")
  elseif UnitExists("target") and not UnitIsUnit("target", "player") and not secret(UnitName("target")) then
    self.whoText:SetText("Target: |cffffffff" .. (UnitName("target") or "?") .. "|r")
  else
    self.whoText:SetText("|cffaaaaaaTarget someone suspicious|r")
  end
  local actName = (self.act and self.act <= #ParanoidRP_Acts) and ParanoidRP_Acts[self.act].name or (self.act and "The Finale" or "Five acts of growing concern")
  local stateTxt = state == "running" and "|cff80ff80Watching|r" or state == "paused" and "|cffffd100Paused|r"
    or state == "waiting" and "|cffff8080Waiting (combat / lockdown)|r" or "|cffaaaaaaIdle|r"
  self.actText:SetText(actName .. "  ·  " .. stateTxt .. (self.db.monologue and "  ·  |cffc9a8ffmonologue|r" or ""))
  local done, total = self:Position()
  if state == "idle" and not self.suspect then done = 0 end
  self.bar:SetMinMaxValues(0, total); self.bar:SetValue(done)
  self.barText:SetText(done .. " / " .. total .. " thoughts")
  self.lineText:SetText(self.lastText and ("|cffc9a8ff\"|r" .. self.lastText .. "|cffc9a8ff\"|r") or
    "Target a player and press Start. Your character will slowly become convinced they are up to something.")
  self.startBtn:SetText((state == "idle") and "Start" or (state == "paused" and "Resume" or "Pause"))
  self:RefreshTimer()
end

function P:Toggle()
  if not self.panel then self:BuildPanel() end
  if self.panel:IsShown() then self.panel:Hide() else self.panel:Show(); self.db.shown = true; self:Refresh() end
end

function ParanoidRP_OnAddonCompartmentClick() P:Toggle() end

---------------------------------------------------------------------------
-- Slash commands
---------------------------------------------------------------------------
local HELP = {
  "|cffb98cff/para|r  show or hide the panel",
  "|cffb98cff/para start|r  begin watching your target (|cffb98cff/para start 3|r starts at Act III)",
  "|cffb98cff/para pause|r · |cffb98cffnext|r · |cffb98cffskip|r · |cffb98cffstop|r",
  "|cffb98cff/para interval 15|r  seconds between thoughts (5 to 60)",
  "|cffb98cff/para dice|r  toggle random timing",
  "|cffb98cff/para quiet|r  toggle inner monologue (thoughts shown only to you)",
  "|cffb98cff/para anim|r  toggle emote animations",
}

SLASH_PARANOIDRP1, SLASH_PARANOIDRP2 = "/para", "/paranoid"
SlashCmdList.PARANOIDRP = function(input)
  local cmd, arg = (input or ""):lower():match("^%s*(%S*)%s*(.-)%s*$")
  if cmd == "" then P:Toggle()
  elseif cmd == "start" then P:Start(arg ~= "" and arg or nil)
  elseif cmd == "pause" or cmd == "resume" then P:Pause()
  elseif cmd == "next" then P:Next()
  elseif cmd == "skip" then P:SkipAct()
  elseif cmd == "stop" then P:Stop()
  elseif cmd == "interval" then
    local n = tonumber(arg)
    if n then P.db.interval = math.max(5, math.min(60, math.floor(n))); msg("Interval: " .. P.db.interval .. " seconds.")
    else msg("Usage: /para interval 15") end
  elseif cmd == "dice" then P.db.dice = not P.db.dice; msg("Dice timing " .. (P.db.dice and "on." or "off."))
  elseif cmd == "quiet" or cmd == "monologue" then
    P.db.monologue = not P.db.monologue
    msg(P.db.monologue and "Inner monologue on. Only you will see the thoughts." or "Inner monologue off. Everyone nearby will see the thoughts.")
  elseif cmd == "anim" then P.db.animations = not P.db.animations; msg("Animations " .. (P.db.animations and "on." or "off."))
  else for _, l in ipairs(HELP) do msg(l) end end
  P:Refresh()
end

---------------------------------------------------------------------------
-- Events
---------------------------------------------------------------------------
local ev = CreateFrame("Frame")
ev:RegisterEvent("ADDON_LOADED")
ev:RegisterEvent("PLAYER_TARGET_CHANGED")
ev:RegisterEvent("PLAYER_REGEN_ENABLED")
ev:SetScript("OnEvent", function(_, e, name)
  if e == "ADDON_LOADED" and name == ADDON then
    ParanoidRPDB = ParanoidRPDB or {}
    for k, v in pairs(DEFAULTS) do if ParanoidRPDB[k] == nil then ParanoidRPDB[k] = v end end
    P.db = ParanoidRPDB
    P.state = "idle"
    P:BuildPanel()
    if not P.db.shown then P.panel:Hide() end
    P:Refresh()
  elseif e == "PLAYER_TARGET_CHANGED" then
    P:Refresh()
  elseif e == "PLAYER_REGEN_ENABLED" and P.state == "waiting" then
    P:Tick()
  end
end)
