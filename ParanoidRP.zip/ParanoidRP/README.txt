PARANOID RP 1.0.0
A World of Warcraft roleplay addon from the Cult of Xal'Reth.

Target someone. Press Start. Your character slowly, publicly becomes convinced that
person is up to something, and eventually tells them exactly what they think of them.

THE FIVE ACTS (103 thoughts, plus a finale)
  Act I    The Glance          mild unease, glancing, counting blinks
  Act II   The Evidence        notebook, pebbles, a diagram in the dirt
  Act III  The Theory          red string, three gnomes in a trench coat
  Act IV   The Confrontation   pointing, formal accusations, demands to see hands
  Act V    The Trash Talk      the gloves come off
  Finale   walks away very calmly. Too calmly.

Each thought is posted as an /emote and played with a matching animation
(point, gasp, cower, talk, laugh, roar and more). The suspect's name, class, race,
guild and the zone are filled in automatically. The suspect is locked in when you
start, so you can change target without losing the thread.

COMMANDS
  /para                 show or hide the panel (also on the minimap addon button)
  /para start           start watching your target
  /para start 3         start at Act III
  /para pause           pause or resume
  /para next            say the next thought now
  /para skip            jump to the next act
  /para stop            stop
  /para interval 15     seconds between thoughts (5 to 60)
  /para dice            random timing between thoughts
  /para quiet           inner monologue: thoughts appear only in your own chat
  /para anim            turn emote animations on or off

INSTALL
  1. Extract the zip.
  2. Move the ParanoidRP folder into World of Warcraft\_retail_\Interface\AddOns\
  3. Restart the game or /reload, then type /para.

ETIQUETTE
  Act V is trash talk. It is about gear, rotations and standing in fire, never about
  the real person, but not everyone will be in on the joke. Try it on guildmates and
  willing RP partners first, and use /para quiet if you just want to enjoy the thoughts.
  Thoughts pause automatically in combat and during boss chat lockdown.

Glory to Xal'Reth.
