-- Brain Rotter Pro :: 10,000 lines of Xal'Reth brain rot
-- Picks a victim from your target, group or online guildies and roasts them line by line.
-- 1.2: auto-rot posts emotes, party, raid and guild chat on a timer (default: Emote, so people actually see it).
-- /say needs a key or button press outside instances (Blizzard rule): the SAY button on the panel says the
-- next line instantly, and when auto-rot runs on Say the line waits on that glowing button. Inside dungeons
-- and raids /say is automatic.

local ADDON = ...
local MEDIA = "Interface\\AddOns\\" .. ADDON .. "\\media\\"
local D = BRP_DATA
local DB
local GOLD = { 0.89, 0.72, 0.32 }
local PALE = { 0.95, 0.91, 0.76 }
local PINK = { 1.0, 0.45, 0.85 }
local CYAN = { 0.4, 1.0, 0.9 }

local CHANNELS = { "EMOTE", "SAY", "PARTY", "RAID", "GUILD", "LOCAL" }
local AUTO_OK = { EMOTE = 3, SAY = 3, PARTY = 2, RAID = 2, GUILD = 10, LOCAL = 1 }   -- channel -> minimum seconds between lines
local ICON_SLOT = { spiral = 7, flex = 28, dune = 17, eye = 6, sun = 11, question = 21, shed = 20, fang = 23, tongue = 8, coil = 12 }
local DANCES = { "DANCE", "TRAIN", "CHICKEN", "ROFL", "FLEX", "CHEER", "ROAR" }

local function msg(t) DEFAULT_CHAT_FRAME:AddMessage("|cffff73d9[Brain Rotter Pro]|r " .. t) end
local function pick(t) return t[math.random(#t)] end
local function shortName(n) return n and (n:gsub("%-.*", "")) end

-- Midnight (12.0+): the old global SendChatMessage only exists with the deprecation-fallback CVar,
-- so always prefer C_ChatInfo.SendChatMessage, and report failures instead of hiding them.
local function SendChat(text, channel)
  local fn = (C_ChatInfo and C_ChatInfo.SendChatMessage) or SendChatMessage
  if not fn then return false, "no chat API" end
  return pcall(fn, text, channel)
end
local lastSendErr = 0
local function reportSendError(err, tag)
  if GetTime() - lastSendErr > 60 then
    lastSendErr = GetTime()
    DEFAULT_CHAT_FRAME:AddMessage("|cffff5555[" .. tag .. "] could not post to chat:|r " .. tostring(err))
  end
end
local function nextIn(list, cur)
  for i, v in ipairs(list) do if v == cur then return list[(i % #list) + 1] end end
  return list[1]
end

local function defaults()
  BrainRotterDB = BrainRotterDB or {}
  DB = BrainRotterDB
  local d = { cat = 1, pos = {}, channel = "EMOTE", speed = 8, chaos = false, useTarget = true, useGroup = true,
              useGuild = true, lockTarget = false, anims = true, chime = true, danceEvery = 7, spewed = 0 }
  for k, v in pairs(d) do if DB[k] == nil then DB[k] = v end end
  if (DB.cfgVersion or 0) < 2 then                    -- 1.2: Local only showed in your own window; start on Emote
    if DB.channel == "LOCAL" then DB.channel = "EMOTE" end
    DB.cfgVersion = 2
  end
end

---------------------------------------------------------------- victim selection
local function onlineGuildies()
  local out, me = {}, UnitName("player")
  if not IsInGuild() then return out end
  for i = 1, (GetNumGuildMembers()) do
    local name, _, _, _, _, _, _, _, online = GetGuildRosterInfo(i)
    name = shortName(name)
    if name and online and name ~= me then out[#out + 1] = name end
  end
  return out
end

local function groupMembers()
  local out = {}
  local n = GetNumGroupMembers()
  local prefix = IsInRaid() and "raid" or "party"
  local me = UnitName("player")
  for i = 1, n do
    local name = UnitName(prefix .. i)
    if name and name ~= me and name ~= UNKNOWNOBJECT then out[#out + 1] = name end
  end
  return out
end

local function targetName()
  if UnitExists("target") and UnitIsPlayer("target") and not UnitIsUnit("target", "player") then return (UnitName("target")) end
end

local victim = "chat"
local function chooseVictim()
  local t = targetName()
  if DB.lockTarget and t then victim = t; return victim end
  local pool = {}
  if DB.useTarget and t then pool[#pool + 1] = t; pool[#pool + 1] = t end -- target gets double odds
  if DB.useGroup then for _, n in ipairs(groupMembers()) do pool[#pool + 1] = n end end
  if DB.useGuild then for _, n in ipairs(onlineGuildies()) do pool[#pool + 1] = n end end
  victim = (#pool > 0) and pick(pool) or "chat"
  return victim
end

---------------------------------------------------------------- core spew
local function catData() return D.cats[DB.cat] end
local function pos() return DB.pos[DB.cat] or 1 end

local Refresh, flash
Refresh = function() end

local function send(text, channel)
  if #text > 255 then text = text:sub(1, 252) .. "..." end
  if channel == "PARTY" and not IsInGroup() then channel = "LOCAL" end
  if channel == "RAID" and not IsInRaid() then channel = IsInGroup() and "PARTY" or "LOCAL" end
  if channel == "GUILD" and not IsInGuild() then channel = "LOCAL" end
  if channel == "LOCAL" then msg(text) else
    local ok, err = SendChat(text, channel)
    if not ok then reportSendError(err, "Brain Rotter Pro") end
  end
end

local pendingSay
local function nextLine()
  if DB.chaos then DB.cat = math.random(#D.cats) end
  local cat = catData()
  local p = pos()
  local line = cat.lines[p]
  local act = D.actions[line[1]]
  local who = chooseVictim()
  local text = line[2]:gsub("%%t", function() return who end)
  DB.pos[DB.cat] = (p % #cat.lines) + 1
  return text, act
end

local function rotFx(act)
  DB.spewed = DB.spewed + 1
  if DB.anims and act then
    if DB.danceEvery > 0 and DB.spewed % DB.danceEvery == 0 then DoEmote(pick(DANCES)) else DoEmote(act[1]) end
  end
  if DB.chime then PlaySoundFile(MEDIA .. "chime" .. math.random(1, 8) .. ".ogg", "Master") end
  if flash then flash() end
  if Refresh then Refresh() end
end

-- SAY: speak the waiting line (or the next one) in /say. Needs a click or key press outside instances.
function BRP_Say()
  local text, act = pendingSay, nil
  if not text then text, act = nextLine() end
  if #text > 255 then text = text:sub(1, 252) .. "..." end
  local ok, err = SendChat(text, "SAY")
  if not ok then reportSendError(err, "Brain Rotter Pro"); return end
  pendingSay = nil
  rotFx(act)
end

function BRP_Spew(fromAuto)
  local text, act = nextLine()
  if DB.channel == "SAY" then
    if IsInInstance() or not fromAuto then
      if #text > 255 then text = text:sub(1, 252) .. "..." end
      local ok, err = SendChat(text, "SAY")
      if not ok then
        if fromAuto then pendingSay = text else reportSendError(err, "Brain Rotter Pro") end
      end
    else
      pendingSay = text                               -- open world: waits for the SAY button
    end
  elseif DB.channel == "EMOTE" then send(act[2] .. ": " .. text, "EMOTE")
  else send(text, DB.channel) end
  DB.spewed = DB.spewed + 1
  if DB.anims then
    if DB.danceEvery > 0 and DB.spewed % DB.danceEvery == 0 then DoEmote(pick(DANCES)) else DoEmote(act[1]) end
  end
  if DB.chime then PlaySoundFile(MEDIA .. "chime" .. math.random(1, 8) .. ".ogg", "Master") end
  if flash then flash() end
  if Refresh then Refresh() end
end

---------------------------------------------------------------- auto-play
local auto, acc = false, 0
local function effectiveSpeed() return math.max(DB.speed, AUTO_OK[DB.channel] or 999) end

function BRP_ToggleAuto()
  if auto then auto = false; msg("Auto-rot stopped."); if Refresh then Refresh() end; return end
  if not AUTO_OK[DB.channel] then DB.channel = "EMOTE" end
  auto, acc = true, effectiveSpeed()
  msg(("Auto-rot ON: a line every %ds in %s. Brains: rotting."):format(effectiveSpeed(), DB.channel))
  if DB.channel == "SAY" and not IsInInstance() then msg("Out in the world each line waits on the glowing SAY button: one click per line (Blizzard rule).") end
  if DB.channel == "LOCAL" then msg("Channel is Local: only you can see these. Click Channel to switch to Emote, Guild or Party.") end
  if Refresh then Refresh() end
end

local f, slider
local uiError

local ticker = CreateFrame("Frame")
ticker:SetScript("OnUpdate", function(_, el)
  if not auto or not DB then return end
  if not AUTO_OK[DB.channel] then auto = false; Refresh(); return end
  if InCombatLockdown() or (C_ChatInfo.InChatMessagingLockdown and C_ChatInfo.InChatMessagingLockdown()) then return end
  acc = acc + el
  if acc >= effectiveSpeed() then acc = 0; BRP_Spew(true) end
end)

---------------------------------------------------------------- UI
local function BuildUI()
f = CreateFrame("Frame", "BrainRotterFrame", UIParent, "BackdropTemplate")
f:SetSize(780, 500); f:SetPoint("CENTER"); f:SetFrameStrata("HIGH")
f:SetMovable(true); f:EnableMouse(true); f:SetClampedToScreen(true)
f:RegisterForDrag("LeftButton")
f:SetScript("OnDragStart", f.StartMoving); f:SetScript("OnDragStop", f.StopMovingOrSizing)
f:SetBackdrop({ bgFile = MEDIA .. "bg", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 18,
  insets = { left = 4, right = 4, top = 4, bottom = 4 } })
f:SetBackdropBorderColor(unpack(PINK))
f:Hide()
tinsert(UISpecialFrames, "BrainRotterFrame")
CreateFrame("Button", nil, f, "UIPanelCloseButton"):SetPoint("TOPRIGHT", -4, -4)

local function font(parent, size, color, face, flags)
  local fs = parent:CreateFontString(nil, "OVERLAY")
  fs:SetFont(face or "Fonts\\FRIZQT__.TTF", size, flags or "")
  fs:SetTextColor(unpack(color or PALE)); fs:SetShadowOffset(1, -1)
  return fs
end
local function button(parent, w, h, label, onClick)
  local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
  b:SetSize(w, h); b:SetText(label); b:SetScript("OnClick", onClick); return b
end
local function setIcon(tex, name)
  local slot = ICON_SLOT[name] or 12
  local c, r = (slot - 1) % 8, math.floor((slot - 1) / 8)
  tex:SetTexture(MEDIA .. "icons"); tex:SetTexCoord(c / 8, (c + 1) / 8, r / 8, (r + 1) / 8)
end

-- rainbow title
local title = font(f, 30, PINK, "Fonts\\MORPHEUS.TTF", "OUTLINE"); title:SetPoint("TOP", 0, -12)
title:SetText("Brain Rotter Pro")
local sub = font(f, 11, CYAN); sub:SetPoint("TOP", title, "BOTTOM", 0, -2)
sub:SetText("10,000 lines of certified Xal'Reth brain rot  -  no cap")
local hue = 0
f:SetScript("OnUpdate", function(_, el)
  hue = (hue + el * 0.25) % 1
  local function ch(o) return 0.6 + 0.4 * math.sin(2 * math.pi * (hue + o)) end
  title:SetTextColor(ch(0), ch(0.33), ch(0.66))
end)

-- category icon menu
local catButtons = {}
for i, cat in ipairs(D.cats) do
  local b = CreateFrame("Button", nil, f)
  b:SetSize(210, 34); b:SetPoint("TOPLEFT", 16, -70 - (i - 1) * 36)
  b.icon = b:CreateTexture(nil, "ARTWORK"); b.icon:SetSize(32, 32); b.icon:SetPoint("LEFT", 0, 0); setIcon(b.icon, cat.icon)
  b.text = font(b, 12, PALE); b.text:SetPoint("LEFT", b.icon, "RIGHT", 8, 0); b.text:SetText(cat.title)
  b.sel = b:CreateTexture(nil, "BACKGROUND"); b.sel:SetAllPoints(); b.sel:SetColorTexture(1, 0.4, 0.85, 0.2)
  b:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight", "ADD")
  b:SetScript("OnClick", function() DB.cat = i; DB.chaos = false; Refresh() end)
  catButtons[i] = b
end

-- portrait that spins and wobbles while rotting
local portrait = CreateFrame("Frame", nil, f)
portrait:SetSize(130, 130); portrait:SetPoint("TOPLEFT", 244, -64)
local ptex = portrait:CreateTexture(nil, "ARTWORK"); ptex:SetAllPoints(); ptex:SetTexture(MEDIA .. "xalreth_sheet")
local pglow = portrait:CreateTexture(nil, "OVERLAY"); pglow:SetAllPoints(); pglow:SetTexture(MEDIA .. "xalreth_sheet")
pglow:SetBlendMode("ADD"); pglow:SetAlpha(0)
local pi, pacc = 0, 0
local function setFrame(i)
  local c, r = i % 4, math.floor(i / 4)
  ptex:SetTexCoord(c / 4, (c + 1) / 4, r / 4, (r + 1) / 4); pglow:SetTexCoord(c / 4, (c + 1) / 4, r / 4, (r + 1) / 4)
end
setFrame(0)
portrait:SetScript("OnUpdate", function(_, el)
  pacc = pacc + el
  if pacc > (auto and 0.05 or 0.1) then pacc = 0; pi = (pi + 1) % 16; setFrame(pi) end
end)
local spin = portrait:CreateAnimationGroup()
local rot = spin:CreateAnimation("Rotation"); rot:SetDegrees(-360); rot:SetDuration(0.5)
local wob = portrait:CreateAnimationGroup()
local w1 = wob:CreateAnimation("Scale"); w1:SetScale(1.15, 0.85); w1:SetDuration(0.08); w1:SetOrder(1)
local w2 = wob:CreateAnimation("Scale"); w2:SetScale(0.8, 1.25); w2:SetDuration(0.1); w2:SetOrder(2)
local w3 = wob:CreateAnimation("Scale"); w3:SetScale(1 / 0.92, 1 / 1.0625); w3:SetDuration(0.12); w3:SetOrder(3)
local gl = pglow:CreateAnimationGroup()
local g1 = gl:CreateAnimation("Alpha"); g1:SetFromAlpha(0); g1:SetToAlpha(1); g1:SetDuration(0.1); g1:SetOrder(1)
local g2 = gl:CreateAnimation("Alpha"); g2:SetFromAlpha(1); g2:SetToAlpha(0); g2:SetDuration(0.5); g2:SetOrder(2)
function flash()
  gl:Stop(); gl:Play()
  if math.random() < 0.2 then spin:Stop(); spin:Play() else wob:Stop(); wob:Play() end
end

-- current category + victim
local catIcon = f:CreateTexture(nil, "ARTWORK"); catIcon:SetSize(40, 40); catIcon:SetPoint("TOPLEFT", 390, -70)
local catTitle = font(f, 20, PINK, "Fonts\\MORPHEUS.TTF"); catTitle:SetPoint("LEFT", catIcon, "RIGHT", 8, 4)
local catPos = font(f, 11, CYAN); catPos:SetPoint("TOPLEFT", catTitle, "BOTTOMLEFT", 0, -2)
local victimText = font(f, 15, PALE); victimText:SetPoint("TOPLEFT", 392, -126)
local statsText = font(f, 10, { 0.7, 0.7, 0.8 }); statsText:SetPoint("TOPLEFT", 392, -150)

-- preview box
local box = CreateFrame("Frame", nil, f, "BackdropTemplate")
box:SetPoint("TOPLEFT", 244, -206); box:SetSize(520, 92)
box:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 12,
  insets = { left = 3, right = 3, top = 3, bottom = 3 } })
box:SetBackdropColor(0.08, 0.02, 0.08, 0.8); box:SetBackdropBorderColor(PINK[1], PINK[2], PINK[3], 0.7)
local nextLbl = font(box, 10, CYAN); nextLbl:SetPoint("TOPLEFT", 12, -8); nextLbl:SetText("NEXT BRAIN ROT")
local preview = font(box, 14, PALE); preview:SetPoint("TOPLEFT", 12, -26); preview:SetWidth(496); preview:SetJustifyH("LEFT")
preview:SetSpacing(2)

-- buttons
local spewB = button(f, 124, 36, "SPEW", function() BRP_Spew() end); spewB:SetPoint("TOPLEFT", box, "BOTTOMLEFT", 0, -12)
local sayB = button(f, 124, 36, "SAY", function() BRP_Say() end); sayB:SetPoint("LEFT", spewB, "RIGHT", 6, 0)
local sayGlow = sayB:CreateTexture(nil, "BACKGROUND"); sayGlow:SetPoint("TOPLEFT", -6, 6); sayGlow:SetPoint("BOTTOMRIGHT", 6, -6)
sayGlow:SetColorTexture(1, 0.45, 0.85, 0.45); sayGlow:Hide()
local sayPulse = sayGlow:CreateAnimationGroup(); sayPulse:SetLooping("BOUNCE")
local sp = sayPulse:CreateAnimation("Alpha"); sp:SetFromAlpha(0.2); sp:SetToAlpha(1); sp:SetDuration(0.6)
sayB:SetScript("OnEnter", function(self)
  GameTooltip:SetOwner(self, "ANCHOR_TOP"); GameTooltip:AddLine("Say it out loud in /say", 1, 0.45, 0.85)
  GameTooltip:AddLine(pendingSay and ("Waiting: " .. pendingSay) or "Says the next line of brain rot.", 1, 1, 1, true); GameTooltip:Show()
end)
sayB:SetScript("OnLeave", function() GameTooltip:Hide() end)
local autoB = button(f, 124, 36, "", function() BRP_ToggleAuto() end); autoB:SetPoint("LEFT", sayB, "RIGHT", 6, 0)
local chaosB = button(f, 124, 36, "", function() DB.chaos = not DB.chaos; Refresh() end); chaosB:SetPoint("LEFT", autoB, "RIGHT", 6, 0)

-- speed slider (custom-built; no Blizzard template needed)
slider = CreateFrame("Slider", nil, f, "BackdropTemplate")
slider:SetPoint("TOPLEFT", spewB, "BOTTOMLEFT", 6, -30); slider:SetSize(330, 16)
slider:SetOrientation("HORIZONTAL")
slider:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 })
slider:SetBackdropColor(0.1, 0.02, 0.1, 0.9); slider:SetBackdropBorderColor(PINK[1], PINK[2], PINK[3], 0.8)
local thumb = slider:CreateTexture(nil, "OVERLAY"); thumb:SetSize(14, 22); thumb:SetColorTexture(PINK[1], PINK[2], PINK[3], 1)
slider:SetThumbTexture(thumb)
slider:SetMinMaxValues(1, 60); slider:SetValueStep(1)
if slider.SetObeyStepMode then slider:SetObeyStepMode(true) end
slider:EnableMouse(true)
local sText = font(slider, 12, PALE); sText:SetPoint("BOTTOMLEFT", slider, "TOPLEFT", 0, 4)
local sLow = font(slider, 9, CYAN); sLow:SetPoint("TOPLEFT", slider, "BOTTOMLEFT", 0, -2); sLow:SetText("1s (unhinged)")
local sHigh = font(slider, 9, CYAN); sHigh:SetPoint("TOPRIGHT", slider, "BOTTOMRIGHT", 0, -2); sHigh:SetText("60s (chill)")
slider.update = function(v)
  if not DB then return end
  DB.speed = math.floor((v or DB.speed) + 0.5)
  local eff = effectiveSpeed()
  sText:SetText(("Rot speed: every %ds%s"):format(DB.speed, (AUTO_OK[DB.channel] and eff > DB.speed) and (" (" .. DB.channel .. " min " .. eff .. "s)") or ""))
end
slider:SetScript("OnValueChanged", function(_, v) slider.update(v) end)

local chanB = button(f, 130, 22, "", function()
  DB.channel = nextIn(CHANNELS, DB.channel)
  if DB.channel ~= "SAY" then pendingSay = nil end
  slider.update(DB.speed); Refresh()
end)
chanB:SetPoint("LEFT", slider, "RIGHT", 24, 6)
local danceB = button(f, 130, 22, "", function() DB.danceEvery = nextIn({ 0, 3, 5, 7, 10 }, DB.danceEvery); Refresh() end)
danceB:SetPoint("TOPLEFT", chanB, "BOTTOMLEFT", 0, -4)

-- victim source toggles
local checks = {}
local function check(key, label, x, y)
  local cb = CreateFrame("CheckButton", nil, f, "UICheckButtonTemplate")
  cb:SetSize(24, 24); cb:SetPoint("TOPLEFT", x, y)
  local t = font(cb, 11, PALE); t:SetPoint("LEFT", cb, "RIGHT", 2, 0); t:SetText(label)
  cb:SetScript("OnClick", function(self) DB[key] = self:GetChecked() and true or false; Refresh() end)
  checks[key] = cb
end
check("useTarget", "Target", 244, -426)
check("useGroup", "Group", 330, -426)
check("useGuild", "Online guildies", 410, -426)
check("lockTarget", "Lock on target", 548, -426)
check("anims", "Animations", 244, -452)
check("chime", "Chimes", 350, -452)

function Refresh()
  if not DB or not f:IsShown() then return end
  local cat = catData()
  for i, b in ipairs(catButtons) do b.sel:SetShown(i == DB.cat and not DB.chaos) end
  setIcon(catIcon, cat.icon)
  catTitle:SetText(DB.chaos and "CHAOS MODE" or cat.title)
  catPos:SetText(DB.chaos and "random category every line" or ("Line " .. pos() .. " of " .. #cat.lines))
  local t = targetName()
  victimText:SetText("Current victim: |cffff73d9" .. (DB.lockTarget and t or victim) .. "|r" ..
    ((DB.lockTarget and t) and " (locked)" or ""))
  statsText:SetText(("Lines spewed: %d   |   Online guildies in pool: %d"):format(DB.spewed, DB.useGuild and #onlineGuildies() or 0))
  preview:SetText((cat.lines[pos()][2]:gsub("%%t", "|cffff73d9[victim]|r")))
  autoB:SetText(auto and "STOP AUTO" or "AUTO-ROT")
  sayB:SetText(pendingSay and "|cffffffffSAY IT!|r" or "SAY")
  if pendingSay then if not sayGlow:IsShown() then sayGlow:Show(); sayPulse:Play() end else sayGlow:Hide(); sayPulse:Stop() end
  chaosB:SetText(DB.chaos and "Chaos: ON" or "Chaos: Off")
  chanB:SetText("Channel: " .. DB.channel)
  danceB:SetText(DB.danceEvery > 0 and ("Dance every " .. DB.danceEvery) or "Dances: Off")
  for k, cb in pairs(checks) do cb:SetChecked(DB[k]) end
end
f:SetScript("OnShow", function() Refresh() end)
end

---------------------------------------------------------------- events / slash / bindings
local ev = CreateFrame("Frame")
ev:RegisterEvent("ADDON_LOADED"); ev:RegisterEvent("PLAYER_TARGET_CHANGED"); ev:RegisterEvent("GROUP_ROSTER_UPDATE")
ev:RegisterEvent("PLAYER_LOGIN")
ev:SetScript("OnEvent", function(_, e, a1)
  if e == "ADDON_LOADED" and a1 == ADDON then
    defaults()
    local ok, err = pcall(BuildUI)
    if not ok then
      uiError = tostring(err); f = nil
      msg("|cffff5555Window failed to build:|r " .. uiError .. "  (Spew and auto-rot still work: /rot spew, /rot auto)")
    else
      slider:SetValue(DB.speed); slider.update(DB.speed)
    end
  elseif e == "PLAYER_LOGIN" then
    if C_GuildInfo and C_GuildInfo.GuildRoster then C_GuildInfo.GuildRoster() end
    msg("Brain Rotter Pro 1.2 loaded. Type |cffff73d9/rot|r to open. SAY button, /rot say, or bind a Say key under Key Bindings > AddOns.")
  elseif DB and f then
    pcall(Refresh)
  end
end)

function BRP_Toggle()
  if not f then msg("Window unavailable: " .. (uiError or "not loaded yet")); return end
  f:SetShown(not f:IsShown())
end
BINDING_HEADER_BRAINROTTERPRO = "Brain Rotter Pro"
BINDING_NAME_BRP_SPEW = "Spew next line"
BINDING_NAME_BRP_SAY = "Say the next line (/say)"
BINDING_NAME_BRP_AUTO = "Toggle auto-rot"
BINDING_NAME_BRP_TOGGLE = "Open / close Brain Rotter Pro"

SLASH_BRAINROTTERPRO1 = "/rot"
SLASH_BRAINROTTERPRO2 = "/brainrot"
SlashCmdList.BRAINROTTERPRO = function(arg)
  arg = (arg or ""):lower()
  if arg == "spew" or arg == "s" then BRP_Spew()
  elseif arg == "say" then BRP_Say()
  elseif arg == "auto" then BRP_ToggleAuto()
  elseif arg == "stop" then auto = false; msg("Auto-rot stopped.")
  else BRP_Toggle() end
end
