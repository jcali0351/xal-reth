-- Disciples of Devotion: the Verse Engine.
-- Every chapter holds 10,000 verses. The first verses of each chapter are the
-- hand-written scripture of the Coil (Canon.lua); the rest are built by this
-- engine from hand-written pieces (Pools.lua). A verse number always gives the
-- same verse on every computer, so the faithful can say "tonight, Devotion 42:7731".

local E = {}
DoD_Engine = E

E.PER_CHAPTER = 10000
E.CHAPTERS = 100
local P = 1000003

local cache = {}

local function poolsFor(c)
  if cache[c] then return cache[c] end
  local b = math.floor((c - 1) / 10) + 1
  local pl = {}
  for k, list in pairs(DoD_G) do
    local t = {}
    for i = 1, #list do t[i] = list[i] end
    local extra = DoD_B[b] and DoD_B[b][k]
    if extra then for i = 1, #extra do t[#t + 1] = extra[i] end end
    pl[k] = t
  end
  local title = DoD_Chapters[c].title
  if title:sub(1, 4) == "The " then title = "the" .. title:sub(4) end
  pl.focus = { title }
  local sizes = {}
  for ti, tpl in ipairs(DoD_Templates) do
    local n = 1
    for _, s in ipairs(tpl.s) do n = n * #pl[s] end
    sizes[ti] = n
  end
  cache[c] = { pl = pl, sizes = sizes }
  return cache[c]
end

function E.CanonCount(c)
  return #DoD_Chapters[c].v
end

-- Returns the raw verse text (may contain {target}).
function E.Verse(c, v)
  local ch = DoD_Chapters[c]
  if not ch or v < 1 or v > E.PER_CHAPTER then return nil end
  local k = #ch.v
  if v <= k then return ch.v[v], true end
  local i = v - k - 1
  local d = poolsFor(c)
  local nt = #DoD_Templates
  local t = (i + c) % nt
  local tpl = DoD_Templates[t + 1]
  local j = (math.floor(i / nt) * P + c * 7919) % d.sizes[t + 1]
  local vals = {}
  for _, s in ipairs(tpl.s) do
    local L = #d.pl[s]
    vals[s] = d.pl[s][(j % L) + 1]
    j = math.floor(j / L)
  end
  local text = tpl.t:gsub("{(%w+)}", function(name) return vals[name] or ("{" .. name .. "}") end)
  return text:sub(1, 1):upper() .. text:sub(2), false
end

-- Verse of the day: the same for everyone on a given date.
function E.VerseOfTheDay(dateNum)
  local x = ((dateNum % 100003) * 48271 + 12345) % 2147483647
  local c = (x % E.CHAPTERS) + 1
  local v = (math.floor(x / 100) % E.PER_CHAPTER) + 1
  return c, v
end
