-- Disciples of Devotion
-- The scripture of Xal'Reth, read aloud as emotes. 100 chapters in 10 Books,
-- 10,000 verses each. Browse, read, perform a single verse, or perform a whole
-- chapter on a timer. /dod

local ADDON = ...
local E = DoD_Engine
local MAX_LEN = 255
local FALLBACK = "faithful one"
local MEDIA = "Interface\\AddOns\\DisciplesOfDevotion\\Media\\"

local D = { state = nil, timer = nil }
DisciplesOfDevotion = D

local defaults = {
  c = 1, v = 1, interval = 15, dice = false, diceMin = 8, diceMax = 30,
  useTarget = true, pauseInCombat = true, stopAtCanonEnd = false, channel = "EMOTE",
  showNumbers = true, bookmarks = {}, point = nil, votdShown = 0,
}

local function msg(t) DEFAULT_CHAT_FRAME:AddMessage("|cffb98cffDisciples of Devotion:|r " .. t) end
local function icon(c) return MEDIA .. "icons\\c" .. string.format("%03d", c) end

---------------------------------------------------------------------------
-- Rendering and sending
---------------------------------------------------------------------------
local function targetName()
  if not D.db.useTarget or not UnitExists("target") then return nil end
  local n = UnitName("target")
  if n and issecretvalue and issecretvalue(n) then return nil end
  if UnitIsUnit and UnitIsUnit("target", "player") then return nil end
  return n
end

local function verb(c, v) return DoD_Verbs[((c * 31 + v) % #DoD_Verbs) + 1] end

-- channel "EMOTE" text is prefixed with a reading verb; other channels quote the verse.
function D:Render(c, v, channel)
  local raw = E.Verse(c, v)
  if not raw then return nil end
  local text = raw:gsub("{target}", targetName() or FALLBACK):gsub("|", "")
  local ref = D.db.showNumbers and ("Devotion " .. c .. ":" .. v .. ", ") or ""
  if (channel or "EMOTE") == "EMOTE" then
    if text:find("\"", 1, true) then
      text = verb(c, v) .. " " .. (D.db.showNumbers and ("Devotion " .. c .. ":" .. v .. ": ") or "") .. text
    else
      text = verb(c, v) .. " " .. ref .. "\"" .. text .. "\""
    end
  else
    text = (D.db.showNumbers and ("Devotion " .. c .. ":" .. v .. ": ") or "") .. text
  end
  if #text > MAX_LEN then
    local cut = text:sub(1, MAX_LEN - 3)
    text = (cut:match("^(.*)%s") or cut) .. "..."
  end
  return text
end

function D:CanSpeak()
  if C_ChatInfo and C_ChatInfo.InChatMessagingLockdown and C_ChatInfo.InChatMessagingLockdown() then
    return false, "encounter chat lockdown"
  end
  if self.db.pauseInCombat and InCombatLockdown() then return false, "combat" end
  return true
end

local function send(text, channel)
  channel = channel or "EMOTE"
  if channel == "GUILD" and not IsInGuild() then msg("You are not in a guild.") return end
  if channel == "PARTY" and not IsInGroup() then msg("You are not in a group.") return end
  if C_ChatInfo and C_ChatInfo.SendChatMessage then C_ChatInfo.SendChatMessage(text, channel)
  else SendChatMessage(text, channel) end
end

-- One verse, now. Uses the chosen channel (Say needs a click, which this is).
function D:Perform(c, v, channel)
  c, v = c or self.db.c, v or self.db.v
  local ok, why = self:CanSpeak()
  if not ok then msg("Cannot speak right now (" .. why .. "). The Coil is patient.") return end
  send(self:Render(c, v, channel or self.db.channel), channel or self.db.channel)
end

---------------------------------------------------------------------------
-- Position
---------------------------------------------------------------------------
function D:Set(c, v)
  c = math.max(1, math.min(E.CHAPTERS, math.floor(tonumber(c) or self.db.c)))
  v = math.max(1, math.min(E.PER_CHAPTER, math.floor(tonumber(v) or 1)))
  self.db.c, self.db.v = c, v
  self:Refresh()
end

function D:Step(n)
  local c, v = self.db.c, self.db.v + n
  if v > E.PER_CHAPTER then c, v = c + 1, 1 end
  if v < 1 then c = c - 1; v = E.PER_CHAPTER end
  if c > E.CHAPTERS then c = 1 end
  if c < 1 then c = E.CHAPTERS end
  self:Set(c, v)
end

local function parseRef(s)
  local c, v = (s or ""):match("^(%d+)%s*[:%.]%s*(%d+)$")
  if c then return tonumber(c), tonumber(v) end
  c = (s or ""):match("^(%d+)$")
  if c then return tonumber(c), 1 end
end

---------------------------------------------------------------------------
-- Timed reading (always as emotes, which need no click)
---------------------------------------------------------------------------
function D:Cancel() if self.timer then self.timer:Cancel(); self.timer = nil end end

function D:Delay()
  if self.db.dice then return math.random(self.db.diceMin, math.max(self.db.diceMin, self.db.diceMax)) end
  return self.db.interval
end

function D:Arm(sec)
  self:Cancel()
  self.nextAt = GetTime() + sec
  self.timer = C_Timer.NewTimer(sec, function() self.timer = nil; self:Tick() end)
end

function D:Tick()
  if self.state ~= "running" and self.state ~= "waiting" then return end
  if not self:CanSpeak() then self.state = "waiting"; self:Refresh(); self:Arm(2) return end
  self.state = "running"
  local c, v = self.db.c, self.db.v
  send(self:Render(c, v, "EMOTE"), "EMOTE")
  if self.db.stopAtCanonEnd and v == E.CanonCount(c) then
    self.db.v = v + 1; self:Stop()
    msg("The hand-written verses of Chapter " .. c .. " are complete. Stopping, as you asked.")
    return
  end
  if v >= E.PER_CHAPTER then self:Stop(); msg("Chapter " .. c .. " is complete. All 10,000 verses. Glory to Xal'Reth.") return end
  self.db.v = v + 1
  self:Refresh()
  self:Arm(self:Delay())
end

function D:Play(c, v)
  if c then self:Set(c, v) end
  self.state = "running"; self:Refresh(); self:Tick()
end
function D:Pause() if self.state == "running" or self.state == "waiting" then self:Cancel(); self.state = "paused"; self:Refresh() end end
function D:Resume() if self.state == "paused" then self.state = "running"; self:Refresh(); self:Arm(1) end end
function D:Stop() self:Cancel(); self.state = nil; self:Refresh() end
function D:Toggle()
  if self.state == "running" or self.state == "waiting" then self:Pause()
  elseif self.state == "paused" then self:Resume() else self:Play() end
end

---------------------------------------------------------------------------
-- Bookmarks, search, verse of the day
---------------------------------------------------------------------------
function D:Bookmark()
  local key = self.db.c .. ":" .. self.db.v
  for i, b in ipairs(self.db.bookmarks) do if b == key then table.remove(self.db.bookmarks, i); msg("Removed bookmark " .. key .. "."); self:Refresh() return end end
  table.insert(self.db.bookmarks, key); msg("Bookmarked Devotion " .. key .. "."); self:Refresh()
end

function D:Search(words)
  words = (words or ""):lower()
  if words == "" then msg("Usage: /dod search <words>  (searches the hand-written verses)") return end
  local n = 0
  for c = 1, E.CHAPTERS do
    for v, t in ipairs(DoD_Chapters[c].v) do
      if t:lower():find(words, 1, true) then
        n = n + 1
        if n <= 12 then msg("|cffe0c4ff" .. c .. ":" .. v .. "|r " .. t:sub(1, 90) .. (#t > 90 and "..." or "")) end
      end
    end
  end
  if n == 0 then msg("No hand-written verse contains \"" .. words .. "\".")
  elseif n > 12 then msg(n .. " verses match; showing 12. Use /dod goto <chapter>:<verse>.") end
end

local function today() return tonumber(date("%Y%m%d")) end

function D:VOTD(announce)
  local c, v = E.VerseOfTheDay(today())
  if announce ~= false then
    msg("Verse of the Day, Devotion " .. c .. ":" .. v .. " (" .. DoD_Chapters[c].title .. "):")
    msg("|cffece6f5" .. (E.Verse(c, v):gsub("{target}", FALLBACK)) .. "|r")
  end
  return c, v
end

---------------------------------------------------------------------------
-- The Book (UI)
---------------------------------------------------------------------------
local F
local ROWS = {}

local function btn(parent, text, w, fn)
  local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
  b:SetSize(w, 22); b:SetText(text); b:SetScript("OnClick", fn); return b
end

local function check(parent, label, key, x, y)
  local c = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
  c:SetSize(22, 22); c:SetPoint("TOPLEFT", x, y); c:SetChecked(D.db[key])
  local t = c:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); t:SetPoint("LEFT", c, "RIGHT", 2, 0); t:SetText(label)
  c:SetScript("OnClick", function(s) D.db[key] = s:GetChecked() and true or false; D:Refresh() end)
  return c
end

function D:Build()
  if F then return end
  F = CreateFrame("Frame", "DisciplesOfDevotionFrame", UIParent, "BackdropTemplate")
  F:SetSize(780, 520); F:SetFrameStrata("HIGH"); F:SetClampedToScreen(true)
  F:SetMovable(true); F:EnableMouse(true); F:RegisterForDrag("LeftButton")
  F:SetScript("OnDragStart", F.StartMoving)
  F:SetScript("OnDragStop", function(s) s:StopMovingOrSizing(); local p, _, rp, x, y = s:GetPoint(); D.db.point = { p, rp, x, y } end)
  F:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 16,
    insets = { left = 4, right = 4, top = 4, bottom = 4 } })
  F:SetBackdropColor(0.04, 0.02, 0.08, 0.96); F:SetBackdropBorderColor(0.62, 0.42, 1, 1)
  if D.db.point then F:SetPoint(D.db.point[1], UIParent, D.db.point[2], D.db.point[3], D.db.point[4]) else F:SetPoint("CENTER") end
  tinsert(UISpecialFrames, "DisciplesOfDevotionFrame")
  CreateFrame("Button", nil, F, "UIPanelCloseButton"):SetPoint("TOPRIGHT", -3, -3)

  local logo = F:CreateTexture(nil, "ARTWORK"); logo:SetSize(42, 42); logo:SetPoint("TOPLEFT", 12, -8); logo:SetTexture(MEDIA .. "logo")
  local title = F:CreateFontString(nil, "OVERLAY", "GameFontNormalHuge"); title:SetPoint("LEFT", logo, "RIGHT", 10, 4)
  title:SetText("|cffc9a2ffDisciples of Devotion|r")
  local sub = F:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall"); sub:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -2)
  sub:SetText("The scripture of Xal'Reth  ·  100 chapters  ·  1,000,000 verses")

  -- Chapter list
  local list = CreateFrame("ScrollFrame", "DoDChapterScroll", F, "UIPanelScrollFrameTemplate")
  list:SetPoint("TOPLEFT", 12, -62); list:SetSize(232, 444)
  local content = CreateFrame("Frame", nil, list); content:SetSize(232, 10); list:SetScrollChild(content)
  local y = 0
  for b = 1, 10 do
    local h = content:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    h:SetPoint("TOPLEFT", 4, -y - 4); h:SetText("|cffb98cff" .. b .. ". " .. DoD_Books[b] .. "|r"); y = y + 22
    for k = 1, 10 do
      local c = (b - 1) * 10 + k
      local r = CreateFrame("Button", nil, content); r:SetSize(214, 24); r:SetPoint("TOPLEFT", 2, -y)
      r:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight", "ADD")
      local ic = r:CreateTexture(nil, "ARTWORK"); ic:SetSize(22, 22); ic:SetPoint("LEFT", 2, 0); ic:SetTexture(icon(c))
      local t = r:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); t:SetPoint("LEFT", ic, "RIGHT", 6, 0); t:SetPoint("RIGHT", -2, 0)
      t:SetJustifyH("LEFT"); t:SetWordWrap(false); t:SetText(c .. ". " .. DoD_Chapters[c].title)
      local sel = r:CreateTexture(nil, "BACKGROUND"); sel:SetAllPoints(); sel:SetColorTexture(0.55, 0.3, 1, 0.22); sel:Hide()
      r.sel = sel
      r:SetScript("OnClick", function() D:Set(c, 1) end)
      ROWS[c] = r; y = y + 25
    end
    y = y + 6
  end
  content:SetHeight(y)

  -- Right side: chapter header
  local R = CreateFrame("Frame", nil, F); R:SetPoint("TOPLEFT", 262, -60); R:SetPoint("BOTTOMRIGHT", -14, 12)
  F.icon = R:CreateTexture(nil, "ARTWORK"); F.icon:SetSize(64, 64); F.icon:SetPoint("TOPLEFT", 0, 0)
  F.book = R:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall"); F.book:SetPoint("TOPLEFT", F.icon, "TOPRIGHT", 12, -4)
  F.chap = R:CreateFontString(nil, "OVERLAY", "GameFontHighlightLarge"); F.chap:SetPoint("TOPLEFT", F.book, "BOTTOMLEFT", 0, -4)
  F.meta = R:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall"); F.meta:SetPoint("TOPLEFT", F.chap, "BOTTOMLEFT", 0, -4)
  F.status = R:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall"); F.status:SetPoint("TOPRIGHT", 0, -4)

  -- Verse box
  local box = CreateFrame("Frame", nil, R, "BackdropTemplate")
  box:SetPoint("TOPLEFT", 0, -78); box:SetPoint("TOPRIGHT", 0, -78); box:SetHeight(150)
  box:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 })
  box:SetBackdropColor(0, 0, 0, 0.5); box:SetBackdropBorderColor(0.5, 0.33, 0.85, 0.9)
  F.ref = box:CreateFontString(nil, "OVERLAY", "GameFontNormal"); F.ref:SetPoint("TOPLEFT", 10, -10)
  F.kind = box:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall"); F.kind:SetPoint("TOPRIGHT", -10, -12)
  F.text = box:CreateFontString(nil, "OVERLAY", "GameFontHighlightMedium")
  F.text:SetPoint("TOPLEFT", 10, -32); F.text:SetPoint("BOTTOMRIGHT", -10, 10)
  F.text:SetJustifyH("LEFT"); F.text:SetJustifyV("TOP"); F.text:SetWordWrap(true); F.text:SetSpacing(2)

  -- Transport
  local y1 = -238
  local a = btn(R, "<<", 34, function() D:Step(-10) end); a:SetPoint("TOPLEFT", 0, y1)
  local b2 = btn(R, "< Verse", 70, function() D:Step(-1) end); b2:SetPoint("LEFT", a, "RIGHT", 3, 0)
  F.play = btn(R, "Play", 74, function() D:Toggle() end); F.play:SetPoint("LEFT", b2, "RIGHT", 3, 0)
  local st = btn(R, "Stop", 54, function() D:Stop() end); st:SetPoint("LEFT", F.play, "RIGHT", 3, 0)
  local nx = btn(R, "Verse >", 70, function() D:Step(1) end); nx:SetPoint("LEFT", st, "RIGHT", 3, 0)
  local ff = btn(R, ">>", 34, function() D:Step(10) end); ff:SetPoint("LEFT", nx, "RIGHT", 3, 0)
  F.mark = btn(R, "Bookmark", 80, function() D:Bookmark() end); F.mark:SetPoint("LEFT", ff, "RIGHT", 8, 0)

  -- Perform single verse + channel
  local y2 = -268
  local perf = btn(R, "Perform This Verse", 150, function() D:Perform() end); perf:SetPoint("TOPLEFT", 0, y2)
  local chans = { { "EMOTE", "Emote" }, { "SAY", "Say" }, { "PARTY", "Party" }, { "GUILD", "Guild" } }
  F.chanBtns = {}
  local prev = perf
  for _, ch in ipairs(chans) do
    local cb = btn(R, ch[2], 58, function() D.db.channel = ch[1]; D:Refresh() end)
    cb:SetPoint("LEFT", prev, "RIGHT", prev == perf and 10 or 2, 0); F.chanBtns[ch[1]] = cb; prev = cb
  end

  -- Go to
  local y3 = -300
  local gl = R:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall"); gl:SetPoint("TOPLEFT", 0, y3 - 4); gl:SetText("Go to")
  F.goC = CreateFrame("EditBox", nil, R, "InputBoxTemplate"); F.goC:SetSize(40, 20); F.goC:SetPoint("LEFT", gl, "RIGHT", 10, 0)
  F.goC:SetAutoFocus(false); F.goC:SetNumeric(true); F.goC:SetMaxLetters(3)
  local colon = R:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); colon:SetPoint("LEFT", F.goC, "RIGHT", 2, 0); colon:SetText(":")
  F.goV = CreateFrame("EditBox", nil, R, "InputBoxTemplate"); F.goV:SetSize(56, 20); F.goV:SetPoint("LEFT", colon, "RIGHT", 8, 0)
  F.goV:SetAutoFocus(false); F.goV:SetNumeric(true); F.goV:SetMaxLetters(5)
  local function go() D:Set(F.goC:GetNumber() > 0 and F.goC:GetNumber() or D.db.c, F.goV:GetNumber() > 0 and F.goV:GetNumber() or 1); F.goC:ClearFocus(); F.goV:ClearFocus() end
  F.goC:SetScript("OnEnterPressed", go); F.goV:SetScript("OnEnterPressed", go)
  local gob = btn(R, "Go", 40, go); gob:SetPoint("LEFT", F.goV, "RIGHT", 6, 0)
  local rnd = btn(R, "Random Verse", 104, function() D:Set(math.random(1, E.CHAPTERS), math.random(1, E.PER_CHAPTER)) end); rnd:SetPoint("LEFT", gob, "RIGHT", 10, 0)
  local vd = btn(R, "Verse of the Day", 124, function() local c, v = D:VOTD(false); D:Set(c, v) end); vd:SetPoint("LEFT", rnd, "RIGHT", 4, 0)

  -- Timer
  local s = CreateFrame("Slider", nil, R, "OptionsSliderTemplate")
  s:SetPoint("TOPLEFT", 6, -350); s:SetWidth(220); s:SetMinMaxValues(5, 60); s:SetValueStep(1); s:SetObeyStepOnDrag(true); s:SetValue(D.db.interval)
  if s.Low then s.Low:SetText("5s") end; if s.High then s.High:SetText("60s") end
  local function lbl() if s.Text then s.Text:SetText("Seconds between verses: " .. D.db.interval) end end
  s:SetScript("OnValueChanged", function(_, val) D.db.interval = math.floor(val + 0.5); lbl() end); lbl()

  check(R, "Random timing (8-30s)", "dice", 250, -338)
  check(R, "Use my target's name", "useTarget", 250, -360)
  check(R, "Show verse numbers", "showNumbers", 250, -382)
  check(R, "Stop after hand-written verses", "stopAtCanonEnd", 6, -386)
  check(R, "Pause in combat", "pauseInCombat", 6, -408)

  F.marks = R:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall"); F.marks:SetPoint("BOTTOMLEFT", 0, 4); F.marks:SetPoint("BOTTOMRIGHT", 0, 4)
  F.marks:SetJustifyH("LEFT")
  F:Hide()
end

function D:Refresh()
  if not F or not F:IsShown() then return end
  local c, v = self.db.c, self.db.v
  local ch = DoD_Chapters[c]
  F.icon:SetTexture(icon(c))
  F.book:SetText("|cffb98cffBook " .. ch.book .. ": " .. DoD_Books[ch.book] .. "|r")
  F.chap:SetText("Chapter " .. c .. ": " .. ch.title)
  F.meta:SetText(string.format("%d hand-written verses  ·  %s by the Verse Engine", #ch.v, "the rest"))
  local raw, canon = E.Verse(c, v)
  F.ref:SetText(string.format("|cffe0c4ffDevotion %d:%d|r", c, v))
  F.kind:SetText(canon and "|cffe8d44dHand-written scripture|r" or "Verse Engine")
  F.text:SetText((raw or ""):gsub("{target}", targetName() or FALLBACK))
  local st = self.state == "running" and "|cff9be15dReading aloud|r" or self.state == "paused" and "|cffe8d44dPaused|r"
    or self.state == "waiting" and "|cffff8080Waiting (combat / lockdown)|r" or "|cffaaaaaaIdle|r"
  F.status:SetText(st)
  F.play:SetText((self.state == "running" or self.state == "waiting") and "Pause" or (self.state == "paused" and "Resume" or "Play"))
  for k, b in pairs(F.chanBtns) do if k == self.db.channel then b:LockHighlight() else b:UnlockHighlight() end end
  local key, marked = c .. ":" .. v, false
  for _, b in ipairs(self.db.bookmarks) do if b == key then marked = true end end
  F.mark:SetText(marked and "Unmark" or "Bookmark")
  F.marks:SetText(#self.db.bookmarks > 0 and ("Bookmarks: " .. table.concat(self.db.bookmarks, ", ", 1, math.min(12, #self.db.bookmarks))) or "No bookmarks yet.  ·  /dod help")
  for i, r in pairs(ROWS) do if i == c then r.sel:Show() else r.sel:Hide() end end
end

function D:TogglePanel()
  self:Build()
  if F:IsShown() then F:Hide() else F:Show(); self:Refresh() end
end

---------------------------------------------------------------------------
-- Slash commands
---------------------------------------------------------------------------
local HELP = {
  "/dod  - open or close the Book",
  "/dod read 42:7731  - perform one verse now (also: /dod read 42 for verse 1)",
  "/dod play [42:1]  - read aloud verse by verse from your place (or from 42:1)",
  "/dod pause | resume | stop | next | prev",
  "/dod goto 42:7731  - turn to a verse without reading it",
  "/dod chapter 42  - turn to the start of a chapter",
  "/dod random  - perform a random verse",
  "/dod votd  - show the Verse of the Day (same for everyone today)",
  "/dod search <words>  - search the hand-written verses",
  "/dod mark  - bookmark or unbookmark the current verse;  /dod marks  - list bookmarks",
  "/dod channel emote|say|party|guild  - where single verses are spoken",
  "/dod interval 15  - seconds between verses (5-60);  /dod dice  - random timing",
  "/dod chapters  - list all 100 chapters",
}

SLASH_DISCIPLESOFDEVOTION1 = "/dod"
SLASH_DISCIPLESOFDEVOTION2 = "/devotion"
SlashCmdList.DISCIPLESOFDEVOTION = function(input)
  local cmd, rest = (input or ""):match("^%s*(%S*)%s*(.-)%s*$")
  cmd = (cmd or ""):lower()
  if cmd == "" then D:TogglePanel()
  elseif cmd == "help" then for _, h in ipairs(HELP) do msg(h) end
  elseif cmd == "read" or cmd == "verse" then
    local c, v = parseRef(rest)
    if c then D:Set(c, v); D:Perform(c, v) else D:Perform() end
  elseif cmd == "play" or cmd == "start" then D:Play(parseRef(rest))
  elseif cmd == "pause" then D:Pause()
  elseif cmd == "resume" then D:Resume()
  elseif cmd == "stop" then D:Stop()
  elseif cmd == "next" then D:Step(1); msg("Devotion " .. D.db.c .. ":" .. D.db.v)
  elseif cmd == "prev" then D:Step(-1); msg("Devotion " .. D.db.c .. ":" .. D.db.v)
  elseif cmd == "goto" then local c, v = parseRef(rest); if c then D:Set(c, v); msg("Turned to Devotion " .. D.db.c .. ":" .. D.db.v .. ".") else msg("Usage: /dod goto 42:7731") end
  elseif cmd == "chapter" then local c = tonumber(rest); if c then D:Set(c, 1); msg("Chapter " .. D.db.c .. ": " .. DoD_Chapters[D.db.c].title) end
  elseif cmd == "random" then local c, v = math.random(1, E.CHAPTERS), math.random(1, E.PER_CHAPTER); D:Set(c, v); D:Perform(c, v)
  elseif cmd == "votd" then D:VOTD()
  elseif cmd == "search" then D:Search(rest)
  elseif cmd == "mark" then D:Bookmark()
  elseif cmd == "marks" then msg(#D.db.bookmarks > 0 and table.concat(D.db.bookmarks, ", ") or "No bookmarks.")
  elseif cmd == "channel" then
    local ch = rest:upper()
    if ch == "EMOTE" or ch == "SAY" or ch == "PARTY" or ch == "GUILD" then D.db.channel = ch; D:Refresh(); msg("Single verses will be spoken in " .. ch:lower() .. ".")
    else msg("Usage: /dod channel emote|say|party|guild") end
  elseif cmd == "interval" then local n = tonumber(rest); if n then D.db.interval = math.max(5, math.min(60, math.floor(n))); msg("Interval " .. D.db.interval .. "s.") end
  elseif cmd == "dice" then D.db.dice = not D.db.dice; msg("Random timing " .. (D.db.dice and "on" or "off") .. ".")
  elseif cmd == "chapters" then for c = 1, E.CHAPTERS do if c % 10 == 1 then msg("|cffb98cff" .. DoD_Books[(c - 1) / 10 + 1] .. "|r") end msg(c .. ". " .. DoD_Chapters[c].title) end
  else msg("Unknown command. Type /dod help.") end
end

function DisciplesOfDevotion_OnAddonCompartmentClick() D:TogglePanel() end

---------------------------------------------------------------------------
-- Events
---------------------------------------------------------------------------
local ev = CreateFrame("Frame")
ev:RegisterEvent("ADDON_LOADED")
ev:RegisterEvent("PLAYER_LOGIN")
ev:RegisterEvent("PLAYER_TARGET_CHANGED")
ev:SetScript("OnEvent", function(_, event, arg1)
  if event == "ADDON_LOADED" and arg1 == ADDON then
    DisciplesOfDevotionDB = DisciplesOfDevotionDB or {}
    for k, v in pairs(defaults) do if DisciplesOfDevotionDB[k] == nil then DisciplesOfDevotionDB[k] = v end end
    D.db = DisciplesOfDevotionDB
  elseif event == "PLAYER_LOGIN" then
    msg("The Book is open. 100 chapters, 1,000,000 verses. Type |cffe0c4ff/dod|r. Glory to Xal'Reth.")
    if D.db.votdShown ~= today() then D.db.votdShown = today(); D:VOTD() end
  elseif event == "PLAYER_TARGET_CHANGED" and D.db then
    D:Refresh()
  end
end)
