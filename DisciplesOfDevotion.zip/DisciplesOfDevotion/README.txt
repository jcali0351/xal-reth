DISCIPLES OF DEVOTION  v2.0  -  The scripture of Xal'Reth, read aloud
=======================================================================
World of Warcraft Retail (Midnight 12.1)

100 chapters in 10 Books. 10,000 verses in every chapter: 1,000,000 verses.
Each chapter opens with the hand-written scripture of the Coil (2,349 verses
gathered from the Canon, Chronicle, Legends, Teachings, Rites, Scripture,
Codex and the Politics of Begging). The rest are built by the Verse Engine
from hand-written pieces. Devotion 42:7731 is the same verse on every computer.

INSTALL
  Move the "DisciplesOfDevotion" folder into
    World of Warcraft\_retail_\Interface\AddOns\
  Restart WoW fully (the icons load on a full restart).

THE BOOK  (/dod)
  Left: all 100 chapters with their icons, grouped by Book.
  Right: the current verse, reading controls, Perform This Verse,
  channel (Emote / Say / Party / Guild), Go to chapter:verse, Random,
  Verse of the Day, timer slider, bookmarks.

COMMANDS  (/dod help)
  /dod read 42:7731     perform one verse now
  /dod play [42:1]      read aloud verse by verse (as emotes)
  /dod pause | resume | stop | next | prev
  /dod goto 42:7731     turn to a verse    /dod chapter 42
  /dod random           perform a random verse
  /dod votd             Verse of the Day (same for everyone today)
  /dod search <words>   search the hand-written verses
  /dod mark | marks     bookmarks
  /dod channel emote|say|party|guild   (for single verses)
  /dod interval 15      /dod dice
  /dod chapters

Reading pauses in combat and during boss encounter chat lockdown, then
continues on the same verse. Use your target and their name is read in.
Glory to Xal'Reth.
