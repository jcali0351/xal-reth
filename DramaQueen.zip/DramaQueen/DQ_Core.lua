-- Drama Queen :: deadpan personal drama in guild chat on a timer.
-- * One post every 5 minutes (adjustable 1-60), no limit, keeps going while AFK.
-- * 6,000 one-off updates plus multi-part storylines posted on consecutive ticks.
-- * Never names real players or asks anyone for money. Pauses in combat and during encounter chat lockdown.
-- * Only one copy in the guild speaks at a time (elected over addon messages).
-- * 2.5: also acts it out as an /emote (automatic) and says it in /say. Blizzard only allows
--   automatic /say inside instances; in the open world the line waits on a "Say it" button
--   or key binding (one press).

local ADDON = ...
local PREFIX = "DramaQueen"
local D = DQ_DATA
local DB
local PINK = "|cffff4fa3"

local function msg(t) DEFAULT_CHAT_FRAME:AddMessage(PINK .. "[Drama Queen]|r " .. t) end
local function me() return (UnitName("player")) end
local function short(n) return type(n) == "string" and (n:gsub("%-.*", "")) or nil end

-- Midnight (12.0+): use C_ChatInfo.SendChatMessage; the old global only exists with a fallback CVar.
local function SendChat(text, channel)
  local fn = (C_ChatInfo and C_ChatInfo.SendChatMessage) or SendChatMessage
  if not fn then return false, "no chat API" end
  return pcall(fn, text, channel)
end

local function defaults()
  DramaQueenDB = DramaQueenDB or {}
  DB = DramaQueenDB
  local d = { enabled = true, minutes = 5, sagaChance = 30, pos = 1, sagaNext = 1, posted = 0, mainVoice = false, order = nil,
              toGuild = true, toEmote = true, toSay = true, sayButton = true }
  for k, v in pairs(d) do if DB[k] == nil then DB[k] = v end end
  -- a shuffled order so lines don't repeat until all 5,000 have been used
  if type(DB.order) ~= "table" or #DB.order ~= #D.lines then
    local o = {}; for i = 1, #D.lines do o[i] = i end
    for i = #o, 2, -1 do local j = math.random(i); o[i], o[j] = o[j], o[i] end
    DB.order, DB.pos = o, 1
  end
end

---------------------------------------------------------------- one voice per guild
local peers, lastErr = {}, 0
local function prio() return DB.mainVoice and 2 or 1 end
local function sendAddon(t) if IsInGuild() then pcall(C_ChatInfo.SendAddonMessage, PREFIX, t, "GUILD") end end
local function leader()
  local best, bp, now = me(), prio(), GetTime()
  for n, p in pairs(peers) do
    if now - p.t > 150 then peers[n] = nil
    elseif p.prio > bp or (p.prio == bp and n < best) then best, bp = n, p.prio end
  end
  return best
end
local function lockdown() return C_ChatInfo and C_ChatInfo.InChatMessagingLockdown and C_ChatInfo.InChatMessagingLockdown() end
local function canSpeak() return DB.enabled and IsInGuild() and not InCombatLockdown() and not lockdown() and leader() == me() end

---------------------------------------------------------------- drama
local saga, sagaPart = nil, 0
local nextPost = 0
local Refresh = function() end

local function nextLine()
  if saga then
    sagaPart = sagaPart + 1
    local t = D.sagas[saga][sagaPart]
    if sagaPart >= #D.sagas[saga] then saga, sagaPart = nil, 0 end
    return t
  end
  if #D.sagas > 0 and math.random(100) <= DB.sagaChance then
    saga, sagaPart = DB.sagaNext, 0
    DB.sagaNext = DB.sagaNext % #D.sagas + 1
    return nextLine()
  end
  local t = D.lines[DB.order[DB.pos]]
  DB.pos = DB.pos % #DB.order + 1
  return t
end

local ACTIONS = { "sighs.", "stares at their phone.", "rubs their temples.", "takes a long, slow breath.", "shakes their head slowly.",
  "looks up from their phone.", "laughs without smiling.", "goes very quiet for a moment.", "sets their drink down.", "wipes their eyes.",
  "stares into the middle distance.", "pinches the bridge of their nose.", "lets out a shaky breath.", "puts their phone face down.",
  "exhales through their teeth.", "looks around to see who is listening." }
local pendingSay
local ShowSay = function() end

local function emoteLine(text)
  local e = ACTIONS[math.random(#ACTIONS)] .. ' "' .. text .. '"'
  if #e > 255 then e = text end
  return e
end

local function sayNow(text)
  local ok, err = SendChat(text, "SAY")
  if not ok and GetTime() - lastErr > 60 then lastErr = GetTime(); msg("|cffff5555could not /say:|r " .. tostring(err)) end
  return ok
end

local function post(manual)
  if not manual and not canSpeak() then return false end
  if not IsInGuild() then msg("You are not in a guild. Drama requires an audience."); return false end
  local text = nextLine()
  local ok, err = true, nil
  if DB.toGuild then ok, err = SendChat(text, "GUILD") end
  if DB.toEmote then
    local eok, eerr = SendChat(emoteLine(text), "EMOTE")
    if not DB.toGuild then ok, err = eok, eerr end
  end
  if DB.toSay then
    if IsInInstance() then sayNow(text)          -- allowed automatically inside dungeons and raids
    else pendingSay = text; ShowSay() end        -- open world: needs one key or button press
  end
  if ok then
    DB.posted = DB.posted + 1
    DB.last = text
  elseif GetTime() - lastErr > 60 then
    lastErr = GetTime(); msg("|cffff5555could not post:|r " .. tostring(err))
  end
  nextPost = GetTime() + DB.minutes * 60
  Refresh()
  return ok
end

local function tick()
  if not DB or not DB.enabled then return end
  if GetTime() >= nextPost then
    if canSpeak() then post(false) else nextPost = GetTime() + 15 end
  end
  Refresh()
end

---------------------------------------------------------------- the "Say it" button (open world)
local sb = CreateFrame("Button", "DramaQueenSayButton", UIParent, "UIPanelButtonTemplate")
sb:SetSize(220, 34); sb:SetPoint("CENTER", 0, 180); sb:SetFrameStrata("HIGH"); sb:Hide()
sb:SetMovable(true); sb:RegisterForDrag("LeftButton"); sb:SetClampedToScreen(true)
sb:SetScript("OnDragStart", sb.StartMoving); sb:SetScript("OnDragStop", sb.StopMovingOrSizing)
sb:SetText("|cffff4fa3Say it|r")
local glow = sb:CreateTexture(nil, "BACKGROUND"); glow:SetPoint("TOPLEFT", -8, 8); glow:SetPoint("BOTTOMRIGHT", 8, -8)
glow:SetColorTexture(1, 0.31, 0.64, 0.35)
local pulse = glow:CreateAnimationGroup(); pulse:SetLooping("BOUNCE")
local fade = pulse:CreateAnimation("Alpha"); fade:SetFromAlpha(0.2); fade:SetToAlpha(1); fade:SetDuration(0.8)
sb:SetScript("OnEnter", function(self)
  GameTooltip:SetOwner(self, "ANCHOR_TOP"); GameTooltip:AddLine("Drama Queen: click to say it", 1, 0.31, 0.64)
  GameTooltip:AddLine(pendingSay or "", 1, 1, 1, true); GameTooltip:AddLine("Drag to move. Right-click to skip.", 0.6, 0.6, 0.6); GameTooltip:Show()
end)
sb:SetScript("OnLeave", function() GameTooltip:Hide() end)
sb:RegisterForClicks("LeftButtonUp", "RightButtonUp")
function DramaQueen_Say()
  if not pendingSay then msg("Nothing to say yet. Patience; the drama is coming."); return end
  if InCombatLockdown() then msg("Not in combat."); return end
  if sayNow(pendingSay) then pendingSay = nil; sb:Hide(); pulse:Stop() end
end
sb:SetScript("OnClick", function(_, button)
  if button == "RightButton" then pendingSay = nil; sb:Hide(); pulse:Stop() else DramaQueen_Say() end
end)
ShowSay = function()
  if DB.sayButton and pendingSay then sb:Show(); pulse:Play() end
end
BINDING_HEADER_DRAMAQUEEN = "Drama Queen"
BINDING_NAME_DRAMAQUEEN_SAY = "Say the waiting drama (/say)"

---------------------------------------------------------------- small panel
local f = CreateFrame("Frame", "DramaQueenFrame", UIParent, "BackdropTemplate")
f:SetSize(380, 210); f:SetPoint("CENTER"); f:SetFrameStrata("HIGH"); f:Hide()
f:SetMovable(true); f:EnableMouse(true); f:RegisterForDrag("LeftButton")
f:SetScript("OnDragStart", f.StartMoving); f:SetScript("OnDragStop", f.StopMovingOrSizing)
f:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 16,
  insets = { left = 4, right = 4, top = 4, bottom = 4 } })
f:SetBackdropColor(0.12, 0.02, 0.08, 0.95); f:SetBackdropBorderColor(1, 0.31, 0.64)
tinsert(UISpecialFrames, "DramaQueenFrame")
CreateFrame("Button", nil, f, "UIPanelCloseButton"):SetPoint("TOPRIGHT", -2, -2)
local title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalHuge"); title:SetPoint("TOP", 0, -14)
title:SetText(PINK .. "Drama Queen|r")
local status = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); status:SetPoint("TOP", title, "BOTTOM", 0, -6)
local last = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); last:SetPoint("TOPLEFT", 16, -66)
last:SetWidth(348); last:SetJustifyH("LEFT"); last:SetHeight(60); last:SetJustifyV("TOP")
local function btn(label, w, fn) local b = CreateFrame("Button", nil, f, "UIPanelButtonTemplate"); b:SetSize(w, 24); b:SetText(label); b:SetScript("OnClick", fn); return b end
local onOff = btn("", 110, function() DB.enabled = not DB.enabled; if DB.enabled then nextPost = GetTime() + 5 end; Refresh() end)
onOff:SetPoint("BOTTOMLEFT", 14, 44)
local now = btn("Cause drama now", 140, function() post(true) end); now:SetPoint("LEFT", onOff, "RIGHT", 6, 0)
local mv = btn("", 100, function() DB.mainVoice = not DB.mainVoice; sendAddon("HB:" .. prio()); Refresh() end); mv:SetPoint("LEFT", now, "RIGHT", 6, 0)
local slow = btn("- 1 min", 80, function() DB.minutes = math.max(1, DB.minutes - 1); nextPost = math.min(nextPost, GetTime() + DB.minutes * 60); Refresh() end)
slow:SetPoint("BOTTOMLEFT", 14, 14)
local fast = btn("+ 1 min", 80, function() DB.minutes = math.min(60, DB.minutes + 1); Refresh() end); fast:SetPoint("LEFT", slow, "RIGHT", 6, 0)
local foot = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall"); foot:SetPoint("BOTTOMRIGHT", -14, 20); foot:SetText("/dq help")

Refresh = function()
  if not DB or not f:IsShown() then return end
  local secs = math.max(0, math.floor(nextPost - GetTime()))
  local L = leader()
  status:SetText((DB.enabled and ("Every %d min  ·  next in %d:%02d  ·  posts %d"):format(DB.minutes, secs / 60, secs % 60, DB.posted) or "|cff888888Off|r") ..
    (L ~= me() and ("\n|cffffcc55" .. L .. " is causing the drama (one voice per guild)|r") or ""))
  last:SetText("|cffff9fd0Last:|r " .. (DB.last or "Nothing yet."))
  onOff:SetText(DB.enabled and "Turn off" or "Turn on")
  mv:SetText(DB.mainVoice and "Main voice: on" or "Main voice: off")
end
f:SetScript("OnShow", Refresh)

---------------------------------------------------------------- events and commands
local ev = CreateFrame("Frame")
for _, e in ipairs({ "ADDON_LOADED", "PLAYER_LOGIN", "CHAT_MSG_ADDON" }) do ev:RegisterEvent(e) end
ev:SetScript("OnEvent", function(_, event, a1, a2, a3, a4)
  if event == "ADDON_LOADED" then
    if a1 == ADDON then defaults(); C_ChatInfo.RegisterAddonMessagePrefix(PREFIX) end
  elseif event == "PLAYER_LOGIN" then
    sendAddon("PING"); sendAddon("HB:" .. prio())
    nextPost = GetTime() + 45
    C_Timer.NewTicker(1, tick)
    C_Timer.NewTicker(60, function() sendAddon("HB:" .. prio()) end)
    msg("Drama Queen 2.5 (guild, emote and say) loaded. First post in 45 seconds, then every " .. DB.minutes .. " minutes. /dq to open.")
  elseif event == "CHAT_MSG_ADDON" and DB then
    if a1 ~= PREFIX or a3 ~= "GUILD" then return end
    local who = short(a4); if not who or who == me() then return end
    if a2 == "PING" then sendAddon("HB:" .. prio()); return end
    local p = a2:match("^HB:(%d)"); if p then peers[who] = { prio = tonumber(p), t = GetTime() } end
  end
end)

SLASH_DRAMAQUEEN1 = "/dq"
SLASH_DRAMAQUEEN2 = "/drama"
SlashCmdList.DRAMAQUEEN = function(arg)
  arg = (arg or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")
  local n = tonumber(arg:match("^every%s+(%d+)$"))
  if arg == "" then f:SetShown(not f:IsShown())
  elseif arg == "now" then post(true)
  elseif arg == "on" then DB.enabled = true; nextPost = GetTime() + 5; msg("Drama resumes.")
  elseif arg == "off" then DB.enabled = false; msg("Drama off.")
  elseif n then DB.minutes = math.max(1, math.min(60, n)); nextPost = math.min(nextPost, GetTime() + DB.minutes * 60); msg("Drama every " .. DB.minutes .. " minutes.")
  elseif arg == "say" then DramaQueen_Say()
  elseif arg == "guild" then DB.toGuild = not DB.toGuild; msg("Guild chat: " .. (DB.toGuild and "on" or "off"))
  elseif arg == "emote" then DB.toEmote = not DB.toEmote; msg("Emote: " .. (DB.toEmote and "on" or "off"))
  elseif arg == "saymode" then DB.toSay = not DB.toSay; if not DB.toSay then pendingSay = nil; sb:Hide() end; msg("/say: " .. (DB.toSay and "on" or "off"))
  elseif arg == "main" then DB.mainVoice = not DB.mainVoice; sendAddon("HB:" .. prio()); msg("Main voice " .. (DB.mainVoice and "on" or "off"))
  elseif arg == "status" then
    local L = leader()
    msg(("Guild %s  ·  Emote %s  ·  Say %s%s"):format(DB.toGuild and "on" or "off", DB.toEmote and "on" or "off", DB.toSay and "on" or "off", pendingSay and "  ·  a line is waiting: /dq say" or ""))
    msg(("On: %s  ·  every %d min  ·  next in %ds  ·  posts %d  ·  voice: %s%s"):format(tostring(DB.enabled), DB.minutes, math.floor(nextPost - GetTime()), DB.posted, L, L == me() and " (you)" or ""))
  else
    msg("/dq - panel  ·  /dq now - drama now  ·  /dq say - say the waiting line  ·  /dq on | off  ·  /dq every 5")
    msg("/dq guild · /dq emote · /dq saymode - toggle each channel  ·  /dq main - make this character the voice  ·  /dq status")
  end
end
