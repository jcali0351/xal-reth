-- Drama Queen Pro 3.0 :: deadpan personal drama in guild chat on a timer, with a Queen Detector.
-- * One post every 5 minutes (adjustable 1-60), no limit, keeps going while AFK.
-- * 6,000 one-off updates plus multi-part storylines posted on consecutive ticks.
-- * Never names real players or asks anyone for money. Pauses in combat and during encounter chat lockdown.
-- * Only one copy in the guild speaks at a time (elected over addon messages).
-- * 2.5: also acts it out as an /emote (automatic) and says it in /say. Blizzard only allows
--   automatic /say inside instances; in the open world the line waits on a "Say it" button
--   or key binding (one press).

local ADDON = ...
local PREFIX = "DramaQueen"
local D = DQ_DATA
local DB
local PINK = "|cffff4fa3"

local function msg(t) DEFAULT_CHAT_FRAME:AddMessage(PINK .. "[Drama Queen Pro]|r " .. t) end
local function me() return (UnitName("player")) end
local function short(n) return type(n) == "string" and (n:gsub("%-.*", "")) or nil end

-- Midnight (12.0+): use C_ChatInfo.SendChatMessage; the old global only exists with a fallback CVar.
local function SendChat(text, channel)
  local fn = (C_ChatInfo and C_ChatInfo.SendChatMessage) or SendChatMessage
  if not fn then return false, "no chat API" end
  return pcall(fn, text, channel)
end

local function defaults()
  DramaQueenDB = DramaQueenDB or {}
  DB = DramaQueenDB
  local d = { enabled = true, minutes = 5, sagaChance = 30, pos = 1, sagaNext = 1, posted = 0, mainVoice = false, order = nil,
              toGuild = true, toEmote = true, toSay = true, sayButton = true }
  for k, v in pairs(d) do if DB[k] == nil then DB[k] = v end end
  -- a shuffled order so lines don't repeat until all 5,000 have been used
  if type(DB.order) ~= "table" or #DB.order ~= #D.lines then
    local o = {}; for i = 1, #D.lines do o[i] = i end
    for i = #o, 2, -1 do local j = math.random(i); o[i], o[j] = o[j], o[i] end
    DB.order, DB.pos = o, 1
  end
end

---------------------------------------------------------------- one voice per guild
local peers, lastErr = {}, 0
local function prio() return DB.mainVoice and 2 or 1 end
local function sendAddon(t) if IsInGuild() then pcall(C_ChatInfo.SendAddonMessage, PREFIX, t, "GUILD") end end
local function leader()
  local best, bp, now = me(), prio(), GetTime()
  for n, p in pairs(peers) do
    if now - p.t > 150 then peers[n] = nil
    elseif p.prio > bp or (p.prio == bp and n < best) then best, bp = n, p.prio end
  end
  return best
end
local function lockdown() return C_ChatInfo and C_ChatInfo.InChatMessagingLockdown and C_ChatInfo.InChatMessagingLockdown() end
local function canSpeak() return DB.enabled and IsInGuild() and not InCombatLockdown() and not lockdown() and leader() == me() end

---------------------------------------------------------------- drama
local saga, sagaPart = nil, 0
local nextPost = 0
local Refresh = function() end

local function nextLine()
  if saga then
    sagaPart = sagaPart + 1
    local t = D.sagas[saga][sagaPart]
    if sagaPart >= #D.sagas[saga] then saga, sagaPart = nil, 0 end
    return t
  end
  if #D.sagas > 0 and math.random(100) <= DB.sagaChance then
    saga, sagaPart = DB.sagaNext, 0
    DB.sagaNext = DB.sagaNext % #D.sagas + 1
    return nextLine()
  end
  local t = D.lines[DB.order[DB.pos]]
  DB.pos = DB.pos % #DB.order + 1
  return t
end

local ACTIONS = { "sighs.", "stares at their phone.", "rubs their temples.", "takes a long, slow breath.", "shakes their head slowly.",
  "looks up from their phone.", "laughs without smiling.", "goes very quiet for a moment.", "sets their drink down.", "wipes their eyes.",
  "stares into the middle distance.", "pinches the bridge of their nose.", "lets out a shaky breath.", "puts their phone face down.",
  "exhales through their teeth.", "looks around to see who is listening." }
local pendingSay
local ShowSay = function() end

local function emoteLine(text)
  local e = ACTIONS[math.random(#ACTIONS)] .. ' "' .. text .. '"'
  if #e > 255 then e = text end
  return e
end

local function sayNow(text)
  local ok, err = SendChat(text, "SAY")
  if not ok and GetTime() - lastErr > 60 then lastErr = GetTime(); msg("|cffff5555could not /say:|r " .. tostring(err)) end
  return ok
end

local function post(manual)
  if not manual and not canSpeak() then return false end
  if not IsInGuild() then msg("You are not in a guild. Drama requires an audience."); return false end
  local text = nextLine()
  local ok, err = true, nil
  if DB.toGuild then ok, err = SendChat(text, "GUILD") end
  if DB.toEmote then
    local eok, eerr = SendChat(emoteLine(text), "EMOTE")
    if not DB.toGuild then ok, err = eok, eerr end
  end
  if DB.toSay then
    if IsInInstance() then sayNow(text)          -- allowed automatically inside dungeons and raids
    else pendingSay = text; ShowSay() end        -- open world: needs one key or button press
  end
  if ok then
    DB.posted = DB.posted + 1
    DB.last = text
  elseif GetTime() - lastErr > 60 then
    lastErr = GetTime(); msg("|cffff5555could not post:|r " .. tostring(err))
  end
  nextPost = GetTime() + DB.minutes * 60
  Refresh()
  return ok
end

local function tick()
  if not DB or not DB.enabled then return end
  if GetTime() >= nextPost then
    if canSpeak() then post(false) else nextPost = GetTime() + 15 end
  end
  Refresh()
end

---------------------------------------------------------------- the "Say it" button (open world)
local sb = CreateFrame("Button", "DramaQueenSayButton", UIParent, "UIPanelButtonTemplate")
sb:SetSize(220, 34); sb:SetPoint("CENTER", 0, 180); sb:SetFrameStrata("HIGH"); sb:Hide()
sb:SetMovable(true); sb:RegisterForDrag("LeftButton"); sb:SetClampedToScreen(true)
sb:SetScript("OnDragStart", sb.StartMoving); sb:SetScript("OnDragStop", sb.StopMovingOrSizing)
sb:SetText("|cffff4fa3Say it|r")
local glow = sb:CreateTexture(nil, "BACKGROUND"); glow:SetPoint("TOPLEFT", -8, 8); glow:SetPoint("BOTTOMRIGHT", 8, -8)
glow:SetColorTexture(1, 0.31, 0.64, 0.35)
local pulse = glow:CreateAnimationGroup(); pulse:SetLooping("BOUNCE")
local fade = pulse:CreateAnimation("Alpha"); fade:SetFromAlpha(0.2); fade:SetToAlpha(1); fade:SetDuration(0.8)
sb:SetScript("OnEnter", function(self)
  GameTooltip:SetOwner(self, "ANCHOR_TOP"); GameTooltip:AddLine("Drama Queen: click to say it", 1, 0.31, 0.64)
  GameTooltip:AddLine(pendingSay or "", 1, 1, 1, true); GameTooltip:AddLine("Drag to move. Right-click to skip.", 0.6, 0.6, 0.6); GameTooltip:Show()
end)
sb:SetScript("OnLeave", function() GameTooltip:Hide() end)
sb:RegisterForClicks("LeftButtonUp", "RightButtonUp")
function DramaQueen_Say()
  if not pendingSay then msg("Nothing to say yet. Patience; the drama is coming."); return end
  if InCombatLockdown() then msg("Not in combat."); return end
  if sayNow(pendingSay) then pendingSay = nil; sb:Hide(); pulse:Stop() end
end
sb:SetScript("OnClick", function(_, button)
  if button == "RightButton" then pendingSay = nil; sb:Hide(); pulse:Stop() else DramaQueen_Say() end
end)
ShowSay = function()
  if DB.sayButton and pendingSay then sb:Show(); pulse:Play() end
end
BINDING_HEADER_DRAMAQUEEN = "Drama Queen"
BINDING_NAME_DRAMAQUEEN_SAY = "Say the waiting drama (/say)"

---------------------------------------------------------------- Queen Detector
-- Every copy says hello over hidden addon messages (guild, group and the Drama Queen network channel),
-- so you can see who else is running Drama Queen Pro and how many of you there are.
local VERSION = "3.0"
local NETCHAN = "DramaQueenNet"
local queens = {}           -- name -> { where, ver, posts, t, first }
local lastHi = {}
local Toast = function() end

local function netId()
  if not DB or not DB.network then return nil end
  local id = GetChannelName(NETCHAN)
  return (id and id > 0) and id or nil
end
local function groupDist()
  if IsInGroup(LE_PARTY_CATEGORY_INSTANCE) then return "INSTANCE_CHAT" end
  if IsInRaid() then return "RAID" end
  if IsInGroup() then return "PARTY" end
end
local function sendTo(dist, text)
  if dist == "NETWORK" then
    local id = netId(); if id then pcall(C_ChatInfo.SendAddonMessage, PREFIX, text, "CHANNEL", id) end
  elseif dist then pcall(C_ChatInfo.SendAddonMessage, PREFIX, text, dist) end
end
local function hiText() return ("HI:%s:%d"):format(VERSION, DB.posted or 0) end
local function broadcast(text)
  if IsInGuild() then sendTo("GUILD", text) end
  sendTo(groupDist(), text)
  sendTo("NETWORK", text)
end
local function scan() broadcast("WHO"); broadcast(hiText()) end

local function joinNetwork()
  if not DB.network then return end
  if GetChannelName(NETCHAN) == 0 then pcall(JoinTemporaryChannel, NETCHAN) end
  -- keep the channel out of every chat window: it only carries hidden addon messages
  C_Timer.After(2, function()
    for i = 1, (NUM_CHAT_WINDOWS or 10) do
      local cf = _G["ChatFrame" .. i]
      if cf then
        if ChatFrame_RemoveChannel then pcall(ChatFrame_RemoveChannel, cf, NETCHAN)
        elseif ChatFrameUtil and ChatFrameUtil.RemoveChannel then pcall(ChatFrameUtil.RemoveChannel, cf, NETCHAN) end
      end
    end
    scan()
  end)
end
local function leaveNetwork() if GetChannelName(NETCHAN) > 0 then pcall(LeaveChannelByName, NETCHAN) end end

local WHERE = { GUILD = "Guild", PARTY = "Group", RAID = "Raid", INSTANCE_CHAT = "Instance", CHANNEL = "Network", WHISPER = "Whisper" }
local function seen(name, dist, ver, posts)
  local q = queens[name]
  local isNew = not q
  q = q or { first = GetTime() }
  q.where, q.ver, q.posts, q.t = WHERE[dist] or dist, ver or q.ver or "?", tonumber(posts) or q.posts or 0, GetTime()
  queens[name] = q
  if isNew then Toast(name, q.where) end
end
local function counts()
  local total, online, now = 0, 0, GetTime()
  for _, q in pairs(queens) do total = total + 1; if now - q.t < 300 then online = online + 1 end end
  return total, online
end

---------------------------------------------------------------- the panel (three tabs)
local f = CreateFrame("Frame", "DramaQueenFrame", UIParent, "BackdropTemplate")
f:SetSize(460, 340); f:SetPoint("CENTER"); f:SetFrameStrata("HIGH"); f:Hide()
f:SetMovable(true); f:EnableMouse(true); f:RegisterForDrag("LeftButton"); f:SetClampedToScreen(true)
f:SetScript("OnDragStart", f.StartMoving); f:SetScript("OnDragStop", f.StopMovingOrSizing)
f:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 16,
  insets = { left = 4, right = 4, top = 4, bottom = 4 } })
f:SetBackdropColor(0.12, 0.02, 0.08, 0.96); f:SetBackdropBorderColor(1, 0.31, 0.64)
tinsert(UISpecialFrames, "DramaQueenFrame")
CreateFrame("Button", nil, f, "UIPanelCloseButton"):SetPoint("TOPRIGHT", -2, -2)
local title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalHuge"); title:SetPoint("TOP", 0, -14)
title:SetText(PINK .. "Drama Queen Pro|r")
local queenCount = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); queenCount:SetPoint("TOP", title, "BOTTOM", 0, -4)

local pages, tabs = {}, {}
local function page(name)
  local p = CreateFrame("Frame", nil, f); p:SetPoint("TOPLEFT", 10, -88); p:SetPoint("BOTTOMRIGHT", -10, 10); p:Hide()
  pages[name] = p; return p
end
local function showTab(name)
  for n, p in pairs(pages) do p:SetShown(n == name) end
  for n, b in pairs(tabs) do b:SetEnabled(n ~= name) end
  DB.tab = name; Refresh()
end
local function tab(name, label, x)
  local b = CreateFrame("Button", nil, f, "UIPanelButtonTemplate"); b:SetSize(130, 24); b:SetPoint("TOPLEFT", x, -58)
  b:SetText(label); b:SetScript("OnClick", function() showTab(name) end); tabs[name] = b
end
tab("drama", "Drama", 20); tab("queens", "Queen Detector", 165); tab("settings", "Settings", 310)
local function btn(p, label, w, fn) local b = CreateFrame("Button", nil, p, "UIPanelButtonTemplate"); b:SetSize(w, 24); b:SetText(label); b:SetScript("OnClick", fn); return b end

-- Drama tab
local pd = page("drama")
local status = pd:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); status:SetPoint("TOPLEFT", 8, -6); status:SetWidth(424); status:SetJustifyH("LEFT")
local last = pd:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); last:SetPoint("TOPLEFT", 8, -48)
last:SetWidth(424); last:SetJustifyH("LEFT"); last:SetHeight(90); last:SetJustifyV("TOP")
local onOff = btn(pd, "", 110, function() DB.enabled = not DB.enabled; if DB.enabled then nextPost = GetTime() + 5 end; Refresh() end)
onOff:SetPoint("BOTTOMLEFT", 4, 40)
local now = btn(pd, "Cause drama now", 140, function() post(true) end); now:SetPoint("LEFT", onOff, "RIGHT", 6, 0)
local sayB = btn(pd, "Say waiting line", 140, function() DramaQueen_Say() end); sayB:SetPoint("LEFT", now, "RIGHT", 6, 0)
local slow = btn(pd, "- 1 min", 80, function() DB.minutes = math.max(1, DB.minutes - 1); nextPost = math.min(nextPost, GetTime() + DB.minutes * 60); Refresh() end)
slow:SetPoint("BOTTOMLEFT", 4, 8)
local fast = btn(pd, "+ 1 min", 80, function() DB.minutes = math.min(60, DB.minutes + 1); Refresh() end); fast:SetPoint("LEFT", slow, "RIGHT", 6, 0)
local foot = pd:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall"); foot:SetPoint("BOTTOMRIGHT", -6, 14); foot:SetText("/dq help")

-- Queen Detector tab
local pq = page("queens")
local qHead = pq:CreateFontString(nil, "OVERLAY", "GameFontNormal"); qHead:SetPoint("TOPLEFT", 8, -4); qHead:SetWidth(424); qHead:SetJustifyH("LEFT")
local cols = pq:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall"); cols:SetPoint("TOPLEFT", 8, -26)
cols:SetText("NAME                         SEEN IN        VERSION     POSTS     LAST SEEN")
local rows = {}
for i = 1, 9 do
  local r = pq:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); r:SetPoint("TOPLEFT", 8, -42 - (i - 1) * 17)
  r:SetWidth(424); r:SetJustifyH("LEFT"); rows[i] = r
end
local scanB = btn(pq, "Scan now", 100, function() scan(); msg("Scanning for other Drama Queens...") end); scanB:SetPoint("BOTTOMLEFT", 4, 8)
local clearB = btn(pq, "Clear list", 100, function() wipe(queens); Refresh() end); clearB:SetPoint("LEFT", scanB, "RIGHT", 6, 0)
local qNote = pq:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall"); qNote:SetPoint("BOTTOMRIGHT", -6, 14)
qNote:SetText("Detects copies in your guild, group and the network")

-- Settings tab
local ps = page("settings")
local checks = {}
local function check(key, label, y, fn)
  local cb = CreateFrame("CheckButton", nil, ps, "UICheckButtonTemplate"); cb:SetSize(24, 24); cb:SetPoint("TOPLEFT", 8, y)
  local t = cb:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); t:SetPoint("LEFT", cb, "RIGHT", 4, 0); t:SetText(label)
  cb:SetScript("OnClick", function(self) DB[key] = self:GetChecked() and true or false; if fn then fn() end; Refresh() end)
  cb.key = key; checks[#checks + 1] = cb
end
check("toGuild", "Post drama in guild chat", -4)
check("toEmote", "Act it out as an emote (everyone nearby sees it)", -30)
check("toSay", "Say it in /say (automatic in instances, one press outside)", -56, function() if not DB.toSay then pendingSay = nil; sb:Hide() end end)
check("mainVoice", "Main voice: this character does the posting for the guild", -82, function() sendAddon("HB:" .. prio()) end)
check("network", "Join the Drama Queen network to find queens outside your guild", -108, function() if DB.network then joinNetwork() else leaveNetwork() end end)
check("toasts", "Tell me when a new Drama Queen is detected", -134)
local sNote = ps:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall"); sNote:SetPoint("BOTTOMLEFT", 8, 12); sNote:SetWidth(424); sNote:SetJustifyH("LEFT")
sNote:SetText("The network is a hidden chat channel used only for addon messages; it is kept out of your chat windows. Use at your own risk: see the disclaimer on the website.")

local function ago(s) s = math.floor(s); if s < 60 then return s .. "s ago" elseif s < 3600 then return math.floor(s / 60) .. "m ago" end return math.floor(s / 3600) .. "h ago" end
local function pad(s, n) s = tostring(s); if #s > n then s = s:sub(1, n - 1) .. "." end return s .. string.rep(" ", n - #s) end

Refresh = function()
  if not DB or not f:IsShown() then return end
  local total, online = counts()
  queenCount:SetText(("|cffff9fd0%d other Drama Queen%s detected|r  ·  %d online now"):format(total, total == 1 and "" or "s", online))
  local secs = math.max(0, math.floor(nextPost - GetTime()))
  local L = leader()
  status:SetText((DB.enabled and ("Every %d min  ·  next in %d:%02d  ·  posts %d"):format(DB.minutes, math.floor(secs / 60), secs % 60, DB.posted) or "|cff888888Off|r") ..
    (L ~= me() and ("\n|cffffcc55" .. L .. " is causing the drama for your guild (one voice per guild)|r") or ""))
  last:SetText("|cffff9fd0Last:|r " .. (DB.last or "Nothing yet.") .. (pendingSay and ("\n\n|cffff9fd0Waiting to be said:|r " .. pendingSay) or ""))
  onOff:SetText(DB.enabled and "Turn off" or "Turn on")
  -- detector list, newest first
  local list = {}
  for n, q in pairs(queens) do list[#list + 1] = { n = n, q = q } end
  table.sort(list, function(a, b) return a.q.t > b.q.t end)
  qHead:SetText(total == 0 and "No other Drama Queens detected yet. Press Scan now, or wait: they check in every 2 minutes."
    or ("%d Drama Queen%s found. You are not alone."):format(total, total == 1 and "" or "s"))
  for i, r in ipairs(rows) do
    local e = list[i]
    if e then
      local on = GetTime() - e.q.t < 300
      r:SetText((on and "|cff7dff7d" or "|cff888888") .. pad(e.n, 22) .. "|r  " .. pad(e.q.where, 12) .. "  " .. pad(e.q.ver, 8) .. "  " .. pad(e.q.posts, 7) .. "  " .. ago(GetTime() - e.q.t))
    elseif i == #rows and #list > #rows then r:SetText(("... and %d more"):format(#list - #rows))
    else r:SetText("") end
  end
  for _, cb in ipairs(checks) do cb:SetChecked(DB[cb.key]) end
end
f:SetScript("OnShow", function() showTab(DB.tab or "drama") end)

Toast = function(name, where)
  if DB and DB.toasts then msg(("|cffff9fd0Another Drama Queen detected:|r %s (%s). Type /dq queens to see them all."):format(name, where)) end
  Refresh()
end

---------------------------------------------------------------- events and commands
local ev = CreateFrame("Frame")
for _, e in ipairs({ "ADDON_LOADED", "PLAYER_LOGIN", "CHAT_MSG_ADDON", "GROUP_ROSTER_UPDATE" }) do ev:RegisterEvent(e) end
ev:SetScript("OnEvent", function(_, event, a1, a2, a3, a4)
  if event == "ADDON_LOADED" then
    if a1 == ADDON then
      defaults(); C_ChatInfo.RegisterAddonMessagePrefix(PREFIX)
      for k, v in pairs({ network = true, toasts = true, tab = "drama" }) do if DB[k] == nil then DB[k] = v end end
    end
  elseif event == "PLAYER_LOGIN" then
    sendAddon("PING"); sendAddon("HB:" .. prio())
    nextPost = GetTime() + 45
    C_Timer.NewTicker(1, tick)
    C_Timer.NewTicker(60, function() sendAddon("HB:" .. prio()) end)
    C_Timer.NewTicker(120, function() broadcast(hiText()) end)
    C_Timer.After(8, joinNetwork)
    C_Timer.After(5, scan)
    msg("Drama Queen Pro " .. VERSION .. " loaded. First post in 45 seconds, then every " .. DB.minutes .. " minutes. /dq to open, /dq queens for the Queen Detector.")
  elseif event == "GROUP_ROSTER_UPDATE" and DB then
    local d = groupDist(); if d then sendTo(d, hiText()) end
  elseif event == "CHAT_MSG_ADDON" and DB then
    if a1 ~= PREFIX then return end
    if issecretvalue and (issecretvalue(a2) or issecretvalue(a4)) then return end
    local who = short(a4); if not who or who == me() then return end
    if a3 == "GUILD" then
      if a2 == "PING" then sendAddon("HB:" .. prio()) end
      local p = a2:match("^HB:(%d)"); if p then peers[who] = { prio = tonumber(p), t = GetTime() }; seen(who, "GUILD") end
    end
    if a2 == "WHO" then
      if not lastHi[a3] or GetTime() - lastHi[a3] > 10 then
        lastHi[a3] = GetTime()
        if a3 == "CHANNEL" then sendTo("NETWORK", hiText()) else sendTo(a3, hiText()) end
      end
      seen(who, a3)
    else
      local ver, posts = a2:match("^HI:([^:]+):(%d+)")
      if ver then seen(who, a3, ver, posts) end
    end
  end
end)

SLASH_DRAMAQUEEN1 = "/dq"
SLASH_DRAMAQUEEN2 = "/drama"
SlashCmdList.DRAMAQUEEN = function(arg)
  arg = (arg or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")
  local n = tonumber(arg:match("^every%s+(%d+)$"))
  if arg == "" then f:SetShown(not f:IsShown())
  elseif arg == "queens" or arg == "detect" or arg == "who" then f:Show(); showTab("queens"); scan()
  elseif arg == "scan" then scan(); msg("Scanning for other Drama Queens...")
  elseif arg == "network" then DB.network = not DB.network; if DB.network then joinNetwork() else leaveNetwork() end; msg("Drama Queen network: " .. (DB.network and "on" or "off"))
  elseif arg == "now" then post(true)
  elseif arg == "on" then DB.enabled = true; nextPost = GetTime() + 5; msg("Drama resumes.")
  elseif arg == "off" then DB.enabled = false; msg("Drama off.")
  elseif n then DB.minutes = math.max(1, math.min(60, n)); nextPost = math.min(nextPost, GetTime() + DB.minutes * 60); msg("Drama every " .. DB.minutes .. " minutes.")
  elseif arg == "say" then DramaQueen_Say()
  elseif arg == "guild" then DB.toGuild = not DB.toGuild; msg("Guild chat: " .. (DB.toGuild and "on" or "off"))
  elseif arg == "emote" then DB.toEmote = not DB.toEmote; msg("Emote: " .. (DB.toEmote and "on" or "off"))
  elseif arg == "saymode" then DB.toSay = not DB.toSay; if not DB.toSay then pendingSay = nil; sb:Hide() end; msg("/say: " .. (DB.toSay and "on" or "off"))
  elseif arg == "main" then DB.mainVoice = not DB.mainVoice; sendAddon("HB:" .. prio()); msg("Main voice " .. (DB.mainVoice and "on" or "off"))
  elseif arg == "status" then
    local L = leader()
    msg(("Guild %s  ·  Emote %s  ·  Say %s%s"):format(DB.toGuild and "on" or "off", DB.toEmote and "on" or "off", DB.toSay and "on" or "off", pendingSay and "  ·  a line is waiting: /dq say" or ""))
    local total, online = counts()
    msg(("Drama Queens detected: %d (%d online now)"):format(total, online))
    msg(("On: %s  ·  every %d min  ·  next in %ds  ·  posts %d  ·  voice: %s%s"):format(tostring(DB.enabled), DB.minutes, math.floor(nextPost - GetTime()), DB.posted, L, L == me() and " (you)" or ""))
  else
    msg("/dq - panel  ·  /dq now - drama now  ·  /dq say - say the waiting line  ·  /dq on | off  ·  /dq every 5")
    msg("/dq guild · /dq emote · /dq saymode - toggle each channel  ·  /dq main - make this character the voice  ·  /dq status")
    msg("/dq queens - Queen Detector  ·  /dq scan - look for other Drama Queens  ·  /dq network - join or leave the Drama Queen network")
  end
end
