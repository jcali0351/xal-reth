-- StoryCaster lore library: one more scene for a few sets.
local ADDON, ns = ...
local R = ns.R
R.LORE_MORE = R.LORE_MORE or {}
R.LORE_MORE.class = R.LORE_MORE.class or {}
R.LORE_MORE.faction = R.LORE_MORE.faction or {}
local C, F = R.LORE_MORE.class, R.LORE_MORE.faction

C.MAGE = (C.MAGE or "") .. [[
## The Night Sky
looks up and names the stars the way old astromancers taught them: the Shepherd, the Lantern, the Broken Crown.
says, "Every star is a ward someone forgot to take down. That is a joke. Mostly."
says, "Arcane is the study of patterns. The sky is the oldest pattern there is."
traces a constellation in the air, and faint violet lines linger where their finger passed.
says, "One day I will understand why that one blinks. Not today. But one day."
lets the lines fade, smiling at the dark. [chuckle]
]]

C.MONK = (C.MONK or "") .. [[
## The Rain
tilts their face up to a light rain and closes their eyes, letting it fall.
says, "Rain does not fight the mountain. It wears it down, one drop at a time."
says, "My master called that the slowest victory and the surest."
holds out a hand and catches a single drop, watching it run along the palm.
says, "Be like water. Soft, patient, and impossible to stop."
lets the drop fall and bows to the sky. [bow]
says, "Thank you, rain. Lesson received."
]]

C.DRUID = (C.DRUID or "") .. [[
## The Seed
kneels and presses a single acorn into the soft earth with one thumb. [kneel]
says, "Everything that will ever be a forest starts like this. Small, buried, and patient."
covers it gently and pats the soil flat.
says, "I will not live to see this tree grown. Someone will. That is the point."
murmurs a few words to the earth, and a tiny green shoot pushes up through the dirt.
says, "There. A little head start. Every child deserves one."
rises, brushing soil from their hands with quiet satisfaction.
]]

C.EVOKER = (C.EVOKER or "") .. [[
## The Hoard
admits, "Dragons keep hoards. I keep one too. It is very small."
counts the treasures off on clawed fingers: "A smooth river stone. A feather from a gryphon. A letter from a friend."
says, "The letter is the most valuable. It says I belong somewhere."
says, "Gold is very boring. Stories are not."
offers {target} a small shining scale from their own wrist. "Here. For your hoard."
smiles warmly as the scale catches the light. [chuckle]
says, "Now you have a dragon friend. Very few people can say that."
]]

F.Neutral = (F.Neutral or "") .. [[
## The Campfire Stories
sits by a small fire and stirs it with a stick, sending sparks up into the {time} air. [sit]
says, "I once shared a fire with an orc, a dwarf, and a very nervous gnome during a snowstorm."
says, "By morning we had told every story we knew and invented three more."
says, "The orc sang. The dwarf cried. The gnome fixed my boots."
says, "None of us asked about banners. It did not come up."
laughs softly at the memory. [laugh]
says, "That is the world I want. One long snowstorm full of good company."
]]
