-- StoryCaster: the Lore library. Ready-made roleplay for every class, faction and race,
-- picked from three dropdowns in the Lore window (/story lore). Loaded after the Lore*.lua files.
local ADDON, ns = ...
local R = ns.R
R.LORE = R.LORE or {}
R.LORE_MORE = R.LORE_MORE or {}

R.LORE_KINDS = { { "class", "Class" }, { "faction", "Faction" }, { "race", "Race" } }

local ORDER = {
  class = { "WARRIOR", "PALADIN", "HUNTER", "ROGUE", "PRIEST", "DEATHKNIGHT", "SHAMAN", "MAGE", "WARLOCK",
    "MONK", "DRUID", "DEMONHUNTER", "EVOKER" },
  faction = { "Alliance", "Horde", "Neutral" },
  race = { "Human", "Dwarf", "NightElf", "Gnome", "Draenei", "Worgen", "VoidElf", "LightforgedDraenei",
    "DarkIronDwarf", "KulTiran", "Mechagnome",
    "Orc", "Scourge", "Tauren", "Troll", "BloodElf", "Goblin", "Nightborne", "HighmountainTauren",
    "MagharOrc", "ZandalariTroll", "Vulpera",
    "Pandaren", "Dracthyr", "EarthenDwarf" },
}

-- every key of a kind that has lore, in the order above, then any others alphabetically
function R:LoreKeys(kind)
  local set, out, seen = self.LORE[kind] or {}, {}, {}
  for _, k in ipairs(ORDER[kind] or {}) do
    if set[k] then out[#out + 1] = k; seen[k] = true end
  end
  local extra = {}
  for k in pairs(set) do if not seen[k] then extra[#extra + 1] = k end end
  table.sort(extra)
  for _, k in ipairs(extra) do out[#out + 1] = k end
  return out
end

function R:LoreTitle(kind, key)
  local e = self.LORE[kind] and self.LORE[kind][key]
  return e and e[1] or tostring(key)
end

function R:LoreText(kind, key)
  local e = self.LORE[kind] and self.LORE[kind][key]
  if not e then return nil end
  local more = self.LORE_MORE[kind] and self.LORE_MORE[kind][key]
  return e[2] .. (more and ("\n" .. more) or "")
end

function R:LoreScript(kind, key)
  local text = self:LoreText(kind, key)
  if not text then return {} end
  return (self:Convert(text, "lines", false))
end

function R:LoreName(kind, key) return "Lore: " .. self:LoreTitle(kind, key) end

-- your own class, faction and race, as the starting choice in each dropdown
function R:LoreDefault(kind)
  local key
  if kind == "class" then key = UnitClass and select(2, UnitClass("player"))
  elseif kind == "race" then key = UnitRace and select(2, UnitRace("player"))
  elseif kind == "faction" then key = UnitFactionGroup and UnitFactionGroup("player") end
  if key and self.LORE[kind] and self.LORE[kind][key] then return key end
  return self:LoreKeys(kind)[1]
end

-- saves the set as "Lore: <title>" (refreshing it with the original text) and performs it
function R:PerformLore(kind, key)
  local name = self:LoreName(kind, key)
  local ok, msg = self:Save(name, self:LoreScript(kind, key))
  if not ok then self:Print(msg) return end
  self:Start(name)
end

function R:PreviewLore(kind, key)
  local script = self:LoreScript(kind, key)
  self:Print(("|cffffd100%s|r: %d lines"):format(self:LoreName(kind, key), #script))
  for i, l in ipairs(script) do
    self:Print(("%d. %s%s"):format(i, l[6] and ("|cffffd100## " .. l[6] .. "|r  ") or "",
      self.LineLabel and self:LineLabel(l) or self:LineToText(l)))
  end
end

-- finds a key by a typed name ("blood elf", "dk", "horde")
function R:FindLore(word)
  word = (word or ""):lower():gsub("[%s'%-]", "")
  if word == "" then return nil end
  local alias = { dk = "DEATHKNIGHT", dh = "DEMONHUNTER", undead = "Scourge", forsaken = "Scourge", earthen = "EarthenDwarf",
    neutral = "Neutral", unaligned = "Neutral" }
  for _, kd in ipairs(self.LORE_KINDS) do
    for _, k in ipairs(self:LoreKeys(kd[1])) do
      local t = self:LoreTitle(kd[1], k):lower():gsub("[%s'%-]", "")
      if k:lower() == word or t == word or (alias[word] and alias[word] == k) then return kd[1], k end
    end
  end
end
