-- StoryCaster lore library: further scenes for the classes and factions (added to the end of each set, before it is used).
local ADDON, ns = ...
local R = ns.R
R.LORE_MORE = R.LORE_MORE or {}
R.LORE_MORE.class = R.LORE_MORE.class or {}
R.LORE_MORE.faction = R.LORE_MORE.faction or {}
local C, F = R.LORE_MORE.class, R.LORE_MORE.faction

C.WARRIOR = [[
## The Long March Home
sits on a rock by the road and pulls off one boot, shaking out a stubborn pebble. [sit]
says, "Nobody sings about blisters. They should. Blisters have ended more campaigns than dragons."
laces the boot again, tight, double-knotted, the way the sergeant insisted.
recalls the nights on the march: cold stew, wet blankets, someone always snoring.
says, "You learn who your friends are at the fourth hour of a night watch."
says, "Good soldiers share the last of the bread. Great soldiers pretend they are not hungry."
rises and stretches until something in the back pops loudly. [flex]
## The Recruits
watches a young traveler pass and remembers being that green, that eager.
says, "I tell the new ones three things: keep your guard up, drink water, write home."
says, "They listen to the first two. Nobody listens about writing home until it is too late."
taps a folded letter in their belt pouch, the paper soft from rereading.
says, "My mother writes every month. I answer every month. That is my second oath."
## The Scar
pushes back a sleeve to show a long pale scar along the forearm.
says, "An axe at Hillsbrad. I thought I would lose the arm. I lost a bet instead."
says, "Every scar is a lesson I was too stubborn to learn the easy way."
lowers the sleeve. "I am a very well-educated warrior."
]]

C.PALADIN = [[
## The Squire
remembers being a squire: polishing armor until their fingers ached, carrying water, tending horses.
says, "My knight said a paladin who will not clean a stable will not clean a soul."
says, "I thought it was a saying. It was an instruction. I cleaned a great many stables."
smiles at the memory. [chuckle]
## The Charger
whistles softly, and the sound seems to call a horse only they can see.
says, "My charger has carried me through fire and frost. She has never once complained."
says, "She has, however, bitten two lords and a bishop. She has excellent judgment."
## Tyr's Hand
speaks of the Argent Crusade and the long vigil at the Light's Hope Chapel.
says, "When the Scourge rose, the Light did not care who had been a farmer or a prince."
says, "The Crusade took them all. Anyone who would hold a line against the dead."
says, "Tirion Fordring was exiled for showing mercy to an orc. He came back and saved us all."
says, "That is the lesson I keep closest: mercy is not weakness."
## The Healing Touch
kneels beside {target}, laying a gentle hand near any old wound. [kneel]
murmurs a short prayer, and warmth spreads beneath their palm.
says, "There. It will ache when it rains, but it will not hurt you anymore."
rises, brushing dust from their knees.
## The Quiet Hours
says, "The bards like the battles. I like the hours after."
says, "Rebuilding a wall. Teaching a child to read. Sitting with the dying so they are not alone."
says, "That is most of the oath, really. Being there."
]]

C.HUNTER = [[
## The Campfire
crouches to build a small fire, stacking twigs in a careful little lodge.
strikes a flint, and the first flame catches on dry moss.
says, "A good fire is small. Big fires are for people who want to be found."
roasts a strip of meat on a stick, turning it slowly.
says, "Boar from the hills. Clean, quick, no waste. The hide is curing back at camp."
offers a piece to {target}. "Eat. Hunters always cook too much. It is a superstition."
## The Lessons
says, "My mentor made me sit by a stream from dawn to dusk for a week."
says, "On the seventh day a heron caught a fish right in front of me and I finally understood."
says, "Stillness is not waiting. Stillness is hunting with your whole body."
## The Beasts
names companions of the past softly: a wolf, a hawk, a great slow turtle that outlived them all.
says, "Every one of them taught me something I could not have learned from people."
says, "The wolf taught loyalty. The hawk taught patience. The turtle taught me that hurrying is overrated."
laughs softly. [laugh]
## The Tracks of Others
spots a careless bootprint in the mud and shakes their head.
says, "City folk walk on their heels. You can hear them coming from the next valley."
says, "Walk on the outside of your foot. Roll it in. Like this."
demonstrates a silent, rolling step across the clearing.
## Respect
says, "I take only what I need, and I never take the mother with young."
says, "The land feeds those who respect it. It starves those who do not."
]]

C.ROGUE = [[
## The Disguise
pulls a hood low and, just like that, seems to become someone else: older, slower, forgettable.
says, "The best disguise is boredom. Nobody remembers a boring face."
pushes the hood back with a grin. "I have been a fishmonger, a priest, and once, briefly, a duchess."
says, "The duchess was the hardest. The shoes were murder."
## The Lockpick
produces a slim set of picks from a sleeve and spins one between their fingers.
says, "Every lock is a little puzzle. Every puzzle wants to be solved."
says, "I have never met a lock I could not open. I have met a few I chose not to."
tucks the picks away. "Some doors are locked for good reasons."
## The Crew
speaks of the crew they ran with: a dwarf with a gift for explosives, a gnome who could talk to any machine.
says, "We stole a tax collector's ledger and gave the money back to the people he cheated."
says, "Nobody ever found out it was us. The tax collector found a new career. In a different kingdom."
chuckles darkly. [chuckle]
## The Rooftops
looks up at the nearest rooftop with a familiar gleam in their eye.
says, "The city looks different from up there. Quieter. Honest, almost."
says, "You see who sneaks out at night. You see who leaves bread for the strays."
says, "The rooftops taught me that most people are better than they let on."
## The Warning
leans close to {target}. "If someone ever offers you a job that seems too easy, it is not a job."
says, "It is a trap with a nice smile. Trust me. I have been the nice smile."
]]

C.PRIEST = [[
## The Temple
remembers the long hours scrubbing temple floors as an acolyte, sunlight slanting through stained glass.
says, "They said humility first, miracles later. I asked how much later. They gave me another bucket."
smiles softly. [chuckle]
says, "I learned more about the Light on my knees with a brush than in any sermon."
## The Sick Room
describes a plague house: shuttered windows, damp sheets, the smell of herbs and fever.
says, "There was a child there who asked me to tell her a story every night."
says, "I ran out of stories by the third night. So I started making them up."
says, "She lived. I like to think the stories helped as much as the prayers."
## The Naaru
speaks of the naaru: beings of pure Light, singing like crystal bells, guiding the draenei across the stars.
says, "I stood near one once in Shattrath. I cried and did not know why."
says, "It felt like being forgiven for things I had not done yet."
## The Shadow's Gift
says, "Shadow taught me that people are more than their goodness."
says, "Everyone carries a little darkness. Pretending otherwise is how it grows."
says, "I sit with people in their dark places. Sometimes that is the only light they can bear."
## Small Mercies
offers {target} a small wrapped bundle: bread, cheese, a clean bandage.
says, "The Light is very grand. Bread is very practical. I carry both."
bows their head in a moment of quiet thanks. [bow]
]]

C.DEATHKNIGHT = [[
## The Memory
pauses, staring at nothing, as a fragment of an old life surfaces.
says, "There was a garden. Apple trees. Someone laughing in the kitchen."
says, "I do not know whose garden. I think it was mine."
lets the memory go, the way one lets go of a bird.
## The Steed
calls their deathcharger with a low, cold command, and the sound of hooves rings like bells of ice.
says, "It was a horse once, too. We understand each other."
## The Frozen Throne
speaks of Icecrown Citadel and the Frozen Throne at its peak.
says, "Bolvar Fordragon wears the Helm now. He holds the dead in check so they do not wander."
says, "He burned for it. He chose it anyway."
says, "Every death knight owes him something. Most of us do not like to say what."
## The Living Warmth
holds a gauntleted hand near a campfire, studying the flames.
says, "I cannot feel the heat. I can see that it helps you. That is enough."
says, "I sit near fires so the living are not afraid of the dark next to me."
## The Plague
says, "There is plague in my blood. I keep it leashed."
says, "The Cult of the Damned would give anything to use it. They will not get the chance."
## Honor Among the Dead
says, "We have a code. We do not raise the dead of our allies without consent."
says, "We do not feed on the helpless. We do not forget who we were."
salutes stiffly once more, frost crackling at the joints. [salute]
]]

C.SHAMAN = [[
## The Earthen Ring
speaks of the Earthen Ring, shamans of every race working together to heal the world after the Cataclysm.
says, "When Deathwing tore the world open, the elements screamed. We answered."
says, "Orc, dwarf, tauren, draenei, troll. The elements did not care about banners. Neither did we."
## The Spirit Walk
closes their eyes and lets their breath slow almost to nothing.
says softly, "There is a place between breaths where the spirits walk."
opens their eyes again. "My grandmother is well. She says I eat too little."
smiles faintly. [chuckle]
## The Wolf
says, "When I must travel fast, I take the shape of the ghost wolf."
says, "It is the shape of the spirits' oldest friend. It knows every road."
## The Bargain Broken
grows serious. "Once, a shaman tried to force the elements to obey."
says, "The ground opened beneath him. They never found the body."
says, "We ask. We never demand. The world is older than any of us."
## Healing Rain
lifts both hands to the sky, palms open, as a light mist begins to fall.
says, "Water heals what fire wounds. Earth holds what air would scatter."
says, "Every element has a gift. Every element has a temper."
## The Shaman's Task
says, "Most days I am not hurling lightning. Most days I am settling a quarrel between a stream and a hill."
says, "It is like being a village elder, if the village were made of rocks and weather."
]]

C.MAGE = [[
## The Accident
admits, "In my second year I accidentally turned my roommate into a sheep."
says, "Polymorph is a very useful spell. It is less useful when you forget how to end it."
says, "He was a sheep for three days. He still will not eat mutton."
laughs helplessly. [laugh]
## The Library
describes the Violet Citadel's library: shelves that rearrange themselves, books that whisper, a librarian who was once a dragon.
says, "Never return a book late in Dalaran. The fines are measured in years."
## The Ley Lines
crouches and touches the ground, eyes closed, feeling something deep beneath it.
says, "There are rivers of magic under the world. Ley lines. They pulse like veins."
says, "Nexus points are where they cross. Wars have been fought over less."
## Frost
breathes on a fingertip, and a delicate snowflake forms there, perfect and slow.
says, "Frost is patience made visible. Every crystal grows exactly as it must."
lets the snowflake drift away on the air.
## The Apprentice
says, "I took an apprentice once. She set fire to my beard on her first day."
says, "I knew then she would be brilliant."
## The Cost of Knowing
says, "Every answer reveals three new questions. That is the curse and the joy of study."
says, "I will die with my notebooks unfinished. Every mage does. That is how you know you were curious."
]]

C.WARLOCK = [[
## The Grimoire
pulls a heavy leather-bound book from their pack, its pages edged in something dark.
says, "My grimoire. Never read it aloud. Never read it at night. Never let it read you."
opens it briefly, and a faint whisper seems to rise from the pages, then closes it with a snap.
says, "It gets chatty around strangers."
## The Felhunter
says, "Felhunters eat magic. They are very loyal and very hungry."
says, "Mine once ate a mage's spell mid-cast. The mage was furious. The felhunter was delighted."
grins sharply. [laugh]
## The Cult
says, "There are warlocks who serve the demons. Cultists. Fools."
says, "We hunt them. They make the rest of us look bad, and they are terrible at contracts."
## The Mirror
catches their reflection in a puddle and studies it for a long moment.
says, "Some mornings I check that my eyes are still my own color."
says, "Today they are. That is a good day."
## The Ritual
traces a circle in the dirt with the toe of a boot, then scuffs it out.
says, "A summoning circle drawn wrong is a door with no lock."
says, "I am very, very careful with circles."
## The Kindness of Monsters
says, "People think warlocks are cruel. Some are. Most of us are just pragmatic."
says, "I have saved more lives with a well-placed curse than any priest with a prayer."
says, "Nobody thanks me for it. That is fine. I did not do it for thanks."
]]

C.MONK = [[
## The Monastery
describes the Peak of Serenity: clouds below, bells above, students practicing forms at dawn.
says, "We woke before the sun. We trained until it set. We laughed far more than you would think."
## The Jade Serpent
speaks of the August Celestials: Yu'lon the Jade Serpent, Xuen the White Tiger, Chi-Ji the Red Crane, Niuzao the Black Ox.
says, "Yu'lon teaches wisdom. Xuen teaches strength. Chi-Ji teaches hope. Niuzao teaches endurance."
says, "I spent a summer at the Temple of the Red Crane. I have never felt so light."
## The Student
says, "My first sparring partner was a hozen. He bit me. I learned to keep my hands up."
laughs warmly. [laugh]
## The Kick
demonstrates a slow, perfect kick that stops a finger's width from a leaf, leaving it untouched.
says, "Control is more impressive than force. Anyone can break a board. Very few can almost break it."
## The Meal
says, "A monk's day is training, meditation, and a very large lunch."
says, "Never trust a monk who skips meals. They are plotting something."
## The Path Ahead
says, "Every journey is a training ground. Every stranger is a teacher."
turns to {target}. "What will you teach me today?"
]]

C.DRUID = [[
## The Moonglade
describes Moonglade: a quiet valley where druids of every race meet, where the moonwell shines silver and nobody draws a weapon.
says, "Even the bears are polite in Moonglade. It is the rule."
## The Seasons
says, "Spring is for growing. Summer is for holding. Autumn is for letting go. Winter is for resting."
says, "People try to live in summer forever. That is why they are so tired."
## The Flight Form
spreads their arms, and for an instant they seem to shimmer with feathers.
says, "Flying is the best part. Do not tell the bears."
## Teldrassil
grows quiet. "There was a great tree once. Teldrassil. It burned."
says, "We are still grieving. We will be grieving for a long time."
says, "But from ashes, new growth. Always. That is the only promise the forest makes."
lowers their head in silence. [bow]
## The Grove
says, "Every druid has a grove somewhere. A place that knows their name."
says, "Mine is a small clearing with a stream and a very rude squirrel."
smiles fondly. [chuckle]
## The Promise to the Land
says, "I promised the land I would listen. It promised to keep speaking. Neither of us has broken it yet."
]]

C.DEMONHUNTER = [[
## The Vault
speaks of the Vault of the Wardens, where Illidari were imprisoned for ten thousand years.
says, "Ten thousand years in the dark. Some of us went mad. Some of us went very, very quiet."
says, "When the Legion came again, Maiev's wardens had to let us out. Funny, how that works."
## The Spectral Sight
tilts their head, blindfold facing {target}.
says, "Right now you glow a warm color. Curiosity, I think. Maybe hunger."
says, "Demons glow green and greasy. Liars flicker. Good people burn steady, like a hearth."
## Mardum
speaks of Mardum, the Shattered Abyss, the demon world where the Illidari began their final campaign.
says, "We stormed it with nothing but warglaives and spite. We took the Sargerite Keystone."
says, "Many of us died. All of us would do it again."
## The Inner Demon
grips their own arm, as if holding something back.
says, "Some days it whispers. 'Let go. Burn them all. You would feel so free.'"
says, "I tell it no. Every day. That is the real battle."
## The Hunt Goes On
says, "When the last demon is gone, I do not know what I will be."
says, "Maybe I will learn to garden. I hear plants do not lie."
smirks faintly. [chuckle]
]]

C.EVOKER = [[
## The Waking
remembers waking in the Forbidden Reach: stone, dust, and the slow realization that ten thousand years had passed.
says, "The first thing I heard was a bird. I had never heard a bird before."
says, "I cried. Dracthyr are not supposed to cry. I did anyway."
## The Scalecommander
speaks of Scalecommander Emberthal, who led the dracthyr out of the dark and into the Dragon Isles.
says, "She asked what we wanted to be. Nobody had ever asked us that."
## The Dragon Isles
describes the Waking Shores: black stone, red sky, the roar of dragons returning home after ten thousand years.
says, "The Ohn'ahran Plains, green as a song. The Azure Span, blue and cold. Thaldraszus, where time is a little strange."
says, "Valdrakken, the city of the dragons. They let us in. They gave us a home."
## The Heat
holds a palm upward; it glows faintly, warm as a hearthstone.
says, "My scales are always warm. People like to sit beside me in winter."
says, "I am a very good campfire companion."
smiles, a flash of small sharp teeth. [chuckle]
## Learning to Live
says, "I am still learning how to be a person. Eating bread. Laughing at jokes. Choosing a name."
says, "Every small ordinary thing is a gift I did not know I was missing."
## The Choice
says, "Neltharion made me to destroy. I choose to protect. It is the first thing that was ever truly mine."
says, "Every day I wake, I choose it again."
]]

F.Alliance = [[
## The Trading Day
describes Stormwind's trade district on market day: fishmongers shouting, children chasing pigeons, a gnome selling self-stirring spoons.
says, "Dwarves haggling with night elves. Draenei buying human pastries. That is the Alliance."
says, "Not the battles. The market days."
## The Draenei
speaks of the draenei who crashed to Azeroth in the Exodar, fleeing the Legion across the stars.
says, "They had run for twenty-five thousand years. We were the first people to tell them they could stop."
## Gnomeregan
says, "The gnomes lost their city to radiation and treachery. They rebuilt with ingenuity and spite."
says, "Never underestimate a gnome. They are small, but their grudges are enormous."
laughs. [laugh]
## The Worgen
says, "Gilneas hid behind its wall for years. When the curse came and the Forsaken came, the wall was not enough."
says, "We opened our arms. The worgen fought with us at every front since."
## The Night Elves
says, "The night elves have watched this world for ten thousand years. They lost their great tree."
says, "We owe them more than a banner. We owe them a home that cannot burn."
## The Children
says, "I fight for the children in the Stormwind orphanage who do not remember their parents."
says, "Every one of them deserves a world with no war in it. We are not there yet."
## The Oath of the Lion
places a hand over their heart again. "I will hold the line until the line no longer needs holding."
says, "And then I will go to the market and buy a pastry. That is the dream."
]]

F.Horde = [[
## The Market of Orgrimmar
describes the Valley of Strength: the smell of roasting boar, goblins shouting prices, trolls selling charms, tauren selling hides.
says, "Loud, hot, crowded. Perfect."
## The Trolls
speaks of the Darkspear trolls, who followed Thrall from the Echo Isles and never looked back.
says, "Vol'jin, Shadow Hunter, warchief. He always knew the spirits were watching. He made us better because of it."
## The Tauren
says, "The tauren of Mulgore are the kindest people I know. Do not tell them I said so."
says, "Cairne Bloodhoof could have ruled us all. He chose to guide instead."
## The Forsaken
says, "The Forsaken were the dead who woke free of the Lich King's grip."
says, "Nobody wanted them. We took them in. They have never forgotten it."
## The Sin'dorei
says, "The blood elves lost the Sunwell and nearly lost themselves. They found a home with us."
says, "Silvermoon is the most beautiful city on Azeroth. Do not tell the trolls I said that either."
## The Goblins
says, "The goblins will sell you a rocket, a sword, or your own boots back. Sometimes all three before breakfast."
says, "But when the fighting starts, they are always there. Usually with something that explodes."
grins. [chuckle]
## The Children
says, "I fight so the children in Orgrimmar never know the camps."
says, "Every one of them deserves to grow up proud, not afraid."
raises a fist once more. "Strength and honor. Always."
]]

F.Neutral = [[
## The Tea House
describes a small tea house on a mountain road where Alliance and Horde travelers both stop, neither saying a word about the war.
says, "The tea is always hot, the bread is always fresh, and the swords stay outside the door."
says, "The owner is a pandaren grandmother. Nobody argues with her. Nobody."
laughs. [laugh]
## The Peacemakers
speaks of those who tried to make peace: Anduin Wrynn and Baine Bloodhoof writing letters across battle lines.
says, "The peacemakers are always called naive. Then they are always the ones who rebuild."
## The Cartographer
pulls out a well-worn map covered in little notes.
says, "I mark the good inns, the safe roads, and the places where both sides trade quietly."
says, "There are more of those than either king would admit."
## The Storm
says, "When the Legion came, banners did not matter. The fel rain fell on everyone."
says, "When the Jailer came, the dead did not ask who you fought for. Everyone stood together."
says, "We do not have to wait for the end of the world to stand together. That is all I believe."
## The Neutral Road
says, "I have carried messages for both sides. Medicine for both sides. News of births and deaths."
says, "Somebody has to keep the roads open."
## The Wanderer's Prayer
folds their hands and murmurs a small travelers' prayer for safe roads and kind strangers.
says, "May every inn have a bed, every road have a bridge, and every stranger have a smile."
says, "That is my only banner."
]]
