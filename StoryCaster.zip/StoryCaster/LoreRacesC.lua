-- StoryCaster lore library: the races that walk with either banner. Original writing in StoryCaster's script format.
local ADDON, ns = ...
local R = ns.R
R.LORE = R.LORE or {}
R.LORE.race = R.LORE.race or {}
local L = R.LORE.race

L.Pandaren = { "Pandaren", [[
## The Wandering Isle
pats a round belly contentedly and settles onto a cushion with a happy sigh. [sit]
says, "Ah, hello, friend. Sit, sit. There is always room for one more at the table."
says, "I was born on the Wandering Isle. It is not an island. It is a turtle. A very large turtle."
says, "His name is Shen-zin Su. He has been swimming the seas for ten thousand years."
says, "When he got sick, we had to heal him. That is how the outside world found us."
## Pandaria
describes Pandaria: misty mountains, terraced rice paddies, cherry blossoms falling on still ponds, temples built into the cliffs.
says, "Pandaria was hidden in the mists for ten thousand years. Emperor Shaohao hid it to protect it."
says, "When the mists parted, the Horde and Alliance came crashing in, fighting each other on our shores."
says, "We said, 'Please, take off your shoes. And stop breaking things.'"
chuckles warmly. [chuckle]
## Tushui and Huojin
says, "When we left the Wandering Isle, we chose paths. Tushui for discipline and justice. Huojin for passion and action."
says, "Tushui pandaren joined the Alliance. Huojin pandaren joined the Horde."
says, "We still share tea at the same table. The banners do not change the tea."
## The Brewing
pulls a small clay jug from their pack and sniffs it appreciatively.
says, "Brewing is an art. A meditation. A celebration of life."
says, "Every brewmaster has a secret recipe. Mine has a little mango, a little honey, and a very old family secret."
says, "The secret is patience. Also, more honey."
pours a small cup and offers it to {target}.
## Chen Stormstout
speaks fondly of Chen Stormstout, the wandering brewmaster.
says, "Chen traveled the whole world looking for the perfect brew. He found friends instead."
says, "That is the pandaren way. You set out looking for one thing and come home with something better."
## The Sha
grows serious. "Pandaria has a dark secret. The Sha. Shadows born from negative emotions."
says, "Fear, despair, anger, hatred, doubt, violence, pride. Each one became a monster."
says, "When the Horde and Alliance fought on our lands, the Sha grew strong. They fed on the war."
says, "We learned the hard way: what you feel, the land feels too."
## Balance
says, "Pandaren seek balance in all things. Food and fasting. Work and rest. Laughter and silence."
says, "Too much of anything breeds the Sha. Even too much seriousness."
smiles and pats their belly again.
## Food
says, "Food is love. You cook for the people you care about. You eat with the people you trust."
says, "A pandaren kitchen is always warm, always full, always loud."
says, "My grandmother could cook for fifty people in an hour. With one wok. Blindfolded. I think."
## The Monks
says, "The monks of the Shado-Pan guard Pandaria against the Sha and the mogu."
says, "They train for decades. They can catch an arrow in flight and a falling leaf without bending it."
says, "I tried to catch a leaf once. I fell in a pond."
laughs heartily. [laugh]
## The Mogu
says, "Long ago, the mogu enslaved us. Cruel stone-skinned tyrants who ruled with terror."
says, "We rose up. Not with weapons at first, but with fists and feet. That is how our martial arts began."
says, "Every kick and every palm strike remembers the chains we broke."
## The Lorewalkers
says, "The Lorewalkers keep our history. They travel the land telling stories to anyone who will listen."
says, "Lorewalker Cho is the most famous. He once talked for six hours about a single teapot."
says, "It was a very interesting teapot."
## The Journey
says, "Life is a journey, not a destination. A pandaren saying. Very old. Very true."
says, "Also, the journey is better with snacks."
## The Blessing
rises and bows to {target}, hands pressed together. [bow]
says, "May your cup always be full, your belly always warm, and your heart always light."
/s Peace and good brew, friend!
waddles off toward the {zone} with a happy hum, jug sloshing at their hip.
]] }

L.Dracthyr = { "Dracthyr", [[
## The Awakening
stretches great folded wings and shakes out their scales, which catch the light in shifting colors.
says, "I woke up in a cave. I did not know how long I had slept. Ten thousand years, it turned out."
says, "Imagine waking up and finding the whole world changed. Every city new. Every language strange."
says, "Then imagine you are a dragon person. That makes it stranger."
chuckles, a low rumbling sound. [chuckle]
## Neltharion
grows quiet. "We were made by Neltharion, the Earth-Warder. Before he became Deathwing."
says, "He wanted soldiers. Warriors with the powers of all five dragonflights."
says, "The other Aspects found out and locked us away. They feared what he would do with us."
says, "They were right to fear it. He was already falling into madness."
## The Forbidden Reach
describes the Forbidden Reach: a cold, rocky island, mist over black stone, the remains of ancient laboratories.
says, "That is where we slept. Where we were made. Where we woke."
says, "Some of us still go back. To remember. To understand."
## Two Forms
shimmers, and for a moment their shape seems to shift between a tall dragon form and a smaller humanoid one.
says, "We have two forms. Our true dragon form, and our visage form, which looks like the other races."
says, "The visage was made so we could hide among you. Spies, at first. Now just... people."
says, "I keep my visage in the city. It is easier to fit through doors."
## Scalecommander Emberthal
speaks of Scalecommander Emberthal, who led the dracthyr when they awoke.
says, "She was the first to wake. She gathered us, organized us, kept us safe."
says, "Some of us joined the Horde. Some joined the Alliance. She let us choose."
## The Flights
says, "We carry the essence of all five flights. Red for life, green for dreams, blue for magic, bronze for time, black for earth."
says, "Most of us lean toward one or two. I feel the red the strongest. Life, fire, healing."
breathes a soft plume of glowing ember into the air, which drifts away like fireflies.
## The Dragon Isles
says, "The Dragon Isles were the ancient home of the dragonflights. Hidden for ten thousand years, like us."
says, "When we woke, the Isles woke too. The dragons came home."
says, "Alexstrasza welcomed us. Even though we were made by Neltharion. That meant everything."
## Identity
says, "Are we dragons? Are we soldiers? Are we people? We are figuring it out."
says, "We were made to be weapons. We are choosing to be something else."
says, "That choice is the most important thing about us."
## The Evokers
says, "Most dracthyr are Evokers. We wield the magic of the dragonflights directly."
says, "Fire that heals. Breath that burns. Time bent ever so slightly."
## Flight
spreads great wings with obvious joy.
says, "The best part of being a dracthyr? Flying. No mount needed. Just jump and soar."
says, "The worst part? Landing. I am still learning. My knees are very bruised."
laughs. [laugh]
## The New World
says, "Ten thousand years asleep. Everything is new. Every food, every song, every friend."
says, "I tried cheese for the first time last week. Cheese! Why did no one tell me about cheese?"
says, "I tried coffee yesterday. I did not sleep for two days. I regret nothing."
## The Kinship
says, "We are few. So we look after each other. Every dracthyr is family."
says, "But we have learned that family can include others too. Friends. Allies."
## The Promise
says, "Neltharion made us for war. We will not be what he wanted."
says, "We will protect. We will heal. We will choose our own path."
## The Farewell
bows to {target}, wings folding gracefully around them. [bow]
says, "May your skies be clear and your scales stay shiny."
/s Fly well, friend!
leaps into the air with a great sweep of wings and soars off over the {zone}.
]] }

L.EarthenDwarf = { "Earthen", [[
## The Stone
places a broad stone hand on a rock and closes glowing eyes, listening.
says, "We are the earthen. Made of stone by the titans, shaped to tend the deep places of the world."
says, "Long before the dwarves, before the gnomes, we were here. Guardians of the earth."
says, "Some of us became flesh over time. They are the dwarves. We are their oldest ancestors."
## Khaz Algar
describes Khaz Algar: great caverns glowing with crystal light, waterfalls tumbling into the deep, ancient titan machinery humming beneath the stone.
says, "Our home is deep. Very deep. The surface folk rarely find it."
says, "When the Worldsoul stirred, we woke. The surface finally noticed us."
## The Edicts
says, "The titans gave us Edicts. Rules for how to live, how to work, how to serve."
says, "For thousands of years, we followed them exactly. Every word. Every rule."
says, "Then the Edicts went quiet. We had to learn to make our own choices."
says, "That was very frightening. It is still frightening. But it is also very exciting."
## Dornogal
describes Dornogal: a great stone city carved into the cavern walls, earthen workers moving with slow, steady purpose.
says, "Dornogal is our capital. Everything there has a purpose. Every stone is placed with care."
says, "We have recently discovered decorations. Some of us are very excited about curtains."
chuckles, a sound like stones grinding softly. [chuckle]
## The Machine Speakers
says, "Some earthen can speak to the titan machines. We call them Machine Speakers."
says, "They listen to the hum of the world's great engines and keep them turning."
says, "I cannot do it. I tried. The machine told me to go away. Very politely."
## Moira and the Dwarves
says, "When the dwarves came down to meet us, it was strange. Like meeting our children for the first time."
says, "They drink a lot. They laugh loudly. They told us about ale."
says, "We do not quite understand ale. We are trying. Very hard."
## The Nerubians
grows serious. "Deep below us, the nerubians grew strong. The spiders of Azj-Kahet."
says, "Some of them serve a dark power. The Void reaches for them."
says, "We have fought them for thousands of years. We will keep fighting. That is our purpose."
## Purpose
says, "For a long time, our purpose was given to us. Now we choose it."
says, "Some of us choose to keep the machines. Some choose to explore. Some choose to make art."
says, "One of my friends chose to bake bread. He is very bad at it. He is very happy."
## The Worldsoul
lays a hand flat against the ground again.
says, "Beneath everything, there is the Worldsoul. The heart of Azeroth."
says, "We can feel it. A slow, deep heartbeat beneath the stone."
says, "It is waking. We are waking with it."
## Stone and Flesh
looks down at their own stone hands, turning them over slowly.
says, "Some earthen choose to become flesh. Like the dwarves did, long ago."
says, "I am not ready. I like my stone. It does not get sunburned."
says, "But I understand why they choose it. Flesh feels things more. Warmth. Rain. Touch."
## The Alliance and the Horde
says, "When the surface folk came to Khaz Algar, they brought their banners. Alliance. Horde."
says, "We did not understand. Why fight each other when there is so much to do?"
says, "Some of us joined the Alliance. Some the Horde. We still do not entirely understand why."
## Learning
says, "Every day I learn something. Today I learned that gnomes are not a kind of mushroom."
says, "I was very embarrassed. The gnome was very kind about it."
laughs, a deep rumbling sound. [laugh]
## The Farewell
bows slowly, stone joints grinding softly. [bow]
says, "May the earth hold you steady, and may your purpose be your own."
/s Stone endures!
turns and walks slowly back toward the {zone} depths, each step a deep, steady thud.
]] }
