-- StoryCaster: write or paste your own roleplay, and it is performed as /emotes on a timer (or one key press
-- at a time), with real character animations, chat lines, scenes and duets. /story opens the panel.
local ADDON, ns = ...
local R = {}
ns.R = R
_G.StoryCaster = R

R.version = "1.2.0"

-- Anti-spam: lines posted on their own (by the timer) are never closer than MIN_GAP seconds,
-- and never more than MAX_PER_MIN in any minute. Only your own Deliver presses skip these.
R.MIN_GAP = 15
R.MAX_PER_MIN = 4

BINDING_HEADER_STORYCASTER = "StoryCaster"
BINDING_NAME_STORYCASTER_PANEL = "Show or hide the panel"
BINDING_NAME_STORYCASTER_PLAY = "Play or pause the script"
BINDING_NAME_STORYCASTER_DELIVER = "Deliver the next line now"
BINDING_NAME_STORYCASTER_STOP = "Stop the script"
BINDING_NAME_STORYCASTER_ANIM1 = "Animation: Bow"
BINDING_NAME_STORYCASTER_ANIM2 = "Animation: Wave"
BINDING_NAME_STORYCASTER_ANIM3 = "Animation: Nod"
BINDING_NAME_STORYCASTER_ANIM4 = "Animation: Laugh"
BINDING_NAME_STORYCASTER_ANIM5 = "Animation: Cheer"
BINDING_NAME_STORYCASTER_ANIM6 = "Animation: Kneel"

local DEFAULTS = {
  interval = 20, dice = false, diceMin = 15, diceMax = 25,
  loop = false, shuffle = false, testMode = false, pauseInCombat = true,
  animations = true, autoAnim = true, mode = "sentences", autoPace = false, manual = false,
  duetAuto = false, compact = false,
  showBar = true, barPoint = nil, last = nil,
  scripts = {}, order = {},
}

local function copyDefaults(src, dst)
  if type(dst) ~= "table" then dst = {} end
  for k, v in pairs(src) do
    if type(v) == "table" then dst[k] = copyDefaults(v, dst[k])
    elseif dst[k] == nil then dst[k] = v end
  end
  return dst
end

function R:Print(msg) DEFAULT_CHAT_FRAME:AddMessage("|cffb48cff[StoryCaster]|r " .. tostring(msg)) end

---------------------------------------------------------------------------
-- Scripts
---------------------------------------------------------------------------
function R:Names() return self.db.order end
function R:Get(name) return name and self.db.scripts[name] end

function R:Save(name, script, opts)
  name = (name or ""):gsub("|", ""):gsub("^%s+", ""):gsub("%s+$", "")
  if name == "" then return false, "Give your script a name first." end
  if #name > 48 then return false, "That name is too long (48 characters at most)." end
  if #script == 0 then return false, "Write or paste at least one line." end
  local old = self.db.scripts[name]
  if type(opts) ~= "table" then opts = nil end
  script.opts = opts or (old and type(old.opts) == "table" and old.opts) or nil
  self.db.scripts[name] = script
  if not old then table.insert(self.db.order, name) end
  self.db.last = name
  return true, (old and "Updated" or "Saved") .. " '" .. name .. "': " .. #script .. " line" .. (#script == 1 and "" or "s") .. "."
end

function R:Delete(name)
  if not self.db.scripts[name] then return false end
  if self.run and self.run.name == name then self:Stop(true) end
  self.db.scripts[name] = nil
  for i, n in ipairs(self.db.order) do if n == name then table.remove(self.db.order, i); break end end
  if self.db.last == name then self.db.last = self.db.order[1] end
  return true
end

---------------------------------------------------------------------------
-- Placeholders, text and animation
---------------------------------------------------------------------------
function R:Target()
  local t = UnitExists("target") and UnitName("target") or nil
  if t and issecretvalue and issecretvalue(t) then return nil end
  if t and UnitIsUnit and UnitIsUnit("target", "player") then return nil end
  return t
end

local function timeOfDay()
  local h = GetGameTime and GetGameTime() or 12
  if h < 5 then return "night" elseif h < 12 then return "morning" elseif h < 18 then return "afternoon" elseif h < 22 then return "evening" end
  return "night"
end

-- {target} {name} {class} {race} {zone} {subzone} {time}, and {smiles|grins|smirks} picks one at random
function R:Render(text)
  local function zone() return (GetRealZoneText and GetRealZoneText()) or "here" end
  local values = {
    target = function() return self:Target() or "someone" end,
    name = function() return UnitName("player") or "" end,
    class = function() return ((UnitClass and UnitClass("player")) or ""):lower() end,
    race = function() return (UnitRace and UnitRace("player")) or "" end,
    zone = zone,
    subzone = function() local s = GetSubZoneText and GetSubZoneText(); return (s and s ~= "") and s or zone() end,
    time = timeOfDay,
  }
  text = (text or ""):gsub("{([^{}]-)}", function(k)
    if k:find("|", 1, true) then
      local opts = {}
      for o in (k .. "|"):gmatch("([^|]*)|") do opts[#opts + 1] = o end
      return opts[math.random(#opts)]
    end
    local f = values[k:lower()]
    if f then return f() end
  end)
  text = text:gsub("|", "")
  if #text > self.MAX_LEN then text = (text:sub(1, self.MAX_LEN - 3):match("^(.*)%s") or text:sub(1, self.MAX_LEN - 3)) .. "..." end
  return text
end

local function send(text, chan)
  if C_ChatInfo and C_ChatInfo.SendChatMessage then C_ChatInfo.SendChatMessage(text, chan or "EMOTE")
  else SendChatMessage(text, chan or "EMOTE") end
end

-- Plays an animated emote. Aimed at nobody unless asked, so the game's line reads "X bows." and not "X bows before Y."
function R:Animate(token, onTarget)
  if not token then return end
  local perform = (C_ChatInfo and C_ChatInfo.PerformEmote) or DoEmote
  if not perform then return end
  pcall(perform, token, onTarget and self:Target() and "target" or "none")
end

function R:CanEmote()
  if C_ChatInfo and C_ChatInfo.InChatMessagingLockdown and C_ChatInfo.InChatMessagingLockdown() then return false, "a boss encounter" end
  if self.db.pauseInCombat and InCombatLockdown() then return false, "combat" end
  return true
end

-- /say and /yell outside an instance need a real key press (Blizzard's rule)
function R:NeedsKey(line)
  local c = line and line[4]
  if c ~= "SAY" and c ~= "YELL" then return false end
  local inInstance = IsInInstance and IsInInstance()
  return not inInstance
end

-- the chat a line is posted in; party/raid/guild lines become an emote when you are not in one
function R:Channel(line)
  local c = line[4]
  if c == "PARTY" and not (IsInGroup and IsInGroup()) then return "EMOTE" end
  if c == "RAID" and not (IsInRaid and IsInRaid()) then return (IsInGroup and IsInGroup()) and "PARTY" or "EMOTE" end
  if c == "GUILD" and not (IsInGuild and IsInGuild()) then return "EMOTE" end
  if c == "INSTANCE_CHAT" and not (IsInGroup and LE_PARTY_CATEGORY_INSTANCE and IsInGroup(LE_PARTY_CATEGORY_INSTANCE)) then return "EMOTE" end
  return c or "EMOTE"
end

-- post one line now (text, then its animation)
function R:Perform(line)
  local text, anim = self:Render(line[1]), line[2]
  if text:find("^%s*/") then text = "" end -- a slash command is never posted as words
  local chan = self:Channel(line)
  if chan == "EMOTE" and line[4] and text ~= "" then text = 'says, "' .. text .. '"' end
  if self.db.testMode then
    local who = chan == "EMOTE" and (UnitName("player") .. " ") or ("[" .. chan:lower() .. "] ")
    self:Print(("|cffaaaaaa(test)|r |cffff8040%s%s|r%s"):format(text ~= "" and who or "", text, anim and (" |cff9f8fff[" .. anim:lower() .. "]|r") or ""))
  else
    if text ~= "" then
      local ok, err = pcall(send, text, chan)
      if not ok then self:Print("Line failed: " .. tostring(err)) end
    end
    if anim and self.db.animations then
      if text ~= "" then C_Timer.After(0.4, function() self:Animate(anim) end) else self:Animate(anim) end
    end
  end
  if self.Pulse then self:Pulse(anim) end
end

---------------------------------------------------------------------------
-- The player
---------------------------------------------------------------------------
-- state: nil (idle) | "running" | "paused" | "waiting" (combat/encounter) | "key" (waiting for the Deliver key)
local function shuffled(list)
  local out = {}
  for i, v in ipairs(list) do out[i] = v end
  for i = #out, 2, -1 do local j = math.random(i); out[i], out[j] = out[j], out[i] end
  return out
end

function R:Opts() return (self.run and self.run.opts) or {} end
function R:Flag(name) local o = self:Opts(); if o[name] ~= nil then return o[name] end; return self.db[name] end

function R:NextDelay(prev)
  local o, gap = self:Opts(), self.MIN_GAP
  if o.diceMin then return math.max(gap, math.random(o.diceMin, math.max(o.diceMin, o.diceMax or o.diceMin))) end
  if self.db.dice then return math.max(gap, math.random(self.db.diceMin, math.max(self.db.diceMin, self.db.diceMax))) end
  if self.db.autoPace and prev and prev[1] then
    -- reading time: a few seconds plus about one second for every 15 characters
    return math.max(gap, math.min(60, math.floor(4 + #prev[1] / 15 + 0.5)))
  end
  return math.max(gap, self.db.interval)
end

-- the wait before a line: its own /pause if it has one, otherwise the timer; never under the anti-spam gap
function R:DelayBefore(line, prev) return math.max(self.MIN_GAP, (line and line[3]) or self:NextDelay(prev)) end

-- how long the anti-spam guard still wants to wait before the next automatic line (0 = go)
function R:SpamWait()
  local now = GetTime()
  if self.lastAuto and now - self.lastAuto < self.MIN_GAP then return self.MIN_GAP - (now - self.lastAuto) end
  local recent = self.recent or {}
  while recent[1] and now - recent[1] >= 60 do table.remove(recent, 1) end
  self.recent = recent
  if #recent >= self.MAX_PER_MIN then return 60 - (now - recent[1]) + 0.1 end
  return 0
end

function R:NoteAuto()
  local now = GetTime()
  self.lastAuto = now
  self.recent = self.recent or {}
  table.insert(self.recent, now)
end

function R:CancelTimer() if self.timer then self.timer:Cancel(); self.timer = nil end end

function R:ArmTimer(delay)
  self:CancelTimer()
  self.nextDur, self.nextAt = delay, GetTime() + delay
  self.timer = C_Timer.NewTimer(delay, function() self.timer = nil; self:PostNext() end)
end

-- wait for the next line: the timer, or the Deliver key in manual mode
function R:Schedule(prevLine)
  local nxt = self.run.lines[self.run.i + 1] or (self:Flag("loop") and self.run.lines[1])
  if self.db.manual and not self:Opts().ambient then
    self.state, self.nextAt, self.nextDur = "key", nil, nil
  else
    self:ArmTimer(self:DelayBefore(nxt, prevLine))
  end
end

function R:Start(name, fromLine)
  name = (name and name ~= "") and name or self.db.last
  local script = self:Get(name)
  if not script then self:Print("No script called '" .. tostring(name) .. "'. /story list shows yours.") return end
  if #script == 0 then self:Print("That script is empty.") return end
  if self.following and self.LeaveScene then self:LeaveScene(true) end
  self:Stop(true)
  self.db.last = name
  local opts = type(script.opts) == "table" and script.opts or {}
  local lines = script
  if opts.shuffle or (opts.shuffle == nil and self.db.shuffle) then lines = shuffled(script) end
  self.run = { name = name, lines = lines, i = (fromLine or 1) - 1, opts = opts }
  self.state = "running"
  -- a duet: the others named in the script are invited first, and the first line waits a moment for them
  local cast = self:CastOf(script)
  local wait
  if #cast > 0 and self.CastScene then wait = self:CastScene(name, script, cast) end
  self:Print(("Performing |cffffd100%s|r: %d lines, %s."):format(name, #script,
    opts.ambient and "quietly, in random order" or self.db.manual and "one line each time you press Deliver" or
    self.db.dice and ("random gaps of " .. self.db.diceMin .. "-" .. self.db.diceMax .. "s") or
    self.db.autoPace and "paced to each line's length" or ("one every " .. self.db.interval .. "s")))
  local first = lines[self.run.i + 1]
  if wait then self:ArmTimer(wait + ((first and first[3]) or 0))
  elseif first and first[3] then self:ArmTimer(first[3])
  else self:PostNext() end
  self:Refresh()
end

-- is this line mine to perform? (in a duet, the lines named for me; unnamed lines belong to whoever started)
function R:IsMine(line, leader)
  local s = line[5]
  if not s then return not leader end
  local me = (UnitName("player") or ""):lower()
  return s:lower() == me or (s:match("^([^%-]+)") or s):lower() == me
end

-- fromKey: called from a key press or a click (so /say and /yell may be sent)
function R:PostNext(fromKey)
  local run = self.run
  if not run then return end
  self:CancelTimer()
  local ok, why = self:CanEmote()
  if not ok then
    if self.state ~= "waiting" then self:Print("Holding your script during " .. why .. ".") end
    self.state, self.nextAt = "waiting", nil
    self.timer = C_Timer.NewTimer(3, function() self.timer = nil; self:PostNext() end)
    self:Refresh()
    return
  end
  if self.state == "waiting" then self:Print("Resuming.") end
  local nextI = run.i + 1
  if nextI > #run.lines then
    if self:Flag("loop") then
      local script = self:Get(run.name) or run.lines
      run.lines = (run.opts.shuffle or (run.opts.shuffle == nil and self.db.shuffle)) and shuffled(script) or script
      nextI = 1
    else
      self:Finish(); return
    end
  end
  local line = run.lines[nextI]
  -- anti-spam: an automatic line waits until it is safely apart from the last ones
  if not fromKey then
    local w = self:SpamWait()
    if w > 0 then self:ArmTimer(w); self:Refresh(); return end
  end
  -- /say and /yell outside an instance wait for the Deliver key
  if self:IsMine(line) and self:NeedsKey(line) and not fromKey and not self.db.testMode then
    self.state, self.nextAt, self.nextDur = "key", nil, nil
    if not self.keyHinted then
      self:Print("A /" .. line[4]:lower() .. " line is ready: press |cffffd100Deliver|r (or your Deliver key) to speak it. The game only allows /say and /yell from a key press.")
      self.keyHinted = true
    end
    self:Refresh()
    return
  end
  run.i = nextI
  self.state = "running"
  if self:IsMine(line) then self:Perform(line) end
  if not fromKey then self:NoteAuto() end
  if self.Cue then self:Cue(run.i, line) end
  if run.i >= #run.lines and not self:Flag("loop") then
    self.nextAt, self.nextDur = nil, nil
    self.timer = C_Timer.NewTimer(1, function() self.timer = nil; self:Finish() end)
  else
    self:Schedule(line)
  end
  self:Refresh()
end

-- the Deliver key or button: the next line, right now
function R:Deliver()
  if self.pending and self.DeliverPending then self:DeliverPending() return end
  if not self.run then self:Start(self.db.last); return end
  if self.state == "paused" then self.state = "running" end
  self:PostNext(true)
end

function R:Finish()
  if not self.run then return end
  self:Print(("|cffffd100%s|r finished."):format(self.run.name))
  if self.EndScene then self:EndScene() end
  self:Stop(true)
end

function R:Pause()
  if self.state ~= "running" and self.state ~= "waiting" then return end
  self:CancelTimer()
  self.state, self.nextAt = "paused", nil
  self:Refresh()
end

function R:Resume()
  if self.state ~= "paused" then return end
  self.state = "running"
  self:Schedule(self.run and self.run.lines[self.run.i])
  self:Refresh()
end

function R:Stop(silent)
  self:CancelTimer()
  local was = self.run
  if was and self.EndScene and not silent then self:EndScene() end
  self.run, self.state, self.nextAt, self.nextDur = nil, nil, nil, nil
  if was and not silent then self:Print("Stopped.") end
  self:Refresh()
end

function R:Skip()
  if not self.run then return end
  if self.state == "paused" then self.state = "running" end
  self:PostNext(true)
end

function R:TogglePlay()
  if self.state == "paused" then self:Resume()
  elseif self.state == "key" then self:Deliver()
  elseif self.state then self:Pause()
  else self:Start(self.db.last) end
end

-- jump to a line (a scene) in the running script, or start the chosen script there
function R:JumpTo(i)
  if self.run then
    self.run.i = i - 1
    self:CancelTimer()
    self.state = "running"
    self:PostNext(true)
  else
    self:Start(self.db.last, i)
  end
end

function R:Reschedule()
  if self.state ~= "running" or not self.nextAt then return end
  if self.db.dice then self:ArmTimer(self:NextDelay()); return end
  local elapsed = self.nextDur - (self.nextAt - GetTime())
  self:ArmTimer(math.max(1, self.db.interval - elapsed))
  self.nextDur = self.db.interval
end

function R:SetInterval(v)
  v = math.max(self.MIN_GAP, math.min(60, math.floor(v + 0.5)))
  if v == self.db.interval then return end
  self.db.interval = v
  if not self.db.dice then self:Reschedule() end
  self:Refresh()
end

function R:SetDice(on) self.db.dice = on and true or false; self:Reschedule(); self:Refresh() end

function R:Refresh() if self.UpdateBar then self:UpdateBar() end end

-- key bindings (Bindings.xml)
function StoryCaster_Binding(what)
  if not R.db then return end
  if what == "PANEL" then R.db.showBar = not R.db.showBar; R:Refresh()
  elseif what == "PLAY" then R:TogglePlay()
  elseif what == "DELIVER" then R:Deliver()
  elseif what == "STOP" then R:Stop()
  else
    local anims = { "BOW", "WAVE", "NOD", "LAUGH", "CHEER", "KNEEL" }
    local n = tonumber(what)
    if n and anims[n] then R:Animate(anims[n], true) end
  end
end

---------------------------------------------------------------------------
-- Starter scripts
---------------------------------------------------------------------------
local STARTERS = {
  { "Starter: A Greeting", "steps forward and lifts a hand in greeting.\n[wave]\nsmiles at {target}. \"Well met. I hoped I would find you here.\"\n" ..
    "glances over one shoulder, then lowers their voice. \"We should talk somewhere quieter.\"\n[nod]\nbows, and turns toward the road. [bow]" },
  { "Starter: A Toast", "raises a cup high above the table.\n/pause 3\n/s To friends, old and new!\n[cheer]\ndrinks deep, then sets the cup down with a satisfied {sigh|grin|laugh}." },
  { "Starter: A Duel Challenge", "steps into the open ground and draws their weapon.\nlevels the blade at {target}. \"You. Me. Here, this {time}.\"\n" ..
    "/y Let all of {zone} remember this!\n[salute]\nwaits, weight on the back foot, for an answer." },
  { "Starter: Farewell", "looks around the room one last time.\n[sigh]\n\"It has been an honour, {target}.\"\n[bow]\npulls up their hood and walks out into the {time}." },
  { "Starter: Duet (edit the names)", "## Act One\n[ME] steps into the lantern light.\n[Partner] looks up from the map. \"You came.\"\n[ME] nods. \"I always do.\" [nod]\n" ..
    "## Act Two\n[Partner] rolls up the map and rises. [salute]\n[ME] smiles. \"Then let us go.\"" },
}
local AMBIENT = { "Ambient: Idle", "adjusts their gloves.\nglances around the room.\n[sigh]\nhums a few bars of an old song.\nshifts their weight from one foot to the other.\n" ..
  "brushes some dust from a sleeve.\n[nod]\nwatches the door for a while.\nstretches, rolling one shoulder, then the other.\n[chuckle]\nlooks up at the sky.\ntaps a finger idly." }

function R:AddStarters()
  local me = UnitName("player") or "Me"
  local function add(name, text, opts)
    if self.db.scripts[name] then return end
    local s = self:Convert((text:gsub("%[ME%]", "[" .. me .. "]")), "lines", false)
    s.opts = opts
    self.db.scripts[name] = s
    table.insert(self.db.order, name)
  end
  for _, st in ipairs(STARTERS) do add(st[1], st[2]) end
  add(AMBIENT[1], AMBIENT[2], { ambient = true, loop = true, shuffle = true, diceMin = 25, diceMax = 70 })
end

---------------------------------------------------------------------------
-- Slash commands
---------------------------------------------------------------------------
local HELP = {
  "|cffb48cffStoryCaster|r v%s  -  /story <command>",
  "  (nothing)  show the panel   |   write  the script window   |   lines  edit lines one by one",
  "  start [name] | pause | resume | next | deliver | stop   |   jump <scene number>   |   ambient",
  "  list  your scripts   |   preview <name>   |   share <name>   |   delete <name>",
  "  lore  the Lore Library (class, faction and race roleplay)   |   lore <class, race or faction>  perform one",
  "  anim <emote>  play an animation   |   anims  list them",
  "  interval <15-60> | dice [min max] | pace | manual | loop | shuffle | test | animations | auto | compact",
  "  duet  auto-join duet invitations on or off   |   reset  move the panel back to the top",
  "  In a script: /pause 4, [bow], /bow, /s /y /p /ra /g lines, [Name] for duet parts, ## Scene, {target} {name} {zone} {time} {a|b|c}",
}

function R:Slash(input)
  local cmd, rest = (input or ""):match("^%s*(%S*)%s*(.-)%s*$")
  cmd = cmd:lower()
  local db = self.db
  if cmd == "" or cmd == "show" then db.showBar = true; self:Refresh()
  elseif cmd == "hide" then db.showBar = false; self:Refresh()
  elseif cmd == "help" then for i, l in ipairs(HELP) do self:Print(i == 1 and l:format(self.version) or l) end
  elseif cmd == "write" or cmd == "upload" or cmd == "new" or cmd == "import" then if self.ToggleWriter then self:ToggleWriter(true) end
  elseif cmd == "lines" or cmd == "edit" then if self.ToggleLines then self:ToggleLines(true, rest ~= "" and rest or nil) end
  elseif cmd == "share" or cmd == "export" then if self.Share then self:Share(rest ~= "" and rest or db.last) end
  elseif cmd == "start" or cmd == "play" then self:Start(rest)
  elseif cmd == "ambient" then self:Start("Ambient: Idle")
  elseif cmd == "lore" then
    if rest == "" then if self.ToggleLore then self:ToggleLore(true) end
    else
      local kind, key = self:FindLore(rest)
      if kind then self:PerformLore(kind, key)
      else self:Print("No lore called '" .. rest .. "'. Try a class, race or faction, like: /story lore blood elf") end
    end
  elseif cmd == "pause" then self:Pause()
  elseif cmd == "resume" then self:Resume()
  elseif cmd == "next" or cmd == "skip" then self:Skip()
  elseif cmd == "deliver" then self:Deliver()
  elseif cmd == "stop" then self:Stop()
  elseif cmd == "jump" or cmd == "scene" then
    local scenes = self:Scenes(self:Get(self.run and self.run.name or db.last))
    local n = tonumber(rest)
    if n and scenes[n] then self:JumpTo(scenes[n][1])
    else
      if #scenes == 0 then self:Print("This script has no scenes. Start one with a line like: ## Act Two") end
      for i, s in ipairs(scenes) do self:Print(("  %d. %s"):format(i, s[2])) end
    end
  elseif cmd == "list" then
    if #db.order == 0 then self:Print("No scripts yet. /story write") end
    for _, n in ipairs(db.order) do self:Print(("  |cffffd100%s|r  (%d lines)"):format(n, #db.scripts[n])) end
  elseif cmd == "preview" then
    local s = self:Get(rest ~= "" and rest or db.last)
    if not s then self:Print("Usage: /story preview <script name>") return end
    for i, l in ipairs(s) do self:Print(("%d. %s"):format(i, self.LineLabel and self:LineLabel(l) or self:LineToText(l))) end
  elseif cmd == "delete" or cmd == "del" then
    if self:Delete(rest) then self:Print("Deleted '" .. rest .. "'."); self:Refresh() else self:Print("No script called '" .. rest .. "'.") end
  elseif cmd == "anim" or cmd == "emote" then
    local t = rest:upper()
    if self.ANIM_BY_TOKEN[t] then self:Animate(t, true) else self:Print("Unknown animation. /story anims lists them.") end
  elseif cmd == "anims" then
    local names = {}
    for _, a in ipairs(self.ANIMS) do names[#names + 1] = a[1]:lower() end
    self:Print("Animations: " .. table.concat(names, ", ") .. ". Put one in a line as [bow], or a line /bow.")
  elseif cmd == "interval" then
    local n = tonumber(rest)
    if n and n >= self.MIN_GAP and n <= 60 then self:SetInterval(n); if self.SyncSlider then self:SyncSlider() end; self:Print("Timer: " .. db.interval .. "s")
    else self:Print("Usage: /story interval <" .. self.MIN_GAP .. "-60>  (never faster than one line every " .. self.MIN_GAP .. " seconds, so chat never sees spam)") end
  elseif cmd == "dice" then
    local lo, hi = rest:match("^(%d+)%s+(%d+)$")
    lo, hi = tonumber(lo), tonumber(hi)
    if lo and hi and lo >= self.MIN_GAP and hi <= 300 and lo <= hi then db.diceMin, db.diceMax = lo, hi; self:SetDice(true)
    else self:SetDice(not db.dice) end
    self:Print("Random timing " .. (db.dice and ("on (" .. db.diceMin .. "-" .. db.diceMax .. "s)") or "off"))
  elseif ({ loop = 1, shuffle = 1, test = 1, animations = 1, auto = 1, pace = 1, manual = 1, compact = 1, duet = 1 })[cmd] then
    local field = ({ loop = "loop", shuffle = "shuffle", test = "testMode", animations = "animations", auto = "autoAnim",
      pace = "autoPace", manual = "manual", compact = "compact", duet = "duetAuto" })[cmd]
    db[field] = not db[field]
    self:Print((cmd:gsub("^%l", string.upper)) .. " " .. (db[field] and "on" or "off") .. (cmd == "test" and db[field] and " (lines print only to you)" or "") .. ".")
    self:Refresh()
  elseif cmd == "reset" then
    db.barPoint = nil; db.showBar = true
    if self.bar then self.bar:ClearAllPoints(); self.bar:SetPoint("TOP", 0, -110) end
    self:Refresh()
  else self:Print("Unknown command. /story help") end
end

SLASH_STORYCASTER1, SLASH_STORYCASTER2 = "/story", "/storycaster"
SlashCmdList.STORYCASTER = function(msg) R:Slash(msg) end
function StoryCaster_OnAddonCompartmentClick() R.db.showBar = not R.db.showBar; R:Refresh() end

local f = CreateFrame("Frame")
f:RegisterEvent("ADDON_LOADED")
f:RegisterEvent("PLAYER_LOGIN")
f:RegisterEvent("PLAYER_TARGET_CHANGED")
f:SetScript("OnEvent", function(_, event, arg1)
  if event == "ADDON_LOADED" and arg1 == ADDON then
    StoryCasterDB = copyDefaults(DEFAULTS, StoryCasterDB)
    R.db = StoryCasterDB
    -- pacing repair: older versions could reset the timer to 5 seconds when the panel was built
    if not R.db.pacing15 then
      if (R.db.interval or 0) < 20 then R.db.interval = 20 end
      if (R.db.diceMin or 0) < 15 then R.db.diceMin = 15 end
      if (R.db.diceMax or 0) < R.db.diceMin then R.db.diceMax = 25 end
      R.db.pacingFixed, R.db.pacing15 = true, true
    end
    -- the old single sample is replaced by the starters
    if R.db.scripts["Sample: A Greeting"] and not R.db.startersAdded then R:Delete("Sample: A Greeting") end
    -- scripts saved before /pause and other commands were understood are rebuilt once
    local fixed = 0
    for name, script in pairs(R.db.scripts) do
      local new, changed = R:Repair(script)
      if changed then R.db.scripts[name] = new; fixed = fixed + 1 end
    end
    R.repaired = fixed
    if R.Comms then R:Comms() end
  elseif event == "PLAYER_LOGIN" then
    if not R.db.startersAdded then R:AddStarters(); R.db.startersAdded = true end
    if not R:Get(R.db.last) then R.db.last = R.db.order[1] end
    R:Refresh()
    R:Print("v" .. R.version .. " loaded. /story shows the panel, /story help lists everything.")
    if (R.repaired or 0) > 0 then R:Print(R.repaired .. " saved script" .. (R.repaired == 1 and "" or "s") .. " updated: /pause lines are now real pauses, not emotes.") end
  elseif event == "PLAYER_TARGET_CHANGED" then
    if R.bar and R.bar:IsShown() then R:Refresh() end
  end
end)
