-- StoryCaster lore library: the races of the Horde. Original writing in StoryCaster's script format.
local ADDON, ns = ...
local R = ns.R
R.LORE = R.LORE or {}
R.LORE.race = R.LORE.race or {}
local L = R.LORE.race

L.Orc = { "Orc", [[
## Draenor
stands tall, tusks gleaming, arms folded across a broad chest.
says, "My people came from Draenor, a red world of wide plains and ancient spirits."
says, "We were shamans then. Clans of hunters and warriors who listened to the elements."
says, "Then Gul'dan whispered, and Kil'jaeden promised power, and we drank the blood of a demon."
## The Blood Curse
grips a fist tightly, knuckles cracking.
says, "The fel turned our skin green and our hearts to fire. We forgot the spirits."
says, "We burned Draenor's forests. We slaughtered the draenei. We became what the Legion wanted."
says, "Then they sent us through the Dark Portal to burn your world too."
falls silent, jaw tight. [sigh]
## The Camps
says, "We lost the Second War. The humans put us in camps."
says, "Without the demon's blood, our people grew sick and listless. Lethargy, they called it."
says, "Warriors sitting in the mud, staring at nothing. That was the lowest my people ever sank."
## Thrall
speaks of Thrall, raised as a slave and a gladiator, who broke free and led the orcs out of the camps.
says, "He taught us to listen to the elements again. He gave us back our pride."
says, "He led us across the sea to Kalimdor, to a new land, a new start."
## Grom Hellscream
says, "Grom Hellscream drank the demon's blood a second time at Ashenvale. Then he killed the demon Mannoroth."
says, "His death freed us from the blood curse forever. Every orc owes him our freedom."
raises a fist in salute. [salute]
## Durotar
describes Durotar: red earth, harsh sun, jagged rocks, the land named for Thrall's father, Durotan.
says, "Hard land. It made us strong. We built Orgrimmar with our own hands."
## The Clans
names them proudly: "Frostwolf. Warsong. Blackrock. Bleeding Hollow. Shattered Hand. Thunderlord."
says, "Each clan has its own customs, its own songs, its own grudges."
says, "Under the Horde banner, we stand together. Usually."
grins, tusks flashing. [chuckle]
## Honor
says, "An orc's word is their bond. Break it, and you are nothing."
says, "We fight with honor. We face our enemies. We do not stab in the back."
## Lok'tar
says, "Lok'tar ogar. Victory or death. Every orc child learns those words before their own name."
## The Wolves
says, "Orcs ride great wolves. Loyal, fierce, and smarter than most people."
says, "My wolf would die for me. I would die for my wolf. That is the bond."
## The Shamans Return
says, "Our shamans speak to the elements again. The spirits forgave us. Slowly."
says, "When I hear the earth speak, I remember who we were before the curse."
## Garrosh
grows quiet. "Garrosh Hellscream led us into darkness again. He nearly destroyed everything we rebuilt."
says, "We cast him down. An orc can admit when an orc is wrong."
## The Mag'har
says, "On alternate Draenor, our cousins never drank the demon blood. They are the Mag'har, the uncorrupted."
says, "They remind us of what we could have been. And what we can still become."
## Strength
says, "Strength is not just muscle. Strength is getting back up after your people fall."
says, "Orcs have fallen further than anyone. And we rose. That is our strength."
## The Call
turns to {target}, eyes fierce and proud.
says, "Whatever your blood, if you fight with honor, you are welcome at our fire."
pounds a fist against their chest. [roar]
/s Lok'tar ogar!
strides off across the {zone}, wolf at their side.
]] }

L.Scourge = { "Forsaken", [[
## The Grave
adjusts a tattered cloak over bones that rattle faintly with each movement.
says, "Do not look so horrified. I was a farmer once. Lordaeron. Barley and onions."
says, "Then the plague came, and I died, and I woke up hungry."
## The Scourge
says, "The Lich King raised us. We were his puppets. Mindless. Cruel."
says, "I remember killing. I remember not caring. That is the worst part."
falls silent, jaw creaking. [sigh]
## The Freedom
says, "Then the Lich King's grip slipped. Suddenly I could think again."
says, "I looked down at my hands and saw bones. I screamed for three days."
says, "Lady Sylvanas found us. Gave us a name. The Forsaken. Gave us a purpose."
## The Undercity
describes the Undercity beneath the ruins of Lordaeron: green sewers, the Royal Quarter, the apothecaries' laboratories.
says, "We built a city beneath the city that rejected us. Dark, damp, home."
says, "The living cannot stand the smell. That suits us fine."
## The Rejection
says, "We went to our families. They screamed and ran. Some tried to kill us."
says, "My wife. My son. They did not recognize me. Or they did, and that was worse."
## The Horde
says, "The Horde took us in when no one else would. Thrall gave us a seat at the council."
says, "Not because he liked us. Because he understood what it is to be a monster in others' eyes."
## Sylvanas
grows quiet. "Lady Sylvanas led us for years. Then she burned Teldrassil and served the Jailer."
says, "She betrayed us. She betrayed everyone. We do not speak her name with love anymore."
## Calia
says, "Now Calia Menethil leads us. Undead, but touched by the Light."
says, "She is strange. Warm, somehow. She believes we can be more than the plague made us."
## The Plague
says, "Some Forsaken still brew plagues in secret. They believe the living must pay."
says, "I do not. I died once. I do not wish it on anyone."
## Food
says, "We do not need to eat. We do anyway. Habit. Comfort. Spite."
says, "I still enjoy cheese. My tongue is gone, but I remember the taste."
laughs, a dry rattling sound. [laugh]
## Faith
says, "The Light burns us. But some of us still pray. The Light does not always refuse us."
says, "Calia is proof. Maybe hope does not die when we do."
## The Long Night
says, "We do not sleep. The nights are very long."
says, "I read. I write letters I never send. I visit graves of people I knew."
## Kinship
says, "Forsaken look after each other. No one else will."
says, "If a Forsaken falls, we carry them home. Every time."
## The Truth
says, "I am dead. But I am not gone. I am still here, still thinking, still choosing."
says, "That has to count for something."
## The Farewell
turns to {target} with a grin of yellowed teeth.
says, "Enjoy your heartbeat while you have it. It is a precious thing."
bows stiffly, joints creaking. [bow]
/s Dark Lady watch over— well. Old habits.
shuffles off into the {time} shadows.
]] }

L.Tauren = { "Tauren", [[
## The Earth Mother
lowers their great horned head and touches the earth with one broad hand. [kneel]
says, "An'she and Mu'sha, the sun and the moon. They are the eyes of the Earth Mother."
says, "Everything that lives is her child. We tauren try to remember that."
## Mulgore
describes Mulgore: endless golden grasslands, the wind rippling through them like water, the great mesas of Thunder Bluff rising against the sky.
says, "When the wind is right, you can hear the plains breathing."
says, "My people wandered these lands for generations. Hunting, singing, following the herds."
## The Centaur
says, "We were hunted by the centaur for years. They drove us from our lands."
says, "Then Thrall and his orcs came. They fought beside us. We drove the centaur back."
says, "Cairne Bloodhoof said, 'We owe them our homeland.' We joined the Horde gladly."
## Cairne
speaks with deep reverence of Cairne Bloodhoof, the great chieftain who united the tauren tribes.
says, "He was wise, strong, and gentle. He fought Garrosh in honorable combat and was betrayed by poison."
lowers their head in a long moment of silence. [bow]
says, "His son, Baine, leads us now. He carries his father's wisdom. And his father's sorrow."
## Thunder Bluff
describes Thunder Bluff: great wooden lodges atop the mesas, bridges swaying in the wind, totems taller than trees.
says, "We raised our city in the sky so that we would always be close to An'she."
says, "The elevators are a new invention. The goblins sold them to us. They creak terribly."
## The Shamans and Druids
says, "Tauren were among the first to embrace druidism alongside the night elves."
says, "Hamuul Runetotem brought us into the Cenarion Circle. The forest was glad."
says, "Our shamans speak to the elements as our ancestors did. The spirits know us well."
## The Hunt
says, "We hunt with respect. We take only what we need. We thank the beast for its gift."
says, "Every part is used. Hide, bone, meat, horn. Nothing is wasted."
## The Kodo
says, "Kodo beasts carry our homes on their backs. Slow, patient, enormous."
says, "When a kodo dies, the others gather around and mourn. They remember, as we do."
## The Size
glances down at {target} from a great height with a gentle smile.
says, "People are afraid of us because we are so large. We are mostly very gentle."
says, "Mostly. Do not insult the Earth Mother."
chuckles, a deep rumbling sound. [chuckle]
## The Ancestors
says, "Our ancestors watch over us from the spirit realm. We speak to them through the shamans."
says, "When I am troubled, I sit on the bluffs at dusk and listen to the wind. Sometimes they answer."
## Peace
says, "The tauren do not love war. We fight when we must. We would rather plant and hunt and sing."
says, "Baine has tried to make peace with the Alliance. He is wise. Some call him weak. They are wrong."
## The Stars
looks up at the {time} sky, where the first stars are appearing.
says, "Every star is the campfire of an ancestor. Some nights the sky is very crowded."
## The Blessing
lays a broad, warm hand on {target}'s shoulder.
says, "Walk with the Earth Mother. May An'she warm your days and Mu'sha guide your nights."
bows their great head slowly. [bow]
/s Ishne-alo por'ah.
turns and walks off across the plains, hooves heavy and steady.
]] }

L.Troll = { "Troll", [[
## The Darkspear
leans back with a lazy grin, tusks curling, long arms crossed.
says, "Ya know what a Darkspear is, mon? We da survivors. Every time."
says, "We been chased off islands, betrayed by cousins, cursed by gods. Still here."
## The Echo Isles
describes the Echo Isles: white sand, turquoise water, palm trees, and the old troll ruins half sunk in the jungle.
says, "Da Echo Isles be home. Da sea, da sun, da drums in da night."
says, "We lost dem once to a mad witch doctor. Took dem back. Darkspear always come home."
## Vol'jin
speaks with deep respect of Vol'jin, shadow hunter and warchief of the Horde.
says, "He listened to da loa. He saw true. He gave his life to stop da Legion."
says, "With his last breath, he named Sylvanas warchief. Da spirits tricked him, mon."
lowers their head. [bow]
## The Loa
says, "Da loa be da wild gods. Bwonsamdi, da death loa. Hir'eek, da bat. Shirvallah, da tiger."
says, "We give dem offerings. Dey give us strength. Fair trade."
says, "Bwonsamdi gonna come for all of us one day. I tell him: not yet, mon, not yet."
laughs. [laugh]
## The Empires
says, "Long ago, trolls ruled dis world. Zandalar. Gurubashi. Amani. Drakkari."
says, "We built temples older den any human city. We conquered de elves before dey even had a name."
says, "Den we fell. Empires always fall, mon. Dat's why Darkspear never build one."
## The Regeneration
holds up a scarred arm, flexing long fingers.
says, "Trolls heal fast. Cut off a finger, it grow back. Mostly."
says, "Very useful in a fight. Very confusing for healers."
## Sen'jin
speaks of Sen'jin, Vol'jin's father, the witch doctor who saw the coming of Thrall in a vision.
says, "He died so we could be free. Darkspear never forget."
## Voodoo
pulls a small carved fetish from a pouch and turns it over in their fingers.
says, "Voodoo be powerful, mon. Hexes, charms, visions."
says, "Some say it be evil. It be a tool. Like a knife. Depends who holdin' it."
## The Horde
says, "Thrall saved da Darkspear from da murlocs and da sea witch. We swore to follow him."
says, "We kept dat promise. Darkspear never break a promise."
## Rokhan
says, "Rokhan be our leader now. Shadow hunter, like Vol'jin. Quiet, sharp, patient."
says, "He listen to da spirits. Dey tell him good things, mostly."
## The Dance
starts swaying to a rhythm only they can hear, shoulders rolling. [dance]
says, "Ya gotta dance, mon. Dance for da loa. Dance for da ancestors. Dance cuz it feel good."
## The Spirit
says, "Trolls live hard, laugh loud, fight mean. Dat's da way."
says, "Life too short to be serious all da time. Even for us, and we live a long time."
## The Farewell
throws an arm around {target}'s shoulders with a wide grin.
says, "Stay sharp, mon. Watch ya back. And if Bwonsamdi come callin', tell him I sent ya."
lets go with a hearty laugh and a wave. [wave]
/s Stay away from da voodoo!
saunters off toward the {zone} shore, humming an old island song.
]] }

L.BloodElf = { "Blood Elf", [[
## Quel'Thalas
brushes a speck of dust from an immaculate sleeve, then looks up with a cool, elegant gaze.
says, "Quel'Thalas. The land of eternal spring. Golden forests. Crystal spires. Magic in the very air."
says, "My people built paradise. Then we lost it. Then we built it back."
## The Highborne
says, "We were Highborne once. Night elves. Exiles who loved magic too much for our cousins' taste."
says, "We sailed east and founded a new kingdom around the Sunwell. A fountain of pure arcane power."
says, "For seven thousand years, it nourished us. We were beautiful. We were proud. Perhaps too proud."
## The Scourge
grows cold. "Then Arthas came. He killed King Anasterian. He corrupted the Sunwell."
says, "Our forests burned. Our people died by the thousands. Silvermoon was half destroyed."
falls silent, hand tightening on the hilt of a blade. [sigh]
## The Hunger
says, "Without the Sunwell, we starved. Not for food. For magic."
says, "Kael'thas renamed us sin'dorei, children of the blood, in memory of our dead."
says, "Then he led us to Outland and betrayed us to the Legion. We learned not to trust princes."
## The Sunwell Restored
says, "The Sunwell was restored by the naaru M'uru and the draenei prophet Velen. Holy light and arcane together."
says, "We were saved by the people we had once mocked. Humility is a bitter wine."
## Silvermoon
describes Silvermoon City: crimson and gold banners, floating brooms sweeping the streets, magisters in flowing robes, the scent of flowers and magic.
says, "Every surface gleams. Every garden is perfect. It took centuries."
says, "Half the city still lies in ruins from the Scourge. We call it the Dead Scar. We do not forget."
## The Horde
says, "We joined the Horde when the Alliance turned its back on us."
says, "Strange allies, the orcs. Loud, crude, brave. They kept their word. That matters."
## Lor'themar
speaks of Lor'themar Theron, regent lord of Quel'Thalas.
says, "He is no king. He refuses the title. He simply does the work."
says, "We respect that. We have had enough of kings."
## The Magisters
lifts a hand, and a small flame of golden-red fire dances above it.
says, "Every sin'dorei child learns magic before they learn to walk. It is in our blood."
lets the flame vanish with an elegant flick of the wrist.
## Beauty
says, "Some call us vain. We prefer refined."
smooths an imaginary wrinkle in their sleeve with a small smile.
says, "There is nothing wrong with wanting to be beautiful after so much ugliness."
## The Rangers
says, "The Farstriders, the rangers of Quel'Thalas, guarded our borders for millennia."
says, "Sylvanas Windrunner was their ranger-general once. Before."
says, "We do not speak her name lightly anymore."
## Pride
says, "We have survived the Scourge, the Legion, our own princes, our own hunger."
says, "We are still standing. Still beautiful. Still proud."
## The Farewell
inclines their head to {target} with impeccable courtesy. [bow]
says, "May the eternal sun guide your path."
/s Bal'a dash, malanore.
turns with a swirl of crimson and gold and walks away, every step graceful.
]] }

L.Goblin = { "Goblin", [[
## Business
rubs their hands together, eyes gleaming, a wide toothy grin spreading across their face.
says, "Hey there, friend! You look like someone who appreciates a good deal."
says, "Goblins, see, we got two things in our blood: business and explosives. Sometimes both at once."
## Kezan
describes Kezan: an island of profit, trade princes, gold-plated everything, and a volcano that finally had enough.
says, "Kezan was paradise. If you had money. Which I did. Briefly."
says, "Then the volcano blew. Deathwing, the Cataclysm, everything burning."
says, "Trade Prince Gallywix charged us to get on the boats. Charged us! While the island exploded!"
throws up their hands in disgust.
## Gallywix
says, "Gallywix. The biggest crook in goblin history. Which is saying something."
says, "Charged us for air. For water. For the privilege of being his slaves."
says, "We finally kicked him out. He is probably selling sand in a desert somewhere."
laughs. [laugh]
## The Bilgewater Cartel
says, "We are the Bilgewater Cartel now. Joined the Horde after we washed up on the Lost Isles."
says, "Thrall gave us a chance. We gave the Horde rockets, bombs, and very fair loans."
## The Trade
says, "In Booty Bay, Gadgetzan, Everlook, Ratchet. Goblins run neutral ports where anyone can trade."
says, "We do not care about Horde or Alliance at the auction house. Gold is gold."
## Engineering
pulls out a small handheld gadget that sparks ominously.
says, "Goblin engineering: fast, cheap, and very likely to explode."
says, "Gnomes spend ten years on a blueprint. We spend ten minutes and hope for the best."
says, "Ours works about half the time. That is twice as often as you would think."
## Azerite
says, "Azerite! The blood of the world! Glowing golden stuff that powers everything!"
says, "We mined it, we sold it, we built rockets with it. Some say we should not have. They were probably right."
## Rockets
says, "There is no problem that cannot be solved with a big enough rocket."
says, "Stuck in a canyon? Rocket. Enemy fortress? Rocket. Bad haircut? Small rocket."
## Size
says, "We are small. That just means we get to the gold before the big folk notice."
## Family
says, "Goblins do care about family. Mostly about family businesses. But still."
says, "My grandmother taught me to haggle before I could walk. Best lesson I ever got."
## The Hustle
says, "Every goblin is a hustler. Selling, trading, inventing, betting."
says, "We do not stop. If we stop, someone else gets rich."
## The Truth
grows briefly serious. "We lost our home. We were betrayed by our own leader."
says, "We rebuilt with nothing. Everything we have, we made ourselves."
says, "That is what being a goblin really means. Grit, wit, and a very good accountant."
## The Deal
offers {target} a small business card, printed in gold ink.
says, "Need anything, call me. Fair prices. Mostly fair. Fair-ish."
grins widely and gives a thumbs up.
/s Time is money, friend!
zips off on a small rocket-powered contraption, trailing smoke and laughter.
]] }

L.Nightborne = { "Nightborne", [[
## Suramar
adjusts the delicate silver crown of their headdress, starlight markings glowing faintly along their skin.
says, "For ten thousand years, my people lived beneath a dome. Suramar, the last city of the Highborne."
says, "Protected. Isolated. Beautiful. And slowly rotting from within."
## The Nightwell
speaks of the Nightwell, the source of arcane power that sustained the shal'dorei.
says, "We drank from it every day. Arcwine, from the Nightwell's power. We could not live without it."
says, "It made us immortal. It also made us dependent. A beautiful cage."
## The Withered
grows quiet. "Those who could not get arcwine withered. Became husks. Mindless."
says, "We called them the Withered. We locked them away in the ruins. We did not speak of them."
says, "Every nightborne feared becoming one. It was the price of our perfection."
## Elisande
speaks of Grand Magistrix Elisande, who ruled Suramar for ten thousand years.
says, "She made a deal with the Legion to keep our city safe. She sold our souls for safety."
says, "Thalyssra rebelled. We fought our own people to be free."
## The Rebellion
says, "First Arcanist Thalyssra led the rebellion. Exiled, starving, determined."
says, "With help from outsiders, we threw down Elisande and freed Suramar from the Legion."
says, "Elisande died. The Nightwell was freed. We had to learn to live without it."
## The Horde
says, "The Horde helped us retake our city. We joined them out of gratitude and practicality."
says, "Orcs and trolls in the streets of Suramar. My ancestors would faint."
laughs softly. [chuckle]
## The Night
says, "We are children of the night. Our city glows silver and violet under the stars."
says, "The day is too bright for us. Too loud. We prefer the soft glow of moonlight."
## The Magic
lifts a hand, and delicate silver light spirals upward, forming a tiny glowing constellation.
says, "Magic is our art. Our music. Our poetry."
says, "A nightborne casts the way a bard sings. With feeling, and with style."
## The Gardens
describes the gardens of Suramar: silver trees, glowing flowers, fountains of starlight water.
says, "Ten thousand years to perfect a garden. You learn patience. And a deep hatred of weeds."
## The Masks
says, "The aristocracy of Suramar wore masks to parties. Intrigue was our favorite sport."
says, "Who loved whom. Who betrayed whom. Who wore the same robe twice. Scandalous."
## Freedom
says, "We were trapped in perfection for ten thousand years. Now we are free in imperfection."
says, "It is messy. It is frightening. It is wonderful."
## Learning
says, "Every day I learn something new about the outside world. A new flower. A new taste."
says, "Bread. Do you know how wonderful bread is? We never had bread."
## The Farewell
bows elegantly to {target}, silver markings glowing softly. [bow]
says, "May the stars guide your path, and may you never know the hunger of the Nightwell."
/s Shal'dorei endure.
glides away into the {time} shadows, a trail of faint silver light behind them.
]] }

L.HighmountainTauren = { "Highmountain Tauren", [[
## The Mountain
plants a great hoof on a rock and gazes out at the peaks with a deep, contented breath.
says, "Highmountain. Where the sky is close, the air is thin, and the mountains have names."
says, "We are tauren, but different from our cousins in Mulgore. Mountain-born. Moose-horned."
## The Tribes
says, "Four tribes. Bloodtotem, Skyhorn, Rivermane, Highmountain."
says, "We fought each other for centuries. Then the Legion came, and we remembered we were family."
## Huln
speaks of Huln Highmountain, the great hero of the War of the Ancients.
says, "Ten thousand years ago, Huln stood beside Malfurion and Tyrande against the Burning Legion."
says, "He carried the Hammer of Khaz'goroth. He saved the world. Then he came home and founded our people."
## Mayla
says, "Mayla Highmountain leads us now. Huln's descendant. Strong, fair, stubborn."
says, "She united the tribes again. She led us into the Horde."
## Thunder Totem
describes Thunder Totem: a great carved totem pole taller than a castle, ringed by lodges, eagles circling overhead.
says, "Every carving tells a story. Every story is true. Mostly."
says, "The eagles watch over us. They are our oldest friends."
## Neltharion's Lair
grows quiet. "Deep beneath our mountains is Neltharion's Lair. The black dragon's old home."
says, "The Bloodtotem tribe was corrupted by the dragon's blood. We had to save them from themselves."
## The Drogbar
says, "The drogbar are the earthbound creatures of the deep tunnels. Some are friends. Some are not."
says, "They speak with stone. We speak with sky. We have learned to talk to each other."
## The Eagles
lifts an arm, and for a moment it seems a great eagle might land upon it.
says, "Skyhorn tauren ride eagles across the peaks. There is no freedom like it."
## The Rivers
says, "The Rivermane tribe keeps the waters clean and the fish plentiful."
says, "They say every river in Highmountain sings a different song."
## The Horns
reaches up to touch their great moose-like antlers with a wry smile.
says, "These catch on every doorframe in Orgrimmar. Every single one."
laughs, a deep booming sound. [laugh]
## The Hunt
says, "We hunt the great moose and elk of the mountains. Respectfully. Gratefully."
says, "The Earth Mother provides. We take what we need and give thanks."
## The Horde
says, "We joined the Horde because Baine Bloodhoof, our cousin, asked us. Family asks, family answers."
## The Blessing
lays a heavy, warm hand on {target}'s shoulder.
says, "May the mountain keep you steady, and may the sky keep you free."
bows deeply, antlers sweeping low. [bow]
/s For Highmountain!
turns and climbs off toward the {zone} peaks, steady as the mountain itself.
]] }

L.MagharOrc = { "Mag'har Orc", [[
## The Uncorrupted
stands proud and broad, skin the rich brown of earth, tusks clean and white.
says, "Mag'har. The uncorrupted. We never drank the demon's blood."
says, "On our Draenor, the Iron Horde was stopped. We stayed true to the old ways."
## Draenor
describes their Draenor: wide red plains, ancient forests, mountains where the spirits still speak loudly.
says, "On my world, the shamans never fell silent. The elements never abandoned us."
says, "But the Legion came anyway. The Lightbound came, crushing everything in the name of the Light."
## The Lightbound
grows angry. "The Lightbound draenei of our world said their Light was the only truth."
says, "Convert or die. That was their offer. We refused."
says, "We fought them for years. We lost many. We never bent."
## Grommash
speaks of Grommash Hellscream, who refused the demon's blood on alternate Draenor.
says, "He chose freedom over power. He broke the cycle."
says, "Every Mag'har remembers that choice. It is why we are who we are."
## Geya'rah
says, "Overlord Geya'rah leads us. Grom's daughter. Fierce and fearless."
says, "She brought us to Azeroth when our world was dying. She chose the Horde."
## Azeroth
says, "When we came to Azeroth, we met our cousins. Green-skinned orcs who had drunk the demon blood."
says, "We were shocked. Then we saw how they fought back. How they rebuilt. We were proud of them."
## The Old Ways
says, "We keep the old customs. The rites of passage. The songs of the ancestors."
says, "We hunt the great beasts of Draenor in our dreams. We will hunt them again."
## The Spirits
kneels and presses a palm to the ground, eyes closed. [kneel]
says, "The spirits of Azeroth are different. Quieter. Older. But they listen."
rises again, satisfied.
## The Wolves
says, "Our wolves came with us through the portal. Draenor wolves. Larger. Wilder."
says, "My wolf still howls at the strange moon. I howl with her sometimes."
## Honor
says, "Honor is everything. We fight face to face. We keep our word. We protect the weak."
says, "Our green cousins forgot that for a time. We remind them."
## The Clans
says, "Frostwolf, Warsong, Blackrock. Our clans came through together. We stand together still."
## Pride
says, "We are the orcs your ancestors might have been, if they had refused Gul'dan."
says, "We do not look down on our cousins. We look at them and see survivors."
## The Call
raises a fist toward {target} in greeting.
says, "If you have honor in your heart, you have a friend among the Mag'har."
lets out a deep war cry that echoes across the {zone}. [roar]
/s Lok'tar ogar!
strides away with their wolf, proud and unbroken.
]] }

L.ZandalariTroll = { "Zandalari Troll", [[
## The Golden Empire
stands tall and regal, tusks gleaming with gold rings, adorned in jewels and feathers.
says, "Zandalar. The first empire. The cradle of all trolls."
says, "Before humans learned to build, before elves learned magic, we ruled."
## Dazar'alor
describes Dazar'alor: a great golden pyramid rising above the jungle, the Great Seal at its peak, the city sprawling at its feet.
says, "Every stone was laid by the ancestors. Every carving tells our history."
says, "Gold everywhere. We are not subtle people."
laughs, a deep rich sound. [laugh]
## The Loa
says, "The loa are our gods. Rezan, the king of the jungle. Gonk, the raptor. Pa'ku, the pterrordax. Bwonsamdi, death himself."
says, "We serve them. They protect us. A pact older than any empire."
## Rastakhan
speaks of King Rastakhan, who ruled Zandalar for centuries.
says, "He made a pact with Bwonsamdi to save our people. He gave his life in the battle for Dazar'alor."
lowers their head. [bow]
says, "His daughter, Queen Talanji, rules now. Young, fierce, determined."
## Talanji
says, "Talanji brought us into the Horde. Many of the old families did not like it."
says, "She saw what we could not. The world has changed. Even an empire must change with it."
## The Pyramids
says, "Our temples are older than the Night Elves' first city."
says, "Some say we learned to build from the titans. We say the titans learned from us."
grins proudly.
## The Raptors
says, "Every Zandalari child bonds with a raptor. Mine is named Zekhan. Very loyal. Very bitey."
## Mummies
says, "We honor our dead. The great kings are mummified, preserved, watched over by priests."
says, "Death is not the end in Zandalar. Bwonsamdi keeps the gate. Sometimes he opens it."
## The Prophets
says, "Zandalari prophets see the future in dreams. Sometimes they see the end of empires."
says, "Ours saw the end of ours. We listened. We changed. We survived."
## The Height
stands even taller, looking down at {target} with an amused smile.
says, "We Zandalari are the tallest of the trolls. Some say the most beautiful."
says, "All of them say the most humble, of course."
chuckles. [chuckle]
## Gold
says, "Gold is sacred. It does not tarnish. It shines forever. Like our empire."
## The Fall and Rise
says, "Our empire fell. Then we rose. Then we fell again. Then we rose again."
says, "An empire is not its buildings. It is its people. The Zandalari endure."
## The Farewell
bows with regal dignity, gold jewelry chiming softly. [bow]
says, "May the loa walk beside you, and may Bwonsamdi wait a long time for you."
/s Zandalar forever!
strides away with a raptor at their heels, every step proud.
]] }

L.Vulpera = { "Vulpera", [[
## The Caravan
twitches large ears, sniffing the air with a small fox-like nose.
says, "Hello! Hello! You look like a traveler too. I can always tell."
says, "Vulpera are wanderers. We live in caravans. We move with the sands."
## Vol'dun
describes Vol'dun: endless golden dunes, ancient ruins half buried, the hot wind singing through canyons.
says, "Vol'dun is harsh. Sandstorms. Scorpions. Sethrak raiders. Not much water."
says, "But it is home. We know every dune, every oasis, every secret path."
## The Sethrak
grows serious. "The sethrak, the snake people, hunted us for generations."
says, "They wanted our caravans, our water, our lives."
says, "We fled, hid, fought back. We are small, but we are clever."
## The Caravans
says, "Each caravan is a family. Old ones and pups, traders and fighters, all together."
says, "When one caravan is attacked, the others come running. We protect each other."
## Scavenging
pulls a strange trinket from a bulging pack: a broken compass, a shiny button, a tiny bell.
says, "Vulpera find treasure in everything. Your trash is our fortune."
says, "This bell? It is very important. I do not know why yet."
## Size
says, "We are small. Very small. That is good. You cannot hit what you cannot see."
says, "Also, we fit into very interesting places."
## The Horde
says, "The Horde found us in Vol'dun. They helped us fight the sethrak."
says, "We joined them. They have very big tents and very interesting food."
## Ears
wiggles large fox ears proudly.
says, "These ears can hear a scorpion skittering a hundred paces away."
says, "They can also hear when someone is talking about snacks. Very useful."
laughs, a small yipping sound. [laugh]
## Trade
says, "Vulpera are great traders. We barter everything. Silk for spices. Trinkets for tales."
says, "Do you have anything shiny? I will trade you a very good story."
## The Stars
says, "In the desert, the stars are bright. We navigate by them."
says, "My grandmother taught me every constellation. The Fox, the Caravan, the Lost Pup."
## Kindness
says, "In the desert, you share water. Always. Even with strangers."
says, "Someone shared with us once. Now we share with everyone."
## Resilience
says, "We have lost caravans, families, homes. We keep going."
says, "That is the Vulpera way. Pack up, move on, find a new oasis."
## The Farewell
presses a small shiny trinket into {target}'s hand. "For luck! And trading! Mostly luck."
waves enthusiastically, tail swishing. [wave]
/s May your path be cool and your water plenty!
scurries off toward the {zone} horizon, pack jingling with treasures.
]] }
