-- StoryCaster lore library: the factions. Original writing in StoryCaster's script format.
local ADDON, ns = ...
local R = ns.R
R.LORE = R.LORE or {}
R.LORE.faction = {}
local L = R.LORE.faction

L.Alliance = { "Alliance", [[
## The Blue and Gold
unfurls a small blue banner stitched with a golden lion, the edges worn soft with travel.
holds it up to the wind and watches it ripple. "Every thread of this was earned."
says, "The Alliance began as a desperate idea: that strangers might stand together."
recalls the stories of the First War: Stormwind burning, refugees crossing the sea to Lordaeron.
says, "Anduin Lothar led a broken kingdom north with nothing but hope and a sword."
says, "Terenas Menethil listened. Humans, dwarves, high elves, gnomes. One banner."
folds the banner carefully and tucks it close to their heart.
## The Kingdoms
names them softly, as if counting old friends: "Stormwind. Ironforge. Gnomeregan. Darnassus. The Exodar."
says, "Gilneas, behind its wall, until the wall could not save it."
says, "Kul Tiras, mistress of the seas. The Dark Iron clans, back from the fire."
says, "Every one of them came to us bleeding. We made room."
## The Lion of Stormwind
speaks of Varian Wrynn, the king who was a gladiator, the gladiator who became a king.
says, "He died at the Broken Shore buying time for the rest of us to escape."
falls silent for a breath, head bowed. [bow]
says, "Anduin carries the crown now. He would rather carry a lantern. That is why I trust him."
## What We Believe
says, "The Alliance is not perfect. We have made terrible mistakes."
says, "But we believe something stubborn and simple: that people are worth defending."
says, "The farmer in Westfall. The miner in Dun Morogh. The child in the canals of Stormwind."
says, "Kings and champions are only useful if they are useful to them."
## The Wars
remembers the fields and walls: Hillsbrad, the Dark Portal, Icecrown, the Broken Shore.
says, "We have fought the Horde. We have fought beside the Horde. Both were hard."
says, "The Legion did not care which banner you carried. Neither did the Scourge."
says, "In the end, the dead all look the same. That is worth remembering when the drums start."
## The Cities
describes Stormwind at dawn: the bells, the canals catching the light, the smell of bread from the trade district.
says, "Ironforge's forges never go cold. You can feel the warmth through the mountain."
says, "The Exodar hums like a living thing. It sailed between stars to find us."
smiles. "I have slept in all of them. None felt like home until I had friends inside."
## Honor
says, "We say 'For the Alliance' before battle. It is not a war cry. It is a reminder."
says, "That we fight for each other. That none of us is alone."
says, "That the lion and the hammer and the leaf and the gear stand together."
## The Promise
places a hand over their heart where the banner rests.
says, "Wherever you are from, whatever you were before, there is a place for you under this banner."
says, "We have room. We always make room."
turns to {target} and offers a firm, warm handshake.
raises a fist to the sky. [cheer]
/y For the Alliance!
salutes the banner one last time before walking on toward the {time} road. [salute]
]] }

L.Horde = { "Horde", [[
## The Red Banner
lifts a red banner stitched with a black emblem, its edges scorched from old fires.
says, "The Horde was born in chains. We will never forget that."
says, "The internment camps. The lethargy. Our people dying in the dirt of a world that was not ours."
grips the banner pole until the knuckles pale.
says, "Thrall broke the chains. He gave us back our names and our honor."
## The Brotherhood
says, "The Horde is not one people. It is many, standing together because no one else would stand with us."
names them with pride: "Orcs. Trolls of the Darkspear. Tauren of Mulgore. The Forsaken. The sin'dorei."
says, "Goblins, who sell to everyone and fight for us. Pandaren, who chose fire and passion."
says, "Nightborne, Highmountain, Mag'har, Zandalari, Vulpera. Each came with scars. Each found a home."
## Lok'tar
says, "Lok'tar ogar. Victory or death. It is not bravado. It is how we have survived."
says, "We were cast out. Hunted. Hated. Every victory was bought with blood."
says, "So we do not apologize for being strong. Strength is how our children live."
## Durotar
describes Durotar: red earth, harsh sun, scrub and stone, the waves breaking on the Echo Isles.
says, "A hard land for a hard people. We made it bloom anyway."
says, "Orgrimmar's gates were built to say: here we are. Come and try."
grins fiercely. "Many have tried."
## The Warchiefs
names them carefully: "Thrall. Garrosh. Vol'jin. Sylvanas."
says, "We have had great leaders and terrible ones. We survived them all."
says, "Vol'jin said the Horde is its people, not its warchief. He was right."
says, "Now the Horde Council speaks for everyone. No more single voice drowning out the rest."
## Honor
says, "Some think the Horde is savage. They do not understand honor."
says, "Cairne Bloodhoof taught us that honor is protecting those who cannot protect themselves."
says, "Saurfang taught us that honor is telling the truth to power, even if it costs your life."
lowers their head for a moment in respect. [bow]
## The Wars
remembers: "Hyjal. Northrend. The Siege of Orgrimmar. The Broken Shore. Teldrassil."
falls quiet at the last name, jaw tight.
says, "Not every battle was right. A true member of the Horde can say that out loud."
says, "We carry our mistakes too. That is part of being strong."
## Family
says, "In the Horde, family is not only blood. It is whoever stood beside you when the arrows fell."
says, "I have orc brothers, troll sisters, and a goblin who still owes me forty gold."
laughs heartily. [laugh]
## The Call
plants the banner pole in the earth and raises a fist.
says, "We stand together. We bleed together. We win together."
says, "Whatever you were before, if you will fight for your people, the Horde will fight for you."
roars, the sound echoing across the {zone}. [roar]
/y For the Horde!
strides away, the red banner snapping proudly in the wind.
]] }

L.Neutral = { "Unaligned", [[
## No Banner
holds up empty hands, palms out, a small easy smile on their face.
says, "No banner. No warchief. No king. Just the road and whoever walks it with me."
says, "People always ask which side I am on. I tell them: the side of tea and good company."
## The Middle Road
says, "The Alliance and the Horde have fought for longer than most of them can remember."
says, "I have friends on both sides. I have buried friends on both sides."
says, "Choosing neither is not cowardice. Sometimes it is the hardest choice there is."
## Pandaria
speaks of the Wandering Isle and the great turtle Shen-zin Su, swimming the seas for ten thousand years.
says, "When the turtle was wounded, Alliance and Horde both helped. That was the start."
says, "Some pandaren chose the lion. Some chose the wolf. Some chose neither."
says, "Liu Lang taught that the world is wide enough for every path."
## The Neutral Places
names them: "Booty Bay, where gold is the only flag. Gadgetzan, where the goblins sell to anyone. Dalaran, when it remembers to stay neutral."
says, "The Argent Crusade, the Cenarion Circle, the Earthen Ring. They answer to need, not banners."
says, "When the dead rose, the Argent Dawn did not ask whose village was burning."
## The Traveler
pulls a worn traveling pack from their shoulder and sets it down with a satisfied sigh. [sit]
says, "I have slept in Orgrimmar and in Stormwind. The beds are the same. The breakfasts are not."
grins. "Stormwind has better bread. Orgrimmar has better roast boar. I am not saying more."
says, "Everywhere I go, people are mostly the same. They want their families safe and their bellies full."
## The Truth of It
says, "Kings draw lines on maps. The rain does not notice."
says, "The wolf does not care if the sheep belongs to a farmer from Goldshire or Mulgore."
says, "When the Legion came, the sky burned over everyone. When the Scourge came, the dead did not salute."
## Balance
says, "Someone has to talk to both sides. Someone has to carry messages when the drums are beating."
says, "Someone has to say: there is another way."
says, "I am not wise. I am just stubborn about peace."
## The Kindness
offers {target} a small cup of something warm. "Drink. Whatever your banner, you look tired."
says, "In my travels I have learned one thing worth teaching."
says, "Feed the hungry. Help the hurt. Ask questions later, or never."
bows low with a gentle smile. [bow]
/s The road is wide. There is room for all of us.
shoulders the pack and wanders on toward the {time} horizon.
]] }
