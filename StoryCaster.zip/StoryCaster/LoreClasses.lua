-- StoryCaster lore library: the classes. Each set is a script in StoryCaster's own format (one emote per line,
-- [anim] tags, /s lines spoken aloud). Original writing, performed in the third person after your name.
local ADDON, ns = ...
local R = ns.R
R.LORE = R.LORE or {}
R.LORE.class = {}
local L = R.LORE.class

L.WARRIOR = { "Warrior", [[
## The Weight of Steel
rolls their shoulders and sets their feet, as if the ground itself might try to move them.
runs a calloused thumb along the edge of their blade, counting every notch like an old friend.
murmurs, "Every one of these is a day I did not fall."
plants the weapon point-down in the earth and leans on the pommel, breathing slow.
remembers the first training yard: the splinters, the bruises, the sergeant who never once said well done.
says quietly, "They told me strength was a gift. It was not. It was a debt, paid every morning."
flexes a scarred hand, the knuckles white with old breaks. [flex]
looks out at the horizon the way a soldier reads a battlefield: cover, ground, the long way round.
tightens the straps of their armor, one buckle at a time, unhurried.
says, "Mages bend the world. Priests ask it nicely. I simply refuse to let it win."
## The Shield Wall
recalls a line of shields in the rain, shoulder to shoulder, the enemy breaking against them like surf.
says, "You never fight alone in a shield wall. That is the whole secret."
taps the rim of their shield twice, an old habit from those wet mornings.
names the friends who held the line beside them, softly, one after another.
falls silent for a long moment, jaw set. [sigh]
says, "Some of them I carried home. Some of them I could not."
straightens, letting the grief settle where it always does, under the ribs and out of the way.
## The Fury
admits, "There is a fire in me. I do not pretend otherwise."
describes the battle-rage: the world narrowing to the next foe, the next swing, the next breath.
says, "The trick is not to put the fire out. The trick is to be the one holding the torch."
clenches a fist until the leather of the glove creaks.
lets the fist open again, finger by finger, the way they were taught.
says, "Rage that cannot be put down is not strength. It is a leash someone else is holding."
## Arms and Discipline
draws the weapon in one smooth motion and holds it level, steady as a bridge.
runs through a slow drill: high guard, low guard, the turn, the cut, the return.
says, "A thousand swings in the yard so that one swing in the field is the right one."
lowers the blade and checks their footing, then nods to themselves. [nod]
recalls a veteran who could disarm three recruits at once and never raised his voice.
says, "He told me the best warrior is the one who makes the fight unnecessary."
smiles thinly. "I am still working on that part."
## The Old Wars
speaks of the long wars: the Horde and the Alliance, the Scourge, the Burning Legion, the endless march.
says, "Kings change. Banners change. The mud is always the same."
traces a shape in the dirt with the point of the blade: a map of a battle long finished.
says, "We won that day. I do not remember why it mattered."
wipes the map away with a boot.
## Why We Stand
says, "People ask why I fight. The answer is very small."
glances toward the nearest light, a window, a campfire, a lantern.
says, "Somewhere behind me there is someone who gets to sleep tonight. That is why."
sheathes the weapon with a quiet scrape of steel.
says, "I am not a hero. I am a door that stays closed."
lifts their shield onto their back, the weight familiar as a coat.
/s Stand fast. Hold the line. Go home.
salutes whoever happens to be watching, sharp and sincere. [salute]
turns toward the road, steady, unhurried, ready.
]] }

L.PALADIN = { "Paladin", [[
## The Oath
kneels, one gauntlet resting on the ground, and bows their head. [kneel]
whispers the words of their oath, the same words spoken by a hundred knights before them.
rises slowly, the faint warmth of the Light gathering at their fingertips.
says, "An oath is not a promise to be perfect. It is a promise to get up."
touches the symbol on their breastplate, polished by years of the same small habit.
remembers the cathedral of their youth: the bells, the incense, the cold stone under young knees.
says, "They taught me to pray before they taught me to fight. I understand why now."
## The Light
opens a hand, and a soft golden glow pools in the palm like captured morning.
says, "The Light is not mine. I am only allowed to carry it for a while."
lets the glow fade, gently, as if setting down something fragile.
explains, "It does not care for titles or banners. It answers need, not rank."
says, "I have seen it heal a beggar and refuse a king. I trust it more for that."
## The Silver Hand
speaks of the Knights of the Silver Hand, founded in an age of orcish invasion and desperate courage.
says, "Uther, Turalyon, Tirion. I say their names so I remember what we are for."
grows quiet. "And Arthas. I say his name so I remember what we can become."
looks down at their own hands for a long moment.
says, "A paladin who cannot imagine falling is already halfway down."
## The Hammer and the Shield
lifts the hammer, testing its weight with practiced ease.
says, "The hammer is for those who would harm the innocent. The shield is for the innocent."
says, "If I must choose, I choose the shield. Every time."
taps the shield, and a faint chime of holy light answers.
recalls a village where they held the gate alone until dawn.
says, "I was afraid all night. Courage is not the absence of fear. It is company for it."
## Mercy
says, "The hardest lesson was not how to strike. It was when to stop."
describes a foe who begged for mercy, and the long moment before they lowered the hammer.
says, "I spared him. He went home to his children. That is a victory the bards never sing."
smiles faintly. "The Light does not need songs."
## Doubt
admits, "There are nights the Light feels very far away."
says, "On those nights I do the work anyway. Faith is a muscle, not a feeling."
kneels again, briefly, and touches the ground as if to steady it. [kneel]
rises with a soft clink of armor.
## The Duty
says, "Somewhere tonight a family is frightened of what walks outside their door."
says, "I intend to be what walks outside their door instead."
fastens their cloak and checks the buckles of their gauntlets.
says, "The Light asks very little: be kind, be brave, be there."
lays a gentle hand on {target}'s shoulder. "Be well. I will be close."
raises the hammer in salute, golden light flickering along its head. [salute]
/s By the Light, I stand.
turns toward the road, armor gleaming softly in the {time} air.
]] }

L.HUNTER = { "Hunter", [[
## The Wild
crouches low, fingers brushing the earth, reading the signs no one else noticed.
traces the shape of a track in the dirt: a paw, a hoof, a story only hours old.
murmurs, "Something passed here. Unhurried. Well fed."
rises without a sound, the way a cat rises from long grass.
breathes in deeply, tasting the wind: rain coming, pine, a distant campfire.
says, "The wild does not lie. It just speaks very quietly."
## The Companion
whistles low, two notes, and waits for the familiar answer from the brush.
kneels to scratch behind the ears of a companion only they seem to be talking to. [kneel]
says, "We found each other in a cold winter. I gave food. They gave everything else."
smiles. "People think I tamed them. I think it was the other way round."
describes the bond: a look across a clearing, and both of them knowing what comes next.
says, "No words. Just trust. It is the cleanest thing I know."
## The Bow
draws an arrow from the quiver and checks the fletching against the light.
nocks it, draws to the cheek, and holds, utterly still, breathing out.
lowers the bow without loosing. "Not every shot needs to be taken."
says, "A good hunter takes what is needed and thanks the land for it."
runs a hand along the bow's curve, smooth from years of use.
recalls the craftsman who made it, and the long winter spent learning to string it.
## The Trail
speaks of following a beast for six days across hills and rivers.
says, "On the sixth day I understood it was not running. It was leading me home to its young."
falls quiet. "I let it go. Some hunts are for learning, not for taking."
looks off toward the treeline, eyes narrowed against the light.
## The Old Ways
speaks of the hunters before them: Rexxar of the Mok'nathal, the rangers of Quel'Thalas, Alleria Windrunner.
says, "Every one of them learned the same thing: the wild is not your enemy."
says, "It is a teacher with very sharp edges."
sets a simple snare by a fallen log, then thinks better of it and takes it up again.
## Patience
says, "Most of hunting is waiting. Most of waiting is listening."
closes their eyes, head tilted, cataloguing every sound in the clearing.
says, "Two birds. Water to the east. Someone walking very badly behind us."
opens one eye and grins at {target}. [laugh]
## The Truth of It
says, "Cities make people forget they are animals too. I never got to forget."
says, "I sleep under stars. I eat what I catch. I know exactly how much I need."
checks the sky, judging the hours of light left.
says, "There is a kind of freedom in that. It does not fit in a house."
whistles again, and turns as if a companion has bounded up beside them.
/s The trail is warm. Let's go.
shoulders the bow and slips into the {zone} wilds without a sound.
]] }

L.ROGUE = { "Rogue", [[
## The Shadows
leans back against the wall, half in shadow, as if the darkness were an old coat.
flips a coin across their knuckles, over and under, never once looking at it.
says, "Most people look at the coin. That is the whole trick."
pockets the coin with a flourish that somehow leaves it in their other hand.
scans the room: every exit, every guard, every person who is pretending not to watch.
says, "I count doors the way other people count blessings."
## The Trade
says, "Some call it thieving. I call it redistributing attention."
admits, "I learned in the gutters of a big city. Nobody else was teaching."
remembers a cold alley, a stolen loaf, and the first time they outran a guard.
says, "Hunger is a very good teacher. Strict, but fair."
## The Code
says, "We have rules, you know. Fewer than the knights, but we keep them better."
counts them off on gloved fingers: "Never steal from the poor. Never betray the crew. Never leave a mess."
smiles crookedly. "The third one is mostly about pride."
## SI:7 and the Syndicate
speaks of the old networks: SI:7 in Stormwind, the Syndicate, the Ravenholdt manor hidden in the hills.
says, "Kings rule in the light. Somebody has to tidy up in the dark."
says, "Mathias Shaw never raised his voice. He never needed to."
draws a thin blade, examines it, and sheathes it again before anyone is quite sure they saw it.
## The Poison
holds up a tiny glass vial, its contents a faint unsettling green.
says, "People fear the blade. They should fear the cook."
tucks the vial away. "Don't worry. That one's for emergencies. And ex-partners."
## The Job
describes a job: the guard rotations memorized, the window left unlatched, the silence of an empty hall.
says, "The best jobs end with nobody knowing there was a job at all."
says, "The worst ones end with running. I am very good at running."
grins. [chuckle]
## What They Never Say
grows quieter. "There was someone I worked with. The best I ever saw."
says, "One night she did not come back from a rooftop. No song for that."
turns the coin over once more, slower now.
says, "So I keep her share. I spend it on people she would have liked."
## The Truth
says, "You think I am a liar. I am. But I have never lied about being one."
taps the side of their nose. "That makes me more honest than most lords."
says, "I go where I am not supposed to. I see what I am not supposed to see."
says, "And sometimes, just sometimes, that saves a life."
steps further into the shadow until only their eyes catch the light.
/s You never saw me.
when you look again, there is nobody there at all.
]] }

L.PRIEST = { "Priest", [[
## The Quiet Hour
folds their hands and closes their eyes, letting the noise of the {zone} fall away.
breathes slowly, counting the breaths the way they were taught as an acolyte.
murmurs a short prayer, not for themselves, but for whoever needs it most tonight.
opens their eyes, softer now, as if they had just come back from somewhere far.
says, "Prayer is not asking. Prayer is listening with your whole self."
## The Light and the Shadow
lifts one hand, and a gentle warmth gathers there like candlelight.
lifts the other, and a cool violet shadow coils around the fingers.
says, "Some say we must choose. I say both are only tools for mending."
lets both fade at once. "The Light heals the body. The Shadow understands the mind."
says, "A priest who knows only one has only half the answer."
## The Healer's Burden
remembers a field tent after a battle: the cries, the blood, the endless hands reaching.
says, "You cannot save them all. That is the first lesson and the hardest."
says, "The second lesson is to try anyway, every single time."
rubs tired eyes. [sigh]
says, "I remember every face I could not save. I think I am supposed to."
## The Teachers
speaks of the great priests of the past: Archbishop Alonsus Faol, Velen the Prophet, Moira's chaplains in Ironforge.
says, "Faol rebuilt a kingdom's faith after it burned. Velen kept his for twenty-five thousand years."
says, "I am only trying to keep mine until morning."
smiles gently. "Most days, that is enough."
## Confession
says, "People tell me things they cannot tell anyone else."
says, "A soldier who froze. A mother who is angry at her child. A king who is afraid."
says, "I do not judge. I hold it for a while so they can rest."
places a hand over their heart. "It is heavy. It is also a great honor."
## The Shadow's Whisper
grows quieter. "There are voices in the dark. Old ones."
says, "The Old Gods whisper to anyone who will listen. Shadow priests listen very carefully."
says, "The trick is to hear them without ever answering."
shakes their head slowly. [no]
## Faith
says, "People ask if I am ever certain."
laughs softly. "Never. Certainty is a wall. Faith is a door."
says, "I walk through it every morning not knowing what is on the other side."
## The Blessing
turns to {target} and raises a hand in blessing, a soft glow at the fingertips.
says, "May your road be gentle, your wounds be few, and your friends be near."
says, "And when they are not, may you remember that someone, somewhere, prayed for you."
bows their head. [bow]
/s Go in peace.
gathers their robes and walks quietly on, a little light following behind.
]] }

L.DEATHKNIGHT = { "Death Knight", [[
## The Cold
exhales, and their breath frosts in the air even where no winter should be.
flexes fingers inside a gauntlet rimed with ice, the joints creaking like old timber.
says, "I do not feel the cold anymore. I am the cold."
looks down at their reflection in the runeblade: pale skin, eyes like dying stars.
## What Was Taken
says, "I was someone once. I remember their name. I do not always remember their face."
recalls dying: the field, the mud, the last breath that did not end.
says, "The Lich King raised me. He took the dead and made them weapons."
grips the hilt tighter until frost spreads along the crossguard.
says, "I killed for him. Villages. Friends. People who knew my name."
falls silent. The silence goes on too long.
## Acherus
speaks of Acherus, the floating necropolis over the Plaguelands.
says, "We were born there in ice and screaming. Then the Light of Dawn broke the spell."
says, "At the chapel, we remembered who we were. Some of us wept. The dead can weep."
says, "Darion Mograine led us out. We have been trying to find our way back ever since."
## The Runes
draws a rune in the air with one finger, and it hangs there glowing a cold blue.
says, "Blood, Frost, Unholy. Three ways to carve the world."
lets the rune fade. "Blood to endure. Frost to end. Unholy to remind them what death is."
## The Hunger
admits, "There is a hunger. It never sleeps."
says, "Every death near me feeds it a little. I have learned to starve it on purpose."
says, "Discipline is all that separates a knight from a ghoul."
## The Living
watches {target} with an unreadable gaze.
says, "The living fear me. They are right to. But they are also why I still stand."
says, "I died once so that something worse would not happen. I would do it again."
## Redemption
says, "There is no redemption for what I did. Only work."
says, "Every innocent I shield is one small coin on a debt with no end."
says, "I will never finish paying. That is not the point."
draws the runeblade halfway; it hums with a low, hungry voice.
sheathes it again with deliberate slowness. [no]
## The Ebon Blade
says, "We are the Knights of the Ebon Blade now. Not his. Ours."
says, "We answer to the living when we must. To the dead when we must. To ourselves always."
salutes, the gesture stiff and ancient. [salute]
/s The dead remember.
turns away, frost trailing from their footsteps into the {time}.
]] }

L.SHAMAN = { "Shaman", [[
## The Elements
kneels and presses both palms flat against the earth, eyes closed. [kneel]
listens, head tilted, as if the ground were telling a long and complicated story.
says, "The stone is uneasy here. Something old was buried and forgotten."
rises and lifts a hand to the wind, feeling it slip between the fingers.
says, "The air is restless. It always is. Air is a gossip."
cups water from a nearby flask and lets it fall, drop by drop, listening to each.
says, "Water remembers everything it has touched. That is why it is so patient."
holds a palm over a small flame, close enough that it should burn. It does not.
says, "Fire is honest. It wants only to eat. You must give it something worth eating."
## The Bargain
says, "We do not command the elements. We ask. Politely. Usually."
explains, "A shaman is a diplomat between the world and the people living on it."
says, "When the elements are angry, the world shakes. Someone has to listen."
## The Teachers
speaks of the great shamans: Thrall, who listened when the world itself was breaking; Drek'Thar, blind but all-seeing.
says, "Thrall carried the Doomhammer and the weight of a broken people. He chose listening over war."
says, "Muln Earthfury taught that the spirits do not care what banner you carry."
## The Ancestors
lights a small bundle of herbs and lets the smoke curl upward.
says, "The ancestors walk with us. Not as ghosts. As advice."
murmurs a name softly into the smoke, a grandparent, a teacher, a friend.
says, "When I am lost, I ask what they would do. They are rarely wrong."
## Totems
sets a small carved totem on the ground, adjusting its angle with care.
says, "A totem is a promise: the elements will stand here with us."
taps it lightly, and a faint hum seems to rise from the earth beneath.
## The Storm
looks up at the sky, where clouds are gathering.
says, "A storm is coming. Not tonight. But soon."
says, "Lightning is the sky's way of reminding everyone it is still there."
grins. "I find that comforting. Most people do not."
## Balance
says, "Everything wants balance. Fire and water. Stone and wind. Life and death."
says, "When people take too much, the world takes it back. Always."
says, "My work is to help it take back a little less."
## The Blessing
turns to {target} and touches their brow lightly with two fingers.
says, "Earth to carry you. Air to guide you. Water to heal you. Fire to warm you."
bows to each of the four directions in turn. [bow]
/s The elements walk with you.
picks up the totem and walks on, the wind following at their heels.
]] }

L.MAGE = { "Mage", [[
## The Arcane
holds up a hand, and a small sphere of violet light blooms above the palm, humming softly.
turns the sphere slowly, studying it the way a jeweler studies a flawed stone.
says, "Everyone sees the light. Nobody sees the hundred hours of arithmetic underneath."
closes the hand, and the light folds away into nothing.
## The Study
remembers the libraries of Dalaran: towers of books, candle wax, the smell of old ink and ozone.
says, "My first spell set my eyebrows on fire. My second put them out. Very educational."
says, "Magic is a language. Most people never learn more than the swear words."
pulls a small notebook from a pocket, its pages crammed with diagrams and corrections.
flips through it. "Seven years of notes. Three of them are just apologies to my teachers."
## The Schools
lists them on their fingers: "Arcane, for the shape of things. Fire, for change. Frost, for patience."
says, "Fire students are loud. Frost students are smug. Arcane students are late. Always."
says, "I have tried all three. My accounts still have scorch marks."
## The Kirin Tor
speaks of the Kirin Tor and the violet city: Antonidas, Khadgar, Jaina Proudmoore.
says, "Antonidas died at the gates of Dalaran. Khadgar aged forty years in a single afternoon."
says, "Magic always costs something. The wise ones decide what they can afford to pay."
## The Danger
grows serious. "There is a hunger in the arcane. Some call it addiction."
says, "The highborne drank deep at the Well of Eternity. It cost them their world."
says, "The Legion smells magic like sharks smell blood. Every spell is a little lantern in the dark."
says, "So we cast carefully. And we keep our wards very, very tidy."
## Portals
traces a circle in the air, and for a heartbeat a shimmering doorway flickers there.
lets it collapse. "Portals are just very rude shortcuts through the fabric of the world."
says, "Every mage remembers their first portal. Usually because of where they ended up."
grins. "Mine ended up in a lake. In winter." [laugh]
## Wonder
says, "People think magic made the world less mysterious for me. It is the opposite."
says, "The more I learn, the stranger everything becomes. I love it."
looks up at the {time} sky as if it were an equation half solved.
## The Responsibility
says, "Power without wisdom is just a very expensive disaster."
says, "I could do terrible things. Choosing not to is the most important spell I know."
## Farewell
conjures a small loaf of bread and a cup of water and offers them to {target}.
says, "Never travel with a mage and go hungry. It is a point of professional pride."
bows with a little flourish of their sleeves. [bow]
/s Knowledge is the only treasure that grows when you share it.
steps through a brief shimmer of violet light and is simply elsewhere.
]] }

L.WARLOCK = { "Warlock", [[
## The Pact
smiles slowly, the expression not quite reaching their eyes.
says, "You are wondering what I traded. Everyone wonders. Nobody asks."
lifts a hand, and green fel flame flickers to life around the fingers, hungry and bright.
says, "Power is not free. Power is never free. I simply read the contract."
lets the flame die. The air smells faintly of sulfur.
## The Reason
says, "I did not begin here. I began wanting to protect someone."
says, "The Light did not answer. The elements did not answer. Something else did."
says, "It always does. That is the problem with asking the dark for help."
## The Servants
snaps their fingers, and a small imp seems to grumble at their heels.
says, "Demons are useful. Rude, treacherous, and smelly. But useful."
says, "The trick is to make sure you are holding the leash, not wearing it."
says, "I bound my first imp at sixteen. It has been insulting me ever since."
glances down. "Yes. I heard that."
## The Cost
holds up a hand; faint dark veins are visible beneath the skin.
says, "Every spell takes a little. Health. Sleep. Warmth. Sometimes memories."
says, "I keep a journal. Some mornings I need it to remember my mother's name."
falls quiet for a moment. [sigh]
## The Black Harvest
speaks of the warlocks who came before: Gul'dan, who poisoned a people; Kanrethad, who touched Sargeras and burned.
says, "History is full of warlocks who thought they were clever."
says, "I study them the way a sailor studies shipwrecks."
## Fel and Shadow
says, "Fel to burn. Shadow to wither. Soul to bargain with."
says, "Destruction is honest. Affliction is patient. Demonology is mostly paperwork."
smirks. "The demons insist on contracts. They are very bureaucratic."
## The Soul Shard
holds up a small violet crystal that pulses like a heartbeat.
says, "A soul shard. A piece of someone who no longer needs it."
says, "Do not look so horrified. I only take from those who would have used it for worse."
tucks it away carefully, almost tenderly.
## Why
says, "The Legion came to burn this world. We learned their tricks to stop them."
says, "Fight fire with fire. Fight fel with fel. It is ugly. It worked."
says, "Someone has to stand close enough to the abyss to push back."
## The Warning
leans toward {target}, voice low.
says, "Never make a bargain with something that smiles too wide."
says, "Unless you are me. Then you smile wider."
straightens, green light flickering briefly behind their eyes.
/s Every power has a price. I always pay on time.
walks away, a faint trail of ash where their shadow passed.
]] }

L.MONK = { "Monk", [[
## Stillness
sits cross-legged, hands resting loose upon the knees, breathing slow and deep. [sit]
lets the sounds of the {zone} pass through them like wind through an open door.
opens their eyes after a long moment, calm as still water.
says, "The body moves. The mind waits. Balance is found between."
## The Training
rises in a single smooth motion and moves through a slow form, every gesture flowing into the next.
says, "A thousand repetitions so the body forgets fear."
says, "My master made me carry water up the mountain for a year before I learned a single strike."
smiles. "I hated it. Then I understood."
## Chi
holds out a hand, palm up; a faint swirl of jade mist gathers in it.
says, "Chi is the breath of the world. It flows through all living things."
says, "Most people let it scatter. We learn to gather it, guide it, return it."
lets the mist drift away on the breeze.
## The Three Paths
says, "The Brewmaster bends like the willow. The Mistweaver heals like the rain. The Windwalker strikes like the storm."
says, "I have tried all three. I am best at the brewing. My master says that is not a compliment."
laughs warmly. [laugh]
## The Wandering Isle
speaks of Pandaria and the Wandering Isle, the great turtle Shen-zin Su carrying a people across the sea.
says, "Monks learned patience from a turtle who has swum for ten thousand years."
says, "Liu Lang taught us that the world is wide, and every road is a teacher."
## Brew
produces a small clay jug and swirls it thoughtfully.
says, "A good brew is like a good life. Patience, care, and a little surprise at the end."
takes a sip and sighs contentedly. "Peach and plum. A summer brew."
offers the jug to {target}. "Drink slowly. It is stronger than it looks. So am I."
## Anger
says, "Anger is a fire. It is not evil. It is a fire."
says, "In Pandaria, the Sha rose from anger, fear, and despair left untended."
says, "So we tend them. Every day. Like a garden."
closes their eyes briefly, letting a long breath go.
## The Fist
says, "We fight with hands and feet so we never forget how close the enemy is."
says, "When you can feel their heartbeat, you remember they are a person."
says, "That is why our first strike is always a warning."
## Harmony
says, "The tiger does not hate the deer. The river does not hate the stone."
says, "Strength without harmony is just noise."
presses fist to palm and bows deeply. [bow]
/s Walk gently. The world is listening.
turns and walks on, footsteps light as falling leaves.
]] }

L.DRUID = { "Druid", [[
## The Dream
stands among the trees with eyes half closed, as though listening to something very far away.
says, "Do you hear it? The Emerald Dream. The world as it was meant to be."
breathes deeply, and the scent of moss and rain seems to follow the breath.
says, "Everything that grows remembers a perfect version of itself. We help it remember."
## The Shapes
lowers into a crouch, and for a moment their silhouette seems more bear than mortal.
rises again, shaking the shape off like water.
says, "Bear for strength. Cat for cunning. Owl for the long view. Stag for the long road."
says, "The first time I shifted I forgot how to be a person for three days."
smiles faintly. "My teacher said that was normal. It did not feel normal."
## The Cenarion Circle
speaks of Cenarius, demigod of the forest, and Malfurion Stormrage, the first druid of the night elves.
says, "Malfurion slept for ten thousand years in the Dream to guard the world."
says, "Some druids are still sleeping in the barrow dens. Waiting. Watching."
says, "Hamuul Runetotem brought the tauren into the Circle. The forest was glad of it."
## The Balance
holds out one hand toward the sun and one toward the moon, eyes closed.
says, "Elune's light and the sun's fire. Balance druids carry both."
says, "Too much of either and the world burns or freezes. We walk the line between."
## The Healing
kneels beside a wilted plant and cups it gently in both hands. [kneel]
murmurs to it, and the leaves seem to lift a little, green returning to the edges.
says, "Healing is not magic. It is reminding life of what it already knows."
## The Nightmare
grows grave. "The Dream can sicken. We have seen it."
says, "The Emerald Nightmare twisted Ysera's own children. Xavius whispered rot into the roots."
says, "We fought it back. The forest bears scars. So do we."
touches a pale scar along their forearm without seeming to notice.
## The Wild Heart
says, "Cities forget that they are built on soil."
says, "Every stone in a wall was once part of a mountain. Every beam was once a tree."
says, "Someone should remember that. We volunteered."
## The Cycle
says, "Death is not the enemy. Death is the soil the next spring grows in."
says, "What we fight is waste. Things dying for nothing. Things living with no purpose."
## The Blessing
touches {target}'s shoulder, and a faint scent of rain and green leaves lingers there.
says, "May the roots hold you, the canopy shelter you, and the seasons be kind."
bows to the trees around them, one by one. [bow]
/s The wild remembers.
shifts into a great stag and bounds off through the {zone} undergrowth.
]] }

L.DEMONHUNTER = { "Demon Hunter", [[
## The Blindfold
turns their head toward a sound no one else heard, blindfold tight across their eyes.
says, "You think I cannot see. I see more than you ever will."
says, "Every demon burns like a bonfire in the dark. Every lie flickers like a candle."
tilts their head toward {target}. "You, for example, are mostly honest. Mostly."
## The Sacrifice
says, "We gave up our eyes. We burned them out with fel so we could see the Legion coming."
says, "We drank demon blood. We ate their hearts. We became what we hunt."
flexes fingers tipped with dark claws. [flex]
says, "Nobody thanks us. Nobody has to."
## Illidan
speaks of Illidan Stormrage, the Betrayer, the one who first walked this path.
says, "They called him a traitor for ten thousand years. He was the only one who saw clearly."
says, "He gave everything to stop the Burning Legion. Everything. Even his name."
says, "I would follow him again. Into the Nether if I had to."
## The Illidari
says, "We are the Illidari. We trained in the Black Temple and the prisons of the Vault."
says, "Most who began the training died. The rest of us were never quite the same."
says, "Maiev Shadowsong hunted us. We forgave her eventually. She did not forgive us."
## The Fel
lifts a hand, and green fel fire crawls along the forearm, flickering with strange runes.
says, "The fel wants to eat me. Every day, it tries."
says, "I let it have a little. Just enough to stay hungry. Just enough to stay sharp."
lets the fire fade with a slow exhale.
## The Wings
spreads leathery wings briefly, then folds them again with a snap.
says, "They used to frighten children. Now they mostly frighten pigeons."
grins sharply. [laugh]
## Metamorphosis
says, "When I let go, the demon inside wakes. Horns, fire, rage."
says, "The trick is coming back. Some never do."
says, "So I count my friends' names while I am changed. It helps."
## The Hunt
draws a pair of curved warglaives and spins them once in a blur.
says, "The Legion is broken. But demons are like rats. There is always another nest."
says, "I hunt them in the dark places. The places your soldiers do not go."
sheathes the warglaives in a single smooth motion.
## What Remains
says, "I gave up my sight, my people's trust, my ordinary life."
says, "In return, nothing burns this world while I stand watch."
says, "That is a fair trade."
turns their blind face toward the horizon, sensing.
/s You are not prepared. But I am.
leaps into the air on dark wings and vanishes into the {time} sky.
]] }

L.EVOKER = { "Evoker", [[
## The Dragonscale
stretches slowly, scales catching the light like polished bronze and ruby.
says, "Do not stare. Or do. I am used to it."
says, "I am dracthyr. Neither dragon nor mortal. Something in between, made on purpose."
## The Forbidden Reach
speaks of the Forbidden Reach and the long sleep beneath it.
says, "Neltharion made us. The Earth-Warder, before the madness took him completely."
says, "He wanted a weapon. Then he feared it, and locked us away for ten thousand years."
says, "We woke to a world that had forgotten we existed. It was very quiet."
## Two Forms
shifts briefly into a smaller, mortal-seeming shape, then back into scaled form.
says, "We wear the visage when we walk among you. It is more polite."
says, "It is like wearing borrowed clothes. Comfortable enough. Never quite right."
## The Flights
says, "All five flights are in us. Red for life. Blue for magic. Green for dreams. Bronze for time. Black for earth."
says, "Most dragons get one. We were stitched together from all of them."
says, "Some days I feel all five arguing in my blood."
## Fire and Life
breathes out, and a small spiral of golden-red flame curls upward from their lips.
says, "Devastation is the fire that ends things. Preservation is the fire that keeps them."
says, "Augmentation is the fire you give to others. I like that one best."
## The Aspects
speaks of the Aspects: Alexstrasza the Life-Binder, Nozdormu the Timeless, Ysera the Dreamer, Malygos, and the fallen Earth-Warder.
says, "They welcomed us home to the Dragon Isles. That still surprises me."
says, "Alexstrasza looked at us and saw children, not weapons. I will never forget that."
## Purpose
says, "We were made to be weapons. We decided to be something else."
says, "It is the best thing about being alive. You get to decide."
spreads small wings and lifts a few inches off the ground, then settles again.
## The Sky
says, "Flying is not something I do. It is something I am."
looks upward at the {time} sky with longing.
says, "When I am up there, I forget I was ever locked in the dark."
## The Promise
turns to {target}, eyes bright as embers.
says, "Ten thousand years asleep. I do not intend to waste a single day of waking."
bows, wings half spread in a draconic salute. [bow]
/s Fly with us.
leaps skyward, a streak of scale and fire against the clouds.
]] }
