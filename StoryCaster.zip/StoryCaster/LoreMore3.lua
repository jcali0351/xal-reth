-- StoryCaster lore library: further scenes for the Alliance races.
local ADDON, ns = ...
local R = ns.R
R.LORE_MORE = R.LORE_MORE or {}
R.LORE_MORE.race = R.LORE_MORE.race or {}
local M = R.LORE_MORE.race
local function add(k, s) M[k] = (M[k] or "") .. s end

add("Human", [[
## Goldshire
remembers the Lion's Pride Inn in Goldshire: the hearth, the bard who only knew three songs, the stew that was mostly turnip.
says, "Every adventurer in Stormwind starts with a bowl of that stew. It builds character."
laughs at the memory. [laugh]
says, "I still dream about that fireplace sometimes. Warm feet, a full belly, nothing to fear."
## The Militia
says, "When the gnolls raided the farms, it was not knights who stood up. It was farmers with pitchforks."
says, "Humans are best when someone threatens our neighbors. We forget our quarrels very quickly then."
## The Letter
pulls out a folded letter, much read, the ink faded at the creases.
says, "My grandmother wrote this before the Second War. 'Be kind, be brave, come home.'"
says, "I have managed two out of three most days."
tucks it away carefully, close to the heart.
## The Taverns
says, "You learn more about a kingdom in its taverns than in its throne rooms."
says, "The tavern knows who is hungry, who is angry, and who is about to start a revolution."
## Westfall
says, "When the harvest fails in Westfall, all of Stormwind goes hungry by winter."
says, "Every human should spend a summer on a farm. You never waste bread again."
## The Children of Stormwind
watches a group of children chase each other through the street with wooden swords.
says, "Every one of them wants to be a hero. I hope none of them ever have to be."
says, "That is the dream, really. A world where heroes are just a story."
## The Stubbornness
says, "Humans are stubborn. Knock us down and we get back up. Knock us down again and we bring friends."
grins. [chuckle]
]])

add("Dwarf", [[
## The Beard
strokes their beard with great dignity, as if consulting it.
says, "A dwarf's beard tells their whole history. Every braid means something."
says, "This one is for my first mining claim. This one for my first bar fight. This one for my first bar fight that I won."
laughs heartily. [laugh]
## The Tunnels
says, "Dun Morogh is a maze of tunnels under the snow. Every dwarf child gets lost at least once."
says, "My mother found me after three days, sitting on a pile of copper ore, perfectly happy."
## Snow
looks up as a few snowflakes drift down.
says, "Snow in Dun Morogh means the hunting is good and the ale is better."
says, "Nothing warms you like a dwarf's hearth after a day in the snow."
## The Rams
says, "We ride rams. Strong, stubborn, smell terrible. Perfect companions."
says, "Mine has headbutted a troll, a gnoll, and once, regrettably, a member of the Explorers' League."
## The Titans
grows thoughtful. "The Explorers' League found that dwarves were made by the titans from living stone."
says, "Earthen, they called the first of us. The Curse of Flesh made us what we are now."
says, "I like flesh. Stone cannot taste ale."
## Brann's Maps
says, "Brann Bronzebeard drew a map of Uldaman that was wrong in seventeen places."
says, "He found three new chambers because of it. Very dwarven, being wrong in useful directions."
## Loyalty
says, "When a dwarf calls you friend, it is for life. And probably a few lives after."
claps {target} firmly on the shoulder.
## The Feast
says, "A dwarven feast lasts three days. Day one is eating. Day two is singing. Day three is apologizing."
grins. [chuckle]
]])

add("NightElf", [[
## The Owl
looks up as an owl calls from somewhere in the trees.
says, "The owl is Elune's messenger. It sees in the dark, as we do."
says, "When I was a child, I believed owls carried prayers to the moon."
says, "I still leave a feather on the windowsill some nights. Old habits."
## Darnassus
speaks softly of Darnassus, the city in the branches of Teldrassil: moonlit pools, the Temple of the Moon, the quiet beauty of a city built for eternity.
says, "We thought it would stand forever. That was our mistake."
says, "Eternity is not a promise. It is a gift you have to keep earning."
## The Hippogryph
says, "We ride hippogryphs, half eagle, half stag. Proud, graceful, and vain."
says, "Mine preens before every flight. I have learned to wait."
smiles faintly. [chuckle]
## The Sentinel Training
says, "A Sentinel trains for a hundred years before she is trusted with the glaive."
says, "The first ten years are just learning to stand still."
## The Kaldorei Way
says, "We do not rush to judgment. We do not rush to anger. We do not rush to love."
says, "But when we do any of those things, it lasts a very long time."
## Ashenvale
describes Ashenvale's forests: ancient trees, moonwells glowing silver, the soft calls of wildlife in the dark.
says, "The orcs cut our trees there. We fought them. Then we fought beside them."
says, "Ten thousand years have taught us that enemies become friends, and friends become enemies, and the forest outlasts them all."
## The Moonwell
kneels beside a pool of water and touches its surface, watching the ripples spread. [kneel]
says, "Every moonwell holds a little of the old Well's power, purified by Elune."
]])

add("Gnome", [[
## The Explosion
says, "Every gnome remembers their first explosion. Mine was a toaster."
says, "It toasted the bread, the counter, my eyebrows, and a small part of the ceiling."
says, "My parents were so proud."
laughs. [laugh]
## The Leper Gnomes
grows quieter. "Some of our people did not escape Gnomeregan in time. The radiation changed them."
says, "We call them leper gnomes. They still wander the halls. We have not forgotten them."
says, "One day we will cure them. Science never gives up."
## Tinker Town
describes Tinker Town in Ironforge: a crowded district of workshops, test chambers, and a deep tram running beneath the earth.
says, "The Deeprun Tram was our gift to Stormwind. A train under the sea."
says, "It only floods occasionally. Very occasionally."
## The Gnomish Inventor's Creed
recites solemnly: "If it is not broken, improve it. If it is broken, improve it anyway."
says, "That is the first thing they teach you in engineering school."
## Small Hands
holds up small, nimble hands, flexing the fingers.
says, "Small hands for small gears. That is why gnomes make the finest clocks in the world."
says, "Dwarves have tried. Their clocks are lovely and also the size of a cart."
## Mekkatorque
says, "High Tinker Mekkatorque once built a battle suit taller than a house."
says, "He uses it for parades now. And for opening very stubborn jars."
## The Dream
says, "Every gnome dreams of building something that changes the world."
says, "Most of us build something that changes a room. Usually by removing it."
grins widely. [chuckle]
]])

add("Draenei", [[
## The Crystals
touches the small crystals on their brow, which pulse faintly with light.
says, "These grow as we age. Mine are still small. I am barely nine hundred."
says, "Velen's could light a cathedral."
## The Vindicators
says, "Vindicators are our paladins. They hold the Light like a shield."
says, "Maraad gave his life on Draenor to save us. We sing his name at every gathering."
lowers their head in respect. [bow]
## Azuremyst
describes Azuremyst Isle, where the Exodar fell: purple forests, glowing mushrooms, strange new creatures everywhere.
says, "Our crash poisoned some of the land. We spent years healing it."
says, "The first green shoots after the crash made the whole camp cheer."
## The Talbuk
says, "On Draenor we rode talbuks, swift and gentle. Here we ride elekks, huge and gentle."
says, "The elekk is the kindest creature I know. It remembers every face."
## Shattrath
speaks of Shattrath City, the holy city of the draenei, where the naaru A'dal shone like a second sun.
says, "Even after the orcs destroyed it, A'dal returned. The Light always returns."
## The Long Memory
says, "We remember Argus as it was. Crystal towers. Singing rivers. Light everywhere."
says, "We will never see it that way again. But we remember. That is enough."
## Kindness to Strangers
offers {target} a small glowing crystal. "A gift. It glows when someone thinks of you fondly."
smiles warmly as it pulses. [chuckle]
]])

add("Worgen", [[
## The Night Hunt
sniffs the air, nostrils flaring, ears turning toward the treeline.
says, "Deer, two hundred paces east. Wolves, further. Something rotten to the north."
says, "The nose never lies. People do. Noses never do."
## Liam
says quietly, "Prince Liam Greymane died taking an arrow meant for his father."
says, "Every Gilnean remembers where they were when they heard. I was in the mud at the city gates."
lowers their head. [bow]
## The Wall
says, "Greymane's Wall kept the world out for years. It also kept us in."
says, "Some walls protect you. Some walls are just very large regrets."
## The Gilnean Accent
says, "You can always tell a Gilnean. We complain about the weather in the most refined accent imaginable."
says, "Gilneas rains three hundred days a year. We are very good at complaining about it."
laughs. [laugh]
## The Return
says, "In the Fourth War, we took Gilneas back from the Forsaken."
says, "I walked through the streets of my childhood. Everything was overgrown and silent."
says, "We will rebuild. Slowly. With very large paws."
## Trust
says, "People are nervous around worgen. I understand. We are very large and very toothy."
says, "Give us a chance. We bark. We rarely bite. Mostly at enemies."
## The Pack
says, "In Gilneas, neighbors were family. In the curse, the pack is family."
says, "That is the one thing the curse made better."
]])

add("VoidElf", [[
## The Ren'dorei
says, "We call ourselves ren'dorei. Children of the night. It sounds better than 'exiles'."
says, "Magister Umbric led us. He was brilliant and stubborn. We followed him into the dark."
## The Call of Telogrus
says, "On Telogrus there were voices promising us everything. Power, peace, an end to fear."
says, "All we had to do was let go. Many of us almost did."
## Stars
looks up at the {time} sky with a strange fondness.
says, "Since the Void, I see the stars differently. Some of them are watching."
says, "Most are friendly. One or two are very judgmental."
laughs quietly. [chuckle]
## Family
grows quiet. "My family still lives in Silvermoon. They do not write."
says, "Some exiles have reconciled. Some have not. I am still hoping."
## The Mastery
holds out a hand; shadow swirls, then shapes itself into a small glowing star.
says, "The Void can create as well as destroy. That is what Silvermoon never understood."
lets the star fade with a gentle breath.
## The Shadowy Whisper
says, "If you ever see a void elf talking to no one, be kind. We are probably winning an argument."
## Allies
says, "We fight alongside the Alliance against the Old Gods. Who better to fight shadow than us?"
says, "We know their whispers. We know their lies. We are their worst nightmare."
]])

add("LightforgedDraenei", [[
## The First Battle
remembers their first battle against the Legion, on a world whose name they never learned.
says, "I was young. Barely three hundred. I thought the Light would make me fearless."
says, "It did not. It made me brave enough to be afraid and stand anyway."
## The Ranks
says, "The Army of the Light had soldiers from a hundred worlds. Draenei, humans, beings with no names in your tongue."
says, "Every one of them gave up their home to fight the Legion."
## Turalyon
speaks of High Exarch Turalyon, the human general who led the Army of the Light for a thousand years.
says, "He never stopped grieving the world he left behind. He never stopped fighting either."
## The Rituals
kneels and lays both hands on the ground in a brief prayer of thanks. [kneel]
says, "Every morning, we give thanks to the Light. Even after twenty-five thousand years."
rises with quiet dignity.
## The Uniform
glances down at their gleaming armor. "We polish our armor every night. Even in peace."
says, "Old habits. And it looks rather nice."
smiles faintly. [chuckle]
## Learning Peace
says, "Peace is a battlefield I was never trained for. Every day I fail a little less."
## Hope
says, "We fought so long because we believed the war could end. And it did."
says, "So believe me when I say: whatever you are fighting, it can end too."
]])

add("DarkIronDwarf", [[
## The Slaves
grows serious. "Under Ragnaros, our people were slaves. Every Dark Iron child grew up in fear of the Firelord."
says, "Every Dark Iron adult remembers the heat, the chains, the screaming."
says, "We are free now. We do not take it for granted."
## The Fire Elementals
says, "Fire elementals still wander Blackrock Mountain. We do not fear them anymore."
says, "We have learned to speak their language. Mostly it is complaining about being too cold."
laughs. [laugh]
## The Brewing
says, "Dark Iron brewers make ale that will melt your boots."
says, "We serve it at weddings. Fewer people get married that way, but the ones who do mean it."
## Blackrock Depths
describes Blackrock Depths: the Grim Guzzler tavern, the lava rivers, the throne room of the emperor.
says, "The Grim Guzzler is the best tavern in the world. Do not tell the Thunderbrews."
## Dagran
says, "Emperor Dagran Thaurissan, Moira's husband, was killed by adventurers."
says, "Their son, Dagran the Second, rules with his mother now. A child of three clans."
## The Tempering
says, "Dark Iron weapons are tempered in lava. They glow for days after."
says, "I once roasted a whole boar on a freshly forged sword. Delicious."
grins. [chuckle]
## The Pride
says, "We came out of the fire. We are not going back in."
]])

add("KulTiran", [[
## The Tidesages
says, "The tidesages of Stormsong pray to the sea and keep our sailors safe."
says, "Some of them turned to darker gods. The Old Gods whispered through the waves."
says, "We burned the corruption out. It cost us. We do not forget."
## The Drust
says, "The Drust were ancient witches who worshiped dark magic in the forests of Drustvar."
says, "They made servants of wicker and bone. Some of them still walk the woods."
## Proudmoore Keep
describes Proudmoore Keep, overlooking Boralus harbor, its banners snapping in the sea wind.
says, "Lady Katherine Proudmoore ruled from there after her husband died. Stern as a stone, kind as a mother."
## The Fishing Villages
says, "Every coastal village has a fisherman who claims to have caught a sea serpent."
says, "I have heard forty different stories. Thirty-nine are lies."
laughs heartily. [laugh]
## The Waycrests
says, "The Waycrests of Drustvar had a terrible secret. Their own lady was a witch."
says, "Kul Tiras is a beautiful land with a great many dark corners."
## The Anchor
mimes heaving a massive anchor over one shoulder, grunting with effort.
says, "Every Kul Tiran child can haul an anchor by twelve. It is tradition."
## Home Port
says, "Wherever a Kul Tiran sails, Boralus is the home port."
says, "We always come home. Even if it takes years."
]])

add("Mechagnome", [[
## The Junkyard
says, "On Mechagon, junk is treasure. We have whole cities built from scrap."
says, "One gnome's broken cart is another gnome's new leg."
## The Clocktower
describes the great clocktower of Mechagon City, its gears visible through glass, ticking with perfect precision.
says, "It has never been late. Not once in three hundred years."
says, "Unlike my cousin Fizzlesprocket."
laughs, a whirring sound. [laugh]
## The Workshop
says, "Every mechagnome has a workshop. Mine has three. One for gears, one for springs, and one for naps."
## The Pet Bots
says, "We build little robot companions. Mine is a mechanical squirrel named Gearnut."
says, "He collects bolts the way real squirrels collect nuts. He hides them everywhere."
## The Upgrade Debate
says, "Some mechagnomes want to upgrade everything. Others want to keep a little flesh."
says, "I kept my heart. Mostly. It ticks now, but it still loves."
## Oil
pours a few drops of oil onto a squeaking elbow joint, sighing with relief.
says, "Rust is our oldest enemy. Older than the king. More persistent too."
## Rebuilding
says, "Mechagon is rebuilding. Free now. Every gnome choosing their own path."
says, "That is the best upgrade of all."
]])
