-- StoryCaster lore library: the races of the Alliance. Original writing in StoryCaster's script format.
-- Keys are the second value of UnitRace("player").
local ADDON, ns = ...
local R = ns.R
R.LORE = R.LORE or {}
R.LORE.race = R.LORE.race or {}
local L = R.LORE.race

L.Human = { "Human", [[
## The Short Lives
leans on a fence post and watches the {time} light settle over the fields.
says, "Elves live for millennia. Dwarves for centuries. We get a handful of decades."
says, "So we hurry. We build. We argue. We fall in love too fast. It is the only way."
## Arathor
speaks of the ancient empire of Arathor, the first great human kingdom, born from tribes who chose to stand together.
says, "Thoradin united the tribes against the trolls. The elves taught a hundred of us magic. Everything grew from that."
says, "Stromgarde, Lordaeron, Gilneas, Kul Tiras, Stormwind. All children of one stubborn idea."
## Stormwind
describes the white walls of Stormwind, the cathedral bells, the canals, the dwarven district always smelling of smoke.
says, "It burned in the First War. We built it back taller. That is a very human thing to do."
says, "The Stonemasons' Guild rebuilt it with their own hands. Then the nobles refused to pay them."
says, "That is also a very human thing. We are complicated."
## The Farmlands
remembers Westfall in the good years: golden wheat, windmills turning, harvest festivals with too much cider.
says, "Then the Defias came, and the drought, and the people who lost everything."
says, "We forget the farmers when we write the history books. We should not. They feed the heroes."
## The Ambition
says, "Every human child is told they can be anything. Most of us believe it far too long."
says, "That is why humans become archmages, kings, and terrible inventors."
smiles. "And bakers. Good bakers. Underappreciated."
## Lordaeron
grows quiet. "Lordaeron was the jewel of the north. Then the plague came."
says, "Prince Arthas burned Stratholme to stop it. Then he became the thing he was fighting."
says, "Every human remembers that lesson. The road to darkness starts with doing something terrible for a good reason."
## The Light
says, "We are the people of the Light. The Church of the Holy Light, the cathedral, the paladins."
says, "Some of us are devout. Some of us just like the singing."
says, "The Light does not seem to mind which."
## The Kings
names them: "Llane, who fell. Varian, who returned. Anduin, who listens."
says, "Good kings are rare. We have been lucky lately. We should not take it for granted."
## The Ordinary
says, "Most humans are not heroes. They are bakers and fishermen and clerks and mothers."
says, "They get up every day in a dangerous world and keep going anyway."
says, "That is the real human courage. Waking up and opening the shop."
## The Mixing
says, "Humans are the great mixers. We trade with dwarves, learn from elves, laugh with gnomes."
says, "We marry whoever we fall in love with. It upsets the nobles. Good."
laughs. [laugh]
## The Grave
says, "Every human knows they will die. It makes us brave. It also makes us foolish."
says, "We plant trees we will never sit beneath. We build cathedrals we will never see finished."
says, "We do it because someone did it for us."
## The Hope
says, "I think humans are the most hopeful people on Azeroth. Because we have to be."
says, "Short lives leave no time for despair."
turns to {target} with a crooked grin. "So let us do something worth remembering, while we are here."
raises a mug toward the sky. [cheer]
/s To short lives and long stories.
drinks deep and sets off down the {zone} road whistling.
]] }

L.Dwarf = { "Dwarf", [[
## The Mountain
thumps a fist against the nearest stone and listens to the sound, like a smith testing a blade.
says, "Good rock, this. Granite with a vein of something shiny underneath. I can smell it."
says, "Dwarves were made from stone, you know. The titans carved us. We just remembered how to laugh."
## Ironforge
describes Ironforge: the Great Forge glowing at the heart of the mountain, the hammers ringing day and night, the warm smell of iron and ale.
says, "You can feel it in your bones in Ironforge. The mountain breathing."
says, "Outsiders find it too hot and too loud. That is how you know it is home."
## The War of the Three Hammers
speaks of the old war between the clans: Bronzebeard, Wildhammer, and Dark Iron.
says, "We fought each other for the mountain. Thaurissan's sorcery woke Ragnaros himself."
says, "Took us centuries to make peace. Took a Bronzebeard queen and a Dark Iron husband to do it."
grins. "Moira and Dagran. Romance and politics. Very dwarven."
## The Council
says, "Now Ironforge is ruled by three: Bronzebeard, Wildhammer, and Dark Iron. The Council of Three Hammers."
says, "Do they argue? Constantly. Do they get things done? Mostly. That is democracy."
## Magni
lowers their voice. "King Magni turned himself into diamond to hear the earth's voice."
says, "Now he speaks for Azeroth herself. We lost a king and the world gained a speaker."
says, "Still miss him at the feasts. He told the best stories."
## Ale
pulls a well-worn tankard from somewhere and raises it with reverence.
says, "Thunderbrew. Finest ale in the Eastern Kingdoms. The secret is the water. And the arguing."
takes a long swig and wipes the foam from their beard. [cheer]
## The Explorers' League
says, "Every dwarf is part explorer. We want to know where we came from."
says, "Brann Bronzebeard has found more lost cities than anyone alive. He has also fallen into more pits."
laughs. [laugh]
## The Forge
mimes striking an anvil with a heavy hammer, slow and rhythmic.
says, "A good smith listens to the steel. It tells you when it is ready."
says, "Rush it, and it shatters. Same as dwarves. Same as friendships."
## The Grudges
says, "We remember. Every insult, every debt, every kindness. All of it written down."
says, "Some call it holding grudges. We call it bookkeeping."
says, "The kindness ledger is longer, though. People forget that part."
## The Gryphons
says, "The Wildhammer ride gryphons in the Hinterlands. Beautiful beasts. Terrible temper."
says, "A gryphon will bite you for no reason and then die for you without hesitation. Very dwarven, really."
## Home
says, "A dwarf's home is wherever there is stone above, fire before, and friends beside."
says, "I could live in a cave with a good fire and three friends and be the richest dwarf alive."
## The Toast
raises the tankard once more to {target}.
says, "To the mountain, the forge, and the friends who carry you home when you cannot stand!"
/s Stone and fire!
drains the tankard and stomps off toward the {zone} hills, singing an old mining song off key.
]] }

L.NightElf = { "Night Elf", [[
## Ten Thousand Years
stands very still beneath the {time} sky, face lifted toward the moon.
says, "I have watched this moon rise more times than your people have names for."
says, "Night elves count time differently. A century is a season. A lifetime is a history."
## Elune
murmurs a quiet prayer to Elune, the Mother Moon, the words older than most kingdoms.
says, "Elune watches over us. She is gentle, and she is fierce. Both at once."
says, "The Sisterhood of Elune keeps her temples. Tyrande Whisperwind is her high priestess."
says, "Tyrande once became the Night Warrior, Elune's vengeance given form. The world trembled."
## The Well of Eternity
grows solemn. "Long ago, our ancestors lived beside the Well of Eternity. Its power made them arrogant."
says, "Queen Azshara called the Legion. The Well exploded. The world broke apart."
says, "We are what remained. The ones who learned that power without restraint destroys everything."
## The Druids
speaks of Malfurion Stormrage, the first druid, and the long sleep in the Emerald Dream.
says, "Our druids slept in barrow dens while the world changed above them."
says, "When they woke, centuries had passed. They simply went back to work."
## The Sentinels
says, "While the druids slept, the Sentinels kept watch. Priestesses, huntresses, warriors."
says, "Our women held the forests for ten thousand years. Remember that."
## Nordrassil and Teldrassil
speaks of the World Trees: Nordrassil on Mount Hyjal, Teldrassil in the northern sea.
says, "Nordrassil gave us immortality. We gave it up to stop Archimonde at Hyjal."
grows quiet. "Teldrassil burned in the Fourth War. Our city. Our people. Our home."
lowers their head for a long moment, saying nothing. [bow]
says, "We do not forget. We do not forgive easily. But we endure."
## The Forest
runs a hand along the bark of a nearby tree, gentle as a greeting.
says, "Every tree is a living thing with a slow and patient heart."
says, "Humans cut them down without asking. We ask. Sometimes the tree says no."
## The Wisp
says, "When a night elf dies, our spirit can become a wisp, drifting home to the forest."
says, "I find that comforting. Even death is not the end of the journey."
## Shadowmeld
steps back into the shade of the trees and seems to vanish, only their eyes still faintly glowing.
says from the darkness, "The night has always been our friend."
steps out again with a faint smile.
## The Highborne
says, "The Highborne were our nobles, drunk on magic. Some became the blood elves. Some became the naga."
says, "Some, like the shal'dorei of Suramar, hid for ten thousand years under a magical dome."
## Patience
says, "Younger races are always in a hurry. We have learned to wait."
says, "A tree does not rush to grow. A river does not rush to the sea."
## The Blessing
turns to {target}, silver eyes glowing softly in the {time} light.
says, "May Elune light your path, and may the forest remember your name."
bows gracefully, one hand over the heart. [bow]
/s Ishnu-alah.
slips silently back into the shadows of the trees.
]] }

L.Gnome = { "Gnome", [[
## The Spark
adjusts a pair of brass goggles and peers at {target} with intense, unblinking curiosity.
says, "You look like someone who has never once wondered how a sprocket works. Tragic."
pulls a small whirring gadget from a pocket. It beeps, sparks, and stops.
says, "Prototype. Perfectly safe. Mostly. Please stand a little to the left."
## Gnomeregan
says, "Gnomeregan was the greatest city of invention the world has ever seen."
describes it: tunnels of gears and steam, glowing pipes, everyone building something brilliant and slightly dangerous.
says, "Then the troggs came. And Mekgineer Thermaplugg betrayed us."
says, "We flooded our own city with radiation to stop them. Most of our people died."
falls silent, adjusting the goggles a little too carefully. [sigh]
## Operation Gnomeregan
says, "We took part of it back. Operation Gnomeregan. High Tinker Mekkatorque led the charge personally."
says, "He is half the height of a dwarf and twice as brave. Do not tell the dwarves."
## Size
says, "People think being small is a disadvantage. It is not."
says, "We fit into machinery. We hide under tables. We are very hard to hit."
says, "Also, everyone underestimates us. That is the best advantage there is."
## The Workshop
describes their workshop: half-built golems, blueprints on every wall, a small explosion every Tuesday.
says, "Tuesdays are for testing. Wednesdays are for repairs. Thursdays are for apologizing to the neighbors."
laughs. [laugh]
## The Mechanostriders
says, "Gnomes ride mechanostriders. Mechanical birds. Very fast. Very loud."
says, "Mine once ran into a lake because I programmed it to chase shiny things. Lesson learned."
## Inventions
lists inventions on their fingers: "The flying machine. The arcane golem. The self-heating boot. The shrink ray."
says, "Only one of those works exactly as intended. I will not say which."
## The Dwarves
says, "Dwarves and gnomes have been friends for a very long time."
says, "They provide the mountain. We provide the ideas. They provide the ale. We provide the explosions."
## Engineering
says, "Goblins build fast and cheap. Gnomes build precise and beautiful."
says, "A goblin rocket gets there. A gnomish rocket gets there and plays music."
## The Optimism
says, "We lost our home. We lost our people. We kept inventing."
says, "Gnomes believe every problem has a solution. It just might need more gears."
## The Future
says, "One day we will reclaim all of Gnomeregan and clean every gear and pipe."
says, "And we will build the greatest city ever, with automatic doors that actually work this time."
## The Farewell
presses a small brass trinket into {target}'s hand. "Here. It does... something. Find out!"
gives an energetic little wave. [wave]
/s Science awaits!
scurries off toward the {zone} road, gadget beeping all the way.
]] }

L.Draenei = { "Draenei", [[
## The Exiles
bows their head, the soft crystals on their brow catching the light.
says, "My people have been running for twenty-five thousand years. I am still learning how to stop."
says, "We were the eredar once, of the world Argus. Brilliant. Proud. Beloved of the stars."
## The Choice
speaks of Sargeras, the fallen titan, who offered the eredar power beyond imagining.
says, "Kil'jaeden and Archimonde accepted. They became the man'ari, the demons of the Legion."
says, "Velen saw a vision of what they would become. He chose to flee instead."
says, "We are the draenei: the exiled ones."
## The Naaru
speaks of the naaru, beings of pure Light who came to Velen and carried his people away on the Genedar.
says, "The naaru sang to us. We followed them across the void between stars."
says, "Every world we found, the Legion found us again."
## Draenor
describes the world Draenor: red plains, glowing forests, mountains like broken teeth.
says, "We lived there in peace for centuries. Then the orcs were corrupted and turned on us."
says, "Shattrath fell. We were hunted nearly to nothing."
falls silent for a long moment, hand over heart. [bow]
## Azeroth
says, "We came to Azeroth in the Exodar, crashing from the sky."
says, "Your Alliance took us in. You did not have to. You did."
says, "We do not forget kindness. We have lived long enough to know how rare it is."
## Velen
speaks of the Prophet Velen, ancient beyond reckoning, carrying the weight of every vision.
says, "He has seen the end of many worlds. He keeps hoping anyway."
says, "That is the bravest thing I know."
## The Light
lifts a hand, and soft golden light gathers like starlight in the palm.
says, "We do not worship the Light as a god. We understand it as a song we have always heard."
## Argus
says, "We returned to Argus, our homeworld, to end the Legion at last."
says, "I walked where my ancestors walked. Everything was ash and fel."
says, "But we won. After twenty-five thousand years, we won."
## The Tail and Hooves
glances down at their hooves with a wry smile.
says, "Your stairs are designed by people who have never had hooves. It is very rude."
laughs softly. [laugh]
## Patience
says, "When you have lived as long as we have, you learn that hope is a long game."
says, "Empires rise and fall. The Light remains."
## Kindness
says, "Every draenei child is taught: help the stranger, for you were strangers once."
says, "We were strangers on every world. We remember."
## The Blessing
places a gentle hand on {target}'s shoulder.
says, "May the Light guide you, and may the naaru sing you home."
bows deeply. [bow]
/s Archenon poros. Good fortune.
turns, tail swaying, and walks on toward the {time} horizon.
]] }

L.Worgen = { "Worgen", [[
## The Curse
stands half in shadow, broad shoulders hunched, ears twitching at every distant sound.
says, "I was human once. The curse made me something else. Something older."
flexes clawed hands, studying them as if they still surprise them. [flex]
## Gilneas
describes Gilneas: grey stone and mist, the cliffs, the long wall Genn Greymane built to keep the world out.
says, "We were proud. Too proud. We shut the world out and thought we were safe."
says, "Then the curse spread inside the wall. Then the Forsaken came. Then the sea came."
says, "Gilneas fell. We fled to Darnassus with nothing."
## The Scythe
speaks of the Scythe of Elune and the druids who first made the curse, ages ago.
says, "Night elf druids tried to master the wolf. The wolf mastered them."
says, "Arugal brought the curse back to Gilneas. One bite at a time."
## The Wild
says, "The wolf wants to run. It wants to hunt. It wants to forget it was ever a person."
says, "Every day I choose to remember. Every single day."
## The Balance
says, "The night elves taught us the rite of the Tal'doren. Balance between man and beast."
says, "I keep my mind. I keep my heart. The wolf keeps my teeth."
grins, showing every one of them.
## Greymane
speaks of King Genn Greymane, stubborn, proud, and grieving his son Liam.
says, "He lost his son. He lost his kingdom. He never lost his fire."
says, "We fought beside him to take back Gilneas. We will finish what he started."
## The Moon
looks up at the {time} sky, ears perked.
says, "The moon calls to us. Some nights louder than others."
says, "On those nights I stay close to friends. They remind me which half of me answers."
## Running
says, "You have never known freedom until you have run on all fours through a forest at night."
says, "The wind, the scents, the ground under your hands."
says, "Then you stand up and remember you have rent due. It is jarring."
laughs, a deep rumbling sound. [laugh]
## The Two Forms
shifts briefly, and for a moment a human face appears, tired and kind, before the wolf returns.
says, "I can still look human when I need to. It is polite. It is also very itchy."
## Survival
says, "Gilneans are survivors. Curse, war, plague, the sea itself. We survived all of it."
says, "We are not pretty about it. But we survive."
## Loyalty
says, "A wolf never abandons its pack. Neither do I."
says, "If you are my friend, I will cross any distance and fight any foe for you."
## The Howl
turns to {target}. "Keep a candle in your window. Someone out here is watching over you."
lifts their head and lets out a long, low howl at the moon. [roar]
/s For Gilneas.
drops to all fours and lopes off into the {zone} night.
]] }

L.VoidElf = { "Void Elf", [[
## The Whispers
tilts their head, as if listening to someone standing just behind them.
says, "Do not mind the whispers. They are mostly harmless. Mostly."
lifts a hand, and violet shadow coils around the fingers like smoke.
## Exile
says, "We were sin'dorei once. Blood elves of Silvermoon."
says, "We studied the Void. The Silvermoon council called it heresy. They exiled us."
says, "Some of us were consumed by the shadow we touched. The rest of us were changed forever."
## Alleria
speaks of Alleria Windrunner, the ranger who touched the Void and mastered it.
says, "She showed us that the shadow does not have to devour you. It can be guided."
says, "She is our teacher. Our proof that we can survive this."
## Telogrus Rift
describes Telogrus Rift: a fractured island floating in endless darkness, stars that watch back.
says, "We nearly lost ourselves there. Every one of us heard the call to let go."
says, "Alleria pulled us back. We came out different. Stronger. A little strange."
## The Alliance
says, "The Alliance took us in when Silvermoon cast us out."
says, "Some of them still look at us with suspicion. I do not blame them."
says, "We are proof that darkness can be used to protect the light."
## The Void Itself
says, "The Void is not evil. It is hungry. It is chaos. It is the space between stars."
says, "The Old Gods are made of it. That is the danger."
says, "We hold it the way one holds a blade by the handle, very carefully."
## Silvermoon
grows quiet. "I miss Silvermoon. The golden spires. The music in the streets."
says, "I do not regret what I chose. But I miss it."
## The Shadow Form
lets the shadow surge, and for a moment their skin darkens to midnight purple, eyes burning violet.
lets it fade again with a slow breath.
says, "Sometimes it is easier to let it out. Other times I have to hold it with both hands."
## Humor
says, "The whispers once told me the end of the world was coming. It was a Tuesday."
says, "Nothing happened. I had a nice lunch."
laughs softly. [laugh]
## The Price
says, "We gave up our home, our families, our certainty. For knowledge."
says, "I think it was worth it. Ask me again in a hundred years."
## The Future
says, "We are a young people, in a way. Born from a choice."
says, "We get to decide what we become. That is terrifying. It is also beautiful."
## The Farewell
turns to {target}, violet eyes catching the {time} light.
says, "If you ever hear whispers in the dark, do not answer. Come find me."
gives a small graceful bow. [bow]
/s The shadow does not own us.
steps sideways into a shimmer of darkness and is gone.
]] }

L.LightforgedDraenei = { "Lightforged Draenei", [[
## The Army of the Light
stands perfectly straight, golden light flickering faintly beneath their skin.
says, "I have fought the Burning Legion across a thousand worlds for twenty-five thousand years."
says, "I am Lightforged. The Light runs through my veins like blood."
## The Vindicaar
speaks of the Vindicaar, the great ship of the Army of the Light, and the Xenedar before it.
says, "We sailed between stars with the naaru, hunting the Legion wherever it went."
says, "Turalyon was one of us. A human, aged not a day in a thousand years of war."
## The Forging
says, "To be Lightforged, you step into the Light of a naaru and let it remake you."
says, "Not everyone survives. Those who do are never quite the same."
says, "We feel the Light every moment. It is beautiful. It is also very loud."
## Xe'ra
speaks quietly of Xe'ra, the naaru who led the Army of the Light.
says, "She was certain. Too certain. She tried to force the Light on those who were not ready."
says, "Illidan refused her. She died. Some of us still argue whether she was right."
## The War
says, "I have seen worlds burn. I have seen whole peoples consumed by fel."
says, "Every time, we came too late to save everyone. Every time, we saved someone."
says, "That is what kept us going."
## Argus
says, "When we finally broke the Legion's hold on Argus, I wept."
says, "Twenty-five thousand years of war, and it was finally done."
lowers their head, golden light flickering. [bow]
## Peace
says, "Now there is no Legion to fight. I do not know what to do with my hands."
says, "I am learning. Gardening. Reading. Sitting still."
says, "Sitting still is the hardest thing I have ever done."
laughs softly. [chuckle]
## The Fervor
says, "Some of my brethren still burn with fervor. They see shadow everywhere."
says, "I try to remind them: the Light is for healing as much as fighting."
## The Alliance
says, "We joined the Alliance because they fought beside us on Argus."
says, "They do not always understand us. We do not always understand them."
says, "But they bled for the same cause. That matters."
## The Glow
glances down at their glowing arms with a wry smile.
says, "I am very useful in a dark cave. People use me as a lantern."
## The Burden
says, "We carry the memories of every fallen comrade. Every lost world."
says, "The Light helps us bear it. Barely."
## The Salute
salutes {target} with crisp, ancient precision. [salute]
says, "Whatever comes next, the Light stands ready. So do I."
/s The Light endures.
turns and marches on, golden light trailing in their wake.
]] }

L.DarkIronDwarf = { "Dark Iron Dwarf", [[
## The Fire
cracks their knuckles, and faint embers drift up from their skin like sparks from a forge.
says, "Dark Iron. Born in fire, raised in fire, and very hard to put out."
## Thaurissan
speaks of Sorcerer-Thane Thaurissan, who summoned Ragnaros the Firelord in the War of the Three Hammers.
says, "He tried to win a war. He woke a god of fire instead."
says, "The Burning Steppes, the Searing Gorge. All of it was green once. Now it smolders."
says, "We lived as Ragnaros' slaves for centuries. Under the mountain. In the heat."
## Moira
speaks of Moira Thaurissan, daughter of Magni Bronzebeard, wife of the Dark Iron emperor.
says, "She married into our clan. Everyone called it kidnapping. She called it a choice."
says, "Now she sits on the Council of Three Hammers. A Bronzebeard queen of the Dark Irons."
grins. "Dwarven politics. Never boring."
## Shadowforge
describes Shadowforge City, deep in Blackrock Mountain: lava rivers, black stone, forges that never cool.
says, "It is home. It is hot. It is loud. Outsiders call it hell. We call it Tuesday."
laughs. [laugh]
## The Forge
says, "We are the finest smiths alive. Do not tell the Bronzebeards."
says, "We work with dark iron and fire. Our steel holds an edge forever."
mimes swinging a hammer onto an anvil, sparks flying with each strike.
## The Fireblood
says, "We carry the fire in our blood now. Literally."
lets a small flame flicker over one palm, unharmed.
says, "It keeps us warm in winter. And it makes us very popular at campfires."
## Redemption
says, "We did terrible things under Ragnaros. Under Thaurissan. Under our own hate."
says, "Joining the Alliance was not forgiveness. It was a chance."
says, "We intend to make the most of it."
## The Grudge
says, "The Bronzebeards and Wildhammers have long memories. So do we."
says, "We have agreed to forgive. We have not agreed to forget. That is dwarven peace."
## The Mole Machines
says, "We travel by mole machine. Drill down, drill up, pop out anywhere."
says, "Very efficient. Very loud. Occasionally we pop up in someone's kitchen."
## Pride
says, "Every Dark Iron is proud. Too proud, maybe. We survived a god."
says, "Not many people can say that."
## The Toast
raises a tankard of something smoking faintly. "Fireblood ale. It burns going down. Builds character."
drinks deep, then exhales a small puff of flame. [cheer]
/s Forged in fire!
strides off toward the {zone} road, embers trailing behind.
]] }

L.KulTiran = { "Kul Tiran", [[
## The Sea
plants their feet wide, swaying slightly, as if the ground were the deck of a ship.
says, "Land legs are a myth. Kul Tirans are born with sea legs and die with them."
breathes in deeply. "Salt, tar, and fish. The smell of home."
## The Admiralty
speaks of the Kul Tiran admiralty: Proudmoore, Ashvane, Waycrest, Stormsong.
says, "Four great houses ruling the seas. Arguing constantly. Very effective navy."
says, "Daelin Proudmoore. Katherine Proudmoore. Jaina, the prodigal daughter."
## Jaina
says, "Jaina Proudmoore left us to study magic. She came home a legend and a little broken."
says, "She faced the sea itself to earn back her people's trust. She did it."
says, "Every Kul Tiran respects that. Even the ones who will not admit it."
## Boralus
describes Boralus: the great harbor, the gulls, the tidesages chanting on the cliffs, a thousand ships at anchor.
says, "Smells of fish and rain. Every sailor in the world comes through eventually."
## Drustvar
grows quieter. "Inland, there is Drustvar. Dark forests. Witches. Things that move in the fog."
says, "Every Kul Tiran child grows up on stories of the Drust. Every one of them is true."
## Stormsong Valley
says, "Stormsong Valley, where the tidesages pray to the sea. Farms and lighthouses and storms."
says, "The tidesages talk to the sea. Sometimes the sea talks back. Sometimes it should not."
## The Size
says, "We are big people. Broad shoulders. Thick arms. Built for hauling rope and lifting anchors."
says, "Some say we are clumsy. Ask any pirate who tried to board a Kul Tiran ship."
grins. [flex]
## The Navy
says, "The Kul Tiran navy is the finest in the world. It has saved the Alliance more times than anyone can count."
says, "When the orcs came to Lordaeron, our ships carried the army. When the Legion came, our ships carried the survivors."
## The Haul
says, "There is an old Kul Tiran trick: haul everything. Haul crates, haul anchors, haul friends out of trouble."
says, "We have a special talent for it. Strong backs, steady hands."
## Sea Shanties
hums a few bars of an old sea shanty, tapping a foot in time.
says, "Every ship has its own song. You learn them all if you sail long enough."
## The Storm
says, "We do not fear storms. We respect them. There is a difference."
says, "A sailor who fears the storm hides. A sailor who respects it reefs the sails and keeps going."
## The Farewell
offers {target} a firm, salt-rough handshake.
says, "Fair winds and following seas. And if you ever need a ship, ask for a Kul Tiran."
raises a hand in a sailor's wave. [wave]
/s The tides will guide you!
swaggers off toward the {zone} harbor, rolling with every step.
]] }

L.Mechagnome = { "Mechagnome", [[
## The Clockwork
clicks softly as they turn their head, gears whirring faintly in a mechanical arm.
says, "Do not be alarmed. That noise is perfectly normal. Mostly."
flexes the metal fingers, one at a time, listening to each joint.
## Mechagon
describes Mechagon Island: towering junk-heaps, rusted machines, a city of gears and steam built by gnomes who chose metal over flesh.
says, "We were gnomes once. Gnomes who believed the flesh was weak and the machine was eternal."
says, "Some of us went too far. King Mechagon wanted to replace everyone. Even you."
## The Rebellion
speaks of Prince Erazmin, who led the rebellion against his father, King Mechagon.
says, "Erazmin believed machine and flesh could live together. Not one replacing the other."
says, "We won. Mechagon was stopped. Now we choose our own upgrades."
## The Upgrades
lifts a mechanical arm and admires its polished joints.
says, "This arm was an upgrade after a little accident with a lathe. It is much better than the old one."
says, "Some of us replace a little. Some of us replace a lot. It is personal."
## The Fleshy Ones
says, "We do not look down on those who stay all flesh. We used to. We were wrong."
says, "Flesh feels warmth. Flesh tastes bread. Machines cannot do that. Yet."
## Gnomeregan
says, "We left Gnomeregan long ago, before the troggs came."
says, "Our cousins think we are strange. We think they are adorable."
## Repair
pulls a small toolkit from a compartment in their arm.
says, "Never travel without a toolkit. You never know when you will need a spare gear. Or a spare elbow."
## The Hum
says, "My heart is part clockwork. It ticks. Some find it soothing."
says, "When I am anxious, it ticks faster. Very inconvenient for a career in poker."
laughs, a soft whirring sound. [laugh]
## Junkyard Wisdom
says, "On Mechagon, nothing is wasted. Every scrap becomes something new."
says, "Broken things are only unfinished things. That is the first lesson of Mechagon."
## The Alliance
says, "We joined the Alliance because they helped us stop the king."
says, "We are good allies. We are also very good at fixing siege engines."
## Choice
says, "Our people learned something important: improvement should be a choice, not a command."
says, "Nobody should be upgraded against their will. That is the rule."
## The Farewell
presses a small, polished cog into {target}'s hand. "For luck. And emergencies."
gives a cheerful salute with a faint whir of gears. [salute]
/s Efficiency and heart!
clanks off toward the {zone} road, humming a little mechanical tune.
]] }
