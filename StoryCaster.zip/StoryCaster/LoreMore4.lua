-- StoryCaster lore library: further scenes for the Horde races and a few others.
local ADDON, ns = ...
local R = ns.R
R.LORE_MORE = R.LORE_MORE or {}
R.LORE_MORE.race = R.LORE_MORE.race or {}
local M = R.LORE_MORE.race
local function add(k, s) M[k] = (M[k] or "") .. s end

add("DarkIronDwarf", [[
## The Forge Song
hums a low, rumbling work song, tapping out the rhythm with a hammer against a stone.
says, "Every Dark Iron forge has its own song. You learn it with your first burn."
says, "This one is about a smith who fell in love with a lava flow. It does not end well."
laughs, a deep gravelly sound. [laugh]
says, "We sing it at weddings anyway."
]])

add("KulTiran", [[
## The Shanty
plants a boot on a crate and clears their throat. [cheer]
says, "Every Kul Tiran sailor knows a hundred shanties. Most are not fit for polite company."
says, "This is one of the polite ones. It is about a whale who wanted to be a ship."
hums the tune, swaying as if the deck were moving beneath them.
says, "The whale gets the ship in the end. Admiralty songs always have happy endings."
says, "The Drust songs from the forest do not. Learn the difference before you sing in Drustvar."
]])

add("Mechagnome", [[
## The Upgrade
flexes a gleaming mechanical arm, servos whirring softly.
says, "Upgrades are a matter of personal taste. Some of us keep a flesh hand. Some of us keep a flesh nose."
says, "I kept my eyebrows. They are very expressive. Watch." [chuckle]
raises one eyebrow with great precision.
says, "King Mechagon wanted us all metal. Perfect. Identical. No eyebrows at all."
says, "Prince Erazmin said a gnome should choose. We chose. That is the whole revolution, really."
says, "Freedom, and eyebrows."
]])

add("Orc", [[
## The Fire
crouches beside a small fire and feeds it a stick, watching the sparks rise. [sit]
says, "In the old days, the clans gathered around great fires and told the stories of the ancestors."
says, "The storyteller would point at the sparks and say, 'There goes another warrior to the spirits.'"
says, "I liked that. Death was not the end. Just a spark going up."
says, "My father told me the story of Durotan and Draka every winter. How they stood against Gul'dan."
says, "How they lost everything, and their son freed our people anyway."
says, "Every orc child learns that the hardest fights are won by the ones who come after."
says, "So we fight for them. The ones who come after."
pokes the fire, and a column of sparks rises into the {time} sky.
says, "There. Another story going up."
]])

add("Scourge", [[
## The Apothecary
pulls a small corked vial from a coat pocket and holds it up to the light. It glows faintly green.
says, "Do not worry. This one is a remedy. For joint stiffness. Mine are very stiff."
says, "Forsaken apothecaries are brilliant. Some of them use it for terrible things."
says, "I knew one who spent ten years trying to brew a cure for being dead."
says, "She never found it. But she found a cure for the red pox along the way. Saved a village."
says, "The living never thanked her. She did not mind. She said the cure was the thanks."
tucks the vial away again.
## The Mirror
says, "I keep a small mirror. I do not know why. I do not like what I see."
says, "But some mornings I look and think: still here. Still me. That is something."
says, "The face changes. The person underneath is stubborn."
## The Living Friend
says, "I have one living friend. A human baker in a little town. She leaves bread on her windowsill for me."
says, "She knows what I am. She leaves it anyway."
says, "That bread is worth more than every kingdom in Lordaeron."
]])

add("Tauren", [[
## The Sun Rite
rises with the dawn and raises both hands toward the east, horns catching the first light.
says, "Every morning, we greet An'she as he rises. Every evening, we thank Mu'sha as she wakes."
says, "It does not take long. A breath, a word, a moment of stillness."
says, "Some mornings I forget. The day always feels slightly wrong after."
lowers their hands slowly, eyes closed in quiet gratitude.
## The Drum
pulls a small hide drum from their pack and taps it softly with broad fingers.
says, "Every tauren learns the drum before they learn to walk. The heartbeat of the Earth Mother."
begins a slow, steady rhythm, rocking gently in time. [dance]
says, "At the great gatherings, a thousand drums beat together. You feel it in your bones for days."
says, "Orcs find it very calming. Goblins find it very loud. Both are right."
stills the drum and smiles.
## The Plainsrunners
says, "Every young tauren runs the plains as a rite of passage. Days alone with the wind and the grass."
says, "When I ran mine, a great hawk followed me the whole way. My spirit guide, the elders said."
says, "Or a very hungry hawk. Either way, I learned to share my dried meat."
]])

add("Troll", [[
## Da Fishing
sits on the edge of a dock, dangling long legs over the water, line in hand. [sit]
says, "Darkspear fishin' be different, mon. We do it at night, with torches and spears."
says, "Fish come up to see da light. Den — ha! — dinner."
mimes a lightning-fast spear throw, then grins.
says, "My uncle could spear three fish in one throw. He also lost two fingers to a shark. Dey grew back."
## Da Ancestors
says, "When a Darkspear dies, we send dem out to sea on a burning boat."
says, "Da fire carry dem to Bwonsamdi. Da sea carry dem home."
says, "Every time I see a fire on da water at night, I wave. Just in case."
## Da Kids
says, "Troll kids be wild, mon. Climbin' everything, bitin' everything, laughin' at everything."
says, "My little cousin tried to tame a raptor last week. Raptor tamed him instead. He's fine. Mostly."
laughs, slapping a knee. [laugh]
## Da Trust
says, "Darkspear trust slow. Too many betrayals. But once we trust ya, mon, ya family forever."
says, "Ya get da stories, da food, da drums, and da blame when somethin' goes wrong."
]])

add("BloodElf", [[
## The Brooms
watches a small enchanted broom sweep the street nearby with fond exasperation.
says, "Silvermoon is famous for its self-sweeping brooms. Every visitor stares."
says, "They are quite clever. They are also quite stubborn. One followed me home for a week."
says, "I eventually adopted it. It sweeps the doorway and judges my guests."
chuckles softly. [chuckle]
## The Dead Scar
grows quiet, gazing south toward Eversong's long gray wound.
says, "The Dead Scar cuts through Eversong like a knife. Arthas's march, burned into the land."
says, "Nothing grows there. We have tried. The Light, the arcane, the druids. Nothing."
says, "We leave it as it is now. A reminder. Some wounds should not be hidden."
## The Dance of the Sun
says, "At the Sunwell festival, we dance under the golden sky until dawn."
says, "Every step is precise. Every gesture is centuries old. Every dancer is very, very competitive."
rises onto their toes and spins once, gracefully. [dance]
## The Flaw
says, "My people's flaw is pride. We know it. We are working on it."
says, "Slowly. Very slowly. With great dignity."
smiles wryly.
]])

add("Goblin", [[
## The First Deal
leans in close, conspiratorial. "Want to know my first deal? I was four."
says, "Sold my sister's doll back to her. Made a three hundred percent profit."
says, "She still has not forgiven me. She runs a bank now. She charges me double."
laughs. [laugh]
## The Explosion
says, "Every goblin has an explosion story. Mine involves a cooking stove, a rocket booster, and my eyebrows."
says, "They grew back. Mostly. The left one is a little surprised now, permanently."
raises the left eyebrow in demonstration.
## The Cartels
says, "Bilgewater, Steamwheedle, Venture Company, Blackfuse. The great goblin cartels."
says, "Some of them build cities. Some of them strip-mine forests. We are not all the same."
says, "The Venture Company gives everyone a bad name. We tell them so. Loudly."
## The Heart
grows briefly quiet. "People think goblins only care about gold. Not true."
says, "When the volcano blew on Kezan, I lost everything. My shop. My rockets. My savings."
says, "A troll family I had never met shared their food with me on the boat. Did not ask for a copper."
says, "I paid them back tenfold. Not because I owed it. Because I wanted to."
says, "Do not tell anyone. Bad for business."
]])

add("HighmountainTauren", [[
## The Story Pole
runs a hand along a carved pole, tracing the faces cut into the wood.
says, "Every family in Highmountain carves its own story pole. Each generation adds a face."
says, "Mine has a hunter, a shaman, a warrior, and a very surprised-looking moose."
says, "That moose was my great-grandmother's best friend. Long story."
chuckles warmly. [chuckle]
## The Storm
looks up at gathering clouds over the peaks.
says, "Storms in Highmountain are fierce. Lightning dances between the peaks for hours."
says, "The Skyhorn call it the sky's war dance. They stand on the cliffs and dance with it."
says, "I prefer to dance with it from inside a warm lodge. With soup."
## The Hammer
speaks with reverence of the Hammer of Khaz'goroth, Huln's great weapon.
says, "When the Legion returned, heroes came to our mountains seeking that hammer."
says, "We tested them. Not with strength, but with respect. Those who passed earned our trust."
## The Bloodtotem
says, "The Bloodtotem were our cousins. The dragon's whispers twisted them."
says, "We did not abandon them. We fought for them, even when they fought us."
says, "Some came home. We welcomed every one. Family is family, even after a long winter."
## The Rite of the Peaks
says, "Every young Highmountain climbs the tallest peak alone and waits for the sky to speak."
says, "Some hear eagles. Some hear thunder. I heard my own heart, very loud, very afraid."
says, "The elders said that was the best answer of all. Courage starts in a frightened heart."
## The Feast
says, "After a great hunt, the tribes gather for a feast. Drums, dancing, stories by the fire."
says, "The Rivermane bring fish. The Skyhorn bring eggs. The Bloodtotem bring complaints. It is tradition."
laughs heartily. [laugh]
]])

add("MagharOrc", [[
## The Ancestor Stones
kneels beside a ring of stones and lays a hand on each in turn. [kneel]
says, "On Draenor, every clan kept ancestor stones. Each holds the name of a fallen hero."
says, "When we fled our dying world, we carried our stones with us. Every one."
says, "They are heavy. We did not leave one behind. That is what it means to be Mag'har."
rises, dusting off their knees.
## The Hunt of Draenor
says, "On Draenor, we hunted the great beasts. Talbuks. Clefthoofs. Riverbeasts."
says, "A clefthoof is bigger than a house and twice as angry. Bringing one down feeds a clan for a month."
says, "Azeroth's beasts are smaller. Friendlier. I miss the danger, a little."
grins, tusks flashing.
## The Lightbound War
says, "On our world, the Lightbound burned our villages and named it mercy."
says, "My mother fought them at the gates of our stronghold. She did not survive."
says, "When I see the Light now, I remember fire. I am learning not to."
says, "The draenei of Azeroth are different. Kinder. I am learning that too."
## Brown Skin
holds up a strong brown arm.
says, "Our skin is brown because no fel ever touched us. It is the color of Draenor's earth."
says, "Our cousins' green skin is the mark of what was taken from them."
says, "Neither is better. Both remember."
## The Song of Grom
says, "On our Draenor, we sing a song for Grommash every year. The day he said no."
says, "No to the blood. No to Gul'dan. No to the easy power."
says, "One word changed a whole world. Never forget the power of no."
]])

add("Nightborne", [[
## The Arcwine
holds a delicate crystal glass, empty, turning it slowly in elegant fingers.
says, "This glass once held arcwine. Every nightborne drank it daily. We needed it to live."
says, "Now we have learned to live without it. It was like losing a limb. Or a lover."
says, "I keep the glass. A reminder of what we were. And what we no longer need."
sets the glass down gently.
## The Shal'dorei Court
says, "The court of Suramar was elaborate. Seventeen forms of bowing. Thirty-two forms of insult."
says, "I mastered all of them. Very useful in Suramar. Completely useless anywhere else."
performs an exquisitely precise bow, then laughs softly. [bow]
says, "That was the third form. It means 'I respect you, but your shoes are dreadful.'"
## The Stars of Suramar
looks up, silver markings glowing faintly.
says, "Under the dome, we could not see the real stars. Only illusions, projected by the magisters."
says, "When the dome fell, I saw the true night sky for the first time in ten thousand years."
says, "I wept. The illusions were nothing compared to it."
## Thalyssra
says, "First Arcanist Thalyssra is our leader now. A rebel, a survivor, a scholar."
says, "She was exiled, starved, nearly withered. She came back and freed us all."
says, "We follow her not because she is noble. Because she suffered with us."
## The Lesson
says, "Perfection is a prison. Comfort can be a cage. Safety can be a slow death."
says, "We learned that the hard way. We are learning a better way now."
]])

add("Vulpera", [[
## The Caravan Songs
sits by a small fire, ears perked, and begins to hum a soft travelling tune. [sit]
says, "Every caravan has its own song. When two caravans meet, they sing to each other."
says, "If the songs match, you are cousins! If they do not, you trade and part as friends."
says, "Ours is about a fox who found an oasis and shared it with a scorpion."
says, "The scorpion stung him. He shared anyway. The moral is complicated."
laughs, a soft yipping sound. [laugh]
## The Sandstorm
says, "When a great sandstorm comes, the whole caravan circles the wagons and burrows in."
says, "We wrap our faces in cloth and huddle close. The old ones tell stories until it passes."
says, "Some of my best memories are of sandstorms. Warm, cozy, full of tales."
## The Treasures
empties a pouch into one paw: a button, a key, a shiny stone, a tiny bone.
says, "Every treasure has a story. This key? Found it in a ruin. Does not open anything."
says, "Yet. It does not open anything yet."
tucks the treasures away with great care.
## The Dazar'alor Visit
says, "When I first saw Dazar'alor, I stood and stared for an hour. So much gold!"
says, "I asked a Zandalari guard if I could have a tiny piece. He laughed for a very long time."
says, "Then he gave me a single golden bead. I wear it still." [chuckle]
## The Dream
says, "Every vulpera dreams of finding the Lost Oasis. Endless water, endless shade."
says, "Some say it is a myth. I say it is out there. Just past the next dune."
]])

add("Pandaren", [[
## The Turtle's Song
says, "Sometimes, on the Wandering Isle, Shen-zin Su would hum. The whole island would hum with him."
says, "The fish came up to listen. The birds went quiet. Even the monks stopped training."
says, "I hum his song when I cannot sleep. It sounds like the sea and a very old friend."
hums a low, slow tune, eyes half closed.
]])

add("Dracthyr", [[
## The First Sunrise
says, "The morning I woke, I climbed out of the cave and saw the sun for the first time in ten thousand years."
says, "I had forgotten its color. I had forgotten its warmth on my scales."
says, "I sat on a cliff and watched it rise for an hour. Emberthal had to come and fetch me."
says, "She did not scold me. She sat down and watched it with me."
smiles at the memory, wings settling. [sit]
says, "Every sunrise since, I stop for a moment. I owe the sun that much."
]])

add("EarthenDwarf", [[
## The First Song
says, "We earthen did not sing, for a very long time. The Edicts said nothing about singing."
says, "Then a dwarf taught me a song about a pickaxe that fell in love with a gemstone."
says, "I sang it for three days straight. My neighbours asked me to stop. Very politely."
says, "I did not stop. That was my first choice that was truly my own."
grinds out a few deep notes of the song, slightly off key. [cheer]
says, "Freedom sounds a little like a bad song, sung with great joy."
]])

add("ZandalariTroll", [[
## The Loa Shrines
kneels before a small carved shrine and lays a golden coin at its base. [kneel]
says, "Every Zandalari household keeps a shrine to their family's loa."
says, "Mine is Pa'ku, the wind loa. She guides travelers and sailors."
says, "I leave her offerings every morning. She has never let me get lost. Not once."
rises with quiet dignity.
## Gonk
says, "Gonk is the loa of the hunt. A great raptor, wise and fierce."
says, "Every Zandalari hunter asks his blessing. If he gives it, your raptor will never fail you."
says, "If he does not, you should probably stay home that day."
## The Pyramid Climb
says, "There are seven thousand steps to the top of the Great Seal. I have climbed them twice."
says, "Once as a child, on a dare. Once as an adult, for the king. The second time was harder."
laughs ruefully. [laugh]
## The Zanchuli
says, "The Zanchuli Council once ruled beside the king. Priests of the loa."
says, "Some betrayed us. Turned to G'huun, the blood god. We cast them down."
says, "Even in an ancient empire, you must watch for those who would sell it."
## Talanji's Courage
says, "Queen Talanji was young when her father died. Many said she was too young."
says, "She stood before Bwonsamdi, the death loa himself, and bargained for her people's souls."
says, "She won. Bwonsamdi still talks about it. He respects her. A little."
## The Tides
says, "Zuldazar faces the sea. Our fleets once ruled every ocean."
says, "When the tides are right, you can hear the old drums from the harbor at night."
says, "Ghosts, some say. Memory, others say. I say both."
]])
