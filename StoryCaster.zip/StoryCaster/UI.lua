-- StoryCaster: the panel (player, timing, animated emotes), the script and scene menus, the line editor,
-- the share window and the writing window.
local ADDON, ns = ...
local R = ns.R
local WHITE = "Interface\\Buttons\\WHITE8X8"
local FONT = "Fonts\\FRIZQT__.TTF"
local ACCENT = { 0.71, 0.55, 1.0 }

---------------------------------------------------------------------------
-- Little building blocks
---------------------------------------------------------------------------
local function Grad(tex, a, b, alpha)
  tex:SetTexture(WHITE)
  if tex.SetGradient and CreateColor then
    if pcall(tex.SetGradient, tex, "VERTICAL", CreateColor(a[1], a[2], a[3], alpha or 1), CreateColor(b[1], b[2], b[3], alpha or 1)) then return end
  end
  tex:SetVertexColor(b[1], b[2], b[3], alpha or 1)
end

local function Edge(f, r, g, b, a)
  f.edges = f.edges or {}
  local spec = { { "TOPLEFT", "TOPRIGHT", nil, 1 }, { "BOTTOMLEFT", "BOTTOMRIGHT", nil, 1 }, { "TOPLEFT", "BOTTOMLEFT", 1 }, { "TOPRIGHT", "BOTTOMRIGHT", 1 } }
  for i, p in ipairs(spec) do
    local t = f.edges[i]
    if not t then
      t = f:CreateTexture(nil, "BORDER")
      t:SetPoint(p[1]); t:SetPoint(p[2])
      if p[3] then t:SetWidth(p[3]) end
      if p[4] then t:SetHeight(p[4]) end
      f.edges[i] = t
    end
    t:SetColorTexture(r, g, b, a or 1)
  end
end

local function Glass(f, alpha, header)
  local bg = f:CreateTexture(nil, "BACKGROUND")
  bg:SetAllPoints()
  Grad(bg, { 0.03, 0.02, 0.06 }, { 0.10, 0.07, 0.17 }, alpha or 0.94)
  Edge(f, 0.42, 0.33, 0.62, 1)
  if header then
    local hb = f:CreateTexture(nil, "BACKGROUND", nil, 2)
    hb:SetPoint("TOPLEFT", 1, -1); hb:SetPoint("TOPRIGHT", -1, -1); hb:SetHeight(header)
    hb:SetColorTexture(0, 0, 0, 1)
    local hl = f:CreateTexture(nil, "ARTWORK")
    hl:SetPoint("TOPLEFT", 1, -header - 1); hl:SetPoint("TOPRIGHT", -1, -header - 1); hl:SetHeight(1)
    hl:SetColorTexture(ACCENT[1], ACCENT[2], ACCENT[3], 0.6)
  end
end

local function Text(parent, size, r, g, b, flags)
  local fs = parent:CreateFontString(nil, "OVERLAY")
  fs:SetFont(FONT, size, flags or "")
  fs:SetTextColor(r or 1, g or 1, b or 1)
  fs:SetJustifyH("LEFT")
  return fs
end

local function Tip(w, title, body)
  w:SetScript("OnEnter", function(self)
    GameTooltip:SetOwner(self, "ANCHOR_TOP")
    GameTooltip:SetText(title, 1, 0.85, 0.4)
    if body then GameTooltip:AddLine(body, 0.9, 0.9, 0.9, true) end
    GameTooltip:Show()
  end)
  w:SetScript("OnLeave", function() GameTooltip:Hide() end)
end

-- a flat button with a label; kind: "primary" (accent), "on" (green), "emote", "key" (gold) or plain
local function Btn(parent, label, w, h, onClick, kind)
  local b = CreateFrame("Button", nil, parent)
  b:SetSize(w, h)
  b.bg = b:CreateTexture(nil, "BACKGROUND")
  b.bg:SetAllPoints()
  b.hl = b:CreateTexture(nil, "HIGHLIGHT")
  b.hl:SetAllPoints()
  b.hl:SetColorTexture(1, 1, 1, 0.12)
  b.text = Text(b, h >= 24 and 11 or 10, 1, 1, 1)
  b.text:SetPoint("CENTER")
  b.text:SetJustifyH("CENTER")
  b.text:SetText(label)
  function b:Kind(k)
    if k == "primary" then Grad(self.bg, { 0.35, 0.20, 0.62 }, { 0.58, 0.40, 0.95 }); Edge(self, 0.85, 0.75, 1, 1)
    elseif k == "on" then Grad(self.bg, { 0.12, 0.35, 0.18 }, { 0.20, 0.55, 0.28 }); Edge(self, 0.5, 0.95, 0.6, 1)
    elseif k == "key" then Grad(self.bg, { 0.55, 0.38, 0.05 }, { 0.92, 0.70, 0.18 }); Edge(self, 1, 0.9, 0.55, 1)
    elseif k == "go" then Grad(self.bg, { 0.06, 0.40, 0.14 }, { 0.16, 0.72, 0.30 }); Edge(self, 0.55, 1, 0.65, 1)
    elseif k == "stop" then Grad(self.bg, { 0.45, 0.04, 0.04 }, { 0.85, 0.14, 0.14 }); Edge(self, 1, 0.6, 0.6, 1)
    elseif k == "emote" then Grad(self.bg, { 0.10, 0.07, 0.18 }, { 0.20, 0.14, 0.32 }); Edge(self, 0.45, 0.36, 0.68, 1)
    else Grad(self.bg, { 0.08, 0.06, 0.13 }, { 0.15, 0.12, 0.22 }); Edge(self, 0.36, 0.30, 0.50, 1) end
  end
  b:Kind(kind)
  b:SetScript("OnMouseDown", function(self) self.text:SetPoint("CENTER", 1, -1) end)
  b:SetScript("OnMouseUp", function(self) self.text:SetPoint("CENTER", 0, 0) end)
  b:SetScript("OnClick", onClick)
  return b
end

local function Bar(parent, w, h, r, g, b)
  local sb = CreateFrame("StatusBar", nil, parent)
  sb:SetSize(w, h)
  sb:SetStatusBarTexture(WHITE)
  sb:SetStatusBarColor(r, g, b)
  sb:SetMinMaxValues(0, 1)
  sb:SetValue(0)
  local bg = sb:CreateTexture(nil, "BACKGROUND")
  bg:SetAllPoints()
  bg:SetColorTexture(1, 1, 1, 0.08)
  return sb
end

local function Section(parent, h)
  local f = CreateFrame("Frame", nil, parent)
  f:SetHeight(h)
  f:SetPoint("LEFT"); f:SetPoint("RIGHT")
  return f
end

-- a line as people read it: who, where, the words, the animation, the pause before it
function R:LineLabel(l)
  if not l then return "" end
  local parts = {}
  if l[3] then parts[#parts + 1] = "|cff888888(pause " .. l[3] .. "s)|r" end
  if l[5] then parts[#parts + 1] = "|cff7fd8ff[" .. l[5] .. "]|r" end
  if l[1] ~= "" then
    if l[4] then parts[#parts + 1] = "|cffffd27f" .. (self.CHANNEL_SLASH[l[4]] or "/s") .. "|r " .. self:Render(l[1])
    else parts[#parts + 1] = (l[5] or UnitName("player")) .. " " .. self:Render(l[1]) end
  end
  if l[2] then parts[#parts + 1] = "|cff9f8fff[" .. l[2]:lower() .. "]|r" end
  return table.concat(parts, " ")
end

---------------------------------------------------------------------------
-- The panel
---------------------------------------------------------------------------
local PW, HEAD, PAD = 500, 54, 16

function R:BuildBar()
  local p = CreateFrame("Frame", "StoryCasterPanel", UIParent)
  p:SetSize(PW, 400)
  if self.db.barPoint then local t = self.db.barPoint; p:SetPoint(t[1], UIParent, t[2], t[3], t[4])
  else p:SetPoint("TOP", 0, -110) end
  p:SetFrameStrata("MEDIUM")
  p:SetClampedToScreen(true)
  p:SetMovable(true)
  p:EnableMouse(true)
  p:RegisterForDrag("LeftButton")
  p:SetScript("OnDragStart", p.StartMoving)
  p:SetScript("OnDragStop", function(f)
    f:StopMovingOrSizing()
    local a, _, b, x, y = f:GetPoint()
    R.db.barPoint = { a, b, x, y }
  end)
  Glass(p, nil, HEAD)

  -- a soft light under the header that flares on every line
  p.flare = p:CreateTexture(nil, "ARTWORK")
  p.flare:SetPoint("TOPLEFT", 1, -HEAD - 2); p.flare:SetPoint("TOPRIGHT", -1, -HEAD - 2); p.flare:SetHeight(14)
  p.flare:SetTexture(WHITE)
  p.flare:SetVertexColor(ACCENT[1], ACCENT[2], ACCENT[3], 0.18)
  if p.flare.SetGradient and CreateColor then pcall(p.flare.SetGradient, p.flare, "VERTICAL", CreateColor(ACCENT[1], ACCENT[2], ACCENT[3], 0), CreateColor(ACCENT[1], ACCENT[2], ACCENT[3], 0.4)) end
  p.flare:SetBlendMode("ADD")
  p.flare:SetAlpha(0)
  local fa = p.flare:CreateAnimationGroup()
  local a1 = fa:CreateAnimation("Alpha"); a1:SetFromAlpha(0); a1:SetToAlpha(1); a1:SetDuration(0.12); a1:SetOrder(1)
  local a2 = fa:CreateAnimation("Alpha"); a2:SetFromAlpha(1); a2:SetToAlpha(0); a2:SetDuration(1.2); a2:SetOrder(2)
  p.flareAnim = fa

  -- header
  -- the StoryCaster logo (logo.tga in the addon folder), with a soft violet glow behind it
  local glow = p:CreateTexture(nil, "ARTWORK", nil, 1)
  glow:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
  glow:SetBlendMode("ADD")
  glow:SetVertexColor(ACCENT[1], ACCENT[2], ACCENT[3], 0.55)
  glow:SetSize(84, 84)
  glow:SetPoint("CENTER", p, "TOPLEFT", PAD + 22, -HEAD / 2)
  local logo = p:CreateTexture(nil, "ARTWORK", nil, 2)
  logo:SetSize(46, 46)
  logo:SetPoint("CENTER", p, "TOPLEFT", PAD + 22, -HEAD / 2)
  logo:SetTexture("Interface\\AddOns\\StoryCaster\\logo")
  p.logo = logo
  local head = Text(p, 15, 0.92, 0.84, 1, "OUTLINE")
  head:SetPoint("LEFT", p, "TOPLEFT", PAD + 54, -HEAD / 2)
  head:SetText("StoryCaster")
  p.sub = Text(p, 10, 0.75, 0.72, 0.85)
  p.sub:SetPoint("RIGHT", p, "TOPRIGHT", -64, -HEAD / 2)
  p.sub:SetJustifyH("RIGHT")
  local close = Btn(p, "x", 20, 20, function() R.db.showBar = false; R:Refresh(); R:Print("Panel hidden. /story brings it back.") end)
  close:SetPoint("RIGHT", p, "TOPRIGHT", -10, -HEAD / 2)
  Tip(close, "Hide the panel", "/story brings it back. A script that is playing keeps going.")
  p.compactBtn = Btn(p, "-", 20, 20, function() R.db.compact = not R.db.compact; R:Refresh() end)
  p.compactBtn:SetPoint("RIGHT", close, "LEFT", -6, 0)
  Tip(p.compactBtn, "Compact mode", "Fold the panel down to its header and play controls, or open it again.")

  -- the script: its name, progress, the line coming next and the countdown
  local body = Section(p, 112)
  p.body = body
  p.title = Text(body, 13, 1, 0.85, 0.4)
  p.title:SetPoint("TOPLEFT", PAD, -14)
  p.title:SetWidth(PW - PAD * 2)
  if p.title.SetWordWrap then p.title:SetWordWrap(false) end
  p.progress = Bar(body, PW - PAD * 2, 5, 1, 0.82, 0.35)
  p.progress:SetPoint("TOPLEFT", PAD, -38)
  p.preview = Text(body, 11, 0.86, 0.84, 0.95)
  p.preview:SetPoint("TOPLEFT", PAD, -52)
  p.preview:SetWidth(PW - PAD * 2)
  p.preview:SetHeight(40)
  p.preview:SetJustifyV("TOP")
  if p.preview.SetSpacing then p.preview:SetSpacing(4) end
  if p.preview.SetWordWrap then p.preview:SetWordWrap(true) end
  p.countdown = Bar(body, PW - PAD * 2, 4, ACCENT[1], ACCENT[2], ACCENT[3])
  p.countdown:SetPoint("TOPLEFT", PAD, -102)

  -- controls: playing
  local row1 = Section(p, 42)
  p.row1 = row1
  p.play = Btn(row1, "Play", 64, 26, function() R:TogglePlay() end, "go")
  p.play:SetPoint("TOPLEFT", PAD, -8)
  Tip(p.play, "Play / Pause", "Perform the chosen script, or pause it.")
  p.deliver = Btn(row1, "Deliver", 74, 26, function() R:Deliver() end)
  p.deliver:SetPoint("LEFT", p.play, "RIGHT", 8, 0)
  Tip(p.deliver, "Deliver", "Post the next line right now. /say and /yell lines wait for this button (or your Deliver key): the game only allows them from a key press. Bind it under Key Bindings > AddOns > StoryCaster.")
  local nx = Btn(row1, "Next", 54, 26, function() R:Skip() end)
  nx:SetPoint("LEFT", p.deliver, "RIGHT", 8, 0)
  Tip(nx, "Next", "Skip ahead to the next line now.")
  local st = Btn(row1, "Stop", 54, 26, function() R:Stop() end, "stop")
  st:SetPoint("LEFT", nx, "RIGHT", 8, 0)
  p.pick = Btn(row1, "Scripts", 80, 26, function() R:ToggleMenu("scripts") end)
  p.pick:SetPoint("LEFT", st, "RIGHT", 18, 0)
  Tip(p.pick, "Your scripts", "Choose a script. Right-click one in the list to start it at once.")
  p.scenes = Btn(row1, "Scenes", 74, 26, function() R:ToggleMenu("scenes") end)
  p.scenes:SetPoint("LEFT", p.pick, "RIGHT", 8, 0)
  Tip(p.scenes, "Scenes", "Jump to a scene. A line like  ## Act Two  starts a scene in your script.")

  -- controls: writing
  local row2 = Section(p, 38)
  p.row2 = row2
  local wr = Btn(row2, "Write a Script", 118, 24, function() R:ToggleWriter(true) end, "primary")
  wr:SetPoint("TOPLEFT", PAD, -4)
  Tip(wr, "Write a Script", "Paste or type your roleplay. It becomes lines automatically. A script a friend shared is pasted here too.")
  local ed = Btn(row2, "Edit Lines", 92, 24, function() R:ToggleLines(true) end)
  ed:SetPoint("LEFT", wr, "RIGHT", 8, 0)
  Tip(ed, "Edit Lines", "Every line of the chosen script as a row: start from it, test it, move it up or down, or delete it.")
  local sh = Btn(row2, "Share", 70, 24, function() R:Share(R.db.last) end)
  sh:SetPoint("LEFT", ed, "RIGHT", 8, 0)
  Tip(sh, "Share", "Copy the chosen script as text for a friend or Discord. They paste it into Write a Script.")
  p.ambient = Btn(row2, "Ambient", 76, 24, function()
    if R.run and R.run.opts and R.run.opts.ambient then R:Stop() else R:Start("Ambient: Idle") end
  end)
  p.ambient:SetPoint("LEFT", sh, "RIGHT", 8, 0)
  Tip(p.ambient, "Ambient", "A quiet loop of small idle actions in random order, every 25 to 70 seconds. Edit the 'Ambient: Idle' script to make it yours.")

  -- timing
  local timer = Section(p, 92)
  p.timer = timer
  p.sliderLabel = Text(timer, 10, 0.85, 0.82, 0.95)
  p.sliderLabel:SetPoint("TOPLEFT", PAD, -10)
  -- while the panel is being built the slider's own events must not touch your timer
  -- (setting its range fires a change to the lowest value, which used to reset the timer to the minimum)
  self.building = true
  local sl = CreateFrame("Slider", nil, timer)
  sl:SetOrientation("HORIZONTAL")
  sl:SetSize(PW - PAD * 2, 14)
  sl:SetPoint("TOPLEFT", PAD, -28)
  sl:SetMinMaxValues(R.MIN_GAP, 60)
  sl:SetValueStep(1)
  if sl.SetObeyStepOnDrag then sl:SetObeyStepOnDrag(true) end
  local track = sl:CreateTexture(nil, "BACKGROUND")
  track:SetPoint("LEFT"); track:SetPoint("RIGHT"); track:SetHeight(4)
  track:SetColorTexture(1, 1, 1, 0.15)
  local thumb = sl:CreateTexture(nil, "OVERLAY")
  thumb:SetColorTexture(ACCENT[1], ACCENT[2], ACCENT[3], 1)
  thumb:SetSize(10, 16)
  sl:SetThumbTexture(thumb)
  sl:EnableMouseWheel(true)
  sl:SetScript("OnMouseWheel", function(s, d) s:SetValue(s:GetValue() + d) end)
  sl:SetScript("OnValueChanged", function(_, v)
    if R.building then return end
    R:SetInterval(v)
  end)
  Tip(sl, "Timer", "Seconds between lines, " .. R.MIN_GAP .. " to 60. The mouse wheel moves it one second at a time. StoryCaster never posts lines faster than one every " .. R.MIN_GAP .. " seconds on its own, so chat never sees spam.")
  p.slider = sl
  local toggles = {
    { "Random", "dice", "Every gap becomes a random 10 to 30 seconds. /story dice 12 25 changes the range." },
    { "Auto pace", "autoPace", "Longer lines get more time: about one second for every 15 characters, plus a moment to breathe." },
    { "Manual", "manual", "No timer: every line waits for Deliver (or your Deliver key), like a teleprompter." },
    { "Loop", "loop", "Start the script again when it ends." },
    { "Shuffle", "shuffle", "Perform the lines in a random order (never in duets)." },
    { "Test", "testMode", "Lines print only to you, so you can rehearse." },
  }
  p.toggles = {}
  local tw, tg = 72, 6
  for i, t in ipairs(toggles) do
    local b = Btn(timer, t[1], tw, 22, function()
      if t[2] == "dice" then R:SetDice(not R.db.dice) else R.db[t[2]] = not R.db[t[2]]; R:Refresh() end
    end)
    b:SetPoint("TOPLEFT", PAD + (i - 1) * (tw + tg), -54)
    b.field = t[2]
    Tip(b, t[1], t[3])
    p.toggles[i] = b
  end

  -- animated emote buttons
  local emo = Section(p, 128)
  p.emotes = emo
  local div = emo:CreateTexture(nil, "ARTWORK")
  div:SetPoint("TOPLEFT", PAD, -2); div:SetPoint("TOPRIGHT", -PAD, -2); div:SetHeight(1)
  div:SetColorTexture(1, 1, 1, 0.08)
  local lbl = Text(emo, 10, 0.85, 0.78, 1)
  lbl:SetPoint("TOPLEFT", PAD, -14)
  lbl:SetText("ANIMATED EMOTES")
  p.animToggle = Btn(emo, "Animations in scripts", 140, 18, function() R.db.animations = not R.db.animations; R:Refresh() end)
  p.animToggle:SetPoint("TOPRIGHT", -PAD, -11)
  Tip(p.animToggle, "Animations in scripts", "Play the animation tagged on each line ([bow]) while a script runs. The buttons below always work.")
  local cols, bw, bh, gap = 6, 74, 24, 6
  local x0 = (PW - (cols * bw + (cols - 1) * gap)) / 2
  for i = 1, 18 do
    local a = R.ANIMS[i]
    local b = Btn(emo, a[2], bw, bh, function() R:Animate(a[1], true); R:Pulse(a[1]) end, "emote")
    local col, row = (i - 1) % cols, math.floor((i - 1) / cols)
    b:SetPoint("TOPLEFT", x0 + col * (bw + gap), -34 - row * (bh + gap))
    Tip(b, a[2], "Play the /" .. a[1]:lower() .. " animation. In a script, write [" .. a[1]:lower() .. "] on a line, or /" .. a[1]:lower() .. " on its own line.")
  end

  p:SetScript("OnUpdate", function(f, el)
    f.acc = (f.acc or 0) + el
    if f.acc < 0.1 then return end
    f.acc = 0
    if R.state == "running" and R.nextAt and R.nextDur and R.run then
      local remain = math.max(0, R.nextAt - GetTime())
      f.countdown:SetValue(remain / R.nextDur)
      f.sub:SetText(("%d / %d   |cffc9b4ffnext in %ds|r"):format(R.run.i, #R.run.lines, math.ceil(remain)))
    end
  end)
  self.bar = p
  self.building = false
  self:SyncSlider()
end

-- stack the sections under the header; compact mode keeps only the play controls
function R:LayoutBar()
  local p = self.bar
  local y = -HEAD
  local compact = self.db.compact
  local order = compact and { p.row1 } or { p.body, p.row1, p.row2, p.timer, p.emotes }
  for _, s in ipairs({ p.body, p.row1, p.row2, p.timer, p.emotes }) do s:Hide() end
  for _, s in ipairs(order) do
    s:ClearAllPoints()
    s:SetPoint("TOPLEFT", p, "TOPLEFT", 0, y)
    s:SetPoint("TOPRIGHT", p, "TOPRIGHT", 0, y)
    s:Show()
    y = y - s:GetHeight()
  end
  p:SetHeight(-y + 8)
  p.compactBtn.text:SetText(compact and "+" or "-")
end

function R:SyncSlider()
  if not self.bar then return end
  self.building = true
  self.bar.slider:SetValue(self.db.interval)
  self.building = false
end

function R:Pulse()
  local p = self.bar
  if p and p:IsShown() then p.flareAnim:Stop(); p.flareAnim:Play() end
end

function R:UpdateBar()
  if not self.db then return end
  if not self.db.showBar then if self.bar then self.bar:Hide() end return end
  if not self.bar then self:BuildBar() end
  local p = self.bar
  p:Show()
  self:LayoutBar()
  local run, f = self.run, self.following
  local name = run and run.name or self.db.last
  local script = self:Get(name)
  if f then
    p.title:SetText("Duet: " .. f.name .. "  |cff888888with " .. f.from .. "|r")
    p.sub:SetText(self.pending and "|cffffd27fyour line: press Deliver|r" or ("|cff7fd8ff" .. f.mine .. " lines are yours|r"))
    p.preview:SetText(self.pending and ("|cffb48cffReady:|r " .. self:LineLabel(self.pending)) or "|cffb48cffWaiting for your cue.|r")
    p.progress:SetValue(0); p.countdown:SetValue(0)
  elseif run then
    p.title:SetText(name .. (self.scene and "  |cff7fd8ff(duet)|r" or ""))
    p.progress:SetValue(run.i / #run.lines)
    if self.state == "paused" then p.sub:SetText(("%d / %d   |cffffaa00paused|r"):format(run.i, #run.lines))
    elseif self.state == "waiting" then p.sub:SetText(("%d / %d   |cffff5555holding|r"):format(run.i, #run.lines))
    elseif self.state == "key" then p.sub:SetText(("%d / %d   |cffffd27fpress Deliver|r"):format(run.i, #run.lines)) end
    local nxt = run.lines[run.i + 1]
    p.preview:SetText(nxt and ("|cffb48cffNext:|r " .. self:LineLabel(nxt)) or "|cffb48cffLast line performed.|r")
    if self.state ~= "running" then p.countdown:SetValue(0) end
  else
    p.title:SetText(name or "No script yet: press Write a Script")
    p.progress:SetValue(0)
    p.countdown:SetValue(0)
    p.sub:SetText(script and ("%d lines   |cff999999ready|r"):format(#script) or "")
    p.preview:SetText(script and script[1] and ("|cffb48cffFirst:|r " .. self:LineLabel(script[1])) or "|cff999999Write a script, or choose one from Scripts.|r")
  end
  p.play.text:SetText((self.state == "running" or self.state == "waiting") and "Pause" or "Play")
  p.deliver:Kind((self.state == "key" or self.pending) and "key" or nil)
  local scenes = self:Scenes(script)
  p.scenes:SetAlpha(#scenes > 0 and 1 or 0.45)
  p.ambient:Kind(run and run.opts and run.opts.ambient and "on" or nil)
  local dice = self.db.dice
  p.sliderLabel:SetText((dice or self.db.autoPace or self.db.manual) and ("|cff777777Timer: " .. self.db.interval .. "s (" .. (self.db.manual and "Manual" or dice and "Random" or "Auto pace") .. " is on)|r")
    or ("Timer: |cffffffff" .. self.db.interval .. "s|r between lines"))
  p.slider:SetAlpha((dice or self.db.autoPace or self.db.manual) and 0.4 or 1)
  for _, b in ipairs(p.toggles) do
    b:Kind(self.db[b.field] and "on" or nil)
    if b.field == "dice" then b.text:SetText(dice and (self.db.diceMin .. "-" .. self.db.diceMax .. "s") or "Random") end
  end
  p.animToggle:Kind(self.db.animations and "on" or nil)
  if self.menu and self.menu:IsShown() then self:RefreshMenu() end
  if self.lines and self.lines:IsShown() then self:RefreshLines() end
end

---------------------------------------------------------------------------
-- The script and scene menus
---------------------------------------------------------------------------
local ROWS = 10
function R:ToggleMenu(kind)
  if not self.menu then
    local m = CreateFrame("Frame", "StoryCasterMenu", self.bar)
    m:SetSize(270, ROWS * 24 + 38)
    m:SetFrameStrata("DIALOG")
    m:EnableMouse(true)
    m:EnableMouseWheel(true)
    Glass(m, 0.98)
    m.head = Text(m, 10, 0.85, 0.78, 1)
    m.head:SetPoint("TOPLEFT", 12, -10)
    m.offset = 0
    m.rows = {}
    for i = 1, ROWS do
      local b = Btn(m, "", 250, 22, nil)
      b:SetPoint("TOPLEFT", 10, -28 - (i - 1) * 24)
      b.text:ClearAllPoints(); b.text:SetPoint("LEFT", 8, 0); b.text:SetJustifyH("LEFT")
      b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
      b:SetScript("OnClick", function(self, button)
        if m.kind == "scenes" then
          if self.index then R:JumpTo(self.index) end
        elseif self.name then
          R.db.last = self.name
          if button == "RightButton" then R:Start(self.name) end
        end
        m:Hide(); R:Refresh()
      end)
      m.rows[i] = b
    end
    m:SetScript("OnMouseWheel", function(_, d)
      m.offset = math.max(0, math.min(math.max(0, (m.count or 0) - ROWS), m.offset - d))
      R:RefreshMenu()
    end)
    m:Hide()
    self.menu = m
  end
  local m = self.menu
  if m:IsShown() and m.kind == kind then m:Hide() return end
  m.kind, m.offset = kind, 0
  m:ClearAllPoints()
  m:SetPoint("TOPLEFT", kind == "scenes" and self.bar.scenes or self.bar.pick, "BOTTOMLEFT", 0, -4)
  m:Show()
  self:RefreshMenu()
end

function R:RefreshMenu()
  local m = self.menu
  local items = {}
  if m.kind == "scenes" then
    local script = self:Get(self.run and self.run.name or self.db.last)
    for i, s in ipairs(self:Scenes(script)) do items[i] = { label = i .. ". " .. s[2], index = s[1] } end
    m.head:SetText(#items == 0 and "No scenes. Add a line like  ## Act Two" or "Jump to a scene")
  else
    for i, n in ipairs(self.db.order) do
      items[i] = { label = (n == self.db.last and "|cffffd100" or "") .. n .. "|r  |cff888888" .. #self.db.scripts[n] .. "|r", name = n }
    end
    m.head:SetText(#items == 0 and "No scripts yet" or ("Your scripts (" .. #items .. ")  ·  right-click to start"))
  end
  m.count = #items
  for i, b in ipairs(m.rows) do
    local it = items[i + m.offset]
    b.name, b.index = it and it.name, it and it.index
    if it then b:Show(); b.text:SetText(it.label); b:Kind(it.name and it.name == self.db.last and "emote" or nil) else b:Hide() end
  end
end

---------------------------------------------------------------------------
-- The line editor
---------------------------------------------------------------------------
local LROWS = 12
function R:ToggleLines(show, name)
  if name and self:Get(name) then self.db.last = name end
  if not self.lines then self:BuildLines() end
  if show == true or not self.lines:IsShown() then self.lines.offset = 0; self.lines:Show(); self:RefreshLines() else self.lines:Hide() end
end

function R:BuildLines()
  local f = CreateFrame("Frame", "StoryCasterLines", UIParent)
  f:SetSize(600, LROWS * 28 + 92)
  f:SetPoint("CENTER", 0, 20)
  f:SetFrameStrata("DIALOG")
  f:SetToplevel(true)
  f:SetClampedToScreen(true)
  f:EnableMouse(true)
  f:EnableMouseWheel(true)
  f:SetMovable(true)
  f:RegisterForDrag("LeftButton")
  f:SetScript("OnDragStart", f.StartMoving)
  f:SetScript("OnDragStop", f.StopMovingOrSizing)
  tinsert(UISpecialFrames, "StoryCasterLines")
  Glass(f, 0.97, 40)
  f.head = Text(f, 13, 0.88, 0.80, 1, "OUTLINE")
  f.head:SetPoint("LEFT", f, "TOPLEFT", 16, -20)
  local close = Btn(f, "x", 20, 20, function() f:Hide() end)
  close:SetPoint("RIGHT", f, "TOPRIGHT", -10, -20)
  f.help = Text(f, 10, 0.75, 0.72, 0.85)
  f.help:SetPoint("BOTTOMLEFT", 16, 14)
  f.help:SetWidth(568)
  f.help:SetText("Start begins the script at that line. Test prints it to you only. Up and down move it; x deletes it. Write a Script edits the words.")
  f.rows = {}
  local function script() return R:Get(R.db.last) end
  for i = 1, LROWS do
    local row = CreateFrame("Frame", nil, f)
    row:SetSize(568, 24)
    row:SetPoint("TOPLEFT", 16, -52 - (i - 1) * 28)
    local bg = row:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(1, 1, 1, i % 2 == 0 and 0.04 or 0.02)
    row.num = Text(row, 10, 0.6, 0.58, 0.7)
    row.num:SetPoint("LEFT", 4, 0)
    row.num:SetWidth(26)
    row.text = Text(row, 10, 0.9, 0.88, 0.96)
    row.text:SetPoint("LEFT", 32, 0)
    row.text:SetWidth(360)
    if row.text.SetWordWrap then row.text:SetWordWrap(false) end
    local function act(fn) return function() local s = script(); local n = row.index; if s and n and s[n] then fn(s, n) end end end
    local bStart = Btn(row, "Start", 46, 20, act(function(_, n) f:Hide(); R:Start(R.db.last, n) end), "primary")
    bStart:SetPoint("RIGHT", -128, 0)
    local bTest = Btn(row, "Test", 40, 20, act(function(s, n)
      local was = R.db.testMode; R.db.testMode = true; R:Perform(s[n]); R.db.testMode = was
    end))
    bTest:SetPoint("LEFT", bStart, "RIGHT", 4, 0)
    local bUp = Btn(row, "^", 22, 20, act(function(s, n) if n > 1 then s[n], s[n - 1] = s[n - 1], s[n]; R:Refresh() end end))
    bUp:SetPoint("LEFT", bTest, "RIGHT", 4, 0)
    local bDown = Btn(row, "v", 22, 20, act(function(s, n) if n < #s then s[n], s[n + 1] = s[n + 1], s[n]; R:Refresh() end end))
    bDown:SetPoint("LEFT", bUp, "RIGHT", 4, 0)
    local bDel = Btn(row, "x", 22, 20, act(function(s, n)
      if R.run and R.run.name == R.db.last then R:Print("Stop the script before deleting lines.") return end
      if #s == 1 then R:Print("A script needs at least one line. Delete the whole script with /story delete.") return end
      table.remove(s, n); R:Refresh()
    end))
    bDel:SetPoint("LEFT", bDown, "RIGHT", 4, 0)
    Tip(bDel, "Delete this line")
    f.rows[i] = row
  end
  f:SetScript("OnMouseWheel", function(_, d)
    local s = R:Get(R.db.last)
    f.offset = math.max(0, math.min(math.max(0, (s and #s or 0) - LROWS), f.offset - d * 3))
    R:RefreshLines()
  end)
  f.offset = 0
  f:Hide()
  self.lines = f
end

function R:RefreshLines()
  local f = self.lines
  local s = self:Get(self.db.last)
  f.head:SetText(s and ("Edit Lines: " .. self.db.last .. "  |cff888888" .. #s .. " lines, scroll for more|r") or "Edit Lines: choose a script first")
  for i, row in ipairs(f.rows) do
    local n = i + f.offset
    local l = s and s[n]
    row.index = l and n
    if l then
      row:Show()
      row.num:SetText(n .. ".")
      row.text:SetText((l[6] and ("|cffffd100## " .. l[6] .. "|r  ") or "") .. self:LineLabel(l))
    else row:Hide() end
  end
end

---------------------------------------------------------------------------
-- Sharing
---------------------------------------------------------------------------
function R:Share(name)
  local s = self:Get(name)
  if not s then self:Print("Choose a script to share first.") return end
  if not self.share then
    local f = CreateFrame("Frame", "StoryCasterShare", UIParent)
    f:SetSize(520, 360)
    f:SetPoint("CENTER", 0, 30)
    f:SetFrameStrata("DIALOG")
    f:SetToplevel(true)
    f:EnableMouse(true)
    f:SetMovable(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", f.StartMoving)
    f:SetScript("OnDragStop", f.StopMovingOrSizing)
    tinsert(UISpecialFrames, "StoryCasterShare")
    Glass(f, 0.97, 40)
    f.head = Text(f, 13, 0.88, 0.80, 1, "OUTLINE")
    f.head:SetPoint("LEFT", f, "TOPLEFT", 16, -20)
    local close = Btn(f, "x", 20, 20, function() f:Hide() end)
    close:SetPoint("RIGHT", f, "TOPRIGHT", -10, -20)
    local help = Text(f, 10, 0.80, 0.78, 0.88)
    help:SetPoint("TOPLEFT", 16, -52)
    help:SetWidth(488)
    if help.SetSpacing then help:SetSpacing(3) end
    help:SetText("It is already selected: press Ctrl+C to copy, then paste it to a friend, into Discord or a document. " ..
      "To use a shared script: open Write a Script, paste it, name it and press Save.")
    local box = CreateFrame("Frame", nil, f)
    box:SetPoint("TOPLEFT", 16, -88)
    box:SetPoint("BOTTOMRIGHT", -16, 16)
    local bbg = box:CreateTexture(nil, "BACKGROUND")
    bbg:SetAllPoints()
    bbg:SetColorTexture(0.01, 0.01, 0.03, 0.9)
    Edge(box, 0.36, 0.30, 0.50, 1)
    local scroll = CreateFrame("ScrollFrame", "StoryCasterShareScroll", box, "UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", 6, -6)
    scroll:SetPoint("BOTTOMRIGHT", -26, 6)
    local edit = CreateFrame("EditBox", nil, scroll)
    edit:SetMultiLine(true)
    edit:SetAutoFocus(false)
    edit:SetFontObject(ChatFontNormal)
    edit:SetWidth(452)
    edit:SetScript("OnEscapePressed", function() f:Hide() end)
    edit:SetScript("OnTextChanged", function(b, user) if user then b:SetText(f.textValue or ""); b:HighlightText() end end)
    scroll:SetScrollChild(edit)
    f.edit = edit
    self.share = f
  end
  local f = self.share
  f.head:SetText("Share: " .. name)
  f.textValue = "-- StoryCaster script: " .. name .. "\n" .. self:ScriptToText(s)
  f:Show()
  f.edit:SetText(f.textValue)
  f.edit:SetFocus()
  f.edit:HighlightText()
end

---------------------------------------------------------------------------
-- The writing window
---------------------------------------------------------------------------
local WW, WH = 540, 520
local MODES = {
  { "sentences", "One per sentence", "Each sentence becomes its own line." },
  { "lines", "One per line", "Each line you typed becomes one line." },
  { "fill", "Fill each emote", "Sentences are packed together up to the chat limit, a paragraph at a time." },
}

function R:ToggleWriter(show)
  if not self.writer then self:BuildWriter() end
  local w = self.writer
  if show == true or not w:IsShown() then w:Show(); self:RefreshWriter() else w:Hide() end
end

function R:BuildWriter()
  local f = CreateFrame("Frame", "StoryCasterWriter", UIParent)
  f:SetSize(WW, WH)
  f:SetPoint("CENTER", 0, 30)
  f:SetFrameStrata("DIALOG")
  f:SetToplevel(true)
  f:SetClampedToScreen(true)
  f:EnableMouse(true)
  f:SetMovable(true)
  f:RegisterForDrag("LeftButton")
  f:SetScript("OnDragStart", f.StartMoving)
  f:SetScript("OnDragStop", f.StopMovingOrSizing)
  tinsert(UISpecialFrames, "StoryCasterWriter")
  Glass(f, 0.97, 40)

  local head = Text(f, 14, 0.88, 0.80, 1, "OUTLINE")
  head:SetPoint("LEFT", f, "TOPLEFT", 16, -20)
  head:SetText("Write a Script")
  local close = Btn(f, "x", 20, 20, function() f:Hide() end)
  close:SetPoint("RIGHT", f, "TOPRIGHT", -10, -20)
  local help = Text(f, 10, 0.80, 0.78, 0.88)
  help:SetPoint("TOPLEFT", 16, -52)
  help:SetWidth(WW - 32)
  if help.SetWordWrap then help:SetWordWrap(true) end
  if help.SetSpacing then help:SetSpacing(3) end
  help:SetText("Paste or type your roleplay (Ctrl+V), written after your name the way emotes read: \"walks to the door.\" " ..
    "[bow] plays an animation. /pause 4 waits. /s, /y, /p, /ra or /g lines are said in that chat. [Name] at the start gives a line to a duet partner. " ..
    "## Act Two starts a scene. {target} {name} {zone} {time} fill themselves in, and {smiles|grins} picks one.")

  local nl = Text(f, 10, 0.85, 0.82, 0.95)
  nl:SetPoint("TOPLEFT", 16, -122)
  nl:SetText("Script name")
  local name = CreateFrame("EditBox", nil, f, "InputBoxTemplate")
  name:SetSize(270, 20)
  name:SetPoint("LEFT", nl, "RIGHT", 12, 0)
  name:SetAutoFocus(false)
  name:SetMaxLetters(48)
  name:SetScript("OnEscapePressed", function(b) b:ClearFocus() end)
  name:SetScript("OnEnterPressed", function(b) b:ClearFocus() end)
  name:SetScript("OnTabPressed", function() f.edit:SetFocus() end)
  f.name = name

  f.modeBtns = {}
  for i, m in ipairs(MODES) do
    local b = Btn(f, m[2], 124, 22, function() R.db.mode = m[1]; R:RefreshWriter() end)
    b:SetPoint("TOPLEFT", 16 + (i - 1) * 130, -148)
    b.mode = m[1]
    Tip(b, m[2], m[3])
    f.modeBtns[i] = b
  end
  f.auto = Btn(f, "Auto animate", 104, 22, function() R.db.autoAnim = not R.db.autoAnim; R:RefreshWriter() end)
  f.auto:SetPoint("TOPRIGHT", -16, -148)
  Tip(f.auto, "Auto animate", "Lines that say bows, waves, laughs, nods, kneels, cries, cheers and so on play that animation, even without a [tag].")

  local box = CreateFrame("Frame", nil, f)
  box:SetPoint("TOPLEFT", 16, -182)
  box:SetPoint("BOTTOMRIGHT", -16, 118)
  local bbg = box:CreateTexture(nil, "BACKGROUND")
  bbg:SetAllPoints()
  bbg:SetColorTexture(0.01, 0.01, 0.03, 0.9)
  Edge(box, 0.36, 0.30, 0.50, 1)
  local scroll = CreateFrame("ScrollFrame", "StoryCasterWriterScroll", box, "UIPanelScrollFrameTemplate")
  scroll:SetPoint("TOPLEFT", 6, -6)
  scroll:SetPoint("BOTTOMRIGHT", -26, 6)
  local edit = CreateFrame("EditBox", nil, scroll)
  edit:SetMultiLine(true)
  edit:SetAutoFocus(false)
  edit:SetFontObject(ChatFontNormal)
  edit:SetWidth(WW - 74)
  edit:SetMaxLetters(0)
  edit:SetTextInsets(4, 4, 4, 4)
  edit:SetScript("OnEscapePressed", function(b) b:ClearFocus() end)
  edit:SetScript("OnTextChanged", function(b)
    if ScrollingEdit_OnTextChanged then ScrollingEdit_OnTextChanged(b, scroll) end
    -- a pasted shared script names itself
    local shared = (b:GetText() or ""):match("^%-%- StoryCaster script: ([^\r\n]+)")
    if shared and (f.name:GetText() or "") == "" then f.name:SetText(shared) end
    R:RefreshWriter()
  end)
  if ScrollingEdit_OnCursorChanged then edit:SetScript("OnCursorChanged", ScrollingEdit_OnCursorChanged) end
  if ScrollingEdit_OnUpdate then edit:SetScript("OnUpdate", function(b, el) ScrollingEdit_OnUpdate(b, el, scroll) end) end
  scroll:SetScrollChild(edit)
  box:EnableMouse(true)
  box:SetScript("OnMouseDown", function() edit:SetFocus() end)
  f.edit = edit

  f.status = Text(f, 10, 0.86, 0.84, 0.95)
  f.status:SetPoint("BOTTOMLEFT", 16, 78)
  f.status:SetWidth(WW - 32)
  f.status:SetHeight(32)
  f.status:SetJustifyV("TOP")
  if f.status.SetWordWrap then f.status:SetWordWrap(true) end
  if f.status.SetSpacing then f.status:SetSpacing(3) end

  local function text() return (f.edit:GetText() or ""):gsub("^%-%- StoryCaster script: [^\r\n]*\r?\n", "") end
  local function convert() return R:Convert(text(), R.db.mode, R.db.autoAnim) end
  local function save()
    local ok, msg = R:Save(f.name:GetText(), (convert()))
    R:Print(msg)
    if ok then R:Refresh() end
    return ok
  end
  local saveB = Btn(f, "Save", 70, 26, function() save() end, "primary")
  saveB:SetPoint("BOTTOMLEFT", 16, 42)
  local goB = Btn(f, "Save and Perform", 132, 26, function() if save() then f:Hide(); R:Start(R.db.last) end end, "primary")
  goB:SetPoint("LEFT", saveB, "RIGHT", 8, 0)
  local prevB = Btn(f, "Preview in Chat", 118, 26, function()
    local script = convert()
    if #script == 0 then R:Print("Nothing to preview yet.") return end
    for i, l in ipairs(script) do R:Print(("%d. %s%s"):format(i, l[6] and ("|cffffd100## " .. l[6] .. "|r  ") or "", R:LineLabel(l))) end
  end)
  prevB:SetPoint("LEFT", goB, "RIGHT", 8, 0)
  Tip(prevB, "Preview", "Shows every line in your own chat window only.")
  local clr = Btn(f, "Clear", 62, 26, function() f.edit:SetText(""); f.name:SetText("") end)
  clr:SetPoint("BOTTOMRIGHT", -16, 42)

  local loadB = Btn(f, "Load", 62, 22, function()
    local n = f.name:GetText():gsub("^%s+", ""):gsub("%s+$", "")
    if not R:Get(n) then n = R.db.last; f.name:SetText(n or "") end
    local s = R:Get(n)
    if not s then R:Print("Type the name of a saved script to load it.") return end
    f.edit:SetText(R:ScriptToText(s))
    R.db.mode = "lines"
    R:RefreshWriter()
    R:Print("Loaded '" .. n .. "' for editing (one line per line).")
  end)
  loadB:SetPoint("BOTTOMLEFT", 16, 12)
  Tip(loadB, "Load", "Load the script named above (or the one chosen on the panel) to edit it.")
  local delB = Btn(f, "Delete", 62, 22, function()
    local n = f.name:GetText():gsub("^%s+", ""):gsub("%s+$", "")
    if R:Delete(n) then R:Print("Deleted '" .. n .. "'."); R:Refresh() else R:Print("No script called '" .. n .. "'.") end
    R:RefreshWriter()
  end)
  delB:SetPoint("LEFT", loadB, "RIGHT", 8, 0)
  f.saved = Text(f, 10, 0.7, 0.68, 0.8)
  f.saved:SetPoint("LEFT", delB, "RIGHT", 12, 0)
  f:Hide()
  self.writer = f
end

function R:RefreshWriter()
  local f = self.writer
  if not f then return end
  for _, b in ipairs(f.modeBtns) do b:Kind(self.db.mode == b.mode and "on" or nil) end
  f.auto:Kind(self.db.autoAnim and "on" or nil)
  local raw = (f.edit:GetText() or ""):gsub("^%-%- StoryCaster script: [^\r\n]*\r?\n", "")
  local script, split, skipped = self:Convert(raw, self.db.mode, self.db.autoAnim)
  local anims, chat, pauses = 0, 0, 0
  for _, l in ipairs(script) do
    if l[2] then anims = anims + 1 end
    if l[4] then chat = chat + 1 end
    if l[3] then pauses = pauses + 1 end
  end
  local cast = self:CastOf(script)
  local msg = ("|cff55ff55%d line%s|r  |cffc9b4ff%d animated|r  |cffffd27f%d chat|r  |cff888888%d pauses|r"):format(#script, #script == 1 and "" or "s", anims, chat, pauses)
  if #cast > 0 then msg = msg .. "  |cff7fd8ffduet with " .. table.concat(cast, ", ") .. "|r" end
  if split > 0 then msg = msg .. ("  |cffffcc00%d split to fit|r"):format(split) end
  if skipped > 0 then msg = msg .. ("  |cff999999%d skipped|r"):format(skipped) end
  if script[1] then msg = msg .. "\n|cffb48cffFirst:|r " .. self:LineLabel(script[1]) end
  f.status:SetText(msg)
  f.saved:SetText(#self.db.order .. " saved script" .. (#self.db.order == 1 and "" or "s"))
end
