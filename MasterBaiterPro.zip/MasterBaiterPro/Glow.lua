-- The glow: soft light around the windows, a spark that runs the border, bubbles rising through the water,
-- twinkling stars, sheens sweeping across buttons and coins bursting out of every catch.
-- Shared by Master Baiter Pro and Master Bait Forever. "/mbp glow off" (or /mbf) keeps only the still glow.
local MBP = MasterBaiterPro or MasterBaitForever
if not MBP then return end

local WHITE = "Interface\\Buttons\\WHITE8X8"
local STAR = "Interface\\Cooldown\\star4"
local BURST = "Interface\\Cooldown\\starburst"
local COIN = "Interface\\MoneyFrame\\UI-GoldIcon"
local ROUND = "Interface\\CharacterFrame\\TempPortraitAlphaMask"

local G = {}
MBP.Glow = G

local function On() return not (MBP.db and MBP.db.glow == false) end
G.On = On

local function Round(tex, owner)
	if not owner.CreateMaskTexture then return end
	local m = owner:CreateMaskTexture()
	m:SetAllPoints(tex)
	m:SetTexture(ROUND, "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
	tex:AddMaskTexture(m)
end

local function Rotate(tex, rad) if tex.SetRotation then tex:SetRotation(rad) end end

-- One driver runs every moving effect, and only while its window is on screen.
local fx = {}
local driver = CreateFrame("Frame")
driver:SetScript("OnUpdate", function(_, el)
	if el > 0.1 then el = 0.1 end
	for i = 1, #fx do
		local e = fx[i]
		if e.owner:IsVisible() then e:Update(el) end
	end
end)
local function Add(e) fx[#fx + 1] = e; return e end

-- Aura: rings of light just outside a frame's edge, fading outward. Breathes, flashes, changes colour.
function G.Aura(frame, rings, r, g, b, strength)
	local a = { owner = frame, rings = {}, r = r, g = g, b = b, base = strength or 0.5, cur = strength or 0.5,
		target = strength or 0.5, flash = 0, t = math.random() * 6, breathe = 0.18, speed = 1.6 }
	rings = rings or 7
	for i = 1, rings do
		local k = (1 - (i - 1) / rings) ^ 2.2
		local ring = {}
		for side = 1, 4 do
			local t = frame:CreateTexture(nil, "BACKGROUND", nil, -7)
			t:SetTexture(WHITE)
			t:SetBlendMode("ADD")
			if side == 1 then t:SetPoint("BOTTOMLEFT", frame, "TOPLEFT", -i, i - 1); t:SetPoint("BOTTOMRIGHT", frame, "TOPRIGHT", i, i - 1); t:SetHeight(1)
			elseif side == 2 then t:SetPoint("TOPLEFT", frame, "BOTTOMLEFT", -i, 1 - i); t:SetPoint("TOPRIGHT", frame, "BOTTOMRIGHT", i, 1 - i); t:SetHeight(1)
			elseif side == 3 then t:SetPoint("TOPRIGHT", frame, "TOPLEFT", 1 - i, i - 1); t:SetPoint("BOTTOMRIGHT", frame, "BOTTOMLEFT", 1 - i, 1 - i); t:SetWidth(1)
			else t:SetPoint("TOPLEFT", frame, "TOPRIGHT", i - 1, i - 1); t:SetPoint("BOTTOMLEFT", frame, "BOTTOMRIGHT", i - 1, 1 - i); t:SetWidth(1) end
			ring[side] = t
		end
		a.rings[i] = { tex = ring, k = k }
	end
	function a:Paint()
		local fr, fg, fb = self.r, self.g, self.b
		if self.flash > 0 then
			local f = self.flash
			fr = fr + (self.fr - fr) * f; fg = fg + (self.fg - fg) * f; fb = fb + (self.fb - fb) * f
		end
		local s = math.min(1, self.cur * (1 + (On() and math.sin(self.t * self.speed) * self.breathe or 0)) + self.flash * 0.6)
		for _, ring in ipairs(self.rings) do
			for _, t in ipairs(ring.tex) do t:SetVertexColor(fr, fg, fb, s * ring.k) end
		end
	end
	function a:SetColor(nr, ng, nb, strength, speed)
		self.r, self.g, self.b = nr, ng, nb
		if strength then self.target = strength end
		if speed then self.speed = speed end
		self:Paint()
	end
	function a:Flash(fr, fg, fb, power)
		self.fr, self.fg, self.fb = fr, fg, fb
		self.flash = math.max(self.flash, power or 1)
	end
	function a:Update(el)
		self.t = self.t + el
		self.cur = self.cur + (self.target - self.cur) * math.min(1, el * 3)
		if self.flash > 0 then self.flash = math.max(0, self.flash - el * 1.1) end
		self:Paint()
	end
	a:Paint()
	return Add(a)
end

-- Spark: a bright star with a comet tail that runs round and round the border.
function G.Spark(frame, r, g, b, speed, size)
	local s = { owner = frame, pos = math.random() * 400, speed = speed or 90, trail = {}, r = r, g = g, b = b }
	size = size or 26
	local layer = CreateFrame("Frame", nil, frame)
	layer:SetAllPoints()
	layer:SetFrameLevel(frame:GetFrameLevel() + 8)
	s.layer = layer
	s.star = layer:CreateTexture(nil, "OVERLAY", nil, 7)
	s.star:SetTexture(STAR)
	s.star:SetBlendMode("ADD")
	s.star:SetSize(size, size)
	for i = 1, 7 do
		local t = layer:CreateTexture(nil, "OVERLAY", nil, 6)
		t:SetTexture(WHITE)
		t:SetBlendMode("ADD")
		local d = 4 - i * 0.35
		t:SetSize(d, d)
		Round(t, layer)
		s.trail[i] = t
	end
	function s:SetColor(nr, ng, nb, nspeed) self.r, self.g, self.b = nr, ng, nb; if nspeed then self.speed = nspeed end end
	local function At(self, p)
		local w, h = self.owner:GetWidth(), self.owner:GetHeight()
		local per = 2 * (w + h)
		p = p % per
		if p < w then return p, 0 end
		p = p - w
		if p < h then return w, p end
		p = p - h
		if p < w then return w - p, h end
		return 0, h - (p - w)
	end
	function s:Update(el)
		local on = On()
		self.layer:SetShown(on)
		if not on then return end
		self.pos = self.pos + el * self.speed
		local x, y = At(self, self.pos)
		self.star:ClearAllPoints()
		self.star:SetPoint("CENTER", self.owner, "TOPLEFT", x, -y)
		self.star:SetVertexColor(self.r, self.g, self.b, 0.95)
		Rotate(self.star, self.pos * 0.04)
		for i, t in ipairs(self.trail) do
			local tx, ty = At(self, self.pos - i * 5)
			t:ClearAllPoints()
			t:SetPoint("CENTER", self.owner, "TOPLEFT", tx, -ty)
			t:SetVertexColor(self.r, self.g, self.b, 0.75 * (1 - i / 8))
		end
	end
	return Add(s)
end

-- Bubbles: little round lights drifting up from the bottom of the window, wobbling as they rise.
function G.Bubbles(frame, count, r, g, b, height)
	local bb = { owner = frame, list = {}, r = r, g = g, b = b, height = height or 120, rate = 1 }
	local layer = CreateFrame("Frame", nil, frame)
	layer:SetAllPoints()
	layer:SetFrameLevel(frame:GetFrameLevel() + 1)
	if layer.SetClipsChildren then layer:SetClipsChildren(true) end
	bb.layer = layer
	local function Reset(o, scatter)
		o.x = 8 + math.random() * (frame:GetWidth() - 16)
		o.y = scatter and math.random() * bb.height or -4
		o.v = 10 + math.random() * 18
		o.w = math.random() * 6.28
		o.size = 2 + math.random() * 4
		o.t:SetSize(o.size, o.size)
	end
	for i = 1, count or 10 do
		local t = layer:CreateTexture(nil, "BACKGROUND", nil, 2)
		t:SetTexture(WHITE)
		t:SetBlendMode("ADD")
		Round(t, layer)
		local o = { t = t }
		Reset(o, true)
		bb.list[i] = o
	end
	function bb:Update(el)
		local on = On()
		self.layer:SetShown(on)
		if not on then return end
		for _, o in ipairs(self.list) do
			o.y = o.y + o.v * el * self.rate
			o.w = o.w + el * 2.2
			if o.y > self.height then Reset(o) end
			local life = o.y / self.height
			local a = (life < 0.15 and life / 0.15 or 1) * (1 - life) * 0.55
			o.t:ClearAllPoints()
			o.t:SetPoint("CENTER", self.owner, "BOTTOMLEFT", o.x + math.sin(o.w) * 3, o.y)
			o.t:SetVertexColor(self.r, self.g, self.b, a)
		end
	end
	return Add(bb)
end

-- Twinkles: stars that blink on and off somewhere inside a box of the window.
function G.Twinkles(frame, count, x1, y1, x2, y2, r, g, b)
	local tw = { owner = frame, list = {} }
	local layer = CreateFrame("Frame", nil, frame)
	layer:SetAllPoints()
	layer:SetFrameLevel(frame:GetFrameLevel() + 6)
	tw.layer = layer
	local function Move(o)
		o.x = x1 + math.random() * (x2 - x1)
		o.y = y1 + math.random() * (y2 - y1)
		o.life = 0.9 + math.random() * 1.4
		o.age = -math.random() * 2.5
		o.size = 8 + math.random() * 12
		o.t:SetSize(o.size, o.size)
		o.t:ClearAllPoints()
		o.t:SetPoint("CENTER", frame, "TOPLEFT", o.x, -o.y)
	end
	for i = 1, count or 5 do
		local t = layer:CreateTexture(nil, "OVERLAY", nil, 5)
		t:SetTexture(STAR)
		t:SetBlendMode("ADD")
		t:SetVertexColor(r, g, b, 0)
		local o = { t = t }
		Move(o)
		tw.list[i] = o
	end
	function tw:Update(el)
		local on = On()
		self.layer:SetShown(on)
		if not on then return end
		for _, o in ipairs(self.list) do
			o.age = o.age + el
			if o.age > o.life then Move(o) end
			local p = o.age > 0 and (o.age / o.life) or 0
			local a = o.age > 0 and math.sin(p * math.pi) ^ 2 or 0
			o.t:SetAlpha(a * 0.9)
			Rotate(o.t, p * 2)
		end
	end
	return Add(tw)
end

-- Sheen: a band of light that sweeps across a frame now and then (buttons, badges, toasts).
function G.Sheen(frame, every, alpha, width)
	local clip = CreateFrame("Frame", nil, frame)
	clip:SetAllPoints()
	clip:SetFrameLevel(frame:GetFrameLevel() + 3)
	if clip.SetClipsChildren then clip:SetClipsChildren(true) end
	local inner = CreateFrame("Frame", nil, clip)
	inner:SetAllPoints()
	width = width or 34
	local left = inner:CreateTexture(nil, "OVERLAY", nil, 6)
	local right = inner:CreateTexture(nil, "OVERLAY", nil, 6)
	for _, t in ipairs({ left, right }) do t:SetTexture(WHITE); t:SetBlendMode("ADD") end
	left:SetSize(width / 2, 200); right:SetSize(width / 2, 200)
	left:SetPoint("CENTER", inner, "LEFT", -width, 0)
	right:SetPoint("LEFT", left, "RIGHT", 0, 0)
	local a = alpha or 0.35
	if left.SetGradient and CreateColor then
		pcall(left.SetGradient, left, "HORIZONTAL", CreateColor(1, 1, 1, 0), CreateColor(1, 1, 1, a))
		pcall(right.SetGradient, right, "HORIZONTAL", CreateColor(1, 1, 1, a), CreateColor(1, 1, 1, 0))
	else
		left:SetVertexColor(1, 1, 1, a / 2); right:SetVertexColor(1, 1, 1, a / 2)
	end
	Rotate(left, 0.35); Rotate(right, 0.35)
	local sh = { owner = frame, t = every and (math.random() * every) or 0, every = every, run = 0.7, inner = inner, width = width, playing = false }
	function sh:Play() self.playing, self.p = true, 0 end
	function sh:Update(el)
		if not On() and self.every then inner:Hide(); return end
		if self.every then
			self.t = self.t + el
			if self.t >= self.every then self.t = 0; self:Play() end
		end
		if not self.playing then inner:Hide(); return end
		inner:Show()
		self.p = self.p + el / self.run
		if self.p >= 1 then self.playing = false; inner:Hide(); return end
		local travel = self.owner:GetWidth() + self.width * 3
		left:ClearAllPoints()
		left:SetPoint("CENTER", inner, "LEFT", -self.width + travel * (self.p * self.p * (3 - 2 * self.p)), 0)
	end
	inner:Hide()
	return Add(sh)
end

-- Halo: a slowly turning starburst behind something precious (the haul number). Pulses on demand.
function G.Halo(frame, anchor, size, r, g, b, alpha)
	local h = { owner = frame, rot = 0, base = alpha or 0.22, pulse = 0 }
	h.t = frame:CreateTexture(nil, "BACKGROUND", nil, 1)
	h.t:SetTexture(BURST)
	h.t:SetBlendMode("ADD")
	h.t:SetSize(size, size)
	h.t:SetPoint("CENTER", anchor, "CENTER")
	h.t:SetVertexColor(r, g, b)
	h.t2 = frame:CreateTexture(nil, "BACKGROUND", nil, 1)
	h.t2:SetTexture(STAR)
	h.t2:SetBlendMode("ADD")
	h.t2:SetSize(size * 0.8, size * 0.8)
	h.t2:SetPoint("CENTER", anchor, "CENTER")
	h.t2:SetVertexColor(r, g, b)
	function h:Pulse(power) self.pulse = math.max(self.pulse, power or 1) end
	function h:SetColor(nr, ng, nb) self.t:SetVertexColor(nr, ng, nb); self.t2:SetVertexColor(nr, ng, nb) end
	function h:Update(el)
		local on = On()
		if on then self.rot = self.rot + el * 0.25 end
		if self.pulse > 0 then self.pulse = math.max(0, self.pulse - el * 1.4) end
		Rotate(self.t, self.rot)
		Rotate(self.t2, -self.rot * 1.6)
		local a = self.base * (on and (0.8 + math.sin(self.rot * 6) * 0.2) or 0.8) + self.pulse * 0.7
		self.t:SetAlpha(math.min(1, a))
		self.t2:SetAlpha(math.min(1, a * 0.6))
		local sc = 1 + self.pulse * 0.35
		self.t:SetScale(sc); self.t2:SetScale(sc)
	end
	return Add(h)
end

-- Burst: coins and sparks thrown out of a point, then falling and fading. Happens on catches and jackpots.
function G.Burst(frame)
	local bu = { owner = frame, parts = {}, next = 1 }
	local layer = CreateFrame("Frame", nil, frame)
	layer:SetAllPoints()
	layer:SetFrameLevel(frame:GetFrameLevel() + 12)
	for i = 1, 24 do
		local t = layer:CreateTexture(nil, "OVERLAY", nil, 7)
		t:Hide()
		bu.parts[i] = { t = t, life = 0 }
	end
	-- x, y from the frame's top left; n pieces; coins: true for gold coins mixed in
	function bu:Fire(x, y, n, r, g, b, coins, power)
		power = power or 1
		for _ = 1, n or 10 do
			local p = self.parts[self.next]
			self.next = self.next % #self.parts + 1
			local coin = coins and math.random() < 0.5
			p.t:SetTexture(coin and COIN or STAR)
			p.t:SetBlendMode(coin and "BLEND" or "ADD")
			p.t:SetVertexColor(coin and 1 or r, coin and 1 or g, coin and 1 or b, 1)
			p.size = coin and (9 + math.random() * 5) or (10 + math.random() * 14)
			p.t:SetSize(p.size, p.size)
			local ang = math.random() * math.pi * 2
			local sp = (50 + math.random() * 90) * power
			p.x, p.y = x, y
			p.vx, p.vy = math.cos(ang) * sp, math.abs(math.sin(ang)) * sp * 1.2 + 40 * power
			p.age, p.life, p.spin = 0, 0.7 + math.random() * 0.6, (math.random() - 0.5) * 8
			p.t:Show()
		end
	end
	function bu:Update(el)
		for _, p in ipairs(self.parts) do
			if p.t:IsShown() then
				p.age = p.age + el
				if p.age >= p.life then p.t:Hide()
				else
					p.vy = p.vy - 260 * el
					p.x, p.y = p.x + p.vx * el, p.y - p.vy * el
					p.t:ClearAllPoints()
					p.t:SetPoint("CENTER", self.owner, "TOPLEFT", p.x, -p.y)
					local k = 1 - p.age / p.life
					p.t:SetAlpha(k)
					Rotate(p.t, p.age * p.spin)
				end
			end
		end
	end
	return Add(bu)
end

-- Text glow: a soft coloured shadow straight under the letters
function G.TextGlow(fs, r, g, b, a)
	if fs.SetShadowColor then fs:SetShadowColor(r, g, b, a or 0.8); fs:SetShadowOffset(0, 0) end
end

-- Hover glow for buttons: a tight aura that lights up while the mouse is over it
function G.Hover(button, r, g, b)
	local a = G.Aura(button, 4, r, g, b, 0)
	a.breathe = 0.25
	button:HookScript("OnEnter", function() a.target = 0.75 end)
	button:HookScript("OnLeave", function() a.target = 0 end)
	button:HookScript("OnMouseDown", function() a:Flash(1, 1, 1, 0.8) end)
	return a
end
