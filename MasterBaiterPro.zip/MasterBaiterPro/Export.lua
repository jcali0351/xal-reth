-- Master Baiter Pro: the export.
-- /mbp export opens a window with your records and the leaderboard your game has heard, as one line of text
-- to copy (Ctrl+C) and hand to whoever keeps your guild's or community's fishing leaderboard website.
-- The same text is saved in WTF\Account\<ACCOUNT>\SavedVariables\MasterBaiterPro.lua on /reload or logout.
local MBP = MasterBaiterPro

local function jstr(s)
	s = tostring(s or "")
	s = s:gsub("\\", "\\\\"):gsub('"', '\\"'):gsub("\n", "\\n"):gsub("\r", ""):gsub("\t", " ")
	s = s:gsub("[%z\1-\31]", "")
	return '"' .. s .. '"'
end

local encode
local function isArray(t)
	local n = 0
	for k in pairs(t) do if type(k) ~= "number" then return false end n = n + 1 end
	return n == #t
end
encode = function(v)
	local tv = type(v)
	if tv == "nil" then return "null"
	elseif tv == "boolean" then return v and "true" or "false"
	elseif tv == "number" then
		if v ~= v or v == math.huge or v == -math.huge then return "0" end
		if math.floor(v) == v then return string.format("%.0f", v) end
		return string.format("%.2f", v)
	elseif tv == "string" then return jstr(v)
	elseif tv == "table" then
		local out = {}
		if next(v) == nil then return "[]" end
		if isArray(v) then
			for i = 1, #v do out[#out + 1] = encode(v[i]) end
			return "[" .. table.concat(out, ",") .. "]"
		end
		local keys = {}
		for k in pairs(v) do keys[#keys + 1] = tostring(k) end
		table.sort(keys)
		for _, k in ipairs(keys) do out[#out + 1] = jstr(k) .. ":" .. encode(v[k]) end
		return "{" .. table.concat(out, ",") .. "}"
	end
	return "null"
end

local REGIONS = { [1] = "us", [2] = "kr", [3] = "eu", [4] = "tw", [5] = "cn" }

local function Me()
	local name = UnitName("player") or "?"
	local realm = (GetNormalizedRealmName and GetNormalizedRealmName()) or ""
	return realm ~= "" and (name .. "-" .. realm) or name, realm
end

function MBP.BuildExport()
	local db = MBP.db
	if not db then return nil end
	local full, realm = Me()
	local r, t = db.records, db.totals
	local top = {}
	for _, row in ipairs((MBP.TopCatches("all", 10))) do
		top[#top + 1] = { id = row.id, n = row.n, q = row.q or 1, unit = math.floor(row.unit or 0) }
	end
	local notable = {}
	for i, e in ipairs(db.notable or {}) do
		if i > 40 then break end
		notable[#notable + 1] = { t = e.t, id = e.id, q = e.q or 1, v = math.floor(e.v or 0), n = e.n or 1 }
	end
	local board = {}
	for name, e in pairs(db.board or {}) do
		if name ~= full then
			board[#board + 1] = { name = name, c = e.c or 0, w = e.w or 0, wid = e.wid or 0, b = e.b or 0,
				bv = math.floor(e.bv or 0), g = math.floor(e.g or 0), t = math.floor(e.t or 0), seen = e.seen or 0 }
		end
	end
	table.sort(board, function(a, b) return a.c > b.c end)
	local data = {
		format = "master-baiter-pro",
		version = MBP.VERSION,
		exportedAt = time(),
		region = REGIONS[GetCurrentRegion and GetCurrentRegion() or 1] or "us",
		realm = realm,
		me = {
			name = full,
			catches = t.catches or 0, casts = t.casts or 0, misses = t.misses or 0,
			copper = math.floor(t.copper or 0), seconds = math.floor(t.seconds or 0), sessions = t.sessions or 0,
			week = db.week.catches or 0, wid = db.week.id or 0,
			best = MBP.ItemID(r.bestLink) or 0, bestValue = math.floor(r.bestValue or 0), bestQuality = r.bestQuality or -1,
			gph = math.floor(r.gph or 0), session = r.session or 0, streak = r.streak or 0,
			zones = MBP.Count(db.zones or {}), ach = MBP.Count(db.ach or {}),
			top = top, notable = notable,
		},
		board = board,
	}
	db.export = encode(data)
	db.exportedAt = data.exportedAt
	return db.export
end

local win
function MBP.ShowExport()
	local text = MBP.BuildExport()
	if not text then return end
	if not win then
		win = CreateFrame("Frame", "MasterBaiterProExport", UIParent, "BackdropTemplate")
		win:SetSize(560, 360); win:SetPoint("CENTER"); win:SetFrameStrata("DIALOG")
		win:SetMovable(true); win:EnableMouse(true); win:RegisterForDrag("LeftButton")
		win:SetScript("OnDragStart", win.StartMoving); win:SetScript("OnDragStop", win.StopMovingOrSizing)
		win:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 })
		win:SetBackdropColor(0.03, 0.06, 0.09, 0.97); win:SetBackdropBorderColor(0.31, 0.85, 1, 0.8)
		local title = win:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
		title:SetPoint("TOP", 0, -12); title:SetText("|cffffd24aMaster Baiter|r |cff4fd8ffPro|r export")
		local hint = win:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
		hint:SetPoint("TOP", title, "BOTTOM", 0, -6); hint:SetWidth(520)
		hint:SetText("Press Ctrl+C to copy your records and the leaderboard, then paste them wherever your leaderboard website asks.")
		win.when = win:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
		win.when:SetPoint("TOP", hint, "BOTTOM", 0, -4)
		local sf = CreateFrame("ScrollFrame", nil, win, "UIPanelScrollFrameTemplate")
		sf:SetPoint("TOPLEFT", 14, -70); sf:SetPoint("BOTTOMRIGHT", -34, 44)
		local eb = CreateFrame("EditBox", nil, sf)
		eb:SetMultiLine(true); eb:SetAutoFocus(false); eb:SetFontObject(ChatFontSmall); eb:SetWidth(500); eb:SetMaxLetters(0)
		eb:SetScript("OnEscapePressed", function() win:Hide() end)
		eb:SetScript("OnTextChanged", function(self, user) if user then self:SetText(win.text or ""); self:HighlightText() end end)
		eb:SetScript("OnEditFocusGained", function(self) self:HighlightText() end)
		sf:SetScrollChild(eb); win.eb = eb
		local close = CreateFrame("Button", nil, win, "UIPanelButtonTemplate")
		close:SetSize(110, 24); close:SetPoint("BOTTOMRIGHT", -12, 12); close:SetText(CLOSE or "Close")
		close:SetScript("OnClick", function() win:Hide() end)
		local again = CreateFrame("Button", nil, win, "UIPanelButtonTemplate")
		again:SetSize(130, 24); again:SetPoint("BOTTOMLEFT", 12, 12); again:SetText("Select all")
		again:SetScript("OnClick", function() win.eb:SetFocus(); win.eb:HighlightText() end)
		tinsert(UISpecialFrames, "MasterBaiterProExport")
	end
	win.text = text
	win.eb:SetText(text)
	local n = 0
	for _ in pairs(MBP.db.board or {}) do n = n + 1 end
	win.when:SetText(date("Exported %Y-%m-%d %H:%M", MBP.db.exportedAt or time()) .. "  ·  you and " .. n .. " other angler" .. (n == 1 and "" or "s"))
	win:Show(); win.eb:SetFocus(); win.eb:HighlightText()
end

-- Keep the saved copy fresh for anyone who uploads the SavedVariables file instead of copying.
local ev = CreateFrame("Frame")
ev:RegisterEvent("PLAYER_LOGOUT")
ev:SetScript("OnEvent", function() pcall(MBP.BuildExport) end)
