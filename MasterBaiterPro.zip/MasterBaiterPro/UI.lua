-- Master Baiter Pro: the panel, catch toasts and the session summary.
-- Deep-water navy glass, a gold haul counter, and your five best catches with their auction prices.
local MBP = MasterBaiterPro
local S = MBP.S

local HEAD_FONT = "Fonts\\FRIZQT__.TTF"
local BODY_FONT = STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF"
local WHITE = "Interface\\Buttons\\WHITE8X8"

local C = {
	gold = { 1.00, 0.82, 0.29 }, goldDeep = { 0.85, 0.55, 0.10 },
	aqua = { 0.31, 0.85, 1.00 }, teal = { 0.10, 0.55, 0.70 },
	ink = { 0.03, 0.07, 0.12 }, panelTop = { 0.07, 0.19, 0.29 }, panelBot = { 0.02, 0.05, 0.09 },
	line = { 0.20, 0.42, 0.55 }, muted = { 0.55, 0.68, 0.78 }, text = { 0.92, 0.96, 1.00 },
	red = { 1.00, 0.36, 0.36 }, green = { 0.36, 1.00, 0.55 },
}

-- Helpers -------------------------------------------------------------------------------
local function Color(t, a) if CreateColor then return CreateColor(t[1], t[2], t[3], a or 1) end end

local function Grad(tex, orient, bottomOrLeft, topOrRight, a1, a2)
	tex:SetTexture(WHITE)
	local ok = false
	if tex.SetGradient and CreateColor then
		ok = pcall(tex.SetGradient, tex, orient, Color(bottomOrLeft, a1), Color(topOrRight, a2))
	end
	if not ok then tex:SetVertexColor(topOrRight[1], topOrRight[2], topOrRight[3], a2 or 1) end
end

local function Text(parent, size, col, font, flags, layer)
	local fs = parent:CreateFontString(nil, layer or "OVERLAY")
	fs:SetFont(font or BODY_FONT, size, flags or "")
	col = col or C.text
	fs:SetTextColor(col[1], col[2], col[3])
	fs:SetJustifyH("LEFT")
	if fs.SetWordWrap then fs:SetWordWrap(false) end
	return fs
end

local function Border(f, col, alpha)
	f.edges = f.edges or {}
	local function edge(p1, p2, w, h)
		local t = f:CreateTexture(nil, "BORDER")
		t:SetColorTexture(col[1], col[2], col[3], alpha or 1)
		t:SetPoint(p1); t:SetPoint(p2)
		if w then t:SetWidth(w) end
		if h then t:SetHeight(h) end
		f.edges[#f.edges + 1] = t
		return t
	end
	edge("TOPLEFT", "TOPRIGHT", nil, 1); edge("BOTTOMLEFT", "BOTTOMRIGHT", nil, 1)
	edge("TOPLEFT", "BOTTOMLEFT", 1, nil); edge("TOPRIGHT", "BOTTOMRIGHT", 1, nil)
end

local function SetBorderColor(f, r, g, b, a)
	for _, t in ipairs(f.edges or {}) do t:SetColorTexture(r, g, b, a or 1) end
end

local function ScaleAnim(ag, from, to, dur, order, smooth)
	local a = ag:CreateAnimation("Scale")
	if a.SetScaleFrom then a:SetScaleFrom(from, from); a:SetScaleTo(to, to)
	else a:SetFromScale(from, from); a:SetToScale(to, to) end
	a:SetDuration(dur); a:SetOrder(order or 1); a:SetSmoothing(smooth or "OUT")
	a:SetOrigin("CENTER", 0, 0)
	return a
end

local function AlphaAnim(ag, from, to, dur, order, delay)
	local a = ag:CreateAnimation("Alpha")
	a:SetFromAlpha(from); a:SetToAlpha(to)
	a:SetDuration(dur); a:SetOrder(order or 1)
	if delay then a:SetStartDelay(delay) end
	return a
end

local function MoveAnim(ag, x, y, dur, order, smooth)
	local a = ag:CreateAnimation("Translation")
	a:SetOffset(x, y); a:SetDuration(dur); a:SetOrder(order or 1)
	a:SetSmoothing(smooth or "OUT")
	return a
end

local function QualityColor(q)
	q = q or 1
	if C_Item and C_Item.GetItemQualityColor then
		local ok, r, g, b = pcall(C_Item.GetItemQualityColor, q)
		if ok and r then return r, g, b end
	end
	if GetItemQualityColor then
		local ok, r, g, b = pcall(GetItemQualityColor, q)
		if ok and r then return r, g, b end
	end
	local c = ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[q]
	if c then return c.r, c.g, c.b end
	return 1, 1, 1
end

-- Value tiers: grey for pocket change, white, gold, then blazing orange for the big ones
local function TierColor(copper)
	local g = (copper or 0) / 10000
	if g >= 1000 then return 1.0, 0.55, 0.15 end
	if g >= 100 then return C.gold[1], C.gold[2], C.gold[3] end
	if g >= 10 then return 0.95, 0.97, 1.0 end
	return 0.62, 0.68, 0.74
end

local function Button(parent, label, w, primary, onClick)
	local b = CreateFrame("Button", nil, parent)
	b:SetSize(w, 24)
	b.bg = b:CreateTexture(nil, "BACKGROUND")
	b.bg:SetAllPoints()
	b.hl = b:CreateTexture(nil, "ARTWORK")
	b.hl:SetAllPoints()
	b.hl:SetColorTexture(1, 1, 1, 0.08)
	b.hl:Hide()
	b.text = Text(b, 11, primary and { 0.10, 0.06, 0.0 } or C.text, HEAD_FONT)
	b.text:SetPoint("CENTER", 0, 0)
	b.text:SetJustifyH("CENTER")
	b.text:SetText(label)
	Border(b, primary and C.gold or C.line, primary and 0.9 or 0.8)
	function b:Style(isPrimary)
		if isPrimary then
			Grad(self.bg, "VERTICAL", C.goldDeep, C.gold, 1, 1)
			self.text:SetTextColor(0.12, 0.07, 0.0)
			SetBorderColor(self, 1, 0.9, 0.55, 0.9)
		else
			Grad(self.bg, "VERTICAL", { 0.04, 0.10, 0.16 }, { 0.08, 0.20, 0.30 }, 1, 1)
			self.text:SetTextColor(C.text[1], C.text[2], C.text[3])
			SetBorderColor(self, C.line[1], C.line[2], C.line[3], 0.8)
		end
	end
	b:Style(primary)
	local push = b:CreateAnimationGroup()
	ScaleAnim(push, 1, 0.94, 0.06, 1, "IN")
	ScaleAnim(push, 0.94, 1, 0.12, 2, "OUT")
	b:SetScript("OnEnter", function(self) self.hl:Show() end)
	b:SetScript("OnLeave", function(self) self.hl:Hide() end)
	b:SetScript("OnMouseDown", function() push:Stop(); push:Play() end)
	b:SetScript("OnClick", onClick)
	local GL = MBP.Glow
	if GL then
		b.aura = GL.Hover(b, primary and C.gold[1] or C.aqua[1], primary and C.gold[2] or C.aqua[2], primary and C.gold[3] or C.aqua[3])
		if primary then b.sheen = GL.Sheen(b, 3.5, 0.45, 30) end
	end
	return b
end

-- Shared with the leaderboard window
MBP.UI = { C = C, WHITE = WHITE, HEAD_FONT = HEAD_FONT, Text = Text, Grad = Grad, Border = Border,
	SetBorderColor = SetBorderColor, ScaleAnim = ScaleAnim, AlphaAnim = AlphaAnim, MoveAnim = MoveAnim,
	QualityColor = QualityColor, TierColor = TierColor, Button = Button }

-- Catch slots ---------------------------------------------------------------------------------
local function SlotTooltip(self)
	local r = self.row
	GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
	if not r then
		GameTooltip:AddLine("Empty slot", C.muted[1], C.muted[2], C.muted[3])
		GameTooltip:AddLine("Your most valuable catches show up here.", 1, 1, 1, true)
		GameTooltip:Show()
		return
	end
	local ok = r.link and pcall(GameTooltip.SetHyperlink, GameTooltip, r.link)
	if not ok then pcall(GameTooltip.SetItemByID, GameTooltip, r.id) end
	GameTooltip:AddLine(" ")
	GameTooltip:AddLine("|cffffd24aMaster Baiter|r |cff4fd8ffPro|r")
	GameTooltip:AddDoubleLine("Auction price (each)", MBP.Coins(r.unit), C.muted[1], C.muted[2], C.muted[3], 1, 1, 1)
	GameTooltip:AddDoubleLine(self.scope == "all" and "Caught all time" or "Caught this session", BreakUpLargeNumbers(r.n),
		C.muted[1], C.muted[2], C.muted[3], 1, 1, 1)
	GameTooltip:AddDoubleLine("Total value", MBP.Coins(r.value), C.muted[1], C.muted[2], C.muted[3], 1, 1, 1)
	if self.total and self.total > 0 then
		GameTooltip:AddDoubleLine("Share of haul", string.format("%d%%", math.floor(r.value / self.total * 100 + 0.5)),
			C.muted[1], C.muted[2], C.muted[3], 1, 1, 1)
	end
	GameTooltip:AddLine(MBP.SourceText(r.src, r.age), 0.55, 0.62, 0.70)
	if r.src == "Vendor" or r.src == "None" then
		GameTooltip:AddLine("Visit the auction house to get a live price.", 0.31, 0.85, 1.0, true)
	end
	GameTooltip:Show()
end

local function MakeSlot(parent, size)
	local s = CreateFrame("Button", nil, parent)
	s:SetSize(size, size)
	s.bg = s:CreateTexture(nil, "BACKGROUND")
	s.bg:SetAllPoints()
	s.bg:SetColorTexture(C.ink[1], C.ink[2], C.ink[3], 1)
	s.icon = s:CreateTexture(nil, "ARTWORK")
	s.icon:SetPoint("TOPLEFT", 2, -2)
	s.icon:SetPoint("BOTTOMRIGHT", -2, 2)
	s.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
	Border(s, C.line, 1)
	s.shine = s:CreateTexture(nil, "OVERLAY")
	s.shine:SetPoint("TOPLEFT", 2, -2)
	s.shine:SetPoint("TOPRIGHT", -2, -2)
	s.shine:SetHeight(size * 0.45)
	Grad(s.shine, "VERTICAL", { 1, 1, 1 }, { 1, 1, 1 }, 0, 0.12)
	s.glow = s:CreateTexture(nil, "OVERLAY", nil, 3)
	s.glow:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
	s.glow:SetBlendMode("ADD")
	s.glow:SetSize(size * 1.9, size * 1.9)
	s.glow:SetPoint("CENTER")
	s.glow:SetAlpha(0)
	s.count = Text(s, 11, { 1, 1, 1 }, HEAD_FONT, "OUTLINE")
	s.count:SetPoint("BOTTOMRIGHT", -3, 3)
	s.count:SetJustifyH("RIGHT")
	s.rank = Text(s, 9, C.gold, HEAD_FONT, "OUTLINE")
	s.rank:SetPoint("TOPLEFT", 3, -3)
	s.value = Text(parent, 10, C.text, HEAD_FONT)
	s.value:SetPoint("TOP", s, "BOTTOM", 0, -4)
	s.value:SetJustifyH("CENTER")
	s.barBg = parent:CreateTexture(nil, "ARTWORK")
	s.barBg:SetColorTexture(1, 1, 1, 0.06)
	s.barBg:SetSize(size, 3)
	s.barBg:SetPoint("TOP", s.value, "BOTTOM", 0, -3)
	s.bar = parent:CreateTexture(nil, "OVERLAY")
	s.bar:SetPoint("TOPLEFT", s.barBg, "TOPLEFT")
	s.bar:SetHeight(3)
	s.bar:SetWidth(1)
	Grad(s.bar, "HORIZONTAL", C.goldDeep, C.gold, 1, 1)
	s.barW, s.barTarget = 0, 0

	s.pop = s:CreateAnimationGroup()
	ScaleAnim(s.pop, 1, 1.28, 0.12, 1, "OUT")
	ScaleAnim(s.pop, 1.28, 1, 0.28, 2, "IN_OUT")
	s.flash = s.glow:CreateAnimationGroup()
	AlphaAnim(s.flash, 0, 1, 0.12, 1)
	AlphaAnim(s.flash, 1, 0, 0.9, 2)
	if MBP.Glow then s.aura = MBP.Glow.Aura(s, 5, 1, 1, 1, 0) end

	s:SetScript("OnEnter", SlotTooltip)
	s:SetScript("OnLeave", GameTooltip_Hide)
	s:SetScript("OnClick", function(self)
		if self.row and self.row.link and IsModifiedClick and IsModifiedClick("CHATLINK") then
			ChatEdit_InsertLink(self.row.link)
		end
	end)
	return s
end

local function FillSlot(s, row, rank, total, scope)
	s.row, s.total, s.scope = row, total, scope
	if not row then
		s.icon:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark")
		s.icon:SetDesaturated(true)
		s.icon:SetAlpha(0.18)
		SetBorderColor(s, C.line[1], C.line[2], C.line[3], 0.5)
		s.count:SetText("")
		s.rank:SetText("")
		s.value:SetText("|cff3a5466-|r")
		s.barTarget = 0
		if s.aura then s.aura.target = 0 end
		return
	end
	s.icon:SetTexture(row.icon or MBP.ItemIcon(row.id) or "Interface\\Icons\\INV_Misc_Fish_02")
	s.icon:SetDesaturated(false)
	s.icon:SetAlpha(1)
	local r, g, b = QualityColor(row.q)
	SetBorderColor(s, r, g, b, 1)
	s.glow:SetVertexColor(r, g, b)
	if s.aura then s.aura:SetColor(r, g, b, (row.q or 1) >= 2 and (0.25 + math.min(0.4, ((row.q or 1) - 2) * 0.15)) or 0.08) end
	s.count:SetText(row.n > 1 and BreakUpLargeNumbers(row.n) or "")
	s.rank:SetText(rank)
	local tr, tg, tb = TierColor(row.value)
	s.value:SetText(MBP.ShortGold(row.value) .. ((row.src == "Vendor" or row.src == "None") and "|cff6f8597*|r" or ""))
	s.value:SetTextColor(tr, tg, tb)
	s.barTarget = total > 0 and (row.value / total) or 0
end

local function AnimateBars(slots, el)
	for _, s in ipairs(slots) do
		s.barW = s.barW + (s.barTarget - s.barW) * math.min(1, el * 6)
		local w = math.max(1, s.barW * s.barBg:GetWidth())
		s.bar:SetWidth(w)
		s.bar:SetAlpha(s.barW > 0.005 and 1 or 0)
	end
end

-- The panel ------------------------------------------------------------------------------------
local panel, summary
local slots = {}
local hero = { shown = 0, target = 0 }

local function Divider(parent, y)
	local t = parent:CreateTexture(nil, "ARTWORK")
	t:SetPoint("TOPLEFT", 14, y)
	t:SetPoint("TOPRIGHT", parent, "TOP", 0, y)
	t:SetHeight(1)
	Grad(t, "HORIZONTAL", C.line, C.line, 0, 0.6)
	local t2 = parent:CreateTexture(nil, "ARTWORK")
	t2:SetPoint("TOPLEFT", parent, "TOP", 0, y)
	t2:SetPoint("TOPRIGHT", -14, y)
	t2:SetHeight(1)
	Grad(t2, "HORIZONTAL", C.line, C.line, 0.6, 0)
end

local function SmallCaps(parent, txt, size)
	local fs = Text(parent, size or 9, C.muted, HEAD_FONT)
	fs:SetText(txt)
	return fs
end

local function StatTile(parent, label, x, y, w)
	local f = CreateFrame("Frame", nil, parent)
	f:SetSize(w, 40)
	f:SetPoint("TOPLEFT", x, y)
	local bg = f:CreateTexture(nil, "BACKGROUND")
	bg:SetAllPoints()
	Grad(bg, "VERTICAL", { 0.02, 0.06, 0.10 }, { 0.06, 0.15, 0.22 }, 0.9, 0.9)
	Border(f, C.line, 0.45)
	f.value = Text(f, 14, { 1, 1, 1 }, HEAD_FONT)
	f.value:SetPoint("TOP", 0, -6)
	f.value:SetJustifyH("CENTER")
	f.label = SmallCaps(f, label, 8)
	f.label:SetPoint("BOTTOM", 0, 6)
	f.label:SetJustifyH("CENTER")
	return f
end

local function Tab(parent, label, onClick)
	local b = CreateFrame("Button", nil, parent)
	b:SetSize(56, 16)
	b.text = Text(b, 9, C.muted, HEAD_FONT)
	b.text:SetPoint("CENTER")
	b.text:SetText(label)
	b.under = b:CreateTexture(nil, "ARTWORK")
	b.under:SetPoint("BOTTOMLEFT", 6, 0)
	b.under:SetPoint("BOTTOMRIGHT", -6, 0)
	b.under:SetHeight(2)
	b.under:SetColorTexture(C.aqua[1], C.aqua[2], C.aqua[3], 1)
	function b:SetActive(on)
		self.under:SetShown(on)
		local c = on and C.aqua or C.muted
		self.text:SetTextColor(c[1], c[2], c[3])
	end
	b:SetScript("OnClick", onClick)
	return b
end

function MBP.BuildUI()
	if panel then return end
	local db = MBP.db
	local W, H = 312, 378
	panel = CreateFrame("Frame", "MasterBaiterProPanel", UIParent)
	panel:SetSize(W, H)
	panel:SetFrameStrata("MEDIUM")
	panel:SetClampedToScreen(true)
	panel:SetMovable(true)
	panel:EnableMouse(true)
	panel:RegisterForDrag("LeftButton")
	panel:SetScript("OnDragStart", panel.StartMoving)
	panel:SetScript("OnDragStop", function(self)
		self:StopMovingOrSizing()
		local p, _, rp, x, y = self:GetPoint()
		db.point = { p, rp, x, y }
	end)
	if db.point then panel:SetPoint(db.point[1], UIParent, db.point[2], db.point[3], db.point[4])
	else panel:SetPoint("RIGHT", UIParent, "RIGHT", -60, 40) end

	-- Glass body: drop shadow, gradient, faint wave bands, gold top rule
	local shadow = panel:CreateTexture(nil, "BACKGROUND", nil, -8)
	shadow:SetPoint("TOPLEFT", -6, 6)
	shadow:SetPoint("BOTTOMRIGHT", 6, -6)
	shadow:SetColorTexture(0, 0, 0, 0.35)
	local body = panel:CreateTexture(nil, "BACKGROUND", nil, -6)
	body:SetAllPoints()
	Grad(body, "VERTICAL", C.panelBot, C.panelTop, 0.96, 0.96)
	for i = 1, 3 do
		local wave = panel:CreateTexture(nil, "BACKGROUND", nil, -5)
		wave:SetPoint("BOTTOMLEFT", 1, 1 + (i - 1) * 22)
		wave:SetPoint("BOTTOMRIGHT", -1, 1 + (i - 1) * 22)
		wave:SetHeight(22)
		Grad(wave, "VERTICAL", C.teal, C.teal, 0.10 - i * 0.025, 0)
	end
	Border(panel, C.line, 0.9)
	local rule = panel:CreateTexture(nil, "ARTWORK")
	rule:SetPoint("TOPLEFT", 1, -1)
	rule:SetPoint("TOPRIGHT", -1, -1)
	rule:SetHeight(2)
	Grad(rule, "HORIZONTAL", C.goldDeep, C.gold, 1, 1)
	local GL = MBP.Glow
	if GL then
		-- light spilling down from the gold rule, an aura round the glass, a spark on the rim, bubbles below
		local spill = panel:CreateTexture(nil, "BACKGROUND", nil, -4)
		spill:SetPoint("TOPLEFT", 1, -3)
		spill:SetPoint("TOPRIGHT", -1, -3)
		spill:SetHeight(46)
		Grad(spill, "VERTICAL", C.gold, C.gold, 0, 0.10)
		spill:SetBlendMode("ADD")
		panel.aura = GL.Aura(panel, 9, C.aqua[1], C.aqua[2], C.aqua[3], 0.35)
		panel.spark = GL.Spark(panel, C.aqua[1], C.aqua[2], C.aqua[3], 70)
		panel.bubbles = GL.Bubbles(panel, 12, C.aqua[1], C.aqua[2], C.aqua[3], 150)
		panel.burst = GL.Burst(panel)
	end

	-- Header
	local badge = CreateFrame("Frame", nil, panel)
	badge:SetSize(40, 40)
	badge:SetPoint("TOPLEFT", 10, -10)
	local ring = badge:CreateTexture(nil, "ARTWORK", nil, 1)
	ring:SetAllPoints()
	ring:SetTexture(WHITE)
	ring:SetColorTexture(C.gold[1], C.gold[2], C.gold[3], 1)
	local icon = badge:CreateTexture(nil, "ARTWORK", nil, 2)
	icon:SetPoint("TOPLEFT", 2, -2)
	icon:SetPoint("BOTTOMRIGHT", -2, 2)
	-- the Master Baiter Pro logo (logo.tga in the addon folder); the fishing icon if it is missing
	if not icon:SetTexture("Interface\\AddOns\\MasterBaiterPro\\logo") then
		icon:SetTexture("Interface\\Icons\\Trade_Fishing")
		icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
	end
	if badge.CreateMaskTexture then
		local mask = badge:CreateMaskTexture()
		mask:SetAllPoints(ring)
		mask:SetTexture("Interface\\CharacterFrame\\TempPortraitAlphaMask", "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
		ring:AddMaskTexture(mask)
		local mask2 = badge:CreateMaskTexture()
		mask2:SetAllPoints(icon)
		mask2:SetTexture("Interface\\CharacterFrame\\TempPortraitAlphaMask", "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
		icon:AddMaskTexture(mask2)
	end
	local bob = badge:CreateAnimationGroup()
	bob:SetLooping("BOUNCE")
	MoveAnim(bob, 0, 2, 1.4, 1, "IN_OUT")
	bob:Play()

	local title = Text(panel, 16, C.gold, HEAD_FONT, "OUTLINE")
	title:SetPoint("TOPLEFT", badge, "TOPRIGHT", 10, -2)
	title:SetText("Master Baiter")
	local pro = CreateFrame("Frame", nil, panel)
	pro:SetSize(30, 14)
	pro:SetPoint("LEFT", title, "RIGHT", 6, 0)
	local proBg = pro:CreateTexture(nil, "BACKGROUND")
	proBg:SetAllPoints()
	Grad(proBg, "HORIZONTAL", C.teal, C.aqua, 1, 1)
	local proText = Text(pro, 9, { 0.02, 0.08, 0.12 }, HEAD_FONT)
	proText:SetPoint("CENTER", 0, 0)
	proText:SetText("PRO")
	local proShine = pro:CreateAnimationGroup()
	proShine:SetLooping("REPEAT")
	AlphaAnim(proShine, 1, 0.65, 1.2, 1)
	AlphaAnim(proShine, 0.65, 1, 1.2, 2)
	proShine:Play()
	if GL then
		GL.TextGlow(title, 1, 0.65, 0.15, 0.9)
		GL.Sheen(pro, 2.6, 0.7, 16)
		GL.Aura(pro, 4, C.aqua[1], C.aqua[2], C.aqua[3], 0.45).speed = 2.4
		local halo = GL.Halo(panel, badge, 70, C.gold[1], C.gold[2], C.gold[3], 0.18)
		panel.badgeHalo = halo
		GL.Twinkles(panel, 6, 10, 6, W - 40, 56, 1, 0.9, 0.6)
	end
	local sub = Text(panel, 10, C.muted)
	sub:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -3)
	sub:SetText("One key. Every fish priced.")

	local close = CreateFrame("Button", nil, panel)
	close:SetSize(20, 20)
	close:SetPoint("TOPRIGHT", -8, -8)
	close.t = Text(close, 13, C.muted, HEAD_FONT)
	close.t:SetPoint("CENTER", 0, 0)
	close.t:SetText("X")
	close:SetScript("OnEnter", function(self) self.t:SetTextColor(1, 1, 1) end)
	close:SetScript("OnLeave", function(self) self.t:SetTextColor(C.muted[1], C.muted[2], C.muted[3]) end)
	close:SetScript("OnClick", function() MBP.HidePanel() end)

	-- Status pill
	local dot = panel:CreateTexture(nil, "OVERLAY")
	dot:SetSize(8, 8)
	dot:SetPoint("TOPLEFT", 16, -62)
	dot:SetTexture(WHITE)
	if panel.CreateMaskTexture then
		local m = panel:CreateMaskTexture()
		m:SetAllPoints(dot)
		m:SetTexture("Interface\\CharacterFrame\\TempPortraitAlphaMask", "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
		dot:AddMaskTexture(m)
	end
	local pulse = dot:CreateAnimationGroup()
	pulse:SetLooping("BOUNCE")
	AlphaAnim(pulse, 1, 0.25, 0.7, 1)
	pulse:Play()
	panel.dot = dot
	panel.status = Text(panel, 11, C.text)
	panel.status:SetPoint("LEFT", dot, "RIGHT", 8, 0)
	panel.status:SetWidth(W - 44)

	-- Cast timer: a bar of water with a light running across it
	local bar = CreateFrame("StatusBar", nil, panel)
	bar:SetSize(W - 28, 8)
	bar:SetPoint("TOPLEFT", 14, -78)
	bar:SetStatusBarTexture(WHITE)
	local fill = bar:GetStatusBarTexture()
	Grad(fill, "HORIZONTAL", C.teal, C.aqua, 1, 1)
	bar:SetMinMaxValues(0, 1)
	bar:SetValue(0)
	if bar.SetClipsChildren then bar:SetClipsChildren(true) end
	local barBg = bar:CreateTexture(nil, "BACKGROUND")
	barBg:SetAllPoints()
	barBg:SetColorTexture(1, 1, 1, 0.06)
	local sheen = bar:CreateTexture(nil, "OVERLAY")
	sheen:SetSize(46, 8)
	sheen:SetPoint("LEFT", bar, "LEFT", -46, 0)
	Grad(sheen, "HORIZONTAL", { 1, 1, 1 }, { 1, 1, 1 }, 0, 0.45)
	sheen:SetBlendMode("ADD")
	local run = sheen:CreateAnimationGroup()
	run:SetLooping("REPEAT")
	MoveAnim(run, W, 0, 1.6, 1, "IN_OUT")
	run:Play()
	panel.sheen = sheen
	panel.bar = bar
	if GL then
		local holder = CreateFrame("Frame", nil, panel)
		holder:SetAllPoints(bar)
		panel.barAura = GL.Aura(holder, 5, C.aqua[1], C.aqua[2], C.aqua[3], 0)
	end
	panel.barLabel = Text(panel, 9, C.muted, HEAD_FONT)
	panel.barLabel:SetPoint("BOTTOMRIGHT", bar, "TOPRIGHT", 0, 3)
	panel.barLabel:SetJustifyH("RIGHT")

	Divider(panel, -96)

	-- The haul: a big rolling gold number
	panel.haulLabel = SmallCaps(panel, "SESSION HAUL", 9)
	panel.haulLabel:SetPoint("TOPLEFT", 16, -106)
	local heroFrame = CreateFrame("Frame", nil, panel)
	heroFrame:SetSize(190, 30)
	heroFrame:SetPoint("TOPLEFT", 14, -118)
	local coin = heroFrame:CreateTexture(nil, "ARTWORK")
	coin:SetSize(20, 20)
	coin:SetPoint("LEFT", 0, 0)
	coin:SetTexture("Interface\\MoneyFrame\\UI-GoldIcon")
	panel.hero = Text(heroFrame, 26, C.gold, HEAD_FONT, "OUTLINE")
	panel.hero:SetPoint("LEFT", coin, "RIGHT", 6, 0)
	if GL then
		GL.TextGlow(panel.hero, 1, 0.6, 0.1, 1)
		panel.heroHalo = GL.Halo(panel, coin, 110, C.gold[1], C.gold[2], C.gold[3], 0.16)
	end
	panel.heroPop = heroFrame:CreateAnimationGroup()
	ScaleAnim(panel.heroPop, 1, 1.12, 0.1, 1, "OUT")
	ScaleAnim(panel.heroPop, 1.12, 1, 0.3, 2, "IN_OUT")
	panel.heroFrame = heroFrame

	panel.gphLabel = SmallCaps(panel, "PER HOUR", 9)
	panel.gphLabel:SetPoint("TOPRIGHT", -16, -106)
	panel.gphLabel:SetJustifyH("RIGHT")
	panel.gph = Text(panel, 15, C.text, HEAD_FONT)
	panel.gph:SetPoint("TOPRIGHT", -16, -122)
	panel.gph:SetJustifyH("RIGHT")

	-- Pace meter: this hour against your best hour ever
	local pace = CreateFrame("StatusBar", nil, panel)
	pace:SetSize(W - 32, 4)
	pace:SetPoint("TOPLEFT", 16, -156)
	pace:SetStatusBarTexture(WHITE)
	Grad(pace:GetStatusBarTexture(), "HORIZONTAL", C.goldDeep, C.gold, 1, 1)
	pace:SetMinMaxValues(0, 1)
	local paceBg = pace:CreateTexture(nil, "BACKGROUND")
	paceBg:SetAllPoints()
	paceBg:SetColorTexture(1, 1, 1, 0.07)
	panel.pace, panel.paceShown = pace, 0
	panel.paceText = Text(panel, 9, C.muted)
	panel.paceText:SetPoint("TOPLEFT", pace, "BOTTOMLEFT", 0, -4)
	panel.paceText:SetWidth(W - 32)

	-- Stat tiles
	local tw, gap = 66, 6
	local x0 = (W - (tw * 4 + gap * 3)) / 2
	panel.tTime = StatTile(panel, "TIME", x0, -180, tw)
	panel.tCatch = StatTile(panel, "CATCHES", x0 + (tw + gap), -180, tw)
	panel.tLand = StatTile(panel, "LANDED", x0 + (tw + gap) * 2, -180, tw)
	panel.tStreak = StatTile(panel, "STREAK", x0 + (tw + gap) * 3, -180, tw)

	-- Top catches
	local topLabel = SmallCaps(panel, "TOP CATCHES", 9)
	topLabel:SetPoint("TOPLEFT", 16, -232)
	panel.tabAll = Tab(panel, "ALL TIME", function() db.topView = "all"; MBP.Refresh(true) end)
	panel.tabAll:SetPoint("TOPRIGHT", -10, -229)
	panel.tabSes = Tab(panel, "SESSION", function() db.topView = "session"; MBP.Refresh(true) end)
	panel.tabSes:SetPoint("RIGHT", panel.tabAll, "LEFT", 0, 0)

	local size, sgap = 46, 10
	local sx = (W - (size * 5 + sgap * 4)) / 2
	for i = 1, 5 do
		local s = MakeSlot(panel, size)
		s:SetPoint("TOPLEFT", sx + (i - 1) * (size + sgap), -250)
		slots[i] = s
	end
	panel.priceNote = Text(panel, 9, C.muted)
	panel.priceNote:SetPoint("TOP", 0, -326)
	panel.priceNote:SetJustifyH("CENTER")
	panel.priceNote:SetWidth(W - 24)

	-- Buttons
	panel.go = Button(panel, "Start fishing", 118, true, function() MBP.Toggle() end)
	panel.go:SetPoint("BOTTOMLEFT", 12, 12)
	local rec = Button(panel, "Records", 78, false, function() SlashCmdList.MASTERBAITERPRO("records") end)
	rec:SetPoint("LEFT", panel.go, "RIGHT", 6, 0)
	local lb = Button(panel, "Leaderboard", 78, false, function() if MBP.ToggleBoard then MBP.ToggleBoard() end end)
	lb:SetPoint("LEFT", rec, "RIGHT", 6, 0)

	-- Live count of anglers on the network; click to open the leaderboard
	local online = CreateFrame("Button", nil, panel)
	online:SetSize(84, 14)
	online:SetPoint("TOPRIGHT", -12, -36)
	online.dot = online:CreateTexture(nil, "OVERLAY")
	online.dot:SetSize(6, 6)
	online.dot:SetTexture(WHITE)
	online.dot:SetVertexColor(C.green[1], C.green[2], C.green[3])
	online.text = Text(online, 9, C.muted, HEAD_FONT)
	online.text:SetPoint("RIGHT", 0, 0)
	online.text:SetJustifyH("RIGHT")
	online.dot:SetPoint("RIGHT", online.text, "LEFT", -4, 0)
	local blink = online.dot:CreateAnimationGroup()
	blink:SetLooping("BOUNCE")
	AlphaAnim(blink, 1, 0.3, 0.9, 1)
	blink:Play()
	online:SetScript("OnClick", function() if MBP.ToggleBoard then MBP.ToggleBoard() end end)
	online:SetScript("OnEnter", function(self)
		self.text:SetTextColor(1, 1, 1)
		GameTooltip:SetOwner(self, "ANCHOR_BOTTOMLEFT")
		GameTooltip:AddLine("Anglers online")
		GameTooltip:AddLine("Players running Master Baiter Pro that your game can see right now. Click for the leaderboard.", 1, 1, 1, true)
		GameTooltip:Show()
	end)
	online:SetScript("OnLeave", function(self) self.text:SetTextColor(C.muted[1], C.muted[2], C.muted[3]); GameTooltip:Hide() end)
	panel.online = online

	-- Opening animation: rise and fade in
	panel.open = panel:CreateAnimationGroup()
	MoveAnim(panel.open, 0, -14, 0, 1)
	AlphaAnim(panel.open, 0, 0, 0, 1)
	MoveAnim(panel.open, 0, 14, 0.28, 2, "OUT")
	AlphaAnim(panel.open, 0, 1, 0.22, 2)

	panel:SetScript("OnUpdate", function(self, el)
		self.t = (self.t or 0) + el
		-- cast timer
		if S.fishing and S.castEnd > S.castStart then
			local now = GetTime()
			local frac = (now - S.castStart) / (S.castEnd - S.castStart)
			bar:SetValue(math.max(0, math.min(1, 1 - frac)))
			panel.barLabel:SetText(string.format("%.0fs", math.max(0, S.castEnd - now)))
			sheen:Show()
		else
			if bar:GetValue() > 0 then bar:SetValue(math.max(0, bar:GetValue() - el * 3)) end
			panel.barLabel:SetText("")
			sheen:SetShown(bar:GetValue() > 0)
		end
		-- rolling haul number
		if hero.shown ~= hero.target then
			local d = hero.target - hero.shown
			if math.abs(d) < 100 then hero.shown = hero.target else hero.shown = hero.shown + d * math.min(1, el * 5) end
			panel.hero:SetText(BreakUpLargeNumbers(math.floor(hero.shown / 10000)))
		end
		-- pace meter and catch bars ease into place
		local pv = panel.pace.target or 0
		panel.paceShown = panel.paceShown + (pv - panel.paceShown) * math.min(1, el * 4)
		panel.pace:SetValue(math.min(1, panel.paceShown))
		AnimateBars(slots, el)
		if self.t > 1 then self.t = 0; MBP.Refresh() end
	end)

	if db.panelShown then panel:Show() else panel:Hide() end
	MBP.Refresh(true)
end

local function SetDot(r, g, b) if panel then panel.dot:SetVertexColor(r, g, b) end end

function MBP.Refresh(force)
	if not panel or not panel:IsShown() then return end
	local db = MBP.db
	local key = "|cffffd24a" .. (db.key or "?") .. "|r"

	-- status
	if S.missAt and GetTime() - S.missAt < 2.5 then
		panel.status:SetText("|cffff5c5c" .. (S.missText or "It got away.") .. "|r")
		SetDot(C.red[1], C.red[2], C.red[3])
	elseif not S.active then
		panel.status:SetText("Not fishing. Press Start, or just cast Fishing.")
		SetDot(0.45, 0.52, 0.58)
	elseif S.paused then
		panel.status:SetText("|cffff5c5cPaused for combat.|r Your key is yours again.")
		SetDot(C.red[1], C.red[2], C.red[3])
	elseif S.fishing then
		panel.status:SetText("Line in the water. Press " .. key .. " on the splash!")
		SetDot(C.aqua[1], C.aqua[2], C.aqua[3])
	else
		panel.status:SetText("Ready. Press " .. key .. " to cast.")
		SetDot(C.green[1], C.green[2], C.green[3])
	end
	-- the glow follows the mood: dim when idle, green when ready, bright fast water while the line is out, red when paused
	if panel.aura then
		local A, sp = panel.aura, panel.spark
		if S.missAt and GetTime() - S.missAt < 2.5 then
			A:SetColor(C.red[1], C.red[2], C.red[3], 0.45, 2.2); sp:SetColor(C.red[1], C.red[2], C.red[3], 80)
		elseif not S.active then
			A:SetColor(C.line[1] + 0.1, C.line[2] + 0.2, C.line[3] + 0.3, 0.28, 1.2); sp:SetColor(C.aqua[1], C.aqua[2], C.aqua[3], 45)
		elseif S.paused then
			A:SetColor(C.red[1], C.red[2], C.red[3], 0.4, 1.6); sp:SetColor(C.red[1], C.red[2], C.red[3], 40)
		elseif S.fishing then
			A:SetColor(C.aqua[1], C.aqua[2], C.aqua[3], 0.65, 4.0); sp:SetColor(0.75, 0.97, 1, 170)
		else
			A:SetColor(C.green[1], C.green[2], C.green[3], 0.45, 2.0); sp:SetColor(C.green[1], C.green[2], C.green[3], 90)
		end
		panel.barAura.target = S.fishing and 0.7 or 0
		panel.bubbles.rate = S.fishing and 2.2 or S.active and 1.2 or 0.6
	end
	panel.go.text:SetText(S.active and "Stop" or "Start fishing")
	if MBP.OnlineCount then
		local n, connected = MBP.OnlineCount()
		if connected then
			panel.online.text:SetText(n .. " online")
			panel.online.dot:SetVertexColor(C.green[1], C.green[2], C.green[3])
		else
			panel.online.text:SetText(db.network and "connecting" or "offline")
			panel.online.dot:SetVertexColor(0.45, 0.52, 0.58)
		end
	end
	panel.go:Style(not S.active)

	-- haul
	local hasSession = S.active or next(S.loot) ~= nil
	local value
	if hasSession then
		value = MBP.SessionValue()
		panel.haulLabel:SetText(S.active and "SESSION HAUL" or "LAST SESSION")
	else
		value = MBP.LootValue(db.loot)
		panel.haulLabel:SetText("EVERYTHING YOU'VE CAUGHT")
	end
	if value > hero.target + 50 and hero.target > 0 then panel.heroPop:Stop(); panel.heroPop:Play() end
	hero.target = value
	if force or hero.shown == hero.target then panel.hero:SetText(BreakUpLargeNumbers(math.floor(value / 10000))) end

	local gph = MBP.GoldPerHour()
	local best = db.records.gph or 0
	panel.gph:SetText(hasSession and MBP.Gold(gph) or "|cff6f8597-|r")
	if not hasSession then
		panel.pace.target = 0
		panel.paceText:SetText("Start a session to race your best hour.")
	elseif best <= 0 then
		panel.pace.target = gph > 0 and 1 or 0
		panel.paceText:SetText("Fish 10 minutes to set your first gold-per-hour record.")
	else
		local pct = gph / best
		panel.pace.target = pct
		if pct >= 1 then
			panel.paceText:SetText(string.format("|cffffd24aRecord pace!|r %d%% of your best hour (%s)", math.floor(pct * 100), MBP.Gold(best)))
			if panel.aura and S.active and not S.paused then
				panel.aura:SetColor(C.gold[1], C.gold[2], C.gold[3], 0.7, 3.0)
				panel.spark:SetColor(1, 0.85, 0.4, S.fishing and 170 or 110)
			end
		else
			panel.paceText:SetText(string.format("%d%% of your best hour (%s)", math.floor(pct * 100), MBP.Gold(best)))
		end
	end

	-- tiles
	local t = MBP.SessionSeconds()
	local tries = S.catches + S.misses
	local hit = tries > 0 and math.floor((tries - S.misses) / tries * 100 + 0.5) or 0
	panel.tTime.value:SetText(MBP.Clock(t))
	panel.tCatch.value:SetText(BreakUpLargeNumbers(S.catches))
	panel.tLand.value:SetText(tries > 0 and (hit .. "%") or "-")
	panel.tStreak.value:SetText(S.streak)
	if S.streak >= 10 then panel.tStreak.value:SetTextColor(C.gold[1], C.gold[2], C.gold[3])
	else panel.tStreak.value:SetTextColor(1, 1, 1) end

	-- top catches
	local view = db.topView == "all" and "all" or "session"
	panel.tabSes:SetActive(view == "session")
	panel.tabAll:SetActive(view == "all")
	local rows, total = MBP.TopCatches(view, 5)
	for i = 1, 5 do FillSlot(slots[i], rows[i], i, total, view) end
	local vendorOnly, src = false, nil
	for _, r in ipairs(rows) do
		if r.src == "Vendor" or r.src == "None" then vendorOnly = true end
		if r.src ~= "Vendor" and r.src ~= "None" then src = src or r.src end
	end
	if #rows == 0 then
		panel.priceNote:SetText(view == "session" and "Catch something and it lands here." or "Nothing caught yet. The water awaits.")
	elseif vendorOnly then
		panel.priceNote:SetText("|cff6f8597*|r vendor price. Visit the auction house to price them.")
	else
		panel.priceNote:SetText("Prices: " .. (src == "AH" and "your auction house" or src == "TSM" and "TradeSkillMaster" or src or "auction house") .. "  |cff3a5466·|r  hover a fish for details")
	end
end

function MBP.ShowPanel()
	if not panel then return end
	local was = panel:IsShown()
	panel:Show()
	MBP.db.panelShown = true
	MBP.Refresh(true)
	if not was then panel.open:Stop(); panel.open:Play() end
end
function MBP.HidePanel() if panel then panel:Hide(); MBP.db.panelShown = false end end
function MBP.TogglePanel() if panel and panel:IsShown() then MBP.HidePanel() else MBP.ShowPanel() end end

-- Catch toasts --------------------------------------------------------------------------------
local toasts = {}

local function MakeToast()
	local t = CreateFrame("Frame", nil, UIParent)
	t:SetSize(250, 46)
	t:SetFrameStrata("HIGH")
	t:SetClampedToScreen(true)
	local bg = t:CreateTexture(nil, "BACKGROUND")
	bg:SetAllPoints()
	Grad(bg, "HORIZONTAL", C.panelBot, C.panelTop, 0.94, 0.94)
	Border(t, C.line, 0.9)
	t.accent = t:CreateTexture(nil, "ARTWORK")
	t.accent:SetPoint("TOPLEFT", 1, -1)
	t.accent:SetPoint("BOTTOMLEFT", 1, 1)
	t.accent:SetWidth(3)
	t.icon = t:CreateTexture(nil, "ARTWORK")
	t.icon:SetSize(34, 34)
	t.icon:SetPoint("LEFT", 10, 0)
	t.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
	t.name = Text(t, 11, C.text, HEAD_FONT)
	t.name:SetPoint("TOPLEFT", t.icon, "TOPRIGHT", 8, -2)
	t.name:SetWidth(140)
	t.src = Text(t, 9, C.muted)
	t.src:SetPoint("BOTTOMLEFT", t.icon, "BOTTOMRIGHT", 8, 2)
	t.src:SetWidth(140)
	t.value = Text(t, 15, C.gold, HEAD_FONT, "OUTLINE")
	t.value:SetPoint("RIGHT", -10, 0)
	t.value:SetJustifyH("RIGHT")
	t.burst = t:CreateTexture(nil, "OVERLAY")
	t.burst:SetTexture("Interface\\Cooldown\\star4")
	t.burst:SetBlendMode("ADD")
	t.burst:SetSize(90, 90)
	t.burst:SetPoint("CENTER", t.icon, "CENTER")
	t.burst:SetAlpha(0)
	t.burstAnim = t.burst:CreateAnimationGroup()
	AlphaAnim(t.burstAnim, 0, 1, 0.1, 1)
	ScaleAnim(t.burstAnim, 0.4, 2.0, 0.7, 2, "OUT")
	AlphaAnim(t.burstAnim, 1, 0, 0.7, 2)
	local rot = t.burstAnim:CreateAnimation("Rotation")
	rot:SetDegrees(-120); rot:SetDuration(0.8); rot:SetOrder(2)

	t.anim = t:CreateAnimationGroup()
	MoveAnim(t.anim, 30, 0, 0, 1)
	AlphaAnim(t.anim, 0, 0, 0, 1)
	MoveAnim(t.anim, -30, 0, 0.25, 2, "OUT")
	AlphaAnim(t.anim, 0, 1, 0.2, 2)
	MoveAnim(t.anim, 0, 0, 2.2, 3)
	MoveAnim(t.anim, 0, 18, 0.5, 4, "IN")
	AlphaAnim(t.anim, 1, 0, 0.5, 4)
	t.anim:SetScript("OnFinished", function() t:Hide(); MBP.LayoutToasts() end)
	if MBP.Glow then
		t.aura = MBP.Glow.Aura(t, 7, 1, 1, 1, 0.45)
		t.sheen = MBP.Glow.Sheen(t, nil, 0.4, 40)
		MBP.Glow.TextGlow(t.value, 1, 0.6, 0.1, 0.9)
	end
	t:Hide()
	return t
end

function MBP.LayoutToasts()
	local shown = {}
	for _, t in ipairs(toasts) do if t:IsShown() then shown[#shown + 1] = t end end
	table.sort(shown, function(a, b) return a.born > b.born end)
	-- Above the panel when there is room for the whole stack, otherwise below it (a panel parked at the top
	-- of the screen used to push the pop-ups off screen).
	local below = false
	if panel and panel:IsShown() then
		local top = (panel:GetTop() or 0) * panel:GetEffectiveScale() / UIParent:GetEffectiveScale()
		below = UIParent:GetHeight() - top < 10 + #shown * 52
	end
	for i, t in ipairs(shown) do
		t:ClearAllPoints()
		if panel and panel:IsShown() and below then
			t:SetPoint("TOP", panel, "BOTTOM", 0, -10 - (i - 1) * 52)
		elseif panel and panel:IsShown() then
			t:SetPoint("BOTTOM", panel, "TOP", 0, 10 + (i - 1) * 52)
		else
			t:SetPoint("CENTER", UIParent, "CENTER", 0, 170 + (i - 1) * 52)
		end
	end
end

local function ShowToast(link, qty, value, quality, icon, src, jackpot)
	local t
	for _, x in ipairs(toasts) do if not x:IsShown() then t = x; break end end
	if not t then
		if #toasts < 4 then t = MakeToast(); toasts[#toasts + 1] = t
		else
			t = toasts[1]
			for _, x in ipairs(toasts) do if x.born < t.born then t = x end end
			t.anim:Stop()
		end
	end
	t.born = GetTime()
	local r, g, b = QualityColor(quality)
	t.accent:SetColorTexture(r, g, b, 1)
	t.icon:SetTexture(icon or "Interface\\Icons\\INV_Misc_Fish_02")
	local name = link and link:match("%[(.-)%]") or "Something"
	t.name:SetText(name .. (qty > 1 and (" |cffffffffx" .. qty .. "|r") or ""))
	t.name:SetTextColor(r, g, b)
	t.src:SetText(jackpot and "|cffffd24aJACKPOT!|r" or (src == "Vendor" and "vendor price" or src == "None" and "no price yet" or "auction price"))
	t.value:SetText(value > 0 and ("+" .. MBP.ShortGold(value)) or "")
	t.value:SetTextColor(TierColor(value))
	t:Show()
	MBP.LayoutToasts()
	t.anim:Stop(); t.anim:Play()
	if t.aura then
		if jackpot then t.aura:SetColor(1, 0.82, 0.3, 0.8, 4) else t.aura:SetColor(r, g, b, (quality or 1) >= 3 and 0.65 or 0.35, 2) end
		t.aura:Flash(1, 1, 1, 0.7)
		t.sheen.p, t.sheen.playing = 0, false
		C_Timer.After(0.25, function() if t:IsShown() then t.sheen:Play() end end)
	end
	if jackpot or (quality or 0) >= 3 then
		t.burst:SetVertexColor(jackpot and 1 or r, jackpot and 0.82 or g, jackpot and 0.3 or b)
		t.burstAnim:Stop(); t.burstAnim:Play()
	end
end

function MBP.OnCatch(id, link, qty, value, quality, icon, src)
	local db = MBP.db
	local jackpot = value >= (db.jackpot or 100) * 10000
	if db.toasts then ShowToast(link, qty, value, quality, icon, src, jackpot) end
	if jackpot then
		if RaidNotice_AddMessage and RaidWarningFrame then
			RaidNotice_AddMessage(RaidWarningFrame, "|cffffd24aJACKPOT!|r " .. (link or "") .. "  " .. MBP.Gold(value), ChatTypeInfo["RAID_WARNING"])
		end
		pcall(PlaySound, SOUNDKIT and SOUNDKIT.UI_EPICLOOT_TOAST or 31578)
	end
	if panel and panel:IsShown() then
		MBP.Refresh()
		if panel.burst then
			local r, g, b = QualityColor(quality)
			local big = jackpot or (quality or 0) >= 3
			panel.burst:Fire(40, 133, big and 22 or (value > 0 and 9 or 5), r, g, b, value > 0, big and 1.5 or 1)
			panel.aura:Flash(jackpot and 1 or r, jackpot and 0.85 or g, jackpot and 0.3 or b, big and 1 or 0.6)
			panel.heroHalo:Pulse(big and 1.2 or 0.6)
			panel.badgeHalo:Pulse(0.5)
		end
		for _, s in ipairs(slots) do
			if s.row and s.row.id == id then
				s.pop:Stop(); s.pop:Play()
				s.flash:Stop(); s.flash:Play()
				if s.aura then local r, g, b = QualityColor(quality); s.aura:Flash(r, g, b, 1) end
			end
		end
	end
end

function MBP.OnMiss()
	S.missAt = GetTime()
	S.missText = MBP.MISS[math.random(#MBP.MISS)]
end

function MBP.OnPrice() if panel and panel:IsShown() then MBP.Refresh() end end

-- The summary card ----------------------------------------------------------------------------
local sumSlots = {}

function MBP.ShowSummary(sum)
	if not summary then
		local W = 340
		summary = CreateFrame("Frame", "MasterBaiterProSummary", UIParent)
		summary:SetSize(W, 330)
		summary:SetPoint("CENTER", 0, 80)
		summary:SetFrameStrata("DIALOG")
		summary:EnableMouse(true)
		summary:SetMovable(true)
		summary:RegisterForDrag("LeftButton")
		summary:SetScript("OnDragStart", summary.StartMoving)
		summary:SetScript("OnDragStop", summary.StopMovingOrSizing)
		tinsert(UISpecialFrames, "MasterBaiterProSummary")
		local shadow = summary:CreateTexture(nil, "BACKGROUND", nil, -8)
		shadow:SetPoint("TOPLEFT", -8, 8)
		shadow:SetPoint("BOTTOMRIGHT", 8, -8)
		shadow:SetColorTexture(0, 0, 0, 0.45)
		local body = summary:CreateTexture(nil, "BACKGROUND", nil, -6)
		body:SetAllPoints()
		Grad(body, "VERTICAL", C.panelBot, C.panelTop, 0.98, 0.98)
		Border(summary, C.line, 0.9)
		local rule = summary:CreateTexture(nil, "ARTWORK")
		rule:SetPoint("TOPLEFT", 1, -1)
		rule:SetPoint("TOPRIGHT", -1, -1)
		rule:SetHeight(2)
		Grad(rule, "HORIZONTAL", C.goldDeep, C.gold, 1, 1)

		local h = Text(summary, 18, C.gold, HEAD_FONT, "OUTLINE")
		h:SetPoint("TOP", 0, -16)
		h:SetJustifyH("CENTER")
		h:SetText("Session Haul")
		summary.sub = Text(summary, 10, C.muted)
		summary.sub:SetPoint("TOP", h, "BOTTOM", 0, -4)
		summary.sub:SetJustifyH("CENTER")

		local heroF = CreateFrame("Frame", nil, summary)
		heroF:SetSize(240, 34)
		heroF:SetPoint("TOP", 0, -58)
		local coin = heroF:CreateTexture(nil, "ARTWORK")
		coin:SetSize(22, 22)
		coin:SetTexture("Interface\\MoneyFrame\\UI-GoldIcon")
		summary.hero = Text(heroF, 30, C.gold, HEAD_FONT, "OUTLINE")
		summary.hero:SetPoint("CENTER", 14, 0)
		summary.hero:SetJustifyH("CENTER")
		coin:SetPoint("RIGHT", summary.hero, "LEFT", -6, 0)
		summary.heroAnim = heroF:CreateAnimationGroup()
		ScaleAnim(summary.heroAnim, 0.6, 1.1, 0.25, 1, "OUT")
		ScaleAnim(summary.heroAnim, 1.1, 1, 0.2, 2, "IN_OUT")

		summary.body = Text(summary, 11, C.text)
		summary.body:SetPoint("TOP", 0, -100)
		summary.body:SetJustifyH("CENTER")
		summary.body:SetWidth(W - 30)
		summary.body:SetSpacing(4)
		if summary.body.SetWordWrap then summary.body:SetWordWrap(true) end

		summary.topLabel = SmallCaps(summary, "BEST CATCHES", 9)
		summary.topLabel:SetJustifyH("CENTER")
		local size, gap = 46, 12
		local sx = (W - (size * 5 + gap * 4)) / 2
		for i = 1, 5 do
			local s = MakeSlot(summary, size)
			s:SetPoint("BOTTOMLEFT", sx + (i - 1) * (size + gap), 74)
			sumSlots[i] = s
		end
		summary.topLabel:SetPoint("BOTTOM", 0, 128)

		local ok = Button(summary, "Nice.", 120, true, function() summary:Hide() end)
		ok:SetPoint("BOTTOM", 0, 16)

		if MBP.Glow then
			local GL = MBP.Glow
			summary.aura = GL.Aura(summary, 10, C.gold[1], C.gold[2], C.gold[3], 0.5)
			GL.Spark(summary, 1, 0.85, 0.4, 120)
			summary.halo = GL.Halo(summary, heroF, 190, C.gold[1], C.gold[2], C.gold[3], 0.22)
			GL.TextGlow(h, 1, 0.6, 0.1, 0.9)
			GL.TextGlow(summary.hero, 1, 0.6, 0.1, 1)
			GL.Twinkles(summary, 8, 20, 10, W - 20, 100, 1, 0.9, 0.6)
			GL.Bubbles(summary, 10, C.aqua[1], C.aqua[2], C.aqua[3], 120)
			summary.burst = GL.Burst(summary)
		end
		summary.open = summary:CreateAnimationGroup()
		ScaleAnim(summary.open, 0.9, 1, 0.22, 1, "OUT")
		AlphaAnim(summary.open, 0, 1, 0.18, 1)
		summary:SetScript("OnUpdate", function(_, el) AnimateBars(sumSlots, el) end)
	end
	local tries = sum.catches + sum.misses
	local hit = tries > 0 and math.floor((tries - sum.misses) / tries * 100 + 0.5) or 0
	summary.sub:SetText(string.format("%s at the water", MBP.Clock(sum.seconds)))
	summary.hero:SetText(BreakUpLargeNumbers(math.floor((sum.copper or 0) / 10000)))
	local lines = {
		string.format("|cff8aa3b8Casts|r %d    |cff8aa3b8Catches|r %d    |cff8aa3b8Landed|r %d%%", sum.casts, sum.catches, hit),
		string.format("|cff8aa3b8Gold per hour|r %s%s    |cff8aa3b8Best streak|r %d", MBP.Gold(sum.gph), sum.newGph and " |cffffd24a(record!)|r" or "", sum.bestStreak or 0),
	}
	if sum.misses > 0 then lines[#lines + 1] = "|cff6f8597" .. sum.misses .. " got away. " .. MBP.MISS[math.random(#MBP.MISS)] .. "|r" end
	summary.body:SetText(table.concat(lines, "\n"))
	local rows, total = sum.top or {}, 0
	for _, r in ipairs(rows) do total = total + (r.value or 0) end
	for i = 1, 5 do
		local s = sumSlots[i]
		s.barW = 0
		FillSlot(s, rows[i], i, total, "session")
	end
	summary.topLabel:SetShown(#rows > 0)
	summary:Show()
	summary.open:Stop(); summary.open:Play()
	summary.heroAnim:Stop(); summary.heroAnim:Play()
	if summary.burst then
		C_Timer.After(0.15, function()
			summary.burst:Fire(summary:GetWidth() / 2, 75, (sum.copper or 0) > 0 and 22 or 8, 1, 0.85, 0.4, (sum.copper or 0) > 0, sum.newGph and 1.6 or 1.2)
			summary.halo:Pulse(1.2)
			summary.aura:Flash(1, 1, 1, 0.8)
		end)
	end
	pcall(PlaySound, 888)
end

function MBP.OnAchievement() if panel and panel:IsShown() then panel.heroPop:Stop(); panel.heroPop:Play() end end
