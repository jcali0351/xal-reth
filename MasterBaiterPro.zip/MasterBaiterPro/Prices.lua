-- Master Baiter Pro: auction house prices for everything you catch.
-- Price order: a fresh price from your own auction house visit, then Auctionator, then TSM,
-- then an older auction house price, then the vendor price.
local MBP = MasterBaiterPro
local S = MBP.S

local FRESH = 60 * 60          -- an auction house price under an hour old beats everything else
local RESCAN = 30 * 60         -- prices older than this are refreshed when you visit the auction house
local CALLER = "MasterBaiterPro"

local function Now() return time() end

local function VendorPrice(id)
	local f = (C_Item and C_Item.GetItemInfo) or GetItemInfo
	if not f then return 0 end
	local ok, _, _, _, _, _, _, _, _, _, _, sell = pcall(f, id)
	if ok and type(sell) == "number" then return sell end
	return 0
end

local function AuctionatorPrice(id, link)
	local api = Auctionator and Auctionator.API and Auctionator.API.v1
	if not api then return end
	if link and api.GetAuctionPriceByItemLink then
		local ok, p = pcall(api.GetAuctionPriceByItemLink, CALLER, link)
		if ok and type(p) == "number" and p > 0 then return p end
	end
	if api.GetAuctionPriceByItemID then
		local ok, p = pcall(api.GetAuctionPriceByItemID, CALLER, id)
		if ok and type(p) == "number" and p > 0 then return p end
	end
end

local function TSMPrice(id, link)
	if not (TSM_API and TSM_API.GetCustomPriceValue) then return end
	local s = "i:" .. id
	if link and TSM_API.ToItemString then
		local ok, v = pcall(TSM_API.ToItemString, link)
		if ok and v then s = v end
	end
	for _, src in ipairs({ "dbmarket", "dbminbuyout", "dbregionmarketavg" }) do
		local ok, p = pcall(TSM_API.GetCustomPriceValue, src, s)
		if ok and type(p) == "number" and p > 0 then return p end
	end
end

function MBP.HasPriceAddon()
	return (Auctionator and Auctionator.API and Auctionator.API.v1) and true or (TSM_API and true) or false
end

-- Returns unit price in copper, the source name, and (for our own scans) the age in seconds.
function MBP.Price(id, link)
	id = MBP.ItemID(id) or MBP.ItemID(link)
	if not id then return 0, "None" end
	local own = MBP.db and MBP.db.prices[id]
	local age = own and (Now() - (own.t or 0))
	if own and own.p and own.p > 0 and age < FRESH then return own.p, "AH", age end
	local p = AuctionatorPrice(id, link)
	if p then return p, "Auctionator" end
	p = TSMPrice(id, link)
	if p then return p, "TSM" end
	if own and own.p and own.p > 0 then return own.p, "AH", age end
	p = VendorPrice(id)
	if p > 0 then return p, "Vendor" end
	return 0, "None"
end

local function Ago(sec)
	sec = sec or 0
	if sec < 90 then return "just now" end
	if sec < 3600 then return math.floor(sec / 60) .. "m ago" end
	if sec < 86400 then return math.floor(sec / 3600) .. "h ago" end
	return math.floor(sec / 86400) .. "d ago"
end

function MBP.SourceText(src, age)
	if src == "AH" then return "Auction house, " .. Ago(age) end
	if src == "Auctionator" then return "Auctionator" end
	if src == "TSM" then return "TradeSkillMaster" end
	if src == "Vendor" then return "Vendor price (no auction data yet)" end
	return "No price"
end

-- Your own auction house scan -----------------------------------------------------------
-- When the auction house is open, Master Baiter Pro looks up each fish you have caught, one at a time,
-- at the game's own pace. It also notes the price of any of your fish you browse yourself.
local ahOpen, queue, queued, pending, pendingAt, done, total = false, {}, {}, nil, 0, 0, 0
local button

local function Store(id, price)
	if not (MBP.db and id and price and price > 0) then return end
	local old = MBP.db.prices[id]
	MBP.db.prices[id] = { p = price, t = Now() }
	if MBP.OnPrice then MBP.OnPrice(id, price, old and old.p) end
end

local function UpdateButton()
	if not button then return end
	if #queue > 0 or pending then
		button.text:SetText(string.format("Pricing fish %d/%d", done, total))
	elseif total > 0 then
		button.text:SetText("Fish priced")
	else
		button.text:SetText("Price my fish")
	end
end

function MBP.QueueScan(id, force)
	if not (ahOpen and id and MBP.db) or queued[id] then return end
	local own = MBP.db.prices[id]
	if not force and own and Now() - (own.t or 0) < RESCAN then return end
	queued[id] = true
	queue[#queue + 1] = id
	total = total + 1
	UpdateButton()
end

function MBP.ScanAll(force)
	if not ahOpen then MBP.Say("Open the auction house first."); return end
	local ids = {}
	for id, e in pairs(MBP.db.loot) do ids[#ids + 1] = { id = id, n = e.n or 0 } end
	table.sort(ids, function(a, b) return a.n > b.n end)
	if #ids == 0 then
		if force ~= nil then MBP.Say("Nothing to price yet. Go catch something!") end
		return
	end
	for i = 1, math.min(60, #ids) do MBP.QueueScan(ids[i].id, force) end
	UpdateButton()
end

local function SendNext()
	if not ahOpen or pending then return end
	local id = table.remove(queue, 1)
	if not id then UpdateButton(); return end
	local ready = C_AuctionHouse.IsThrottledMessageSystemReady and C_AuctionHouse.IsThrottledMessageSystemReady()
	if ready == false then table.insert(queue, 1, id); return end
	local key = C_AuctionHouse.MakeItemKey(id)
	local sorts = { { sortOrder = Enum.AuctionHouseSortOrder.Price, reverseSort = false } }
	local ok = pcall(C_AuctionHouse.SendSearchQuery, key, sorts, false)
	if ok then pending, pendingAt = id, GetTime() else done = done + 1 end
	UpdateButton()
end

local function Finish(id)
	if pending == id then pending = nil; done = done + 1 end
	UpdateButton()
	if MBP.Refresh then MBP.Refresh() end
end

local function OnCommodity(id)
	if not id or not (MBP.db.loot[id] or pending == id) then return end
	local n = C_AuctionHouse.GetNumCommoditySearchResults(id) or 0
	if n > 0 then
		local info = C_AuctionHouse.GetCommoditySearchResultInfo(id, 1)
		if info and info.unitPrice then Store(id, info.unitPrice) end
		Finish(id)
	elseif pending == id and C_AuctionHouse.HasFullCommoditySearchResults and C_AuctionHouse.HasFullCommoditySearchResults(id) then
		Finish(id) -- none listed right now
	end
end

local function OnItem(key)
	local id = key and key.itemID
	if not id or not (MBP.db.loot[id] or pending == id) then return end
	local n = C_AuctionHouse.GetNumItemSearchResults(key) or 0
	local best
	for i = 1, math.min(n, 20) do
		local info = C_AuctionHouse.GetItemSearchResultInfo(key, i)
		local p = info and (info.buyoutAmount or info.bidAmount)
		if p and p > 0 and (not best or p < best) then best = p end
	end
	if best then Store(id, best) end
	if n > 0 or (C_AuctionHouse.HasFullItemSearchResults and C_AuctionHouse.HasFullItemSearchResults(key)) then Finish(id) end
end

local function MakeButton()
	if button or not AuctionHouseFrame then return end
	button = CreateFrame("Button", "MasterBaiterProScanButton", AuctionHouseFrame, "UIPanelButtonTemplate")
	button:SetSize(140, 22)
	button:SetPoint("TOPRIGHT", AuctionHouseFrame, "TOPRIGHT", -30, -1)
	button.text = button:GetFontString() or button.Text
	button:SetText("Price my fish")
	button:SetScript("OnClick", function() MBP.ScanAll(IsShiftKeyDown()) end)
	button:SetScript("OnEnter", function(self)
		GameTooltip:SetOwner(self, "ANCHOR_BOTTOMLEFT")
		GameTooltip:AddLine("|cffffd24aMaster Baiter|r |cff4fd8ffPro|r")
		GameTooltip:AddLine("Looks up the current lowest price of every fish you have caught.", 1, 1, 1, true)
		GameTooltip:AddLine("Shift-click to refresh prices you checked recently too.", 0.7, 0.7, 0.7, true)
		GameTooltip:Show()
	end)
	button:SetScript("OnLeave", GameTooltip_Hide)
end

local ticker
function MBP.InitPrices()
	local f = CreateFrame("Frame")
	f:RegisterEvent("AUCTION_HOUSE_SHOW")
	f:RegisterEvent("AUCTION_HOUSE_CLOSED")
	f:RegisterEvent("COMMODITY_SEARCH_RESULTS_UPDATED")
	f:RegisterEvent("ITEM_SEARCH_RESULTS_UPDATED")
	f:SetScript("OnEvent", function(_, e, a)
		if e == "AUCTION_HOUSE_SHOW" then
			ahOpen = true
			wipe(queue); wipe(queued); pending, done, total = nil, 0, 0
			MakeButton()
			UpdateButton()
			if MBP.db.autoScan then C_Timer.After(1.5, function() if ahOpen then MBP.ScanAll(nil) end end) end
			if not ticker then
				ticker = C_Timer.NewTicker(0.6, function()
					if not ahOpen then return end
					if pending and GetTime() - pendingAt > 6 then Finish(pending) end
					SendNext()
				end)
			end
		elseif e == "AUCTION_HOUSE_CLOSED" then
			ahOpen = false
			if total > 0 and done > 0 then MBP.Say("Priced " .. done .. " kind" .. (done == 1 and "" or "s") .. " of fish at the auction house.") end
			wipe(queue); wipe(queued); pending, done, total = nil, 0, 0
			if ticker then ticker:Cancel(); ticker = nil end
			if MBP.Refresh then MBP.Refresh() end
		elseif e == "COMMODITY_SEARCH_RESULTS_UPDATED" then
			pcall(OnCommodity, a)
		elseif e == "ITEM_SEARCH_RESULTS_UPDATED" then
			pcall(OnItem, a)
		end
	end)
end
