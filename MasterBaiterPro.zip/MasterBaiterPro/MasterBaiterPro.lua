-- Master Baiter Pro: one-key fishing with live auction house prices.
-- Every action still needs a real key press from you. The addon only decides what that key does:
-- cast Fishing while idle, Interact with the bobber while your line is in the water.

local ADDON = ...
local MBP = {}
_G.MasterBaiterPro = MBP

BINDING_HEADER_MASTERBAITERPRO = "Master Baiter Pro"
BINDING_NAME_MASTERBAITERPRO_TOGGLE = "Begin or end a fishing session"
BINDING_NAME_MASTERBAITERPRO_PANEL = "Show or hide the Master Baiter Pro panel"

MBP.VERSION = "2.0"
local FISHING_SPELL = 131474
local FISH_IDS = { [131474] = true, [131476] = true, [131490] = true, [7620] = true }

local function SpellName(id)
	if C_Spell and C_Spell.GetSpellName then
		local ok, n = pcall(C_Spell.GetSpellName, id)
		if ok and n then return n end
	end
	if GetSpellInfo then
		local ok, n = pcall(GetSpellInfo, id)
		if ok and n then return n end
	end
	return "Fishing"
end
local FISH_NAME = SpellName(FISHING_SPELL)

-- Flavor -----------------------------------------------------------------------
local HOOKED = {
	"Hooked:", "Reeled in:", "Nice catch:", "Landed:", "Into the bag:", "Look at the size of it:",
	"The pro strikes again:", "Fresh from the water:",
}
local MISS = {
	"It got away.", "That one wasn't hungry.", "Even pros miss one.", "Too slow on the splash.",
	"The fish wins this round.",
}
MBP.MISS = MISS

local function pick(t) return t[math.random(#t)] end
local function say(msg) print("|cffffd24aMaster Baiter|r |cff4fd8ffPro|r: " .. msg) end
MBP.Say = say

-- Saved data -----------------------------------------------------------------
local DEFAULTS = {
	key = "F", autoStart = true, boostSound = true, softInteract = true, autoLoot = true,
	idleMinutes = 3, summary = true, bagWarn = 3, autoScan = true, toasts = true, jackpot = 100,
	panelShown = true, topView = "session",
	totals = { casts = 0, catches = 0, misses = 0, copper = 0, seconds = 0, sessions = 0 },
	records = { session = 0, streak = 0, gph = 0, bestLink = nil, bestValue = 0, bestQuality = -1 },
	loot = {}, prices = {}, zones = {}, ach = {}, saved = nil,
}

local function fill(dst, src)
	for k, v in pairs(src) do
		if dst[k] == nil then
			if type(v) == "table" then dst[k] = {}; fill(dst[k], v) else dst[k] = v end
		elseif type(v) == "table" and type(dst[k]) == "table" then
			fill(dst[k], v)
		end
	end
end

-- Session state ---------------------------------------------------------------
local S = { active = false, fishing = false, paused = false, start = 0, casts = 0, catches = 0, misses = 0,
	streak = 0, bestStreak = 0, last = nil, looted = false, lastAction = 0, castStart = 0, castEnd = 0,
	loot = {}, stopped = 0 }
MBP.S = S

-- CVars borrowed while a session runs --------------------------------------------
local CVARS = {
	{ "Sound_EnableAllSound", "1", "boostSound" }, { "Sound_EnableSFX", "1", "boostSound" },
	{ "Sound_SFXVolume", "1.0", "boostSound" }, { "Sound_MasterVolume", "1.0", "boostSound" },
	{ "Sound_MusicVolume", "0", "boostSound" }, { "Sound_AmbienceVolume", "0", "boostSound" },
	{ "Sound_DialogVolume", "0.3", "boostSound" },
	{ "SoftTargetInteract", "3", "softInteract" }, { "SoftTargetInteractRange", "30", "softInteract" },
	{ "SoftTargetInteractArc", "2", "softInteract" },
	{ "autoLootDefault", "1", "autoLoot" },
}

local function GetCV(n)
	local ok, v = pcall(C_CVar and C_CVar.GetCVar or GetCVar, n)
	if ok then return v end
end
local function SetCV(n, v) pcall(C_CVar and C_CVar.SetCVar or SetCVar, n, v) end
MBP.GetCV = GetCV

local function BorrowCVars()
	local db = MBP.db
	if db.saved then return end
	db.saved = {}
	for _, c in ipairs(CVARS) do
		if db[c[3]] then
			local old = GetCV(c[1])
			if old ~= nil then db.saved[c[1]] = old; SetCV(c[1], c[2]) end
		end
	end
end

local function RestoreCVars()
	local db = MBP.db
	if not db or not db.saved then return end
	for n, v in pairs(db.saved) do SetCV(n, v) end
	db.saved = nil
end

-- The one key -----------------------------------------------------------------
local owner = CreateFrame("Frame", "MasterBaiterProBindingOwner", UIParent)
local castBtn = CreateFrame("Button", "MasterBaiterProCastButton", UIParent, "SecureActionButtonTemplate")
castBtn:RegisterForClicks("AnyDown")
castBtn:Hide()
local pendingBind, pendingAttr = false, true

local function SetCastAttributes()
	if InCombatLockdown() then pendingAttr = true; return end
	castBtn:SetAttribute("type", "spell")
	castBtn:SetAttribute("spell", FISH_NAME)
	pendingAttr = false
end

function MBP.ApplyBinding()
	if InCombatLockdown() then pendingBind = true; return end
	pendingBind = false
	ClearOverrideBindings(owner)
	if not S.active or S.paused then return end
	local key = MBP.db.key
	if not key or key == "" then return end
	if S.fishing then
		SetOverrideBinding(owner, true, key, "INTERACTTARGET")
	else
		SetOverrideBindingClick(owner, true, key, "MasterBaiterProCastButton", "LeftButton")
	end
end

-- Money and time ------------------------------------------------------------------
function MBP.ItemID(link)
	if type(link) == "number" then return link end
	return link and tonumber(link:match("item:(%d+)"))
end

function MBP.Gold(copper)
	local g = math.floor((copper or 0) / 10000)
	local s = BreakUpLargeNumbers and BreakUpLargeNumbers(g) or tostring(g)
	return s .. "|cffffd100g|r"
end

-- Short form for small spaces: 950g, 12.4k, 3.1m
function MBP.ShortGold(copper)
	local g = (copper or 0) / 10000
	if g >= 1e6 then return string.format("%.1fm", g / 1e6) end
	if g >= 1e4 then return string.format("%.0fk", g / 1e3) end
	if g >= 1e3 then return string.format("%.1fk", g / 1e3) end
	if g >= 10 then return string.format("%d", math.floor(g)) .. "g" end
	if g >= 1 then return string.format("%.1fg", g) end
	return string.format("%ds", math.floor((copper or 0) / 100))
end

-- Full coin string with the game's coin icons, for tooltips
function MBP.Coins(copper)
	copper = math.floor(copper or 0)
	if C_CurrencyInfo and C_CurrencyInfo.GetCoinTextureString then
		local ok, s = pcall(C_CurrencyInfo.GetCoinTextureString, copper)
		if ok and s then return s end
	end
	if GetCoinTextureString then
		local ok, s = pcall(GetCoinTextureString, copper)
		if ok and s then return s end
	end
	return MBP.Gold(copper)
end

function MBP.Clock(sec)
	sec = math.floor(sec or 0)
	local h, m, s = math.floor(sec / 3600), math.floor(sec % 3600 / 60), sec % 60
	if h > 0 then return string.format("%d:%02d:%02d", h, m, s) end
	return string.format("%d:%02d", m, s)
end

function MBP.SessionSeconds()
	if S.active then return GetTime() - S.start end
	return S.stopped or 0
end

-- Value of a loot table ({ [itemID] = { n = count } }) at today's prices
function MBP.LootValue(loot)
	local total = 0
	for id, e in pairs(loot) do
		local p = MBP.Price(id, e.link)
		total = total + p * (e.n or 0)
	end
	return total
end

function MBP.SessionValue() return MBP.LootValue(S.loot) end

function MBP.GoldPerHour()
	local t = MBP.SessionSeconds()
	if t < 60 then return 0 end
	return MBP.SessionValue() / t * 3600
end

-- Top catches by total value (count x price), then by count
function MBP.TopCatches(which, n)
	local loot = which == "all" and MBP.db.loot or S.loot
	local rows, total = {}, 0
	for id, e in pairs(loot) do
		local unit, src, age = MBP.Price(id, e.link)
		local value = unit * (e.n or 0)
		total = total + value
		rows[#rows + 1] = { id = id, link = e.link, icon = e.icon, q = e.q or 1, n = e.n or 0,
			unit = unit, value = value, src = src, age = age }
	end
	table.sort(rows, function(a, b)
		if a.value ~= b.value then return a.value > b.value end
		return a.n > b.n
	end)
	for i = (n or 5) + 1, #rows do rows[i] = nil end
	return rows, total
end

-- Bags --------------------------------------------------------------------------
local function FreeSlots()
	local free = 0
	local getFree = (C_Container and C_Container.GetContainerNumFreeSlots) or GetContainerNumFreeSlots
	if not getFree then return 99 end
	for bag = 0, 5 do
		local ok, n, family = pcall(getFree, bag)
		if ok and n and (family == 0 or family == nil) then free = free + n end
	end
	return free
end

local warnedBags = 0
local function CheckBags()
	local free = FreeSlots()
	if free <= (MBP.db.bagWarn or 3) and GetTime() - warnedBags > 60 then
		warnedBags = GetTime()
		local msg = free == 0 and "Your bags are full. Time to sell some fish."
			or ("Only " .. free .. " bag slot" .. (free == 1 and "" or "s") .. " left.")
		if RaidNotice_AddMessage and RaidWarningFrame then
			RaidNotice_AddMessage(RaidWarningFrame, "|cff4fd8ff" .. msg .. "|r", ChatTypeInfo["RAID_WARNING"])
		end
		say(msg)
		pcall(PlaySound, 8959)
	end
end

-- Achievements --------------------------------------------------------------------
local function count(t) local n = 0; for _ in pairs(t) do n = n + 1 end; return n end
MBP.Count = count
MBP.ACH = {
	{ id = "first", name = "Baby's First Bite", desc = "Land your first catch.", test = function(d) return d.totals.catches >= 1 end },
	{ id = "c100", name = "Getting the Hang of It", desc = "Catch 100 fish.", test = function(d) return d.totals.catches >= 100 end },
	{ id = "c1000", name = "Seasoned Baiter", desc = "Catch 1,000 fish.", test = function(d) return d.totals.catches >= 1000 end },
	{ id = "c5000", name = "Master Baiter", desc = "Catch 5,000 fish.", test = function(d) return d.totals.catches >= 5000 end },
	{ id = "s100", name = "Can't Stop, Won't Stop", desc = "Catch 100 fish in one session.", test = function(d) return d.records.session >= 100 end },
	{ id = "streak25", name = "Iron Wrist", desc = "Catch 25 in a row without missing one.", test = function(d) return d.records.streak >= 25 end },
	{ id = "rare", name = "Shiny!", desc = "Catch something of rare quality or better.", test = function(d) return (d.records.bestQuality or -1) >= 3 end },
	{ id = "epic", name = "Purple Haze", desc = "Catch something of epic quality or better.", test = function(d) return (d.records.bestQuality or -1) >= 4 end },
	{ id = "zones5", name = "Tourist", desc = "Fish in 5 different zones.", test = function(d) return count(d.zones) >= 5 end },
	{ id = "zones15", name = "Every Pond in Azeroth", desc = "Fish in 15 different zones.", test = function(d) return count(d.zones) >= 15 end },
	{ id = "g1000", name = "Fish Money", desc = "Catch 1,000 gold worth of fish.", test = function(d) return d.totals.copper >= 1000 * 10000 end },
	{ id = "g10000", name = "Goblin Approved", desc = "Catch 10,000 gold worth of fish.", test = function(d) return d.totals.copper >= 10000 * 10000 end },
	{ id = "hour", name = "Touch Grass (Near Water)", desc = "Fish for one hour in a single session.", test = function(d) return S.active and MBP.SessionSeconds() >= 3600 end },
	{ id = "jackpot", name = "Jackpot", desc = "Land a single catch worth your jackpot amount or more.", test = function(d) return (d.records.bestValue or 0) >= (d.jackpot or 100) * 10000 end },
}

local function CheckAchievements()
	local db = MBP.db
	for _, a in ipairs(MBP.ACH) do
		if not db.ach[a.id] then
			local ok, done = pcall(a.test, db)
			if ok and done then
				db.ach[a.id] = time()
				if RaidNotice_AddMessage and RaidWarningFrame then
					RaidNotice_AddMessage(RaidWarningFrame, "|cffffd24aAchievement: " .. a.name .. "|r", ChatTypeInfo["RAID_WARNING"])
				end
				say("|cffffd24aAchievement unlocked: " .. a.name .. ".|r " .. a.desc)
				pcall(PlaySound, 12891)
				if MBP.OnAchievement then MBP.OnAchievement(a) end
			end
		end
	end
end
MBP.CheckAchievements = CheckAchievements

-- Catches --------------------------------------------------------------------------------
local function ItemInfo(link)
	local f = (C_Item and C_Item.GetItemInfo) or GetItemInfo
	if not f then return end
	local ok, name, _, quality, _, _, _, _, _, _, icon = pcall(f, link)
	if ok then return name, quality, icon end
end

local function ItemIcon(id)
	if C_Item and C_Item.GetItemIconByID then
		local ok, t = pcall(C_Item.GetItemIconByID, id)
		if ok and t then return t end
	end
	if GetItemIcon then
		local ok, t = pcall(GetItemIcon, id)
		if ok and t then return t end
	end
end
MBP.ItemIcon = ItemIcon

local function AddLoot(t, id, link, qty, quality, icon)
	local e = t[id]
	if not e then e = { n = 0 }; t[id] = e end
	e.n = e.n + qty
	e.link, e.q = link, quality
	e.icon = icon or e.icon or ItemIcon(id)
end

local lootHandled = 0
local function RecordLoot()
	if not (IsFishingLoot and IsFishingLoot()) then return end
	if GetTime() - lootHandled < 1 then return end
	lootHandled = GetTime()
	if not S.active then return end
	local db = MBP.db
	local got = false
	for i = 1, GetNumLootItems() do
		local link = GetLootSlotLink(i)
		local id = MBP.ItemID(link)
		if link and id then
			local tex, name, qty, _, quality = GetLootSlotInfo(i)
			qty = qty or 1
			local iname, iq, icon = ItemInfo(link)
			quality = quality or iq or 1
			icon = tex or icon
			local unit, src = MBP.Price(id, link)
			local value = unit * qty
			got = true
			S.catches = S.catches + qty
			db.totals.catches = db.totals.catches + qty
			db.totals.copper = db.totals.copper + value
			AddLoot(S.loot, id, link, qty, quality, icon)
			AddLoot(db.loot, id, link, qty, quality, icon)
			S.last = link
			local r = db.records
			if value > (r.bestValue or 0) then
				if r.bestLink and value >= 10000 then say("New personal best catch: " .. link .. " (" .. MBP.Gold(value) .. ")") end
				r.bestLink, r.bestValue = link, value
			end
			if quality > (r.bestQuality or -1) then r.bestQuality = quality end
			say(pick(HOOKED) .. " " .. link .. (qty > 1 and (" x" .. qty) or "") ..
				(value > 0 and ("  |cffffffff" .. MBP.Coins(value) .. "|r" .. (src == "Vendor" and " |cff888888(vendor)|r" or "")) or ""))
			if MBP.OnCatch then MBP.OnCatch(id, link, qty, value, quality, icon, src) end
			if MBP.QueueScan then MBP.QueueScan(id) end
		end
	end
	if got then
		S.looted = true
		S.streak = S.streak + 1
		if S.streak > S.bestStreak then S.bestStreak = S.streak end
		local r = db.records
		if S.streak > (r.streak or 0) then
			if r.streak and r.streak >= 10 and S.streak == r.streak + 1 then say("New record streak! " .. S.streak .. " in a row.") end
			r.streak = S.streak
		end
		if S.catches > (r.session or 0) then r.session = S.catches end
		CheckAchievements()
		if MBP.Refresh then MBP.Refresh() end
	end
end

-- Sessions ----------------------------------------------------------------------------------
function MBP.Start(auto)
	if S.active then return end
	if InCombatLockdown() then say("Not in combat. Fish later, fight now."); return end
	wipe(S.loot)
	S.active, S.paused, S.fishing = true, false, false
	S.start, S.lastAction, S.stopped = GetTime(), GetTime(), 0
	S.casts, S.catches, S.misses, S.streak, S.bestStreak, S.last = 0, 0, 0, 0, 0, nil
	BorrowCVars()
	MBP.ApplyBinding()
	local zone = GetRealZoneText and GetRealZoneText()
	if zone and zone ~= "" then MBP.db.zones[zone] = true end
	say("Session started. Press |cffffd24a" .. (MBP.db.key or "?") .. "|r to cast, and again on the splash.")
	CheckBags()
	if MBP.ShowPanel then MBP.ShowPanel() end
	if MBP.Refresh then MBP.Refresh() end
end

function MBP.Stop(reason, quiet)
	if not S.active then return end
	local secs = MBP.SessionSeconds()
	CheckAchievements()
	S.active, S.fishing, S.stopped = false, false, secs
	if not InCombatLockdown() then ClearOverrideBindings(owner) else pendingBind = true end
	RestoreCVars()
	local db = MBP.db
	local value = MBP.SessionValue()
	db.totals.casts = db.totals.casts + S.casts
	db.totals.misses = db.totals.misses + S.misses
	db.totals.seconds = db.totals.seconds + secs
	db.totals.sessions = db.totals.sessions + 1
	local gph = secs >= 600 and (value / secs * 3600) or 0
	local newGph = gph > (db.records.gph or 0)
	if newGph then db.records.gph = gph end
	CheckAchievements()
	local top = MBP.TopCatches("session", 5)
	local sum = {
		reason = reason, seconds = secs, casts = S.casts, catches = S.catches, misses = S.misses, copper = value,
		gph = secs >= 60 and (value / secs * 3600) or 0, bestStreak = S.bestStreak, newGph = newGph, top = top,
	}
	db.lastSummary = sum
	if MBP.Refresh then MBP.Refresh() end
	if quiet then return end
	local why = reason == "combat" and " (combat)" or reason == "idle" and " (you wandered off)" or reason == "mount" and " (you mounted up)" or ""
	say("Session ended" .. why .. ". Your sound and settings are back to normal.")
	if db.summary and S.casts > 0 and MBP.ShowSummary then MBP.ShowSummary(sum) end
end

function MBP.Toggle() if S.active then MBP.Stop("manual") else MBP.Start(false) end end

-- Events ------------------------------------------------------------------------------------
local function IsFishingChannel(eventSpell)
	local name, _, _, startMS, endMS, _, _, spellID = UnitChannelInfo("player")
	if eventSpell and FISH_IDS[eventSpell] then return true, startMS, endMS end
	if not name then return false end
	local ok, isFish = pcall(function() return name == FISH_NAME or FISH_IDS[spellID] end)
	if ok and isFish then return true, startMS, endMS end
	return false
end

local ev = CreateFrame("Frame")
ev:RegisterEvent("PLAYER_LOGIN")
ev:RegisterEvent("PLAYER_LOGOUT")
ev:RegisterEvent("PLAYER_REGEN_DISABLED")
ev:RegisterEvent("PLAYER_REGEN_ENABLED")
ev:RegisterEvent("LOOT_READY")
ev:RegisterEvent("ZONE_CHANGED_NEW_AREA")
ev:RegisterEvent("PLAYER_MOUNT_DISPLAY_CHANGED")
ev:RegisterUnitEvent("UNIT_SPELLCAST_CHANNEL_START", "player")
ev:RegisterUnitEvent("UNIT_SPELLCAST_CHANNEL_STOP", "player")

ev:SetScript("OnEvent", function(_, e, ...)
	if e == "PLAYER_LOGIN" then
		MasterBaiterProDB = MasterBaiterProDB or {}
		fill(MasterBaiterProDB, DEFAULTS)
		MBP.db = MasterBaiterProDB
		RestoreCVars() -- a session left open by a crash or disconnect gives your settings back
		SetCastAttributes()
		if MBP.InitPrices then MBP.InitPrices() end
		if MBP.BuildUI then MBP.BuildUI() end
		C_Timer.NewTicker(5, function()
			if S.active and not S.fishing and not S.paused then
				local idle = (MBP.db.idleMinutes or 3) * 60
				if idle > 0 and GetTime() - S.lastAction > idle then MBP.Stop("idle") end
			end
		end)
	elseif e == "PLAYER_LOGOUT" then
		if S.active then MBP.Stop("logout", true) end
		RestoreCVars()
	elseif e == "PLAYER_REGEN_DISABLED" then
		-- Fires just before combat lockdown, so the key can still be handed back.
		if S.active then
			S.paused = true
			ClearOverrideBindings(owner)
			if MBP.Refresh then MBP.Refresh() end
		end
	elseif e == "PLAYER_REGEN_ENABLED" then
		if pendingAttr then SetCastAttributes() end
		if S.active then S.paused = false; S.lastAction = GetTime() end
		if S.active or pendingBind then MBP.ApplyBinding() end
		if MBP.Refresh then MBP.Refresh() end
	elseif e == "UNIT_SPELLCAST_CHANNEL_START" then
		local _, _, eventSpell = ...
		local fishing, startMS, endMS = IsFishingChannel(eventSpell)
		if MBP.debug then say("Channel start: spell " .. tostring(eventSpell) .. ", fishing = " .. tostring(fishing)) end
		if not fishing then return end
		if not S.active then
			if MBP.db and MBP.db.autoStart and not InCombatLockdown() then MBP.Start(true) else return end
		end
		S.fishing, S.looted = true, false
		S.casts = S.casts + 1
		S.lastAction = GetTime()
		S.castStart = (startMS or GetTime() * 1000) / 1000
		S.castEnd = (endMS or (GetTime() + 20) * 1000) / 1000
		local zone = GetRealZoneText and GetRealZoneText()
		if zone and zone ~= "" then MBP.db.zones[zone] = true end
		MBP.ApplyBinding()
		CheckBags()
		if UnitExists("target") and not S.warnedTarget then
			S.warnedTarget = true
			say("Tip: clear your target (Escape) so your key reaches the bobber instead of " .. tostring(UnitName("target")) .. ".")
		end
		if MBP.Refresh then MBP.Refresh() end
	elseif e == "UNIT_SPELLCAST_CHANNEL_STOP" then
		if not S.fishing then return end
		S.fishing = false
		S.lastAction = GetTime()
		MBP.ApplyBinding()
		C_Timer.After(1.2, function()
			if S.active and not S.looted then
				S.misses = S.misses + 1
				S.streak = 0
				if MBP.OnMiss then MBP.OnMiss() end
				if MBP.Refresh then MBP.Refresh() end
			end
		end)
		if MBP.Refresh then MBP.Refresh() end
	elseif e == "LOOT_READY" then
		RecordLoot()
	elseif e == "ZONE_CHANGED_NEW_AREA" then
		if S.active then
			local zone = GetRealZoneText and GetRealZoneText()
			if zone and zone ~= "" then MBP.db.zones[zone] = true end
		end
	elseif e == "PLAYER_MOUNT_DISPLAY_CHANGED" then
		if S.active and not S.fishing and IsMounted and IsMounted() then MBP.Stop("mount") end
	end
end)

-- Slash commands ----------------------------------------------------------------------------------
local function onoff(v)
	if v == "on" then return true elseif v == "off" then return false end
end

local HELP = {
	"/mbp  show or hide the panel",
	"/mbp start | stop  begin or end a session (casting Fishing also begins one)",
	"/mbp key F  choose your one key (now: %s)",
	"/mbp sound on|off  loud splash mode: SFX up, music and ambience off",
	"/mbp soft on|off  let the key reach the bobber (soft interact)",
	"/mbp autoloot on|off  turn on auto loot while fishing",
	"/mbp idle 3  end the session after N idle minutes (0 = never)",
	"/mbp scan on|off  price your fish automatically when you open the auction house",
	"/mbp prices  list the price of everything you have caught",
	"/mbp toasts on|off  the pop-up for every catch",
	"/mbp jackpot 100  gold value that counts as a jackpot catch",
	"/mbp summary on|off  show the summary card when a session ends",
	"/mbp records | ach | last | reset",
	"/mbp debug  check why the key is not reaching the bobber",
}

SLASH_MASTERBAITERPRO1, SLASH_MASTERBAITERPRO2, SLASH_MASTERBAITERPRO3 = "/mbp", "/baiter", "/masterbaiter"
SlashCmdList.MASTERBAITERPRO = function(input)
	local db = MBP.db
	if not db then return end
	local cmd, arg = (input or ""):match("^%s*(%S*)%s*(.-)%s*$")
	cmd = (cmd or ""):lower()
	local larg = (arg or ""):lower()
	if cmd == "" then
		if MBP.TogglePanel then MBP.TogglePanel() end
	elseif cmd == "start" then MBP.Start(false)
	elseif cmd == "stop" or cmd == "end" then MBP.Stop("manual")
	elseif cmd == "key" then
		if InCombatLockdown() then say("Change your key after combat."); return end
		if arg == "" then say("Your one key is |cffffd24a" .. (db.key or "none") .. "|r. Try /mbp key F"); return end
		db.key = arg:upper()
		say("Your one key is now |cffffd24a" .. db.key .. "|r. It only changes while a session is running.")
		MBP.ApplyBinding()
	elseif cmd == "sound" or cmd == "soft" or cmd == "autoloot" or cmd == "summary" or cmd == "scan" or cmd == "toasts" then
		local field = ({ sound = "boostSound", soft = "softInteract", autoloot = "autoLoot", summary = "summary", scan = "autoScan", toasts = "toasts" })[cmd]
		local v = onoff(larg)
		if v == nil then v = not db[field] end
		db[field] = v
		say(cmd .. " is now " .. (v and "|cff40ff40on|r" or "|cffff4040off|r") .. ((cmd == "sound" or cmd == "soft" or cmd == "autoloot") and S.active and ". Takes effect next session." or "."))
	elseif cmd == "idle" then
		local n = tonumber(arg)
		if n and n >= 0 and n <= 120 then db.idleMinutes = n; say("Sessions end after " .. (n == 0 and "never" or (n .. " idle minute" .. (n == 1 and "" or "s"))) .. ".")
		else say("Usage: /mbp idle 3") end
	elseif cmd == "jackpot" then
		local n = tonumber(arg)
		if n and n >= 1 then db.jackpot = math.floor(n); say("A catch worth " .. MBP.Gold(db.jackpot * 10000) .. " or more is a jackpot.")
		else say("Usage: /mbp jackpot 100  (now " .. MBP.Gold((db.jackpot or 100) * 10000) .. ")") end
	elseif cmd == "prices" then
		local rows = MBP.TopCatches("all", 40)
		if #rows == 0 then say("Nothing caught yet."); return end
		say("What your catches are worth (each):")
		for _, r in ipairs(rows) do
			print(string.format("  %s  %s  |cff888888%s|r", r.link or ("item:" .. r.id), MBP.Coins(r.unit), MBP.SourceText(r.src, r.age)))
		end
		say("Open the auction house to refresh prices" .. (MBP.HasPriceAddon() and "." or ", or install Auctionator or TSM."))
	elseif cmd == "debug" then
		MBP.debug = not MBP.debug
		say("Debug " .. (MBP.debug and "on" or "off") .. ".")
		local key = db.key or "?"
		local action = GetBindingAction and GetBindingAction(key, true) or "?"
		say("Session: " .. tostring(S.active) .. ", line in water: " .. tostring(S.fishing) .. ", paused: " .. tostring(S.paused))
		say("Key " .. key .. " is bound to: " .. tostring(action))
		for _, n in ipairs({ "SoftTargetInteract", "SoftTargetInteractRange", "SoftTargetInteractArc", "autoLootDefault" }) do
			say(n .. " = " .. tostring(GetCV(n)))
		end
		local soft = UnitExists and UnitExists("softinteract") and UnitName("softinteract")
		say("Soft interact target: " .. tostring(soft or "none") .. (UnitExists("target") and (". You also have a target: " .. tostring(UnitName("target"))) or ""))
	elseif cmd == "records" then
		local r, t = db.records, db.totals
		say(string.format("All time: %s catches over %s sessions, %s fishing, %s earned.",
			BreakUpLargeNumbers(t.catches), t.sessions, MBP.Clock(t.seconds), MBP.Gold(t.copper)))
		say("Most in one session: " .. (r.session or 0) .. ". Longest streak: " .. (r.streak or 0) .. ". Best gold per hour: " .. MBP.Gold(r.gph or 0) .. ".")
		if r.bestLink then say("Most valuable catch: " .. r.bestLink .. " (" .. MBP.Gold(r.bestValue or 0) .. ")") end
	elseif cmd == "ach" then
		local n = 0
		for _, a in ipairs(MBP.ACH) do
			local done = db.ach[a.id]
			if done then n = n + 1 end
			print((done and "|cffffd24a" or "|cff888888") .. a.name .. "|r  " .. a.desc)
		end
		say(n .. " of " .. #MBP.ACH .. " achievements.")
	elseif cmd == "last" then
		if db.lastSummary and MBP.ShowSummary then MBP.ShowSummary(db.lastSummary) else say("No session yet. Go cast a line.") end
	elseif cmd == "reset" then
		if larg ~= "confirm" then say("This wipes your records, catches and achievements. Type |cffffd24a/mbp reset confirm|r to do it."); return end
		if S.active then MBP.Stop("manual", true) end
		local keep = { key = db.key, point = db.point, prices = db.prices }
		wipe(db)
		fill(db, DEFAULTS)
		for k, v in pairs(keep) do db[k] = v end
		say("Records wiped. Fresh start.")
		if MBP.Refresh then MBP.Refresh() end
	else
		say("Commands:")
		for _, l in ipairs(HELP) do print("  " .. l:format(db.key or "none")) end
	end
end
