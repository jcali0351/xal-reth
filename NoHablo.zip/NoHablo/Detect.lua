-- No Hablo: tells whether a chat line is Spanish.
-- It scores words that are Spanish and not English, Spanish spelling (ñ, ¿, ¡, accented vowels), and weighs them
-- against common English words, so "la la la", "no", "me too" or "taco" are left alone.
local NH = NoHablo

local function set(list) local t = {}; for w in list:gmatch("%S+") do t[w] = true end; return t end

-- Words that are Spanish and essentially never English (one of these in a short line is enough)
local STRONG = set([[
que qué porque porqué pero para por con como cómo cuando cuándo donde dónde quien quién quiero quieres quiere
tengo tienes tiene tenemos estoy estás esta está estamos están soy eres somos hola gracias alguien nadie
algo todos todas mucho muchos mucha muy también tambien ahora aquí aqui allí alli vamos venga ven
bueno buena buenos buenas noches días dias tardes amiga amigos hermano hermana gente ayuda ayudar
necesito necesita puedo puedes puede podemos hacer hago hace hacemos sabe saber sé creo crees dónde
había habia fue eres verdad oye mira mirá jaja jajaja jajajaja jeje xfa porfa favor perdón perdon
disculpa lo siento entonces luego después despues antes siempre nunca tampoco quizás quizas sí ese esa eso
este estos estas esos esas mi mis tu tus su nuestro nuestra vosotros ustedes nosotros ellos ellas él
los las unos unas una uno dos tres cuatro cinco grupo mazmorra banda hermandad gremio mas q onda pues neta chido vale tio mision misiones buscando busco espera momento ayudame oro dias manana tambien despues aqui alli quizas perdon
]])
-- Short words both languages share; they count only beside stronger evidence
local WEAK = set([[ de la el en y o no me te se lo le es a un al del hay nada todo amigo era son sus ya si ]])
-- Common English words: their presence argues against Spanish
local ENGLISH = set([[
the and is are you i it to of in that this was for on with have be not but what all were we when
your can said there use an each which she do how their if will up other about out many then them these
so some her would make like him into time has look two more write go see number way could people my than
first water been call who oil its now find long down day did get come made may part lol lmao ok okay yes
thanks thx please pls wts wtb lf lfg lfm need anyone guild join raid dungeon group hi hey sup
]])

NH.MIN_WORDS = 1
local FOLD = { ["\195\161"] = "a", ["\195\169"] = "e", ["\195\173"] = "i", ["\195\179"] = "o", ["\195\186"] = "u", ["\195\177"] = "n", ["\195\188"] = "u",
	["\195\129"] = "a", ["\195\137"] = "e", ["\195\141"] = "i", ["\195\147"] = "o", ["\195\154"] = "u", ["\195\145"] = "n", ["\194\191"] = " ", ["\194\161"] = " " }

-- Returns true when the line reads as Spanish
function NH.IsSpanish(msg)
	if type(msg) ~= "string" or msg == "" then return false end
	-- strip links, colours, textures and raid icons so item names and {star} don't count
	local s = msg:gsub("|H.-|h(.-)|h", " "):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("|T.-|t", " "):gsub("{.-}", " ")
	local score, english, words = 0, 0, 0
	-- Spanish spelling: ñ, ¿, ¡ are decisive; an accented vowel is strong
	if s:find("ñ", 1, true) or s:find("Ñ", 1, true) or s:find("¿", 1, true) or s:find("¡", 1, true) then score = score + 3 end
	for _, ch in ipairs({ "á", "é", "í", "ó", "ú", "Á", "É", "Í", "Ó", "Ú" }) do
		if s:find(ch, 1, true) then score = score + 1.5; break end
	end
	-- fold Spanish letters to plain ones and drop the opening marks, so words split cleanly everywhere
	for from, to in pairs(FOLD) do s = s:gsub(from, to) end
	s = s:lower() -- only after folding: some locales' lower() rewrites the bytes of accented letters
	for w in s:gmatch("%a+") do
		words = words + 1
		if STRONG[w] then score = score + 2
		elseif WEAK[w] then score = score + 0.5
		elseif ENGLISH[w] then english = english + 1 end
	end
	if words == 0 then return false end
	-- a one or two word line needs one strong word ("hola", "gracias", "alguien?") and no English
	if words <= 2 then return score >= 2 and english == 0 end
	-- longer lines: clear Spanish evidence that outweighs the English in them
	return score >= 3 and score > english * 1.5
end
