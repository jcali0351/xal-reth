-- No Hablo: a chat filter for your own screen. With the red button on, text chat in Spanish is hidden from
-- your chat windows, and anyone who writes in Spanish is muted for the rest of the session. Nothing is sent,
-- reported or ignored server-side; turn the button off and everything shows again.
local ADDON = ...
local NH = {}
_G.NoHablo = NH
NH.VERSION = "1.0"

local DEFAULTS = { enabled = false, speakers = true, hidden = 0, shown = true }
local db
local muted = {} -- senders muted this session: name -> number of lines hidden
local function say(m) print("|cffff4d4dNo Hablo|r: " .. m) end
NH.Say = say

-- Every text chat a player can type into
local EVENTS = {
	"CHAT_MSG_SAY", "CHAT_MSG_YELL", "CHAT_MSG_EMOTE", "CHAT_MSG_CHANNEL", "CHAT_MSG_WHISPER",
	"CHAT_MSG_GUILD", "CHAT_MSG_OFFICER", "CHAT_MSG_PARTY", "CHAT_MSG_PARTY_LEADER", "CHAT_MSG_RAID",
	"CHAT_MSG_RAID_LEADER", "CHAT_MSG_RAID_WARNING", "CHAT_MSG_INSTANCE_CHAT", "CHAT_MSG_INSTANCE_CHAT_LEADER",
	"CHAT_MSG_BN_WHISPER", "CHAT_MSG_COMMUNITIES_CHANNEL",
}

local function Me(sender)
	if not sender then return false end
	local me = UnitName("player")
	return sender == me or sender:match("^([^%-]+)") == me
end

local function Secret(v) return issecretvalue and issecretvalue(v) end

-- The chat filter: returning true hides the line from every chat window
local function Filter(_, event, msg, sender, ...)
	if not (db and db.enabled) then return false end
	-- Midnight hides some chat from addons during encounters; those lines are left exactly as they are
	if Secret(msg) or Secret(sender) then return false end
	if Me(sender) then return false end
	local key = sender and sender ~= "" and sender or nil
	local hide = false
	if key and db.speakers and muted[key] then hide = true
	elseif NH.IsSpanish(msg) then
		hide = true
		if key and db.speakers then muted[key] = muted[key] or 0 end
	end
	if hide then
		db.hidden = (db.hidden or 0) + 1
		if key and muted[key] then muted[key] = muted[key] + 1 end
		if NH.Refresh then NH.Refresh() end
	end
	return hide
end

local function AddFilters()
	local add = (ChatFrameUtil and ChatFrameUtil.AddMessageEventFilter) or ChatFrame_AddMessageEventFilter
	if not add then say("this version of the game has no chat filters, so No Hablo cannot work here."); return end
	for _, e in ipairs(EVENTS) do pcall(add, e, Filter) end
end

function NH.SetEnabled(on)
	db.enabled = on and true or false
	if not db.enabled then wipe(muted) end
	say(db.enabled and "Spanish is now hidden from your chat." or "Spanish chat shows again.")
	if NH.Refresh then NH.Refresh() end
end
function NH.Toggle() NH.SetEnabled(not db.enabled) end
function NH.MutedCount() local n = 0; for _ in pairs(muted) do n = n + 1 end; return n end
function NH.Muted() return muted end
function NH.DB() return db end

local ev = CreateFrame("Frame")
ev:RegisterEvent("ADDON_LOADED")
ev:SetScript("OnEvent", function(_, e, name)
	if name ~= ADDON then return end
	NoHabloDB = NoHabloDB or {}
	for k, v in pairs(DEFAULTS) do if NoHabloDB[k] == nil then NoHabloDB[k] = v end end
	db = NoHabloDB
	AddFilters()
	if NH.BuildUI then NH.BuildUI() end
	ev:UnregisterEvent("ADDON_LOADED")
end)

SLASH_NOHABLO1, SLASH_NOHABLO2 = "/nohablo", "/nh"
SlashCmdList.NOHABLO = function(input)
	if not db then return end
	local cmd, arg = (input or ""):match("^%s*(%S*)%s*(.-)%s*$")
	cmd = (cmd or ""):lower()
	if cmd == "" then if NH.TogglePanel then NH.TogglePanel() end
	elseif cmd == "on" then NH.SetEnabled(true)
	elseif cmd == "off" then NH.SetEnabled(false)
	elseif cmd == "speakers" then
		db.speakers = not db.speakers
		if not db.speakers then wipe(muted) end
		say(db.speakers and "Anyone who writes in Spanish is muted for the session." or "Only Spanish lines are hidden; their other lines show.")
	elseif cmd == "list" then
		local n = 0
		for who, c in pairs(muted) do n = n + 1; print("  " .. who .. "  (" .. c .. " hidden)") end
		say(n == 0 and "Nobody is muted right now." or (n .. " muted this session. /nh allow Name lets one back in."))
	elseif cmd == "allow" and arg ~= "" then
		local found
		for who in pairs(muted) do
			if who:lower() == arg:lower() or (who:match("^([^%-]+)") or ""):lower() == arg:lower() then muted[who] = nil; found = who end
		end
		say(found and (found .. " can be seen again.") or ("Nobody called " .. arg .. " is muted."))
	elseif cmd == "test" then
		say("\"" .. arg .. "\" " .. (NH.IsSpanish(arg) and "would be hidden." or "would show."))
	else
		say("/nh  show or hide the button · /nh on | off · /nh speakers (mute whole speakers or only lines) · /nh list · /nh allow Name · /nh test some words")
	end
end
