-- No Hablo: one small movable box with one big red button.
local NH = NoHablo
local WHITE = "Interface\\Buttons\\WHITE8X8"
local FONT = "Fonts\\FRIZQT__.TTF"
local box, button

local function Grad(tex, a, b)
	tex:SetTexture(WHITE)
	if tex.SetGradient and CreateColor then
		local ok = pcall(tex.SetGradient, tex, "VERTICAL", CreateColor(a[1], a[2], a[3], 1), CreateColor(b[1], b[2], b[3], 1))
		if ok then return end
	end
	tex:SetVertexColor(b[1], b[2], b[3], 1)
end

local function Edge(f, r, g, b, a)
	f.edges = f.edges or {}
	for i, p in ipairs({ { "TOPLEFT", "TOPRIGHT", nil, 1 }, { "BOTTOMLEFT", "BOTTOMRIGHT", nil, 1 }, { "TOPLEFT", "BOTTOMLEFT", 1 }, { "TOPRIGHT", "BOTTOMRIGHT", 1 } }) do
		local t = f.edges[i] or f:CreateTexture(nil, "BORDER")
		t:SetColorTexture(r, g, b, a or 1)
		t:ClearAllPoints(); t:SetPoint(p[1]); t:SetPoint(p[2])
		if p[3] then t:SetWidth(p[3]) end
		if p[4] then t:SetHeight(p[4]) end
		f.edges[i] = t
	end
end

function NH.BuildUI()
	if box then return end
	local db = NH.DB()
	box = CreateFrame("Frame", "NoHabloBox", UIParent)
	box:SetSize(176, 74)
	box:SetFrameStrata("MEDIUM")
	box:SetClampedToScreen(true)
	box:SetMovable(true)
	box:EnableMouse(true)
	box:RegisterForDrag("LeftButton")
	box:SetScript("OnDragStart", box.StartMoving)
	box:SetScript("OnDragStop", function(self)
		self:StopMovingOrSizing()
		local p, _, rp, x, y = self:GetPoint()
		db.point = { p, rp, x, y }
	end)
	if db.point then box:SetPoint(db.point[1], UIParent, db.point[2], db.point[3], db.point[4])
	else box:SetPoint("TOP", UIParent, "TOP", 0, -140) end

	local bg = box:CreateTexture(nil, "BACKGROUND")
	bg:SetAllPoints()
	Grad(bg, { 0.04, 0.04, 0.05 }, { 0.12, 0.11, 0.13 })
	bg:SetAlpha(0.92)
	Edge(box, 0.35, 0.35, 0.38, 1)

	local title = box:CreateFontString(nil, "OVERLAY")
	title:SetFont(FONT, 10, "")
	title:SetTextColor(0.75, 0.75, 0.78)
	title:SetPoint("TOPLEFT", 8, -6)
	title:SetText("NO HABLO")

	local close = CreateFrame("Button", nil, box)
	close:SetSize(16, 16)
	close:SetPoint("TOPRIGHT", -3, -2)
	close.t = close:CreateFontString(nil, "OVERLAY")
	close.t:SetFont(FONT, 11, "")
	close.t:SetPoint("CENTER")
	close.t:SetText("x")
	close.t:SetTextColor(0.6, 0.6, 0.62)
	close:SetScript("OnClick", function() NH.HidePanel() end)

	-- the red button
	button = CreateFrame("Button", "NoHabloButton", box)
	button:SetSize(160, 32)
	button:SetPoint("TOP", 0, -20)
	button.bg = button:CreateTexture(nil, "BACKGROUND")
	button.bg:SetAllPoints()
	button.hl = button:CreateTexture(nil, "HIGHLIGHT")
	button.hl:SetAllPoints()
	button.hl:SetColorTexture(1, 1, 1, 0.12)
	button.text = button:CreateFontString(nil, "OVERLAY")
	button.text:SetFont(FONT, 13, "OUTLINE")
	button.text:SetPoint("CENTER")
	button:SetScript("OnClick", function() NH.Toggle() end)
	button:SetScript("OnEnter", function(self)
		GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
		GameTooltip:AddLine("No Hablo")
		GameTooltip:AddLine("Click to hide text chat written in Spanish from your chat windows. Anyone who writes in Spanish is muted for the rest of the session. Only your own screen changes.", 1, 1, 1, true)
		GameTooltip:AddLine("/nh list  shows who is muted · /nh allow Name  lets someone back", 0.7, 0.7, 0.7, true)
		GameTooltip:Show()
	end)
	button:SetScript("OnLeave", GameTooltip_Hide)

	box.status = box:CreateFontString(nil, "OVERLAY")
	box.status:SetFont(FONT, 9, "")
	box.status:SetPoint("BOTTOM", 0, 6)
	box.status:SetTextColor(0.7, 0.7, 0.72)

	if db.shown then box:Show() else box:Hide() end
	NH.Refresh()
end

function NH.Refresh()
	if not box then return end
	local db = NH.DB()
	if db.enabled then
		Grad(button.bg, { 0.45, 0.02, 0.02 }, { 0.95, 0.10, 0.10 })
		Edge(button, 1, 0.75, 0.75, 1)
		button.text:SetText("BLOCKING SPANISH")
		button.text:SetTextColor(1, 1, 1)
		local n = NH.MutedCount()
		box.status:SetText(string.format("%d line%s hidden · %d muted", db.hidden or 0, (db.hidden or 0) == 1 and "" or "s", n))
	else
		Grad(button.bg, { 0.55, 0.05, 0.05 }, { 0.85, 0.12, 0.12 })
		Edge(button, 0.55, 0.15, 0.15, 1)
		button.text:SetText("BLOCK SPANISH")
		button.text:SetTextColor(1, 0.92, 0.92)
		box.status:SetText("Off · click to turn on")
	end
end

function NH.ShowPanel() if box then box:Show(); NH.DB().shown = true end end
function NH.HidePanel() if box then box:Hide(); NH.DB().shown = false; NH.Say("type /nh to bring the button back.") end end
function NH.TogglePanel() if box and box:IsShown() then NH.HidePanel() else NH.ShowPanel() end end
