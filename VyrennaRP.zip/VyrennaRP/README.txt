VYRENNA RP  v1.0  -  THE TEACHINGS OF THE SACRED TRIANGLE   (WoW Retail / Midnight 12.1)
=========================================================================================
Reads the Teachings of the Sacred Triangle aloud as /emotes, one verse at a time, on a timer.
The same panel, Book, timer, dice, upload, synth pad and morph as Xal'Reth RP, in Vyrenna's
green and gold.

  The Preface               2 chapters
  Book I    Vyrenna         the Radiant Scroll, 24 chapters
  Book II   Xal'Reth        the Low Scroll, 24 chapters
  Book III  Nhalor          the Veiled Scroll, 24 chapters
  Book IV   The Turning     the Three Together, 3 chapters
  77 chapters, 509 verses. Read a single verse, a whole chapter, a whole book,
  or the whole Teachings from first verse to last.
  Your Own and Uploads      paste in your own emotes and save them as readings

INSTALL
  Move this "VyrennaRP" folder into
    World of Warcraft\_retail_\Interface\AddOns\
  Fully restart WoW (new art only loads on a full restart, not /reload).
  It runs happily alongside Xal'Reth RP. They keep separate settings.

THE PANEL  (/vrp shows it; drag it anywhere; X hides it)
  Vyrenna sits in a turning ring of crescents with the chapter's icon as a badge.
  Every verse she erupts in gold: a halo, turning light rays, shockwave rings,
  sparkles and a golden border flare, with a soft synth pad (speaker button or
  /vrp sound to turn it off).
  Every 15 seconds she slowly takes her radiant form, holds it, and returns
  (/vrp morph to turn it off). The Book's portrait shines too.
  Play/Pause, Next, Stop     read, pause, skip a verse, close the Teachings
  Teachings (four squares)   open the Teachings
  Timer slider               5 to 60 seconds between emotes
  Dice                       random timing: every gap is a random 5-35 seconds
  Loop / Test / Shuffle      click to toggle (the Teachings are always read in order)
  [ Upload ]                 open the Upload window
  [ Random ]                 Vyrenna chooses a chapter (shift-click to begin at once)

THE TEACHINGS  (four-squares button, or /vrp book)
  Books:     the Preface, Books I to IV, Your Own and Uploads
  Chapters:  The Whole Book, then every chapter by number
  Readings:  the whole chapter first, then each verse on its own
             left-click to choose, right-click to begin at once
  Search:    a verse (1.4.2) or any words, then Enter. It searches every verse.

COMMANDS  (/vrp or /vyrenna)
  /vrp                    show the panel
  /vrp start 1.4          Book I, chapter 4 (I.4 works too; book 0 is the Preface)
  /vrp start 1.4.2        just verse 2 of that chapter
  /vrp start b3           the whole Book of Nhalor
  /vrp start book         the whole Teachings, all 509 verses (bring snacks)
  /vrp pause | resume | next | stop
  /vrp random [start]     a random chapter
  /vrp search <words>     find verses
  /vrp preview <reading>  read it to yourself in chat first
  /vrp sets               list every book and chapter
  /vrp interval <5-60>    /vrp dice [min max]
  /vrp loop | shuffle | test | sound | morph
  /vrp add <text>  /vrp list  /vrp del <n>   your own emotes ({target} works)
  /vrp upload             paste emotes and save them as a reading
  /vrp pronouns auto|she|he|they    /vrp reset    /vrp help

Every line is an /emote, so the game puts your name in front:
  Silverleafe reads, "Wisdom is knowing what to give. Balance is knowing how much."
Long verses continue over two emotes so nothing is cut off. Emotes pause during
combat and boss chat lockdown and resume afterwards.

The Teachings online: https://jcali0351.github.io/xal-reth/teachings-of-the-triangle.html
Hold light.  And let go well.
