--[[ Coil Ledger: the Ministry of Spare Change keeps its books.

  Open the guild bank and the Ledger quietly records it: the gold, every tab you can see (each slot's
  item and count), the money log and each tab's item log. When it is done it says so in chat. While the bank
  stays open it records it again whenever the gold changes or items move.

  Then either:
    * type /ledger, press Ctrl+C to copy the export, and paste it into the Sanctum Editor
      (Guild Bank tab) on the website, or
    * /reload or log out, and upload the file
      World of Warcraft\_retail_\WTF\Account\<ACCOUNT>\SavedVariables\CoilLedger.lua there instead.

  The website keeps every ledger entry it has ever been given, so upload now and then and the history
  grows beyond the game's own short logs. The Ledger also keeps its own history of the guild's gold (a point
  each time the bank is recorded and the gold has changed) and sends all of it with every export.

  The gold is written down only once the server has sent it, checked against what the bank window shows.

  /ledger              show the export to copy
  /ledger scan         record the bank again (it must be open)
  /ledger gold <amt>   set the guild's gold by hand if it was read wrong (e.g. /ledger gold 950123g 45s 6c)
  /ledger help         this list
]]

local ADDON = ...
local VERSION = "1.3.0"
local SLOTS = MAX_GUILDBANK_SLOTS_PER_TAB or 98
local MAXTABS = MAX_GUILDBANK_TABS or 8
local VIOLET = "|cffb07cff"

CoilLedgerDB = CoilLedgerDB or {}

local function say(msg) print(VIOLET .. "Coil Ledger|r: " .. msg) end

--------------------------------------------------------------------------- JSON
local function jstr(s)
  s = tostring(s or "")
  s = s:gsub('\\', '\\\\'):gsub('"', '\\"'):gsub('\n', '\\n'):gsub('\r', ''):gsub('\t', ' ')
  s = s:gsub('[%z\1-\31]', '')
  return '"' .. s .. '"'
end
local encode
local function isArray(t)
  local n = 0
  for k in pairs(t) do if type(k) ~= "number" then return false end n = n + 1 end
  return n == #t
end
encode = function(v)
  local tv = type(v)
  if tv == "nil" then return "null"
  elseif tv == "boolean" then return v and "true" or "false"
  elseif tv == "number" then
    if v ~= v or v == math.huge or v == -math.huge then return "0" end
    -- "%.0f" is exact for whole numbers up to 2^53, whatever size of integer the game's %d uses.
    if math.floor(v) == v then return string.format("%.0f", v) end
    return string.format("%.4f", v)
  elseif tv == "string" then return jstr(v)
  elseif tv == "table" then
    local out = {}
    if isArray(v) then
      for i = 1, #v do out[#out + 1] = encode(v[i]) end
      return "[" .. table.concat(out, ",") .. "]"
    end
    local keys = {}
    for k in pairs(v) do keys[#keys + 1] = tostring(k) end
    table.sort(keys)
    for _, k in ipairs(keys) do out[#out + 1] = jstr(k) .. ":" .. encode(v[k]) end
    return "{" .. table.concat(out, ",") .. "}"
  end
  return "null"
end

--------------------------------------------------------------------------- item links
-- |cnIQ4:|Hitem:12345:...|h[Name]|h|r  (or the older |cffa335ee colour form)
local QUALITY_BY_COLOR = { ["9d9d9d"] = 0, ["ffffff"] = 1, ["1eff00"] = 2, ["0070dd"] = 3, ["a335ee"] = 4, ["ff8000"] = 5, ["e6cc80"] = 6, ["00ccff"] = 7 }
local function parseLink(link)
  if type(link) ~= "string" then return nil end
  local id = tonumber(link:match("item:(%d+)"))
  local name = link:match("|h%[(.-)%]|h")
  local q = tonumber(link:match("|cnIQ(%d+):"))
  if not q then local c = link:match("|cff(%x%x%x%x%x%x)"); q = c and QUALITY_BY_COLOR[c:lower()] end
  if not q and id and C_Item and C_Item.GetItemQualityByID then q = C_Item.GetItemQualityByID(id) end
  return id, name, q
end

--------------------------------------------------------------------------- reading the bank
local function hoursAgo(y, m, d, h) return (((y or 0) * 365 + (m or 0) * 30 + (d or 0)) * 24 + (h or 0)) end

local function readTabs()
  local tabs = {}
  for t = 1, GetNumGuildBankTabs() do
    local name, icon, viewable = GetGuildBankTabInfo(t)
    local tab = { index = t, name = name or ("Tab " .. t), icon = icon, viewable = viewable and true or false, slots = {} }
    if viewable then
      for s = 1, SLOTS do
        local texture, count, _, _, quality = GetGuildBankItemInfo(t, s)
        if texture then
          local link = GetGuildBankItemLink(t, s)
          local id, iname, lq = parseLink(link)
          tab.slots[#tab.slots + 1] = { slot = s, id = id, name = iname, count = count or 1, quality = quality or lq, icon = texture }
        end
      end
    end
    tabs[#tabs + 1] = tab
  end
  return tabs
end

local function readLogs(now)
  local entries = {}
  local nMoney = GetNumGuildBankMoneyTransactions and GetNumGuildBankMoneyTransactions() or 0
  for i = 1, nMoney do
    local kind, who, amount, y, m, d, h = GetGuildBankMoneyTransaction(i)
    if kind then
      entries[#entries + 1] = { log = "money", type = kind, name = who or "", amount = amount or 0, hoursAgo = hoursAgo(y, m, d, h), t = now - hoursAgo(y, m, d, h) * 3600, order = i }
    end
  end
  for t = 1, GetNumGuildBankTabs() do
    local _, _, viewable = GetGuildBankTabInfo(t)
    if viewable then
      for i = 1, (GetNumGuildBankTransactions(t) or 0) do
        local kind, who, link, count, tab1, tab2, y, m, d, h = GetGuildBankTransaction(t, i)
        if kind then
          local id, iname, q = parseLink(link)
          entries[#entries + 1] = { log = "item", tab = t, type = kind, name = who or "", id = id, item = iname, quality = q, count = count or 1,
            fromTab = tab1, toTab = tab2, hoursAgo = hoursAgo(y, m, d, h), t = now - hoursAgo(y, m, d, h) * 3600, order = i }
        end
      end
    end
  end
  return entries
end

--------------------------------------------------------------------------- the gold, checked
-- The game only knows the guild's true gold once the server has sent it (GUILDBANK_UPDATE_MONEY after the bank opens);
-- read too early, GetGuildBankMoney() can hand back an old cached amount. So the Ledger waits for that, and also reads
-- the amount the bank window itself is showing, and keeps whichever it can trust. /ledger gold <amount> sets it by hand.
local moneyArrived, typedGold, typedBase = false, nil, 0

local function windowGold()
  local mf = _G.GuildBankMoneyFrame or (_G.GuildBankFrame and (_G.GuildBankFrame.MoneyFrame or _G.GuildBankFrame.moneyFrame))
  local v = mf and tonumber(mf.staticMoney)
  if v and v > 0 then return v end
end

local function readGold()
  local api = tonumber(GetGuildBankMoney and GetGuildBankMoney()) or 0
  local shown = windowGold()
  -- an amount typed by hand follows later deposits and withdrawals while the bank stays open
  if typedGold then return math.max(0, typedGold + (api - typedBase)), "typed", api, shown end
  if shown and shown ~= api then return shown, "window", api, shown end   -- what the bank window shows wins
  return api, moneyArrived and "server" or "unconfirmed", api, shown
end

-- the Ledger's own record of the hoard over time, sent to the website with every export
local function remember(t, gold, source)
  if source == "unconfirmed" then return end
  local h = CoilLedgerDB.history or {}
  CoilLedgerDB.history = h
  local last = h[#h]
  if last and last.gold == gold and t - last.t < 1800 then return end   -- unchanged: one point per half hour is enough
  h[#h + 1] = { t = t, gold = gold }
  while #h > 2000 do table.remove(h, 1) end
end

local function build()
  local now = time()
  local guild, _, _, realm = GetGuildInfo("player")
  local gold, source, api, shown = readGold()
  remember(now, gold, source)
  local data = {
    format = "coil-ledger", version = VERSION, scannedAt = now, scannedBy = UnitName("player"),
    guild = guild or "", realm = realm or GetRealmName(), region = GetCurrentRegionName and GetCurrentRegionName() or "",
    gold = gold, goldSource = source, goldApi = api, goldShown = shown,
    history = CoilLedgerDB.history or {}, tabs = readTabs(), ledger = readLogs(now),
  }
  local items, kinds = 0, 0
  for _, tab in ipairs(data.tabs) do for _, s in ipairs(tab.slots) do items = items + s.count; kinds = kinds + 1 end end
  CoilLedgerDB.export = encode(data)
  CoilLedgerDB.scannedAt = now
  CoilLedgerDB.summary = { gold = data.gold, goldSource = source, stacks = kinds, items = items, tabs = #data.tabs, entries = #data.ledger }
  return data, items, kinds
end

--------------------------------------------------------------------------- the scan (queries each tab and log, then reads)
local scanning, bankOpen = false, false
local lastScan, rescanQueued = 0, false
local function money(c) return GetCoinTextureString and GetCoinTextureString(c) or (math.floor(c / 10000) .. "g") end

local function scan(quiet)
  if scanning then return end
  if not bankOpen then say("open the guild bank first."); return end
  scanning = true
  local current = GetCurrentGuildBankTab and GetCurrentGuildBankTab() or 1
  local steps = {}
  for t = 1, GetNumGuildBankTabs() do
    steps[#steps + 1] = function() QueryGuildBankTab(t) end
    steps[#steps + 1] = function() QueryGuildBankLog(t) end
  end
  steps[#steps + 1] = function() QueryGuildBankLog(MAXTABS + 1) end   -- the money log
  steps[#steps + 1] = function() if current then QueryGuildBankTab(current) end end
  local i = 0
  local function nextStep()
    if not bankOpen then scanning = false; say("the bank closed before the Ledger finished. Open it again and it will try once more."); return end
    i = i + 1
    if steps[i] then steps[i](); C_Timer.After(0.35, nextStep); return end
    local waited = 0
    local function finish()
      if not bankOpen then scanning = false; return end
      -- wait (up to 8 seconds) for the server to send the guild's gold before writing it down
      if not moneyArrived and not typedGold and not windowGold() and waited < 8 then waited = waited + 1; C_Timer.After(1.0, finish); return end
      scanning = false
      lastScan = GetTime()
      local data, items, kinds = build()
      if not quiet then
        say(string.format("the bank is recorded: %s, %d tabs, %d stacks (%d items), %d ledger entries. Type %s/ledger|r to copy it for the website.",
          money(data.gold), #data.tabs, kinds, items, #data.ledger, VIOLET))
        if data.goldSource == "unconfirmed" then
          say("the server never confirmed the guild's gold, so it may be out of date. Close and reopen the bank, or type " .. VIOLET ..
            "/ledger gold <amount>|r with the amount the bank window shows.")
        elseif data.goldShown and data.goldApi ~= data.goldShown then
          say("the game reported " .. money(data.goldApi) .. " but the bank window shows " .. money(data.goldShown) .. "; the Ledger kept the window's amount.")
        end
      end
    end
    C_Timer.After(1.0, finish)
  end
  nextStep()
end

--------------------------------------------------------------------------- the export window
local win
local function showExport()
  if not CoilLedgerDB.export then say("nothing recorded yet. Open the guild bank and wait for the Ledger to finish."); return end
  if not win then
    win = CreateFrame("Frame", "CoilLedgerExport", UIParent, "BackdropTemplate")
    win:SetSize(560, 380); win:SetPoint("CENTER"); win:SetFrameStrata("DIALOG")
    win:SetMovable(true); win:EnableMouse(true); win:RegisterForDrag("LeftButton")
    win:SetScript("OnDragStart", win.StartMoving); win:SetScript("OnDragStop", win.StopMovingOrSizing)
    win:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 })
    win:SetBackdropColor(0.05, 0.03, 0.09, 0.96); win:SetBackdropBorderColor(0.69, 0.49, 1, 0.8)
    local title = win:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOP", 0, -12); title:SetText(VIOLET .. "The Coil Ledger|r")
    local hint = win:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    hint:SetPoint("TOP", title, "BOTTOM", 0, -6); hint:SetWidth(520)
    hint:SetText("Press Ctrl+C to copy, then paste it into the Sanctum Editor, Guild Bank tab, on the website.")
    win.when = win:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    win.when:SetPoint("TOP", hint, "BOTTOM", 0, -4)
    local sf = CreateFrame("ScrollFrame", nil, win, "UIPanelScrollFrameTemplate")
    sf:SetPoint("TOPLEFT", 14, -70); sf:SetPoint("BOTTOMRIGHT", -34, 44)
    local eb = CreateFrame("EditBox", nil, sf)
    eb:SetMultiLine(true); eb:SetAutoFocus(false); eb:SetFontObject(ChatFontSmall); eb:SetWidth(500); eb:SetMaxLetters(0)
    eb:SetScript("OnEscapePressed", function() win:Hide() end)
    eb:SetScript("OnTextChanged", function(self, user) if user then self:SetText(win.text or ""); self:HighlightText() end end)
    eb:SetScript("OnEditFocusGained", function(self) self:HighlightText() end)
    sf:SetScrollChild(eb); win.eb = eb
    local close = CreateFrame("Button", nil, win, "UIPanelButtonTemplate")
    close:SetSize(110, 24); close:SetPoint("BOTTOMRIGHT", -12, 12); close:SetText(CLOSE or "Close")
    close:SetScript("OnClick", function() win:Hide() end)
    local again = CreateFrame("Button", nil, win, "UIPanelButtonTemplate")
    again:SetSize(130, 24); again:SetPoint("BOTTOMLEFT", 12, 12); again:SetText("Select all")
    again:SetScript("OnClick", function() win.eb:SetFocus(); win.eb:HighlightText() end)
    tinsert(UISpecialFrames, "CoilLedgerExport")
  end
  win.text = CoilLedgerDB.export
  win.eb:SetText(win.text)
  win.when:SetText(CoilLedgerDB.scannedAt and ("Recorded " .. date("%Y-%m-%d %H:%M", CoilLedgerDB.scannedAt)) or "")
  win:Show(); win.eb:SetFocus(); win.eb:HighlightText()
end

--------------------------------------------------------------------------- events and the slash command
-- While the bank stays open, record it again when the gold changes (a deposit or withdrawal) or items move, so /ledger
-- always holds what the bank holds now, not what it held when it was opened. The scan's own tab queries also fire
-- GUILDBANKBAGSLOTS_CHANGED, so item changes are ignored during a scan and for a few seconds after one.
local function rescanSoon(fromItems)
  if not bankOpen or scanning or rescanQueued then return end
  if fromItems and GetTime() - lastScan < 4 then return end
  rescanQueued = true
  C_Timer.After(1.5, function() rescanQueued = false; if bankOpen and not scanning then scan(false) end end)
end

local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_INTERACTION_MANAGER_FRAME_SHOW")
f:RegisterEvent("PLAYER_INTERACTION_MANAGER_FRAME_HIDE")
f:RegisterEvent("GUILDBANK_UPDATE_MONEY")
f:RegisterEvent("GUILDBANKBAGSLOTS_CHANGED")
f:SetScript("OnEvent", function(_, event, kind)
  if event == "GUILDBANK_UPDATE_MONEY" then
    if bankOpen then moneyArrived = true end
    rescanSoon(false); return
  end
  if event == "GUILDBANKBAGSLOTS_CHANGED" then rescanSoon(true); return end
  local banker = Enum and Enum.PlayerInteractionType and Enum.PlayerInteractionType.GuildBanker or 10
  if kind ~= banker then return end
  if event == "PLAYER_INTERACTION_MANAGER_FRAME_SHOW" then
    bankOpen = true; moneyArrived = false; typedGold = nil
    C_Timer.After(0.8, function() scan(false) end)
  else
    bankOpen = false
  end
end)

SLASH_COILLEDGER1 = "/ledger"
SLASH_COILLEDGER2 = "/coilledger"
SlashCmdList.COILLEDGER = function(msg)
  msg = (msg or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")
  if msg == "scan" then scan(false)
  elseif msg:match("^gold") then
    -- /ledger gold 950000   or   /ledger gold 950,123g 45s 6c
    local rest = msg:gsub("^gold%s*", ""):gsub(",", "")
    local g = tonumber(rest:match("^(%d+)%s*g?") or "")
    if not g then say("type the amount the bank window shows, e.g. " .. VIOLET .. "/ledger gold 950123|r or " .. VIOLET .. "/ledger gold 950123g 45s 6c|r."); return end
    if not bankOpen then say("open the guild bank first, then type it again."); return end
    local s, c = tonumber(rest:match("(%d+)%s*s") or 0), tonumber(rest:match("(%d+)%s*c") or 0)
    typedGold = g * 10000 + s * 100 + c
    typedBase = tonumber(GetGuildBankMoney and GetGuildBankMoney()) or 0
    say("the guild's gold is set to " .. money(typedGold) .. " until the bank is closed. Recording the bank again.")
    scan(false)
  elseif msg == "help" then
    say("/ledger shows the export to copy for the website. /ledger scan records the bank again (open it first). " ..
      "/ledger gold <amount> sets the guild's gold by hand if the Ledger read it wrong. The Ledger also records the bank every time you open it.")
  else showExport() end
end
