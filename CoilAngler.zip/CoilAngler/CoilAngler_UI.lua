-- Coil Angler panel and summary card, in the violet and gold of the Coil.
local CA = CoilAngler
local S = CA.S

local VIOLET = { 0.69, 0.49, 1.0 }
local GOLD = { 1.0, 0.82, 0.0 }

local function Backdrop(f, alpha)
	f:SetBackdrop({
		bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8",
		edgeSize = 1, insets = { left = 1, right = 1, top = 1, bottom = 1 },
	})
	f:SetBackdropColor(0.06, 0.03, 0.10, alpha or 0.92)
	f:SetBackdropBorderColor(GOLD[1] * 0.8, GOLD[2] * 0.8, GOLD[3], 0.9)
end

local function Text(parent, size, r, g, b, flags)
	local fs = parent:CreateFontString(nil, "OVERLAY")
	fs:SetFont(STANDARD_TEXT_FONT, size, flags or "")
	fs:SetTextColor(r or 1, g or 1, b or 1)
	fs:SetJustifyH("LEFT")
	return fs
end

local function Button(parent, label, w, onClick)
	local b = CreateFrame("Button", nil, parent, "BackdropTemplate")
	b:SetSize(w, 22)
	Backdrop(b, 0.95)
	b:SetBackdropColor(0.22, 0.10, 0.34, 1)
	b.text = Text(b, 11, GOLD[1], GOLD[2], GOLD[3])
	b.text:SetPoint("CENTER")
	b.text:SetText(label)
	b:SetScript("OnEnter", function(self) self:SetBackdropColor(0.34, 0.16, 0.52, 1) end)
	b:SetScript("OnLeave", function(self) self:SetBackdropColor(0.22, 0.10, 0.34, 1) end)
	b:SetScript("OnClick", onClick)
	return b
end

local panel, summary

function CA.BuildUI()
	if panel then return end
	local db = CA.db
	panel = CreateFrame("Frame", "CoilAnglerPanel", UIParent, "BackdropTemplate")
	panel:SetSize(270, 248)
	panel:SetFrameStrata("MEDIUM")
	Backdrop(panel)
	panel:SetClampedToScreen(true)
	panel:SetMovable(true)
	panel:EnableMouse(true)
	panel:RegisterForDrag("LeftButton")
	panel:SetScript("OnDragStart", panel.StartMoving)
	panel:SetScript("OnDragStop", function(self)
		self:StopMovingOrSizing()
		local p, _, rp, x, y = self:GetPoint()
		db.point = { p, rp, x, y }
	end)
	if db.point then panel:SetPoint(db.point[1], UIParent, db.point[2], db.point[3], db.point[4])
	else panel:SetPoint("RIGHT", UIParent, "RIGHT", -60, 40) end

	-- Sigil: the violet triangle, drawn with three lines.
	local sig = CreateFrame("Frame", nil, panel)
	sig:SetSize(26, 24)
	sig:SetPoint("TOPLEFT", 10, -9)
	local function line(x1, y1, x2, y2)
		local l = sig:CreateLine(nil, "OVERLAY")
		l:SetThickness(2)
		l:SetColorTexture(VIOLET[1], VIOLET[2], VIOLET[3], 1)
		l:SetStartPoint("TOPLEFT", sig, x1, -y1)
		l:SetEndPoint("TOPLEFT", sig, x2, -y2)
	end
	line(1, 2, 25, 2); line(25, 2, 13, 22); line(13, 22, 1, 2)

	local title = Text(panel, 14, VIOLET[1], VIOLET[2], VIOLET[3], "OUTLINE")
	title:SetPoint("TOPLEFT", 42, -9)
	title:SetText("Coil Angler")
	local sub = Text(panel, 10, 0.75, 0.68, 0.85)
	sub:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -2)
	sub:SetText("Offerings to the Coil")

	local close = CreateFrame("Button", nil, panel, "UIPanelCloseButton")
	close:SetPoint("TOPRIGHT", 2, 2)
	close:SetScript("OnClick", function() CA.HidePanel() end)

	panel.status = Text(panel, 12, 1, 1, 1)
	panel.status:SetPoint("TOPLEFT", 12, -44)
	panel.status:SetWidth(246)

	local bar = CreateFrame("StatusBar", nil, panel, "BackdropTemplate")
	bar:SetSize(246, 12)
	bar:SetPoint("TOPLEFT", 12, -64)
	bar:SetStatusBarTexture("Interface\\Buttons\\WHITE8X8")
	bar:SetStatusBarColor(VIOLET[1], VIOLET[2], VIOLET[3], 0.9)
	bar:SetMinMaxValues(0, 1)
	bar:SetValue(0)
	Backdrop(bar, 0.6)
	bar.label = Text(bar, 9, 1, 1, 1, "OUTLINE")
	bar.label:SetPoint("CENTER")
	panel.bar = bar

	panel.stats = Text(panel, 11, 0.92, 0.88, 1)
	panel.stats:SetPoint("TOPLEFT", 12, -84)
	panel.stats:SetWidth(246)
	panel.stats:SetSpacing(3)

	panel.lastLine = Text(panel, 11, 0.9, 0.9, 0.9)
	panel.lastLine:SetPoint("TOPLEFT", 12, -152)
	panel.lastLine:SetWidth(246)

	panel.board = Text(panel, 10, 0.8, 0.75, 0.9)
	panel.board:SetPoint("TOPLEFT", 12, -172)
	panel.board:SetWidth(246)
	panel.board:SetSpacing(2)

	panel.go = Button(panel, "Begin", 80, function() CA.Toggle() end)
	panel.go:SetPoint("BOTTOMLEFT", 10, 10)
	local recBtn = Button(panel, "Records", 80, function() SlashCmdList.COILANGLER("records") end)
	recBtn:SetPoint("BOTTOM", 0, 10)
	local boardBtn = Button(panel, "Board", 80, function()
		db.showBoard = not db.showBoard
		CA.RequestBoard()
		CA.Refresh()
	end)
	boardBtn:SetPoint("BOTTOMRIGHT", -10, 10)

	panel:SetScript("OnUpdate", function(self, el)
		self.t = (self.t or 0) + el
		if S.fishing and S.castEnd > S.castStart then
			local now = GetTime()
			local frac = (now - S.castStart) / (S.castEnd - S.castStart)
			bar:SetValue(math.max(0, math.min(1, 1 - frac)))
			bar.label:SetText(string.format("%.0fs", math.max(0, S.castEnd - now)))
		elseif bar:GetValue() > 0 then
			bar:SetValue(0); bar.label:SetText("")
		end
		if self.t > 1 then self.t = 0; CA.Refresh() end
	end)

	if db.panelShown then panel:Show() else panel:Hide() end
	CA.Refresh()
end

function CA.UpdateBoard() CA.Refresh() end

function CA.Refresh()
	if not panel or not panel:IsShown() then return end
	local db = CA.db
	local key = "|cffffd100[" .. (db.key or "?") .. "]|r"
	if not S.active then
		panel.status:SetText("Not fishing. Press Begin, or just cast Fishing.")
	elseif S.paused then
		panel.status:SetText("|cffff6060Paused for combat.|r Your key is your own again.")
	elseif S.fishing then
		panel.status:SetText("Line in the water. Press " .. key .. " on the splash.")
	else
		panel.status:SetText("Ready. Press " .. key .. " to cast.")
	end
	panel.go.text:SetText(S.active and "End" or "Begin")

	local t = CA.SessionSeconds()
	local tries = S.catches + S.misses
	local hit = tries > 0 and math.floor((tries - S.misses) / tries * 100 + 0.5) or 0
	panel.stats:SetText(string.format(
		"Time  |cffffffff%s|r     Casts  |cffffffff%d|r\nCatches  |cffffffff%d|r  (%d%% landed)\nOfferings  %s     Per hour  %s\nStreak  |cffffffff%d|r     Best today  |cffffffff%d|r",
		CA.Clock(t), S.casts, S.catches, hit, CA.Gold(S.copper), CA.Gold(CA.GoldPerHour()), S.streak, S.bestStreak))
	panel.lastLine:SetText(S.last and ("Last: " .. S.last) or "")

	if db.showBoard then
		local rows = CA.BoardRows()
		local lines = { "|cffb07cffThe Coil's anglers this week|r" }
		for i = 1, math.min(4, #rows) do
			local r = rows[i]
			lines[#lines + 1] = string.format("%d. %s%s|r  %d", i, r.me and "|cffffd100" or "|cffffffff", r.name, r.wc)
		end
		if #rows == 0 then lines[2] = "No guildmates fishing yet this week." end
		panel.board:SetText(table.concat(lines, "\n"))
	else
		local done = 0
		for _ in pairs(db.ach) do done = done + 1 end
		panel.board:SetText(string.format("|cff888888All time: %s catches · %d/%d achievements|r",
			BreakUpLargeNumbers(db.totals.catches), done, #CA.ACH))
	end
end

function CA.ShowPanel() if panel then panel:Show(); CA.db.panelShown = true; CA.Refresh() end end
function CA.HidePanel() if panel then panel:Hide(); CA.db.panelShown = false end end
function CA.TogglePanel() if panel and panel:IsShown() then CA.HidePanel() else CA.ShowPanel() end end

-- The summary card ----------------------------------------------------------------------------
function CA.ShowSummary(sum)
	if not summary then
		summary = CreateFrame("Frame", "CoilAnglerSummary", UIParent, "BackdropTemplate")
		summary:SetSize(320, 300)
		summary:SetPoint("CENTER", 0, 80)
		summary:SetFrameStrata("DIALOG")
		Backdrop(summary, 0.96)
		summary:EnableMouse(true)
		summary:SetMovable(true)
		summary:RegisterForDrag("LeftButton")
		summary:SetScript("OnDragStart", summary.StartMoving)
		summary:SetScript("OnDragStop", summary.StopMovingOrSizing)
		tinsert(UISpecialFrames, "CoilAnglerSummary")
		local h = Text(summary, 16, GOLD[1], GOLD[2], GOLD[3], "OUTLINE")
		h:SetPoint("TOP", 0, -14)
		h:SetJustifyH("CENTER")
		h:SetText("The Offering Is Counted")
		local sub = Text(summary, 10, 0.75, 0.68, 0.85)
		sub:SetPoint("TOP", h, "BOTTOM", 0, -3)
		sub:SetText("A session at the water, recorded in the Ledger")
		summary.body = Text(summary, 12, 0.95, 0.92, 1)
		summary.body:SetPoint("TOPLEFT", 18, -56)
		summary.body:SetWidth(284)
		summary.body:SetSpacing(4)
		local ok = Button(summary, "Glory to Xal'Reth", 150, function() summary:Hide() end)
		ok:SetPoint("BOTTOM", 0, 14)
	end
	local tries = sum.catches + sum.misses
	local hit = tries > 0 and math.floor((tries - sum.misses) / tries * 100 + 0.5) or 0
	local lines = {
		string.format("Time at the water  |cffffffff%s|r", CA.Clock(sum.seconds)),
		string.format("Casts  |cffffffff%d|r     Catches  |cffffffff%d|r  (%d%%)", sum.casts, sum.catches, hit),
		string.format("Offerings  %s%s", CA.Gold(sum.copper), sum.ah and "" or "  |cff888888(vendor value)|r"),
		string.format("Gold per hour  %s%s", CA.Gold(sum.gph), sum.newGph and "  |cffffd100record!|r" or ""),
		string.format("Longest streak  |cffffffff%d|r", sum.bestStreak or 0),
	}
	if sum.best then lines[#lines + 1] = "Finest catch  " .. sum.best end
	if sum.items and #sum.items > 0 then
		lines[#lines + 1] = " "
		lines[#lines + 1] = "|cffb07cffWhat the water gave|r"
		for i = 1, math.min(5, #sum.items) do
			lines[#lines + 1] = string.format("  %d x %s", sum.items[i].n, sum.items[i].name)
		end
	end
	if sum.misses > 0 then
		lines[#lines + 1] = " "
		lines[#lines + 1] = "|cff888888" .. sum.misses .. " let go. " .. CA.MISS[math.random(#CA.MISS)] .. "|r"
	end
	summary.body:SetText(table.concat(lines, "\n"))
	summary:SetHeight(math.max(220, summary.body:GetStringHeight() + 110))
	summary:Show()
	pcall(PlaySound, 888)
end
