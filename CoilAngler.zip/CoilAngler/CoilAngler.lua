-- Coil Angler: one-key fishing for the faithful of Xal'Reth.
-- Every action still needs a real key press from you. The addon only decides what that key does:
-- cast Fishing while idle, Interact with the bobber while your line is in the water.

local ADDON = ...
local CA = {}
_G.CoilAngler = CA

BINDING_HEADER_COILANGLER = "Coil Angler"
BINDING_NAME_COILANGLER_TOGGLE = "Begin or end a fishing session"
BINDING_NAME_COILANGLER_PANEL = "Show or hide the Coil Angler panel"

CA.VERSION = "1.0.0"
local PREFIX = "COILANGLER"
local FISHING_SPELL = 131474
local FISH_IDS = { [131474] = true, [131476] = true, [131490] = true, [7620] = true }

local function SpellName(id)
	if C_Spell and C_Spell.GetSpellName then
		local ok, n = pcall(C_Spell.GetSpellName, id)
		if ok and n then return n end
	end
	if GetSpellInfo then
		local ok, n = pcall(GetSpellInfo, id)
		if ok and n then return n end
	end
	return "Fishing"
end
local FISH_NAME = SpellName(FISHING_SPELL)

-- Words of the Coil ----------------------------------------------------------
local OFFERING = {
	"The Coil accepts your offering:", "The deep gives, and you hold lightly:", "An offering rises from the low place:",
	"Patience is rewarded:", "Xal'Reth stirs, pleased:", "Water gives what it does not need:",
}
local MISS = {
	"It let go. So should you.", "The water kept that one. Hold light.", "A lesson in releasing. Cast again.",
	"Nhalor took it back. In all things ends renewal.",
}
CA.OFFERING, CA.MISS = OFFERING, MISS

local function pick(t) return t[math.random(#t)] end
local function say(msg) print("|cffb07cffCoil Angler|r: " .. msg) end
CA.Say = say

-- Saved data -----------------------------------------------------------------
local DEFAULTS = {
	key = "F", autoStart = true, boostSound = true, softInteract = true, autoLoot = true,
	idleMinutes = 3, guildShare = true, brag = false, summary = true, bagWarn = 3,
	panelShown = true,
	totals = { casts = 0, catches = 0, misses = 0, copper = 0, seconds = 0, sessions = 0 },
	records = { session = 0, streak = 0, gph = 0, bestLink = nil, bestQuality = -1, bestValue = 0 },
	items = {}, zones = {}, ach = {}, week = { id = 0, catches = 0 }, board = {}, saved = nil,
}

local function fill(dst, src)
	for k, v in pairs(src) do
		if dst[k] == nil then
			if type(v) == "table" then dst[k] = {}; fill(dst[k], v) else dst[k] = v end
		elseif type(v) == "table" and type(dst[k]) == "table" then
			fill(dst[k], v)
		end
	end
end

local function WeekId() return math.floor((time() - 4 * 86400) / (7 * 86400)) end

-- Session state ---------------------------------------------------------------
local S = { active = false, fishing = false, paused = false, start = 0, casts = 0, catches = 0, misses = 0,
	copper = 0, streak = 0, bestStreak = 0, best = nil, bestQ = -1, bestV = 0, last = nil,
	looted = false, lastAction = 0, castStart = 0, castEnd = 0, items = {}, ahPriced = false }
CA.S = S

-- CVars borrowed while a session runs --------------------------------------------
local CVARS = {
	{ "Sound_EnableAllSound", "1", "boostSound" }, { "Sound_EnableSFX", "1", "boostSound" },
	{ "Sound_SFXVolume", "1.0", "boostSound" }, { "Sound_MasterVolume", "1.0", "boostSound" },
	{ "Sound_MusicVolume", "0", "boostSound" }, { "Sound_AmbienceVolume", "0", "boostSound" },
	{ "Sound_DialogVolume", "0.3", "boostSound" },
	{ "SoftTargetInteract", "3", "softInteract" }, { "SoftTargetInteractRange", "30", "softInteract" },
	{ "autoLootDefault", "1", "autoLoot" },
}

local function GetCV(n)
	local ok, v = pcall(C_CVar and C_CVar.GetCVar or GetCVar, n)
	if ok then return v end
end
local function SetCV(n, v) pcall(C_CVar and C_CVar.SetCVar or SetCVar, n, v) end

local function BorrowCVars()
	local db = CA.db
	if db.saved then return end
	db.saved = {}
	for _, c in ipairs(CVARS) do
		if db[c[3]] then
			local old = GetCV(c[1])
			if old ~= nil then db.saved[c[1]] = old; SetCV(c[1], c[2]) end
		end
	end
end

local function RestoreCVars()
	local db = CA.db
	if not db or not db.saved then return end
	for n, v in pairs(db.saved) do SetCV(n, v) end
	db.saved = nil
end

-- The one key -----------------------------------------------------------------
local owner = CreateFrame("Frame", "CoilAnglerBindingOwner", UIParent)
local castBtn = CreateFrame("Button", "CoilAnglerCastButton", UIParent, "SecureActionButtonTemplate")
castBtn:RegisterForClicks("AnyUp", "AnyDown")
castBtn:Hide()
local pendingBind, pendingAttr = false, true

local function SetCastAttributes()
	if InCombatLockdown() then pendingAttr = true; return end
	castBtn:SetAttribute("type", "spell")
	castBtn:SetAttribute("spell", FISH_NAME)
	pendingAttr = false
end

function CA.ApplyBinding()
	if InCombatLockdown() then pendingBind = true; return end
	pendingBind = false
	ClearOverrideBindings(owner)
	if not S.active or S.paused then return end
	local key = CA.db.key
	if not key or key == "" then return end
	if S.fishing then
		SetOverrideBinding(owner, true, key, "INTERACTTARGET")
	else
		SetOverrideBindingClick(owner, true, key, "CoilAnglerCastButton", "LeftButton")
	end
end

-- Values ------------------------------------------------------------------------
local function ItemInfo(link)
	local f = (C_Item and C_Item.GetItemInfo) or GetItemInfo
	if not f then return end
	local ok, name, _, quality, _, _, _, _, _, _, _, sell = pcall(f, link)
	if ok then return name, quality, sell end
end

function CA.ItemValue(link, qty)
	qty = qty or 1
	local v
	if Auctionator and Auctionator.API and Auctionator.API.v1 and Auctionator.API.v1.GetAuctionPriceByItemLink then
		local ok, p = pcall(Auctionator.API.v1.GetAuctionPriceByItemLink, "CoilAngler", link)
		if ok and type(p) == "number" and p > 0 then v = p end
	end
	if not v and TSM_API and TSM_API.ToItemString and TSM_API.GetCustomPriceValue then
		local ok, s = pcall(TSM_API.ToItemString, link)
		if ok and s then
			local ok2, p = pcall(TSM_API.GetCustomPriceValue, "dbmarket", s)
			if ok2 and type(p) == "number" and p > 0 then v = p end
		end
	end
	if v then S.ahPriced = true; return v * qty end
	local _, _, sell = ItemInfo(link)
	return (sell or 0) * qty
end

function CA.Gold(copper)
	local g = math.floor((copper or 0) / 10000)
	local s = BreakUpLargeNumbers and BreakUpLargeNumbers(g) or tostring(g)
	return s .. "|cffffd100g|r"
end

function CA.Clock(sec)
	sec = math.floor(sec or 0)
	local h, m, s = math.floor(sec / 3600), math.floor(sec % 3600 / 60), sec % 60
	if h > 0 then return string.format("%d:%02d:%02d", h, m, s) end
	return string.format("%d:%02d", m, s)
end

function CA.SessionSeconds() return S.active and (GetTime() - S.start) or 0 end

function CA.GoldPerHour()
	local t = CA.SessionSeconds()
	if t < 60 then return 0 end
	return S.copper / t * 3600
end

-- Bags --------------------------------------------------------------------------
local function FreeSlots()
	local free = 0
	local getFree = (C_Container and C_Container.GetContainerNumFreeSlots) or GetContainerNumFreeSlots
	if not getFree then return 99 end
	for bag = 0, 4 do
		local ok, n, family = pcall(getFree, bag)
		if ok and n and (family == 0 or family == nil) then free = free + n end
	end
	return free
end

local warnedBags = 0
local function CheckBags()
	local free = FreeSlots()
	if free <= (CA.db.bagWarn or 3) and GetTime() - warnedBags > 60 then
		warnedBags = GetTime()
		local msg = free == 0 and "Your bags are full. The Coil cannot accept offerings into nothing."
			or ("Only " .. free .. " bag slot" .. (free == 1 and "" or "s") .. " left. Make room, faithful.")
		if RaidNotice_AddMessage and RaidWarningFrame then
			RaidNotice_AddMessage(RaidWarningFrame, "|cffb07cff" .. msg .. "|r", ChatTypeInfo["RAID_WARNING"])
		end
		say(msg)
		pcall(PlaySound, 8959) -- raid warning
	end
end

-- Achievements --------------------------------------------------------------------
local function count(t) local n = 0; for _ in pairs(t) do n = n + 1 end; return n end
CA.ACH = {
	{ id = "first", name = "First Offering", desc = "Land your first catch.", test = function(d) return d.totals.catches >= 1 end },
	{ id = "c100", name = "A Hundred Scales", desc = "Catch 100 fish.", test = function(d) return d.totals.catches >= 100 end },
	{ id = "c1000", name = "The Patient Coil", desc = "Catch 1,000 fish.", test = function(d) return d.totals.catches >= 1000 end },
	{ id = "c5000", name = "Wrapped Three Times", desc = "Catch 5,000 fish.", test = function(d) return d.totals.catches >= 5000 end },
	{ id = "s100", name = "The Long Bask", desc = "Catch 100 fish in one session.", test = function(d) return d.records.session >= 100 end },
	{ id = "streak25", name = "Unbroken Coil", desc = "Catch 25 in a row without losing one.", test = function(d) return d.records.streak >= 25 end },
	{ id = "rare", name = "Something Glittered", desc = "Catch something of rare quality or better.", test = function(d) return (d.records.bestQuality or -1) >= 3 end },
	{ id = "epic", name = "The Deep Gave Freely", desc = "Catch something of epic quality or better.", test = function(d) return (d.records.bestQuality or -1) >= 4 end },
	{ id = "zones5", name = "Many Waters", desc = "Fish in 5 different zones.", test = function(d) return count(d.zones) >= 5 end },
	{ id = "zones15", name = "Every Water Is the Same Water", desc = "Fish in 15 different zones.", test = function(d) return count(d.zones) >= 15 end },
	{ id = "g1000", name = "Tithe of the Deep", desc = "Catch 1,000 gold worth of offerings.", test = function(d) return d.totals.copper >= 1000 * 10000 end },
	{ id = "g10000", name = "The Ministry Takes Notice", desc = "Catch 10,000 gold worth of offerings.", test = function(d) return d.totals.copper >= 10000 * 10000 end },
	{ id = "hour", name = "Hold Light for an Hour", desc = "Fish for one hour in a single session.", test = function(d) return CA.SessionSeconds() >= 3600 end },
}

local function CheckAchievements()
	local db = CA.db
	for _, a in ipairs(CA.ACH) do
		if not db.ach[a.id] then
			local ok, done = pcall(a.test, db)
			if ok and done then
				db.ach[a.id] = time()
				local msg = "Achievement: " .. a.name .. ". " .. a.desc
				if RaidNotice_AddMessage and RaidWarningFrame then
					RaidNotice_AddMessage(RaidWarningFrame, "|cffffd100" .. a.name .. "|r", ChatTypeInfo["RAID_WARNING"])
				end
				say("|cffffd100" .. msg .. "|r Glory to Xal'Reth.")
				pcall(PlaySound, 12891)
			end
		end
	end
end
CA.CheckAchievements = CheckAchievements

-- Guild leaderboard ------------------------------------------------------------------
local lastShare = 0
local function Me()
	local n, r = UnitFullName("player")
	return n and (r and r ~= "" and (n .. "-" .. r) or n) or "?"
end

function CA.Share(force)
	local db = CA.db
	if not db.guildShare or not IsInGuild() then return end
	if not force and GetTime() - lastShare < 60 then return end
	lastShare = GetTime()
	local msg = string.format("S:1:%d:%d:%d", db.week.id, db.week.catches, db.totals.catches)
	pcall(C_ChatInfo.SendAddonMessage, PREFIX, msg, "GUILD")
end

function CA.RequestBoard()
	if not IsInGuild() then return end
	pcall(C_ChatInfo.SendAddonMessage, PREFIX, "R:1", "GUILD")
end

local function OnAddonMessage(prefix, msg, channel, sender)
	if prefix ~= PREFIX or type(msg) ~= "string" then return end
	local db = CA.db
	if msg:sub(1, 2) == "R:" then
		if sender ~= Me() then CA.Share(true) end
		return
	end
	local w, wc, total = msg:match("^S:1:(%d+):(%d+):(%d+)")
	if not w then return end
	db.board[sender] = { week = tonumber(w), wc = tonumber(wc), total = tonumber(total), seen = time() }
	if CA.UpdateBoard then CA.UpdateBoard() end
end

function CA.BoardRows()
	local db, wid, rows = CA.db, WeekId(), {}
	local me = Me()
	db.board[me] = { week = db.week.id, wc = db.week.catches, total = db.totals.catches, seen = time() }
	for name, e in pairs(db.board) do
		if e.week == wid and (e.wc or 0) > 0 then rows[#rows + 1] = { name = name:gsub("%-.*", ""), wc = e.wc, total = e.total, me = name == me } end
	end
	table.sort(rows, function(a, b) return a.wc > b.wc end)
	return rows
end

-- Catches --------------------------------------------------------------------------------
local lootHandled = 0
local function RecordLoot()
	if not (IsFishingLoot and IsFishingLoot()) then return end
	if GetTime() - lootHandled < 1 then return end
	lootHandled = GetTime()
	if not S.active then return end
	local db = CA.db
	local got = false
	for i = 1, GetNumLootItems() do
		local link = GetLootSlotLink(i)
		if link then
			local _, name, qty, _, quality = GetLootSlotInfo(i)
			qty = qty or 1
			local value = CA.ItemValue(link, qty)
			local iname, iq = ItemInfo(link)
			quality = quality or iq or 1
			name = iname or name or link
			got = true
			S.catches = S.catches + qty
			S.copper = S.copper + value
			db.totals.catches = db.totals.catches + qty
			db.totals.copper = db.totals.copper + value
			if db.week.id ~= WeekId() then db.week = { id = WeekId(), catches = 0 } end
			db.week.catches = db.week.catches + qty
			S.items[name] = (S.items[name] or 0) + qty
			db.items[name] = (db.items[name] or 0) + qty
			S.last = link
			if quality > S.bestQ or (quality == S.bestQ and value > S.bestV) then S.best, S.bestQ, S.bestV = link, quality, value end
			local r = db.records
			if quality > (r.bestQuality or -1) or (quality == r.bestQuality and value > (r.bestValue or 0)) then
				if r.bestLink then say("New personal record, the rarest offering yet: " .. link) end
				r.bestLink, r.bestQuality, r.bestValue = link, quality, value
			end
			say(pick(OFFERING) .. " " .. link .. (qty > 1 and (" x" .. qty) or "") .. (value > 0 and ("  (" .. CA.Gold(value) .. ")") or ""))
			if db.brag and quality >= 3 and IsInGuild() then
				pcall(SendChatMessage, "The Coil has accepted a rare offering: " .. link .. " Glory to Xal'Reth.", "GUILD")
			end
		end
	end
	if got then
		S.looted = true
		S.streak = S.streak + 1
		if S.streak > S.bestStreak then S.bestStreak = S.streak end
		local r = db.records
		if S.streak > (r.streak or 0) then
			if r.streak and r.streak >= 10 and S.streak == r.streak + 1 then say("New record streak! " .. S.streak .. " in a row.") end
			r.streak = S.streak
		end
		if S.catches > (r.session or 0) then r.session = S.catches end
		CheckAchievements()
		CA.Share()
		if CA.Refresh then CA.Refresh() end
	end
end

-- Sessions ----------------------------------------------------------------------------------
function CA.Start(auto)
	if S.active then return end
	if InCombatLockdown() then say("Not in combat. Even the Coil rests between battles."); return end
	wipe(S.items)
	S.active, S.paused, S.fishing = true, false, false
	S.start, S.lastAction = GetTime(), GetTime()
	S.casts, S.catches, S.misses, S.copper, S.streak, S.bestStreak = 0, 0, 0, 0, 0, 0
	S.best, S.bestQ, S.bestV, S.last, S.ahPriced = nil, -1, 0, nil, false
	BorrowCVars()
	CA.ApplyBinding()
	local zone = GetRealZoneText and GetRealZoneText()
	if zone and zone ~= "" then CA.db.zones[zone] = true end
	if CA.db.week.id ~= WeekId() then CA.db.week = { id = WeekId(), catches = 0 } end
	say("Session begun. Press |cffffd100" .. (CA.db.key or "?") .. "|r to cast, and again on the splash. Hold light.")
	CheckBags()
	if CA.ShowPanel then CA.ShowPanel() end
	if CA.Refresh then CA.Refresh() end
end

function CA.Stop(reason, quiet)
	if not S.active then return end
	local secs = CA.SessionSeconds()
	CheckAchievements()
	S.active, S.fishing = false, false
	if not InCombatLockdown() then ClearOverrideBindings(owner) else pendingBind = true end
	RestoreCVars()
	local db = CA.db
	db.totals.casts = db.totals.casts + S.casts
	db.totals.misses = db.totals.misses + S.misses
	db.totals.seconds = db.totals.seconds + secs
	db.totals.sessions = db.totals.sessions + 1
	local gph = secs >= 600 and (S.copper / secs * 3600) or 0
	local newGph = gph > (db.records.gph or 0)
	if newGph then db.records.gph = gph end
	CheckAchievements()
	CA.Share(true)
	local sum = {
		reason = reason, seconds = secs, casts = S.casts, catches = S.catches, misses = S.misses, copper = S.copper,
		gph = secs >= 60 and (S.copper / secs * 3600) or 0, best = S.best, bestStreak = S.bestStreak, newGph = newGph,
		items = {}, ah = S.ahPriced,
	}
	for name, n in pairs(S.items) do sum.items[#sum.items + 1] = { name = name, n = n } end
	table.sort(sum.items, function(a, b) return a.n > b.n end)
	db.lastSummary = sum
	if CA.Refresh then CA.Refresh() end
	if quiet then return end
	local why = reason == "combat" and " (combat)" or reason == "idle" and " (you wandered off)" or reason == "mount" and " (you mounted up)" or ""
	say("Session ended" .. why .. ". Your sound and settings are back to normal.")
	if db.summary and S.casts > 0 and CA.ShowSummary then CA.ShowSummary(sum) end
end

function CA.Toggle() if S.active then CA.Stop("manual") else CA.Start(false) end end

-- Events ------------------------------------------------------------------------------------
local function IsFishingChannel()
	local name, _, _, startMS, endMS, _, _, spellID = UnitChannelInfo("player")
	if not name then return false end
	local ok, isFish = pcall(function() return name == FISH_NAME or FISH_IDS[spellID] end)
	if ok and isFish then return true, startMS, endMS end
	return false
end

local ev = CreateFrame("Frame")
ev:RegisterEvent("PLAYER_LOGIN")
ev:RegisterEvent("PLAYER_LOGOUT")
ev:RegisterEvent("PLAYER_REGEN_DISABLED")
ev:RegisterEvent("PLAYER_REGEN_ENABLED")
ev:RegisterEvent("LOOT_READY")
ev:RegisterEvent("CHAT_MSG_ADDON")
ev:RegisterEvent("ZONE_CHANGED_NEW_AREA")
ev:RegisterEvent("PLAYER_MOUNT_DISPLAY_CHANGED")
ev:RegisterUnitEvent("UNIT_SPELLCAST_CHANNEL_START", "player")
ev:RegisterUnitEvent("UNIT_SPELLCAST_CHANNEL_STOP", "player")

ev:SetScript("OnEvent", function(_, e, ...)
	if e == "PLAYER_LOGIN" then
		CoilAnglerDB = CoilAnglerDB or {}
		fill(CoilAnglerDB, DEFAULTS)
		CA.db = CoilAnglerDB
		RestoreCVars() -- a session left open by a crash or disconnect gives your settings back
		if CA.db.week.id ~= WeekId() then CA.db.week = { id = WeekId(), catches = 0 } end
		SetCastAttributes()
		pcall(C_ChatInfo.RegisterAddonMessagePrefix, PREFIX)
		if CA.BuildUI then CA.BuildUI() end
		C_Timer.After(12, function() CA.Share(true); CA.RequestBoard() end)
		C_Timer.NewTicker(5, function()
			if S.active and not S.fishing and not S.paused then
				local idle = (CA.db.idleMinutes or 3) * 60
				if idle > 0 and GetTime() - S.lastAction > idle then CA.Stop("idle") end
			end
		end)
	elseif e == "PLAYER_LOGOUT" then
		if S.active then CA.Stop("logout", true) end
		RestoreCVars()
	elseif e == "PLAYER_REGEN_DISABLED" then
		-- Fires just before combat lockdown, so the key can still be handed back.
		if S.active then
			S.paused = true
			ClearOverrideBindings(owner)
			if CA.Refresh then CA.Refresh() end
		end
	elseif e == "PLAYER_REGEN_ENABLED" then
		if pendingAttr then SetCastAttributes() end
		if S.active then S.paused = false; S.lastAction = GetTime() end
		if S.active or pendingBind then CA.ApplyBinding() end
		if CA.Refresh then CA.Refresh() end
	elseif e == "UNIT_SPELLCAST_CHANNEL_START" then
		local fishing, startMS, endMS = IsFishingChannel()
		if not fishing then return end
		if not S.active then
			if CA.db and CA.db.autoStart and not InCombatLockdown() then CA.Start(true) else return end
		end
		S.fishing, S.looted = true, false
		S.casts = S.casts + 1
		S.lastAction = GetTime()
		S.castStart = (startMS or GetTime() * 1000) / 1000
		S.castEnd = (endMS or (GetTime() + 20) * 1000) / 1000
		local zone = GetRealZoneText and GetRealZoneText()
		if zone and zone ~= "" then CA.db.zones[zone] = true end
		CA.ApplyBinding()
		CheckBags()
		if CA.Refresh then CA.Refresh() end
	elseif e == "UNIT_SPELLCAST_CHANNEL_STOP" then
		if not S.fishing then return end
		S.fishing = false
		S.lastAction = GetTime()
		CA.ApplyBinding()
		C_Timer.After(1.2, function()
			if S.active and not S.looted then
				S.misses = S.misses + 1
				S.streak = 0
				if CA.Refresh then CA.Refresh() end
			end
		end)
		if CA.Refresh then CA.Refresh() end
	elseif e == "LOOT_READY" then
		RecordLoot()
	elseif e == "CHAT_MSG_ADDON" then
		OnAddonMessage(...)
	elseif e == "ZONE_CHANGED_NEW_AREA" then
		if S.active then
			local zone = GetRealZoneText and GetRealZoneText()
			if zone and zone ~= "" then CA.db.zones[zone] = true end
		end
	elseif e == "PLAYER_MOUNT_DISPLAY_CHANGED" then
		if S.active and not S.fishing and IsMounted and IsMounted() then CA.Stop("mount") end
	end
end)

-- Slash commands ----------------------------------------------------------------------------------
local function onoff(v)
	if v == "on" then return true elseif v == "off" then return false end
end

local HELP = {
	"/angler  show or hide the panel",
	"/angler start | stop  begin or end a session (casting Fishing also begins one)",
	"/angler key F  choose your one key (now: %s)",
	"/angler sound on|off  loud splash mode: SFX up, music and ambience off",
	"/angler soft on|off  let the key reach the bobber (soft interact)",
	"/angler autoloot on|off  turn on auto loot while fishing",
	"/angler idle 3  end the session after N idle minutes (0 = never)",
	"/angler share on|off  share your catch count with the guild board",
	"/angler brag on|off  announce rare catches in guild chat",
	"/angler summary on|off  show the summary card when a session ends",
	"/angler records | ach | board | last",
}

SLASH_COILANGLER1, SLASH_COILANGLER2 = "/angler", "/coilangler"
SlashCmdList.COILANGLER = function(input)
	local db = CA.db
	if not db then return end
	local cmd, arg = (input or ""):match("^%s*(%S*)%s*(.-)%s*$")
	cmd = (cmd or ""):lower()
	local larg = (arg or ""):lower()
	if cmd == "" then
		if CA.TogglePanel then CA.TogglePanel() end
	elseif cmd == "start" then CA.Start(false)
	elseif cmd == "stop" or cmd == "end" then CA.Stop("manual")
	elseif cmd == "key" then
		if InCombatLockdown() then say("Change your key after combat."); return end
		if arg == "" then say("Your one key is |cffffd100" .. (db.key or "none") .. "|r. Try /angler key F"); return end
		db.key = arg:upper()
		say("Your one key is now |cffffd100" .. db.key .. "|r. It only changes while a session is running.")
		CA.ApplyBinding()
	elseif cmd == "sound" or cmd == "soft" or cmd == "autoloot" or cmd == "share" or cmd == "brag" or cmd == "summary" then
		local field = ({ sound = "boostSound", soft = "softInteract", autoloot = "autoLoot", share = "guildShare", brag = "brag", summary = "summary" })[cmd]
		local v = onoff(larg)
		if v == nil then v = not db[field] end
		db[field] = v
		say(cmd .. " is now " .. (v and "|cff40ff40on|r" or "|cffff4040off|r") .. ((cmd == "sound" or cmd == "soft" or cmd == "autoloot") and S.active and ". Takes effect next session." or "."))
	elseif cmd == "idle" then
		local n = tonumber(arg)
		if n and n >= 0 and n <= 120 then db.idleMinutes = n; say("Sessions end after " .. (n == 0 and "never" or (n .. " idle minute" .. (n == 1 and "" or "s"))) .. ".")
		else say("Usage: /angler idle 3") end
	elseif cmd == "records" then
		local r, t = db.records, db.totals
		say(string.format("All time: %s catches over %s sessions, %s fishing, %s in offerings.",
			BreakUpLargeNumbers(t.catches), t.sessions, CA.Clock(t.seconds), CA.Gold(t.copper)))
		say("Most in one session: " .. (r.session or 0) .. ". Longest streak: " .. (r.streak or 0) .. ". Best gold per hour: " .. CA.Gold(r.gph or 0) .. ".")
		if r.bestLink then say("Rarest offering: " .. r.bestLink) end
	elseif cmd == "ach" then
		local n = 0
		for _, a in ipairs(CA.ACH) do
			local done = db.ach[a.id]
			if done then n = n + 1 end
			print((done and "|cffffd100" or "|cff888888") .. a.name .. "|r  " .. a.desc)
		end
		say(n .. " of " .. #CA.ACH .. " achievements.")
	elseif cmd == "board" then
		CA.RequestBoard()
		local rows = CA.BoardRows()
		say("The Coil's anglers this week:")
		for i = 1, math.min(10, #rows) do print(string.format("  %d. %s  %d", i, rows[i].name, rows[i].wc)) end
	elseif cmd == "last" then
		if db.lastSummary and CA.ShowSummary then CA.ShowSummary(db.lastSummary) else say("No session yet. Cast a line.") end
	else
		say("Commands:")
		for _, l in ipairs(HELP) do print("  " .. l:format(db.key or "none")) end
	end
end
